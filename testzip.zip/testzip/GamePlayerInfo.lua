local GameLogic = require "642.GameLogic"
local GamePlayerInfo =
{
}

function GamePlayerInfo:new(trans)
	local _instance = 
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self 
	setmetatable(_instance, self)
	return _instance
end
function GamePlayerInfo:InitUI()
    self.LbPlayerName = FindChildByName(self.transform, "Label_Name", "UILabel")
    self.LbPlayerMoney = FindChildByName(self.transform, "Label_Money", "UILabel")
    self.LbContent = FindChildByName(self.transform, "Label_Content", "UILabel")
    self.LbData = FindChildByName(self.transform, "Label_Time", "UILabel")
    self.IconHead = FindChildByName(self.transform, "IconHead_Box/Icon_Head", "UISprite")
    --***玩家列表****--
    self.LbPlayerListItemName = FindChildByName(self.transform, "IconHeadBox/LbName", "UILabel")
    self.LbPlayerListItemMoeny = FindChildByName(self.transform, "IconHeadBox/LbMoney", "UILabel")
    self.LbPlayerListItemVip = FindChildByName(self.transform, "IconHeadBox/LbVip", "UILabel")
    self.IconPlayerListItemHead = FindChildByName(self.transform, "IconHeadBox/ImHead", "UISprite")
    self.GoPlayerListItemSSZ = FindChildByName(self.transform, "IconHeadBox/Icon_Sign_Target1", "gameObject")
    self.IconPlayerListItemDFH = FindChildByName(self.transform, "IconHeadBox/Icon_Sign_Target2", "gameObject")
    self.IconPlayerListItemFH = FindChildByName(self.transform, "IconHeadBox/Icon_Sign_Target3", "gameObject")
    self.LbPlayerListItemRank = FindChildByName(self.transform, "IconHeadBox/Label_Rank", "UILabel")
end
--function GamePlayerInfo:SetInfo1(name, money)
--    self.LbPlayerName.text = name
--    self.LbPlayerMoney.text = money.ToString()
--end
function GamePlayerInfo:SetInfo2(jiangChiInfo)--奖池
    --GamePlayerInfo:UpdateHead(jiangChiInfo[4])
    local HeadName = GetHeadSpriteName(jiangChiInfo[4])
	self.IconHead.spriteName = HeadName
    self.LbData.text = jiangChiInfo[3]
    print("jiangChiInfo",jiangChiInfo[1])
    local moneys = MoneyProportionStr(jiangChiInfo[1])
    self.LbContent.text = "玩家"..jiangChiInfo[2].."获得[ffec19] "..moneys.."金币[-]"
end
function GamePlayerInfo:SetInfo3(poolPrizeInfo)--奖池
    --GamePlayerInfo:UpdateHead(poolPrizeInfo[3])
    local HeadName = GetHeadSpriteName(poolPrizeInfo[3])
	self.IconHead.spriteName = HeadName
    self.LbPlayerName.text = poolPrizeInfo[1]
    self.LbPlayerMoney.text = MoneyProportionStr(poolPrizeInfo[2])
end
function GamePlayerInfo:SetInfo4(userIfo,Rankindex,isLucy)--玩家列表
    --GamePlayerInfo:UpdateHead(poolPrizeInfo[3])
    self.LbPlayerListItemName.text = userIfo[4]
    self.LbPlayerListItemMoeny.text = MoneyProportionStr(userIfo[5])
    self.LbPlayerListItemVip.text = tostring(userIfo[7])
    self.IconPlayerListItemHead.spriteName = GetHeadSpriteName(userIfo[2])
    if isLucy then
        if Rankindex == 1 then
            self.GoPlayerListItemSSZ:SetActive(true)
            self.IconPlayerListItemDFH:SetActive(false)
            self.IconPlayerListItemFH:SetActive(false)
            self.LbPlayerListItemRank.gameObject:SetActive(false)
        elseif Rankindex == 2 then
            self.GoPlayerListItemSSZ:SetActive(false)
            self.IconPlayerListItemDFH:SetActive(true)
            self.IconPlayerListItemFH:SetActive(false)
            self.LbPlayerListItemRank.gameObject:SetActive(false)
        elseif Rankindex <= 6 then
            self.GoPlayerListItemSSZ:SetActive(false)
            self.IconPlayerListItemDFH:SetActive(false)
            self.IconPlayerListItemFH:SetActive(true)
            self.LbPlayerListItemRank.gameObject:SetActive(false)
        elseif Rankindex > 6 then
            self.GoPlayerListItemSSZ:SetActive(false)
            self.IconPlayerListItemDFH:SetActive(false)
            self.IconPlayerListItemFH:SetActive(false)
            self.LbPlayerListItemRank.gameObject:SetActive(true)
            self.LbPlayerListItemRank.text = tostring(Rankindex-1)
        end
    else
        self.GoPlayerListItemSSZ:SetActive(false)
        if Rankindex == 1 then
            self.IconPlayerListItemDFH:SetActive(true)
            self.IconPlayerListItemFH:SetActive(false)
            self.LbPlayerListItemRank.gameObject:SetActive(false)
        elseif Rankindex <= 5 then
            self.IconPlayerListItemDFH:SetActive(false)
            self.IconPlayerListItemFH:SetActive(true)
            self.LbPlayerListItemRank.gameObject:SetActive(false)
        elseif Rankindex > 5 then
            self.IconPlayerListItemDFH:SetActive(false)
            self.IconPlayerListItemFH:SetActive(false)
            self.LbPlayerListItemRank.gameObject:SetActive(true)
            self.LbPlayerListItemRank.text = tostring(Rankindex)
        end
    end
end

function GamePlayerInfo:UpdateHead(headId, borderId)
	if self.ImHeadBorder ~= nil then
	    local HeadBorderName = GetHeadBorderById(borderId)
		self.ImHeadBorder.spriteName = HeadBorderName
		--self.ImHeadBorder:MakePixelPerfect()
	end
    local HeadName = GetHeadSpriteName(headId)
	self.IconHead.spriteName = HeadName
	--self.IconHead:MakePixelPerfect()
end
return GamePlayerInfo