local GameTimeClock = 
{
	LbClockTime,
	IconState,
	ClockTime,
	coroutineParent,
	ationFunc,
}

function GameTimeClock.Awake()
	GameTimeClock.LbClockTime = FindChildByName(GameTimeClock.transform, "LbTime", "UILabel")
	GameTimeClock.IconState = FindChildByName(GameTimeClock.transform, "Font_Tips", "UISprite")
end

function GameTimeClock.StartClock(func,itime,state)
	GameTimeClock.transform.gameObject:SetActive(true)
	if GameTimeClock.coroutineParent ~= nil then
		coroutine.stop(GameTimeClock.coroutineParent)
		GameTimeClock.coroutineParent = nil
	end
	if state == 1 then
		GameTimeClock.IconState.spriteName = "Txt_XZZ"
	elseif state == 2 then
		GameTimeClock.IconState.spriteName = "Txt_KJZ"
	else
		GameTimeClock.IconState.spriteName = ""
	end
	GameTimeClock.ationFunc = func
	GameTimeClock.ClockTime = itime
	GameTimeClock.coroutineParent = coroutine.start(GameTimeClock.ReduceTime)
end

function GameTimeClock.StopClock()
	if GameTimeClock.coroutineParent ~= nil then
		coroutine.stop(GameTimeClock.coroutineParent)
		GameTimeClock.coroutineParent = nil
	end
	GameTimeClock.transform.gameObject:SetActive(false)
end

function GameTimeClock.ReduceTime()
	if(GameTimeClock.ClockTime < 10) then
		GameTimeClock.LbClockTime.text = "0"..tostring(GameTimeClock.ClockTime)
	else
		GameTimeClock.LbClockTime.text = tostring(GameTimeClock.ClockTime)
	end
	if(GameTimeClock.ClockTime <= 0)then
		if(GameTimeClock.ationFunc~=nil) then
			GameTimeClock.ationFunc()
			GameTimeClock.ationFunc = nil
		end
		GameTimeClock.StopClock()
	else
		coroutine.wait(1)
		GameTimeClock.ClockTime = GameTimeClock.ClockTime-1
		GameTimeClock.coroutineParent = coroutine.start(GameTimeClock.ReduceTime)
	end

end
function GameTimeClock.OnDestroy()
	GameTimeClock.ationFunc = nil
	if GameTimeClock.coroutineParent ~= nil then
		coroutine.stop(GameTimeClock.coroutineParent)
		GameTimeClock.coroutineParent = nil
	end
end
return GameTimeClock