local GameProtocal =GameDefine.LoadGameLuaFile("GameProtocal")
local ChoumaManager = class("ChoumaManager")

function ChoumaManager:InitManager()
	self.gameView = GameUIManager

	local gameTran = self.gameView.transform:Find("UI_LHD/UIStretch/Group/Game_Group")

	--筹码预制体
	self.ChoumaPrefabGroup = {}
	for i=1,GameProtocal.CM_NUM do
        self.ChoumaPrefabGroup[i] = {
        	_choumaObj = gameTran:Find("CMParent/CM" .. i).gameObject,
        	_amountLabel = gameTran:Find("CMParent/CM" .. i .. "/Pos/Font_Num"):GetComponent("UILabel")
    	}
    end
    
    --筹码父级区域
    self.ChoumaParentGroup = {}
	for i = 1, GameProtocal.AREA_COUNT do
        self.ChoumaParentGroup[i] = gameTran:Find("Btn_Group/CM_Group/Button_CM"..(i-1).."/ChoumaGroup")
    end

    --对象池节点
    self.ChoumaObjectRoot = gameTran:Find("ChoumaObjectPoolRoot")
    --每个玩家对应的筹码集合点
    self.PlayerChoumaRoot = 
    {
    	_self = gameTran:Find("Playeritems/0/ChoumaRoot"),
    	_otherPlayer = gameTran:Find("BtnOnLine/ChoumaRoot"),
		_banker = gameTran:Find("CardTeam/ChoumaRoot"),
    	_seatPlayer = {}
	}
	for i=1,GameProtocal.DESK_PALYER_COUNT do
		if(i>=2 and i<=4) then
			self.PlayerChoumaRoot._seatPlayer[i] = gameTran:Find("Playeritems/Left/" .. i .. "/ChoumaRoot")
		else
			self.PlayerChoumaRoot._seatPlayer[i] = gameTran:Find("Playeritems/Right/" .. i .. "/ChoumaRoot")
		end        
	end

	self:InitData()
    self:InitChoumaDepth()
end

--初始化筹码数据
function ChoumaManager:InitData()
	--筹码对象池
    self.mChoumaObjectPool = {}
    for i=1,GameProtocal.CM_NUM  do
    	--分别装各种筹码
    	self.mChoumaObjectPool[i] = {}
    end
	
	self.mTablePlayerBetChouma={} --初始化占座玩家各个区域下注的筹码
	self.mMyBetChouma={} --玩家各个区域下注的筹码
	self.mOtherPlayerBetChouma={} --其它玩家各个区域下注的筹码	
	for i = 1, GameProtocal.DESK_PALYER_COUNT do
		self.mTablePlayerBetChouma[i]={}
	end
	for i = 1, GameProtocal.AREA_COUNT do
		self.mMyBetChouma[i]={}
		self.mOtherPlayerBetChouma[i]={}
		for j = 1, GameProtocal.DESK_PALYER_COUNT do
			self.mTablePlayerBetChouma[j][i]={}
		end
	end

	self.mTablePlayerWinChouma={} --初始化占座玩家各个区域赢得的筹码
	self.mMyWinChouma={} --  初始化玩家各个区域赢得的筹码
	self.mOtherPlayerWinChouma={} --其它玩家各个区域赢得的筹码	
	for i = 1, GameProtocal.DESK_PALYER_COUNT do
		self.mTablePlayerWinChouma[i]={}
	end	
	for i = 1, GameProtocal.AREA_COUNT do
		self.mMyWinChouma[i]={}
		self.mOtherPlayerWinChouma[i]={}
		for j = 1, GameProtocal.DESK_PALYER_COUNT do
			self.mTablePlayerWinChouma[j][i]={}
		end
	end	

    --需要移动的筹码集合
    self.mNeedMoveChoumaList = {}
	--记录需要移动的筹码ID
	self.mMoveChoumaID=0
    --玩家自己的椅子号
	self.mMeChairdID = self.gameView:GetMeChairID()
	--算出筹码移动的最长的时间
	self.mMaxMoveTime = 0
	self.mIsStartRecover=false --是否处理开始回收
end


function ChoumaManager:Update()
	--print("update 1111111111111111")
	if(self.mIsStartRecover) then
		for id, item in pairs(self.mNeedMoveChoumaList) do
			item.CurrentTime=item.CurrentTime+Time.deltaTime
			-- print("  CurrentTime:",item.CurrentTime,"  MoveTime:",item.MoveTime,"  IsRecover:",item.IsRecover)
			--判断是否需要回收
			if(item.CurrentTime>item.MoveTime and item.IsRecover) then
				--print("回收筹码  ID:",item.ID)
				self:PutChoumaForPool(item.ChouMa)
				self.mNeedMoveChoumaList[id]=nil
				if(table.nums(self.mNeedMoveChoumaList)<=0) then
					self.mIsStartRecover=false
				end
			end
		end
	end	
end

--初始化筹码的深度
function ChoumaManager:InitChoumaDepth()
	self.CurrentChipDepth={}
	for i = 1, GameProtocal.AREA_COUNT do
		self.CurrentChipDepth[i]=20
		-- body
	end
end

--回收一个对象
function ChoumaManager:PutChoumaForPool(choumaObj)
	--choumaObj.gameObject:SetActive(false)
	choumaObj.transform:SetParent(self.ChoumaObjectRoot)

	local choumaIndex = split(choumaObj.gameObject.name,"_")[2]
	--local choumaIndex = (string.gsub(choumaObj.gameObject.name, "Chouma", ""))
	choumaIndex = tonumber(choumaIndex)
	table.insert(self.mChoumaObjectPool[choumaIndex], choumaObj)
end

--使用一个对象
function ChoumaManager:GetChoumaForPool(tagStr,choumaIndex,areaIndex)
	local newChouma = nil
	--debugLog("使用一个对象   choumaIndex",choumaIndex,"  缓存数量:",#self.mChoumaObjectPool[choumaIndex])
	if #self.mChoumaObjectPool[choumaIndex] > 0 then
		newChouma = table.remove(self.mChoumaObjectPool[choumaIndex])
	else
		--对象池对象不足则创建一个对象
		local obj = newObject(self.ChoumaPrefabGroup[choumaIndex]._choumaObj)
		obj.name = "Chouma_" .. choumaIndex
		obj.transform.localEulerAngles = UnityEngine.Vector3.New(0, 0, math.random(-90, 90))
		newChouma={
			gameObject=obj,
			transform=obj.transform,
			tweenPos=obj.transform:GetComponent("TweenPosition"),
			-- tweenScale=obj.transform:GetComponent("TweenScale"),
			sprite=obj.transform:Find("Pos/Background"):GetComponent("UISprite"),
			label=obj.transform:Find("Pos/Font_Num"):GetComponent("UILabel"),
		}
	end
	
	newChouma.transform.localScale=Vector3.one
	--重新设置深度
    newChouma.sprite.depth = self.CurrentChipDepth[areaIndex]
    newChouma.label.depth = self.CurrentChipDepth[areaIndex] + 1	
    self.CurrentChipDepth[areaIndex] = self.CurrentChipDepth[areaIndex] + 2
    return newChouma
end

--根据筹码总数计算筹码的个数
function ChoumaManager:CalculateChoumaByTotal(totalChoumaNum)
    local choumaTable = {}
    --计算最大筹码个数
    while(totalChoumaNum >= self.gameView.mChips[6])
    do
        totalChoumaNum = totalChoumaNum - self.gameView.mChips[6]
        table.insert(choumaTable, 6)
    end
    --计算第二档筹码个数
    while(totalChoumaNum >= self.gameView.mChips[5])
    do
        totalChoumaNum = totalChoumaNum - self.gameView.mChips[5]
        table.insert(choumaTable, 5)
    end
    --计算第三档筹码个数
    while(totalChoumaNum >= self.gameView.mChips[4])
    do
        totalChoumaNum = totalChoumaNum - self.gameView.mChips[4]
        table.insert(choumaTable, 4)
    end
    --计算第四档筹码个数
    while(totalChoumaNum >= self.gameView.mChips[3])
    do
        totalChoumaNum = totalChoumaNum - self.gameView.mChips[3]
        table.insert(choumaTable, 3)
    end
    --计算第五档筹码个数
    while(totalChoumaNum >= self.gameView.mChips[2])
    do
        totalChoumaNum = totalChoumaNum - self.gameView.mChips[2]
        table.insert(choumaTable, 2)
    end
    --计算第六档筹码个数
    while(totalChoumaNum >= self.gameView.mChips[1])
    do
        totalChoumaNum = totalChoumaNum - self.gameView.mChips[1]
        table.insert(choumaTable, 1)
    end

	if(totalChoumaNum>0.6) then
		table.insert(choumaTable, 1)
	end

    return choumaTable
end


--取区域随机坐标
function ChoumaManager:GetRandomPosition(areaIndex)
    local rangeInfo = GameProtocal.ChoumaRange[areaIndex]
    local randomX = math.random(rangeInfo.minX, rangeInfo.maxX)
    local randomY = math.random(rangeInfo.minY, rangeInfo.maxY)
    return UnityEngine.Vector3.New(randomX, randomY, 0)
end


--初始化区域 桌面筹码
function ChoumaManager:ShowAllAreaChoumaObj(areaIndex, playerjetton, deskPlayerJetton, otherPlayerjetton)
	--初始化玩家自己的筹码
	if playerjetton > 0 then
		--保存筹码
		self.mMyBetChouma[areaIndex] = self:CreateChoumaByArea("Self",areaIndex, playerjetton)		
	end

	--初始化桌上玩家的筹码
	for deskIndex = 1, GameProtocal.DESK_PALYER_COUNT do
		local jetton=deskPlayerJetton[deskIndex]
		self.mTablePlayerBetChouma[deskIndex][areaIndex]=self:CreateChoumaByArea("DeskUser"..deskIndex,areaIndex,jetton)
		-- body
	end

	--初始化其他玩家的筹码
	if otherPlayerjetton > 0 then
		self.mOtherPlayerBetChouma[areaIndex] = self:CreateChoumaByArea("Other",areaIndex, otherPlayerjetton)
	end
end

function ChoumaManager:CreateChoumaByArea(tagStr,areaIndex, totalJetton)
    local choumaTb = self:CalculateChoumaByTotal(totalJetton)
    local newChoumaTb = {}

    for _,choumaIndex in ipairs(choumaTb) do
        local newChouma = self:GetChoumaForPool(tagStr,choumaIndex,areaIndex)
        newChouma.transform:SetParent(self.ChoumaParentGroup[areaIndex])
        newChouma.transform.localScale = Vector3.one
        newChouma.transform.localPosition = self:GetRandomPosition(areaIndex)
        --newChouma.gameObject:SetActive(true)

        table.insert(newChoumaTb, newChouma)
    end
    return newChoumaTb
end

--根据开奖结果，生成每个区域玩家赢的筹码
function ChoumaManager:CreateChoumaObjForWinScore(areaIndex,myWinScore,tablePlayersWinScore,otherWinScore)
	--根据玩家的得分，生成对应的筹码
	if myWinScore > 0 then
		--debugLog("根据玩家的得分，生成对应的筹码  myWinScore:",myWinScore)
		--生成并隐藏玩家赢得筹码
		self:CreateKindOfUserChoumaObj(areaIndex,myWinScore,"Self")		
	end

	--根据占座玩家的得分，生成对应的筹码
	for i = 1, GameProtocal.DESK_PALYER_COUNT do
		--根据索引号，获取玩家的座位
		--local deskUserChairId = self.gameView.SeatPlayerLayer:GetDeskUserChairId(i)
		local userID=self.gameView.GetDeskUserUserId(i)
		local deskUserAreaWinScore = tablePlayersWinScore[i]
		-- print("@@@@@@@@@@@@@  i:",i,"  deskUserAreaWinScore:",deskUserAreaWinScore,"  deskUserChairId:",deskUserChairId,"  mMeChairdID:",self.mMeChairdID)
		--当桌子上的玩家赢分 且 不是自己 的情况下，生成筹码
		if deskUserAreaWinScore > 0 and deskUserChairId ~= self.mMeChairdID then
			--生成并隐藏桌子上玩家赢得筹码
			self:CreateKindOfUserChoumaObj(areaIndex, deskUserAreaWinScore, "DeskUser", i)
		end
		-- body
	end

	--根据其他玩家的得分，生成对应的筹码
	if otherWinScore > 0 then
		--生成并隐藏玩家赢得筹码
		self:CreateKindOfUserChoumaObj(areaIndex, otherWinScore, "Other")
	end
end

--生成各类玩家赢得的筹码
function ChoumaManager:CreateKindOfUserChoumaObj(areaIndex, winScore, playerFlag, deskUserChairIndex)	
	local winChoumaObjs = {}
	local needCreateChoumaIndexs = self:CalculateChoumaByTotal(winScore)

	local totalCount=#needCreateChoumaIndexs
	--获取每组筹码移动的个数
	local moveCount=self:GetChoumaMoveCount(totalCount)
	for i = 1, totalCount do
		local choumaIndex=needCreateChoumaIndexs[i]

		local newChouma = self:GetChoumaForPool(playerFlag,choumaIndex,areaIndex)
        newChouma.transform:SetParent(self.PlayerChoumaRoot._banker)
        --newChouma.transform.localScale =Vector3.New(GameProtocal.ChouMaMinScale,GameProtocal.ChouMaMinScale,GameProtocal.ChouMaMinScale)
		newChouma.transform.localScale =Vector3.one
        newChouma.transform.localPosition = Vector3.zero
		--newChouma.gameObject:SetActive(true)

		newChouma.transform:SetParent(self.ChoumaParentGroup[areaIndex])
		newChouma.transform.localScale =Vector3.one

		local startPos=newChouma.transform.localPosition
		local endPos=self:GetRandomPosition(areaIndex)
		local moveTime = Vector3.Distance(endPos,startPos)/GameProtocal.ChoumaMoveSpeed
		
		--local multi=math.modf(i/GameProtocal.ChoumaMoveCount)
		local multi=math.modf(i/moveCount)
		local delayTime=multi*GameProtocal.ChoumaIntervalTime
		
		newChouma.tweenPos.from=startPos
		newChouma.tweenPos.to=endPos
		newChouma.tweenPos.duration=moveTime
		newChouma.tweenPos.delay=delayTime
		newChouma.tweenPos.enabled=true
		newChouma.tweenPos:ResetToBeginning()
		newChouma.tweenPos:PlayForward()


		-- newChouma.tweenScale.from=Vector3.New(GameProtocal.ChouMaMinScale,GameProtocal.ChouMaMinScale,GameProtocal.ChouMaMinScale)
		-- newChouma.tweenScale.to=Vector3.New(GameProtocal.ChouMaMaxScale,GameProtocal.ChouMaMaxScale,GameProtocal.ChouMaMaxScale)
		-- newChouma.tweenScale.enabled=true
		-- newChouma.tweenScale.duration=moveTime+0.1
		-- newChouma.tweenScale:ResetToBeginning()
		-- newChouma.tweenScale:PlayForward()

        table.insert(winChoumaObjs, newChouma)
		local totalMoveTime=multi*GameProtocal.ChoumaIntervalTime+moveTime
		if(totalMoveTime>self.mMaxMoveTime) then
			self.mMaxMoveTime=totalMoveTime
		end
		--debugLog("   mMaxMoveTime:",self.mMaxMoveTime)
		-- body
	end
	
	if playerFlag == "Self" then
		self.mMyWinChouma[areaIndex]=winChoumaObjs
	elseif playerFlag == "DeskUser" then
		self.mTablePlayerWinChouma[deskUserChairIndex][areaIndex]=winChoumaObjs
	else
		self.mOtherPlayerWinChouma[areaIndex] = winChoumaObjs
	end
	-- logError("CreateKindOfUserChoumaObj----------deskUserChairIndex:" .. tostring(deskUserChairIndex) ..  ", AreaIndex: " .. tostring(areaIndex) .. ",WinScore: " .. tostring(winScore) .. " , count: " .. tostring(#winChoumaObjs))
end

--将筹码返回给玩家（比如当该区域赢的时候）
function ChoumaManager:MoveBetChoumaToPlayer(winAreaArray)
	for i = 1, GameProtocal.AREA_COUNT do
		if(winAreaArray[i]) then
			--1.计算自己需要移动的筹码
			local mybetChoumaList=self.mMyBetChouma[i]
			if(mybetChoumaList~=nil and #mybetChoumaList>0) then
				local moveCount=self:GetChoumaMoveCount(#mybetChoumaList)
				for j = 1, #mybetChoumaList do
					local choumaItem=mybetChoumaList[j]
					self:MoveRecoverChouma(self.PlayerChoumaRoot._self,choumaItem,j,moveCount,true)
					-- body
				end

				self.mMyBetChouma[i]={}  --因为已经放入回收筹码，所有需要清空当前区域的押注
			end			

			--2.结算占座玩家需要移动的筹码
			for j = 1, GameProtocal.DESK_PALYER_COUNT do
				local tablePlayerBetChoumaList = self.mTablePlayerBetChouma[j][i]

				if(tablePlayerBetChoumaList~=nil and #tablePlayerBetChoumaList>0) then
					local moveCount=self:GetChoumaMoveCount(#tablePlayerBetChoumaList)
					for k = 1, #tablePlayerBetChoumaList do
						local choumaItem=tablePlayerBetChoumaList[k]
						self:MoveRecoverChouma(self.PlayerChoumaRoot._seatPlayer[j],choumaItem,k,moveCount,true)
					end

					self.mTablePlayerBetChouma[j][i]={}  --因为已经放入回收筹码，所有需要清空当前区域的押注
				end				
			end

			--3.结算其它玩家需要移动的筹码
			local otherBetChoumaList=self.mOtherPlayerBetChouma[i]
			if(otherBetChoumaList~=nil and #otherBetChoumaList>0) then
				local moveCount=self:GetChoumaMoveCount(#otherBetChoumaList)
				for j = 1, #otherBetChoumaList do
					local choumaItem=otherBetChoumaList[j]
					self:MoveRecoverChouma(self.PlayerChoumaRoot._otherPlayer,choumaItem,j,moveCount,true)
					-- body
				end

				self.mOtherPlayerBetChouma[i]={}  --因为已经放入回收筹码，所有需要清空当前区域的押注
			end
		end
	end
end

--移动赢的筹码给玩家
function ChoumaManager:MoveWinChoumaToPlayer()
	for i = 1, GameProtocal.AREA_COUNT do
		--1.结算自己赢的筹码
		local myWinChoumaList=self.mMyWinChouma[i]
		if(myWinChoumaList~=nil and #myWinChoumaList>0) then
			local moveCount=self:GetChoumaMoveCount(#myWinChoumaList)
			for j = 1, #myWinChoumaList do
				local choumaItem=myWinChoumaList[j]
				self:MoveRecoverChouma(self.PlayerChoumaRoot._self,choumaItem,j,moveCount,true)
			end			
			
			self.mMyWinChouma[i]={}  --因为已经放入回收筹码，所有需要清空赢的筹码列表
		end

		--2.结算占座玩家赢的筹码
		for j = 1, GameProtocal.DESK_PALYER_COUNT do
			local tablePlayerWinChoumaList = self.mTablePlayerWinChouma[j][i]

			if(tablePlayerWinChoumaList~=nil and #tablePlayerWinChoumaList>0) then
				local moveCount=self:GetChoumaMoveCount(#tablePlayerWinChoumaList)
				for k = 1, #tablePlayerWinChoumaList do
					local choumaItem=tablePlayerWinChoumaList[k]
					self:MoveRecoverChouma(self.PlayerChoumaRoot._seatPlayer[j],choumaItem,k,moveCount,true)
				end

				self.mTablePlayerWinChouma[j][i]={}  --因为已经放入回收筹码，所有需要清空赢的筹码列表
			end
		end

		--3.结算其它玩家赢的筹码
		local otherWinChoumaList=self.mOtherPlayerWinChouma[i]
		if(otherWinChoumaList~=nil and #otherWinChoumaList>0) then
			local moveCount=self:GetChoumaMoveCount(#otherWinChoumaList)
			for j = 1, #otherWinChoumaList do
				local choumaItem=otherWinChoumaList[j]
				self:MoveRecoverChouma(self.PlayerChoumaRoot._otherPlayer,choumaItem,j,moveCount,true)
				-- body
			end

			self.mOtherPlayerWinChouma[i]={}  --因为已经放入回收筹码，所有需要清空赢的筹码列表
		end
		-- body
	end
end

--移动输的筹码给庄家
function ChoumaManager:MoveLoseChoumaToBanker(winAreaArray)
	--luaPrint("移动输的筹码给庄家 abAreaWin:",abAreaWin,"  countAreaWin:",countAreaWin)	
	for i = 1, GameProtocal.AREA_COUNT do
		if(not winAreaArray[i]) then
			--1.计算自己需要移动的筹码
			local mybetChoumaList=self.mMyBetChouma[i]
			--print("  i:",i,"  #mybetChoumaList:",#mybetChoumaList)
			if(mybetChoumaList~=nil and #mybetChoumaList>0) then
				local moveCount=self:GetChoumaMoveCount(#mybetChoumaList)
				for j = 1, #mybetChoumaList do
					local choumaItem=mybetChoumaList[j]
					self:MoveRecoverChouma(self.PlayerChoumaRoot._banker,choumaItem,j,moveCount,true)
					-- body

					self.mMyBetChouma[i]={}  --因为已经放入回收筹码，所有需要清空当前区域的押注
				end
			end

			--2.结算占座玩家需要移动的筹码
			for j = 1, GameProtocal.DESK_PALYER_COUNT do
				local tablePlayerBetChoumaList = self.mTablePlayerBetChouma[j][i]
				--print(" 移动占座玩家输的筹码给庄家 DeskIndex:"..j)
				--pt(tablePlayerBetChoumaList)
				if(tablePlayerBetChoumaList~=nil and #tablePlayerBetChoumaList>0) then
					local moveCount=self:GetChoumaMoveCount(#tablePlayerBetChoumaList)
					for k = 1, #tablePlayerBetChoumaList do
						local choumaItem=tablePlayerBetChoumaList[k]
						self:MoveRecoverChouma(self.PlayerChoumaRoot._banker,choumaItem,k,moveCount,true)
					end

					self.mTablePlayerBetChouma[j][i]={}  --因为已经放入回收筹码，所有需要清空当前区域的押注
				end
			end

			--3.结算其它玩家需要移动的筹码
			local otherBetChoumaList=self.mOtherPlayerBetChouma[i]
			if(otherBetChoumaList~=nil and #otherBetChoumaList>0) then
				local moveCount=self:GetChoumaMoveCount(#otherBetChoumaList)
				for j = 1, #otherBetChoumaList do
					local choumaItem=otherBetChoumaList[j]
					self:MoveRecoverChouma(self.PlayerChoumaRoot._banker,choumaItem,j,moveCount,true)
					-- body
				end

				self.mOtherPlayerBetChouma[i]={}  --因为已经放入回收筹码，所有需要清空当前区域的押注
			end
		end
		-- body
	end
end

--创建需要回收的移动筹码
function ChoumaManager:MoveRecoverChouma(parent,choumaItem,index,moveCount,isRecover)
	self.mIsStartRecover=true
	choumaItem.transform:SetParent(parent)
	choumaItem.transform.localScale =Vector3.one

	local startPos=choumaItem.transform.localPosition
	local endPos=Vector3.zero
	local moveTime = Vector3.Distance(endPos,startPos)/GameProtocal.ChoumaMoveSpeed
	--获取每组筹码移动的个数	
	--local multi=math.modf(index/GameProtocal.ChoumaMoveCount)
	local multi=math.modf(index/moveCount)

	choumaItem.tweenPos.from=startPos
	choumaItem.tweenPos.to=endPos
	choumaItem.tweenPos.duration=moveTime
	choumaItem.tweenPos.delay=multi*GameProtocal.ChoumaIntervalTime
	choumaItem.tweenPos.enabled=true
	choumaItem.tweenPos:ResetToBeginning()
	choumaItem.tweenPos:PlayForward()

	-- choumaItem.tweenScale.from=Vector3.New(GameProtocal.ChouMaMaxScale,GameProtocal.ChouMaMaxScale,GameProtocal.ChouMaMaxScale)
	-- choumaItem.tweenScale.to=Vector3.New(GameProtocal.ChouMaMinScale,GameProtocal.ChouMaMinScale,GameProtocal.ChouMaMinScale)
	-- choumaItem.tweenScale.enabled=true
	-- choumaItem.tweenScale.duration=moveTime
	-- choumaItem.tweenScale.delay=multi*GameProtocal.ChoumaIntervalTime
	-- choumaItem.tweenScale:ResetToBeginning()
	-- choumaItem.tweenScale:PlayForward()

	local totalMoveTime=multi*GameProtocal.ChoumaIntervalTime+moveTime
	if(totalMoveTime>self.mMaxMoveTime) then
		self.mMaxMoveTime=totalMoveTime
	end
	
	if(isRecover) then
		self.mMoveChoumaID=self.mMoveChoumaID+1
		local item={}
		item.ID=self.mMoveChoumaID
		item.ChouMa=choumaItem
		item.MoveTime=totalMoveTime
		item.CurrentTime=0
		item.IsRecover=true
		self.mNeedMoveChoumaList[self.mMoveChoumaID]=item
	end	
end

--获取筹码每次移动的个数
function ChoumaManager:GetChoumaMoveCount(totalCMCount)
	--获取移动筹码的总组数
	local groupCount=math.floor(GameProtocal.ChoumaTotalIntervalTime/GameProtocal.ChoumaIntervalTime)
	--获取每组移动的筹码数
	local choumaMoveNum=math.ceil(totalCMCount/groupCount)
	--取最大的一个
	local resultCount=math.max(GameProtocal.MinChoumaMoveCount,choumaMoveNum)
	--debugLog(" GetChoumaMoveCount  totalCMCount:",totalCMCount," groupCount:",groupCount,"  choumaMoveNum:",choumaMoveNum,"  resultCount:",resultCount)
	return resultCount
end


--根据下注创建筹码
function ChoumaManager:CreateJettonChouma(isSelf,tableIndex,areaIndex,jettonScore)
	local choumaPool={}
	--local moveSound = nil
	local originParent=nil
	local tagStr=""
	if(isSelf) then --玩家自己下注
		choumaPool=self.mMyBetChouma[areaIndex]
		--moveSound = GameProtocal.EFFECT_Bet.Self
		originParent=self.PlayerChoumaRoot._self
		tagStr="Self"
	elseif tableIndex then --占座玩家下注
		choumaPool=self.mTablePlayerBetChouma[tableIndex][areaIndex]
		--moveSound = GameProtocal.EFFECT_Bet.SeatPlayer
		originParent=self.PlayerChoumaRoot._seatPlayer[tableIndex]
		tagStr="DeskUser"..jettonScore.."|"..tableIndex
	else  --其它玩家下注
		choumaPool = self.mOtherPlayerBetChouma[areaIndex]
		--moveSound = GameProtocal.EFFECT_Bet.OtherPlayer
		originParent = self.PlayerChoumaRoot._otherPlayer
		tagStr="Other"
		-- body
	end

	--从对象池中取出对应下注数值的筹码
    local choumaIndex = self:CalculateChoumaByTotal(jettonScore)[1]
    local choumaObj = self:GetChoumaForPool(tagStr,choumaIndex,areaIndex)
    --1.先设置筹码的位置为下注玩家对应的初始位置
    choumaObj.transform:SetParent(originParent)
    choumaObj.transform.localPosition = Vector3.zero
	choumaObj.transform.localScale=Vector3.one
	--choumaObj.gameObject:SetActive(true)
	--2.再将筹码的父级更改为下注区域的父级，计算出相对于下注区域的位置
	choumaObj.transform:SetParent(self.ChoumaParentGroup[areaIndex])
	choumaObj.transform.localScale=Vector3.one

	local startPos=choumaObj.transform.localPosition
    --筹码移动
    local endPos = self:GetRandomPosition(areaIndex)
    self:ChoumaMoveHandler(choumaObj, startPos, endPos, true)
    --保存筹码
    table.insert(choumaPool, choumaObj)
    --移动音效
    --self.gameView:CheckBetSoundGroup(moveSound)
end

function ChoumaManager:ChoumaMoveHandler(choumaObj, startPos, endPos,needChangeScale)
    --移动固定速度，根据路程计算时间
    local moveTime = Vector3.Distance(endPos,startPos)/GameProtocal.ChoumaMoveSpeed
	choumaObj.tweenPos.enabled=true
	choumaObj.tweenPos.from=startPos
	choumaObj.tweenPos.to=endPos
	choumaObj.tweenPos.duration=moveTime
	choumaObj.tweenPos:ResetToBeginning()
	choumaObj.tweenPos:PlayForward()

	if(needChangeScale) then
		-- choumaObj.tweenScale.from=Vector3.New(GameProtocal.ChouMaMinScale,GameProtocal.ChouMaMinScale,GameProtocal.ChouMaMinScale)
		-- choumaObj.tweenScale.to=Vector3.New(GameProtocal.ChouMaMaxScale,GameProtocal.ChouMaMaxScale,GameProtocal.ChouMaMaxScale)
		-- choumaObj.tweenScale.enabled=true
		-- choumaObj.tweenScale.duration=moveTime+0.1
		-- choumaObj.tweenScale:ResetToBeginning()
		-- choumaObj.tweenScale:PlayForward()
	end
	return moveTime
end

--重置移动筹码时的最长时间
function ChoumaManager:ResetMaxMoveTime()
	self.mMaxMoveTime=0
end

--获取移动筹码时的最长时间
function ChoumaManager:GetMaxMoveTime()
	return self.mMaxMoveTime
end

--回收筹码列表
function ChoumaManager:PutChoumaListToPool(choumaList)
	if(choumaList~=nil and #choumaList>0) then
		for i = 1, #choumaList do
			local item=choumaList[i]
			item.tweenPos.enabled=false
			self:PutChoumaForPool(item)
			-- body
		end
	end
end

--回收所有区域筹码
function ChoumaManager:RecoverAllChip()
	--回收需要回收的筹码
	for id, item in pairs(self.mNeedMoveChoumaList) do
		self:PutChoumaForPool(item.ChouMa)
	end
	--清空需要回收的筹码
	self.mNeedMoveChoumaList={}

	--重置ID
	self.mMoveChoumaID=0

	for i = 1, GameProtocal.AREA_COUNT do
		self:PutChoumaListToPool(self.mMyBetChouma[i])  --回收我的押注筹码
		self.mMyBetChouma[i]={}
		self:PutChoumaListToPool(self.mOtherPlayerBetChouma[i]) --回收其它玩家各个区域下注的筹码
		self.mOtherPlayerBetChouma[i]={}
		for j = 1, GameProtocal.DESK_PALYER_COUNT do
			self:PutChoumaListToPool(self.mTablePlayerBetChouma[j][i])  --回收占座玩家的押注筹码
			self.mTablePlayerBetChouma[j][i]={}
		end	

		self:PutChoumaListToPool(self.mMyWinChouma[i])  --回收我的赢的筹码
		self.mMyWinChouma[i]={}
		self:PutChoumaListToPool(self.mOtherPlayerWinChouma[i]) --回收其它玩家各个区域赢的筹码
		self.mOtherPlayerWinChouma[i]={}
		for j = 1, GameProtocal.DESK_PALYER_COUNT do
			self:PutChoumaListToPool(self.mTablePlayerWinChouma[j][i])  --回收占座玩家的赢的筹码
			self.mTablePlayerWinChouma[j][i]={}
		end	
	end

	self:InitChoumaDepth()

	self.mIsStartRecover=false
end

return ChoumaManager