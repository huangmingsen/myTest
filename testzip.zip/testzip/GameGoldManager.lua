local GameGoldAnima = require "642.GameGoldAnima"
local GameLogic = require "642.GameLogic"
local GameGoldManager = 
{
	goldAnimaListInfo = {},
	GoldItemParent,
	item,
	GoldCount = {},
	zhuangPos = {},
}
function GameGoldManager.InitUI(_GoldItemParent,_item)
	GameGoldManager.goldAnimaListInfo = {}
	GameGoldManager.GoldItemParent = _GoldItemParent
	GameGoldManager.item = _item
	GameGoldManager.GoldCount = {0,0,0}
	GameGoldManager.zhuangPos[1] = Vector3.New(80, 286, 0)
	GameGoldManager.zhuangPos[2] = Vector3.New(-80, 286, 0)
end

function GameGoldManager.GetGoldAnima(AearId, checkIndex)
    local goldAnima
	local userMoney = GameLogic.FormatNoteNumToYW(MoneyProportionStr(GameUIManager.mChips[checkIndex]))
    GameGoldManager.GoldCount[AearId] = GameGoldManager.GoldCount[AearId]+1
    if(GameGoldManager.goldAnimaListInfo[AearId] == nil) then
        local obj = UnityEngine.GameObject.Instantiate(GameGoldManager.item)
        obj:SetActive(true)
        SetParent(GameGoldManager.GoldItemParent.transform.gameObject,obj)
        goldAnima = GameGoldAnima:new(obj.transform)
    	goldAnima:InitUI()
		goldAnima.transform.gameObject.name = "GoldItem"..AearId..GameGoldManager.GoldCount[AearId]
    	GameGoldManager.goldAnimaListInfo[AearId]  = {goldAnima}
    else
    	if(GameGoldManager.GoldCount[AearId] <= #GameGoldManager.goldAnimaListInfo[AearId]) then
    		goldAnima = GameGoldManager.goldAnimaListInfo[AearId][GameGoldManager.GoldCount[AearId]]
    		goldAnima.transform.gameObject:SetActive(true)
    		goldAnima.transform.gameObject.name = "GoldItem"..AearId..GameGoldManager.GoldCount[AearId]
    	else
	        local obj = UnityEngine.GameObject.Instantiate(GameGoldManager.item)
        	obj:SetActive(true)
        	SetParent(GameGoldManager.GoldItemParent.transform.gameObject,obj)
	        goldAnima = GameGoldAnima:new(obj.transform)
    		goldAnima:InitUI()
			goldAnima.transform.gameObject.name = "GoldItem"..AearId..GameGoldManager.GoldCount[AearId]
	        table.insert(GameGoldManager.goldAnimaListInfo[AearId],goldAnima)
    	end
    end
	goldAnima:SetData(userMoney, checkIndex, GameGoldManager.GoldCount[AearId])
    GameGoldManager.LimitGoldNum()
    return goldAnima
end

function GameGoldManager.LimitGoldNum() 
	for i=1,3 do
	    if(GameGoldManager.goldAnimaListInfo[i] ~= nil) then
	    	if(GameGoldManager.GoldCount[i]>50) then
	    		GameGoldManager.GoldCount[i] = GameGoldManager.GoldCount[i] - 20
	    		local snopList = {}
	    		for j=1,20 do
	    			snopList[j] = GameGoldManager.goldAnimaListInfo[i][j]
	    			snopList[j].transform.gameObject:SetActive(false)
	    		end
	    		for j=1,20 do
	    			table.remove(GameGoldManager.goldAnimaListInfo[i],1)
	    		end
	    		for j=1,20 do
	    			table.insert(GameGoldManager.goldAnimaListInfo[i],snopList[j])
	    		end
				for k = 1, #GameGoldManager.goldAnimaListInfo[i] do
					GameGoldManager.goldAnimaListInfo[i][k]:SetDepth(k)
				end
	    	end
	    end
	end
end



function GameGoldManager.AearCollectChip(prizeData, PrizeIndex) 
	local topos
	if(PrizeIndex == 0) then
		topos = GameGoldManager.zhuangPos[1]
	elseif(PrizeIndex == 1) then
		topos = GameGoldManager.zhuangPos[2]
	elseif(PrizeIndex == 2) then
		topos = GameUIManager.BtnOnLine.transform.localPosition
	end
	for i=1,#prizeData do
		if(prizeData[i] <= 0) then
			if(GameGoldManager.goldAnimaListInfo[i] ~= nil) then
				for j=1,#GameGoldManager.goldAnimaListInfo[i] do
					local formPos = GameGoldManager.goldAnimaListInfo[i][j].transform.localPosition
					GameGoldManager.goldAnimaListInfo[i][j]:GotoPosition(formPos, topos, 0.3,true)
				end
			end
		end
	end
end

function GameGoldManager.AearThrowChip(prizeData, PrizeIndex)
	local formPos = GameGoldManager.zhuangPos[2]
	if(PrizeIndex == 0) then
		formPos = GameGoldManager.zhuangPos[1]
	elseif(PrizeIndex == 1) then
		formPos = GameGoldManager.zhuangPos[2]
	end
	for i=1,#prizeData do
		if(prizeData[i] > 0) then
			if(GameUIManager.mTotalBets[i]>0)then
				local count = math.random(20,30)
				local money = tonumber(tostring(GameUIManager.mTotalBets[i]))
				local listChips = GameGoldManager.GetChipList(count,money)
				for j=1,#listChips do
					local snop = GameGoldManager.GetGoldAnima(i,listChips[j])
					local topos = GameLogic.GetRandomPostion(GameUIManager.BetPos[i])
					snop:GotoPosition(formPos, topos, 0.4)
				end
			end
		end
	end
end

function GameGoldManager.FeiGoldToPlayer(prizeData, scoreArr) 
	local formPosArr = {}
	for i=1,#prizeData do
		if(prizeData[i] > 0) then
			local vec = GameUIManager.BetPos[i]
			table.insert(formPosArr,vec)
		end
	end
	local topos
	local otherPlayerWin = 0
	for i=1,180 do
		if(scoreArr[i-1]~=nil) then
			if(scoreArr[i-1]>0) then
				otherPlayerWin = otherPlayerWin+1
			end
		end
	end
	GameGoldManager.HideAllGole()
	for i=1,#GameUIManager.players do
		if(GameUIManager.players[i].transform.gameObject.activeSelf) then
			local info = GameUIManager.players[i]:GetPlayerInfo()
			if(info~=nil) then
				local userinfo = GameSUserBaseInfo.finduserbyid(info[1])
				if(userinfo~=nil and userinfo.iDeskStation <=180) then
					if(scoreArr[userinfo.iDeskStation] ~= nil) then
						if(scoreArr[userinfo.iDeskStation]> 0) then
							topos = GameUIManager.players[i].transform.localPosition
							otherPlayerWin = otherPlayerWin - 1
							local count = math.random(5,10)
							local listChips = GameGoldManager.GetChipList(count,scoreArr[userinfo.iDeskStation])
							for j=1,#listChips do
								local vecIndex = math.random(1,#formPosArr)
								local snop = GameGoldManager.GetGoldAnima(vecIndex,listChips[j])
								local formPos = GameLogic.GetRandomDesktopPostion(formPosArr[vecIndex])
								snop:GotoPosition(formPos, topos, 0.4,true)
							end
						end
					end
				end
			end
		end
	end
	if(otherPlayerWin > 0) then
		topos = GameUIManager.BtnOnLine.transform.localPosition
		local count = math.random(10,20)
		for j=1,count do
			local vecIndex = math.random(1,#formPosArr)
			local ronCheckIndex = math.random(1,5)
			local snop = GameGoldManager.GetGoldAnima(vecIndex,ronCheckIndex)
			local formPos = GameLogic.GetRandomDesktopPostion(formPosArr[vecIndex])
			snop:GotoPosition(formPos, topos, 0.4,true)
		end
	end
end

function GameGoldManager.SetAreaGold()
	for i=1,#GameUIManager.mTotalBets do
		local money = GameUIManager.mTotalBets[i]
		if(money>0)then
		    local checkIndexList = {}
		    while (money > 0) do
		        if (money <= GameUIManager.mChips[1]) then
			        table.insert(checkIndexList, 1)
			        break
		        end
		        for j = 1, #GameUIManager.mChips do
		        	local chipIndex = #GameUIManager.mChips-j+1
		            if (money >= GameUIManager.mChips[chipIndex]) then
		                money = money - GameUIManager.mChips[chipIndex]
		        		table.insert(checkIndexList, chipIndex)
		                break
		            end

					
		        end
		    end
		    for j = 1, #checkIndexList do
				local snop = GameGoldManager.GetGoldAnima(i,checkIndexList[j])
				local topos = GameLogic.GetRandomPostion(GameUIManager.BetPos[i])
				snop:GotoPosition(topos, topos, 0.1,false,false)
		    end
		end
	end
end


function GameGoldManager.HideAllGole() 
	GameGoldManager.GoldCount = {0,0,0}
	for i=1,3 do
    	if(GameGoldManager.goldAnimaListInfo[i] ~= nil) then
    		for j=1,#GameGoldManager.goldAnimaListInfo[i] do
    			GameGoldManager.goldAnimaListInfo[i][j].transform.gameObject:SetActive(false)
    		end
    	end
	end
end
function GameGoldManager.GetChipList(count,money)
	local listChips = {}
	while (count > 0) do
		if (money <= GameUIManager.mChips[1]) then
			table.insert(listChips, 1)
			break
		end
		local randomNote = {}
		for k = 1, 6 do
			if money >= GameUIManager.mChips[k] then
				table.insert(randomNote,GameUIManager.mChips[k])
			end
		end
		local ronCheckIndex = math.random(1,#randomNote)
		table.insert(listChips,ronCheckIndex)
		money = money - randomNote[ronCheckIndex]
		count = count - 1
	end
	return listChips
end
function GameGoldManager.OnDestroy()
	for i=1,3 do
		if(GameGoldManager.goldAnimaListInfo[i] ~= nil) then
			for j=1,#GameGoldManager.goldAnimaListInfo[i] do
				GameGoldManager.goldAnimaListInfo[i][j]:OnDestroy()
			end
		end
	end
end
return GameGoldManager