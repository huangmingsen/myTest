GameAudioContro = 
{
	bgaudiosource = nil,
	SoundEffect = nil,
	BGM = "Public/Audio/BGM.u3d",--背景

	LongWinAud = "Public/Audio/result1.u3d",--黑方赢
	HuWinAud = "Public/Audio/result2.u3d",--红方赢
	HeWinAud = "Public/Audio/result3.u3d",--幸运一击
	WinEffctAud = {"Public/Audio/wintiger.u3d","Public/Audio/windragon.u3d","Public/Audio/winhe.u3d"},--黑方赢
	CardPointAud = {"Public/Audio/point1.u3d","Public/Audio/point2.u3d",
	"Public/Audio/point3.u3d","Public/Audio/point4.u3d","Public/Audio/point5.u3d",
	"Public/Audio/point6.u3d","Public/Audio/point7.u3d","Public/Audio/point8.u3d",
	"Public/Audio/point9.u3d","Public/Audio/point10.u3d","Public/Audio/point11.u3d",
	"Public/Audio/point12.u3d","Public/Audio/point13.u3d"},
	StartEffectAud = "Public/Audio/starteffect.u3d",--开始下注
	StartNoteAud = "Public/Audio/startbet.u3d",--开始下注
	EndNoteAud = "Public/Audio/endbet.u3d",--停止下注
	ClickAud = "Public/Audio/countdown.u3d",--点击
	LastTimeAud = "Public/Audio/clockring.u3d",--倒计时1
	KaiPaiAud = "Public/Audio/opencard.u3d",--开牌
	FaPaiAud = "Public/Audio/sendcard.u3d",--发牌
	NoteAud = "Public/Audio/touzhichouma.u3d",--下注筹码
}

function GameAudioContro.Awake()
	GameAudioContro.bgaudiosource = GameAudioContro.transform:GetComponent("AudioSource")
	GameAudioContro.SoundEffect = GameAudioContro.transform:FindChild("SoundEffect"):GetComponent("AudioSource")
	GameDefine.AddEvent(GameDefine.Action_ResetBGVolume, GameAudioContro.ReSetPlayAudio)
	--gameresMrg:LoadPrefab(GameAudioContro.BGM, nil, nil)--预加载声音
	GameAudioContro.PlayBG(GameAudioContro.BGM,GameAudioContro.ReSetPlayAudio)
	--GameAudioContro.ReSetPlayAudio()
end

function GameAudioContro.Play(AudioPath)
	if soundMgr.CanPlaySoundEffect then
		gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
			if(objects ~= nil) then
				GameAudioContro.SoundEffect:PlayOneShot(objects[0])
			end
		end)
    end
end

function GameAudioContro.PlayBG(AudioPath,func)
	if soundMgr.CanPlayBackSound then
		gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
			if(objects ~= nil) then
				GameAudioContro.bgaudiosource.clip = objects[0]
				GameAudioContro.bgaudiosource.loop = true
				GameAudioContro.bgaudiosource:Play()
				if(func ~= nil)then 
					func()
				end
			end
		end)
    end
end

function GameAudioContro.PlayLoop(AudioPath,func)
	if soundMgr.CanPlaySoundEffect then
		gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
			GameAudioContro.SoundEffect.clip = objects[0]
			GameAudioContro.SoundEffect.loop = true
			GameAudioContro.SoundEffect:Play()
		end)
    end
end

function GameAudioContro.ReSetPlayAudio()
	if soundMgr.CanPlayBackSound then
		GameAudioContro.bgaudiosource:Play()
	else
		GameAudioContro.bgaudiosource:Stop()
	end
	if not soundMgr.CanPlaySoundEffect then
		GameAudioContro.SoundEffect:Stop()
	end
end

function GameAudioContro.StopEffect()
	GameAudioContro.SoundEffect:Stop()
end