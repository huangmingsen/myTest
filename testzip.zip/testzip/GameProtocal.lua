GameProtocal =
{
	GM_SUB_GAMESTATION = 1001,--游戏状态

  GM_SUB_STATEUPDATE = 1002,	--游戏状态更新
  GM_SUB_NOTE = 1003,         --下注
  GM_SUB_CONTINUE = 1004,     --续压
  GM_SUB_SETTLEMENT = 1005,   --结算
  GM_SUB_LUCKPLAYER = 1006,   --幸运星
  GM_SUB_PLAYERNOTEINFO = 1007,   --下注信息

  SUB_GM_POOLDATA_FRESH = 2,--奖池刷新
  SUB_GM_POOL_DISTRIBUTE = 3,--奖池派发
  SUB_GM_POOL_CONFIG = 4,--奖池配置
  SUB_GM_POOL_RECORD = 5,--奖池记录
  
  SUB_GM_GAME_CONFIG = 7,--限制下注


  CMD_GM_Update_PlayerMoney = --身上钱更新
  {
   { names = "nDeskStation", types = "Int32", data = 0 },
   { names = "nMoney", types = "Int64", data = 0 },
  },

	CMD_GM_State= --状态
	{
	  { names = "iState", types = "Byte", data = 0 },
	},
  CMD_GM_State_Note = --开始下注
  {
    { names = "iState", types = "Byte", data = 0 },
  },

  CMD_GM_State_SendCard = --发牌
  {
    { names = "cbState", types = "Byte", data = 0 },
    { names = "bDeskStation", types = "Byte", data = 0 },
    { names = "cbOpenCard", types = "Byte[]", length = 2, data = {} },
  },
  CMD_GM_State_Account = --结算
  {
    { names = "cbPrizeIndex", types = "Byte", data = 0 },
    { names = "iWinMoney", types = "Int64[]", length = 180, data = {} },
    { names = "cbNoted", types = "Byte[]", length = 180, data = {} },
  },
-- C => S
  CMD_GM_Note = --下注数据 
  {
    { names = "bDeskStation", types = "Byte", data = 0 },
    { names = "bChipIndex", types = "Byte", data = 0 },
    { names = "bNoteObject", types = "Byte", data = 0 },
    { names = "bErrorCode", types = "Byte", data = 0 },
  },

  CMD_GM_ContinueNote = --续压 
  {
    { names = "nDeskStation", types = "Byte", data = 0 },
    { names = "AreaNoteMoney", types = "Int64[]", length = 4, data = {} },
  },
  stLuckPlayer = --幸运星座位号
  {
    { names = "cbDeskStation", types = "Byte", data = 0 },
    { names = "cbWinRate", types = "Byte", data = 0 },
  },
  stPlayerNoteInfo = --下注信息
  {
    { names = "cbDeskStation", types = "Byte", data = 0 },
    { names = "iNote", types = "Int64[]", length = 3, data = {} },
  },
  
  CMD_GM_Station_Base= --游戏状态
  {
    { names = "bStation", types = "Byte", data = 0 },
    { names = "iVersion", types = "Byte", data = 0 },
    { names = "iVersion2", types = "Byte", data = 0 },
    { names = "iLeftTick", types = "Int32", data = 0 },
    { names = "iXiaZhuTime", types = "Int32", data = 0 },
    { names = "iSendCardTime", types = "Int32", data = 0 },
    { names = "iAccountTick", types = "Int32", data = 0 },

    { names = "iChouMaNum", types = "Int32", data = 0 },
    { names = "iChouMa", types = "Int32[]", length = 10, data = {} },
    { names = "cbCurGames", types = "Byte", data = 0 },

    { names = "iCardTypeRecordItemCount", types = "Byte", data = 0 },
    { names = "tagCardTypeRecordItem", types = "Byte[]", length = 60, data = {} },

    { names = "cbLuckerDeskStation", types = "Byte", data = 0 },
    { names = "cbLuckerWinRate", types = "Byte", data = 0 },

  },

  CMD_GM_Station_Note= --下注状态
  {
    { names = "bStation", types = "Byte", data = 0 },
    { names = "iVersion", types = "Byte", data = 0 },
    { names = "iVersion2", types = "Byte", data = 0 },
    { names = "iLeftTick", types = "Int32", data = 0 },
    { names = "iXiaZhuTime", types = "Int32", data = 0 },
    { names = "iSendCardTime", types = "Int32", data = 0 },
    { names = "iAccountTick", types = "Int32", data = 0 },

    { names = "iChouMaNum", types = "Int32", data = 0 },
    { names = "iChouMa", types = "Int32[]", length = 10, data = {} },
    { names = "cbCurGames", types = "Byte", data = 0 },

    { names = "iCardTypeRecordItemCount", types = "Byte", data = 0 },
    { names = "tagCardTypeRecordItem", types = "Byte[]", length = 60, data = {} },

    { names = "cbLuckerDeskStation", types = "Byte", data = 0 },
    { names = "cbLuckerWinRate", types = "Byte", data = 0 },

    { names = "NoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "SelfNoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "iLuckerNoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "cbNoted", types = "Byte[]", length = 180, data = {} },
  },

  CMD_GM_Station_SendCard= --发牌状态
  {
    { names = "bStation", types = "Byte", data = 0 },
    { names = "iVersion", types = "Byte", data = 0 },
    { names = "iVersion2", types = "Byte", data = 0 },
    { names = "iLeftTick", types = "Int32", data = 0 },
    { names = "iXiaZhuTime", types = "Int32", data = 0 },
    { names = "iSendCardTime", types = "Int32", data = 0 },
    { names = "iAccountTick", types = "Int32", data = 0 },

    { names = "iChouMaNum", types = "Int32", data = 0 },
    { names = "iChouMa", types = "Int32[]", length = 10, data = {} },
    { names = "cbCurGames", types = "Byte", data = 0 },

    { names = "iCardTypeRecordItemCount", types = "Byte", data = 0 },
    { names = "tagCardTypeRecordItem", types = "Byte[]", length = 60, data = {} },

    { names = "cbLuckerDeskStation", types = "Byte", data = 0 },
    { names = "cbLuckerWinRate", types = "Byte", data = 0 },

    { names = "NoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "SelfNoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "iLuckerNoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "cbNoted", types = "Byte[]", length = 180, data = {} },

    { names = "bDeskStation", types = "Byte", data = 0 },
    { names = "cbOpenCard", types = "Byte[]", length = 2, data = {} },
  },

  CMD_GM_Station_Account= --结算
  {
    { names = "bStation", types = "Byte", data = 0 },
    { names = "iVersion", types = "Byte", data = 0 },
    { names = "iVersion2", types = "Byte", data = 0 },
    { names = "iLeftTick", types = "Int32", data = 0 },
    { names = "iXiaZhuTime", types = "Int32", data = 0 },
    { names = "iSendCardTime", types = "Int32", data = 0 },
    { names = "iAccountTick", types = "Int32", data = 0 },

    { names = "iChouMaNum", types = "Int32", data = 0 },
    { names = "iChouMa", types = "Int32[]", length = 10, data = {} },
    { names = "cbCurGames", types = "Byte", data = 0 },

    { names = "iCardTypeRecordItemCount", types = "Byte", data = 0 },
    { names = "tagCardTypeRecordItem", types = "Byte[]", length = 60, data = {} },

    { names = "cbLuckerDeskStation", types = "Byte", data = 0 },
    { names = "cbLuckerWinRate", types = "Byte", data = 0 },

    { names = "NoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "SelfNoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "iLuckerNoteMoney", types = "Int64[]", length = 3, data = {} },
    { names = "cbNoted", types = "Byte[]", length = 180, data = {} },
    
    { names = "bDeskStation", types = "Byte", data = 0 },
    { names = "cbOpenCard", types = "Byte[]", length = 2, data = {} },

    { names = "iWinMoney", types = "Int64", data = 0 },
  },
  CardTypeRecordItem= --牌型录单
  {
    { names = "cbWinObject", types = "Byte", data = 0 },
    { names = "cbCardData", types = "Byte[]", length = 2, data = {} },
  },
  WinTypeRecordItem= --红黑录单
  {
    { names = "cbWinObject", types = "Byte", data = 0 },
    { names = "uWinCount", types = "UInt32", data = 0 },
  },
  CMD_GR_PoolData_Fresh= --奖池刷新
  {
    { names = "uRoomId", types = "UInt32", data = 0 },
    { names = "iPoolMoney", types = "Int64", data = 0 },
  },
  CMD_GR_PoolData_Distrubute= --派奖
  {
    { names = "uRoomId", types = "UInt32", data = 0 },
    { names = "uDeskId", types = "UInt32", data = 0 },
    { names = "uUserId", types = "UInt32", data = 0 },
    { names = "uCardType", types = "UInt32", data = 0 },
    { names = "uPoolMoney", types = "UInt32", data = 0 },
  },
  CMD_GR_PoolConfig= --奖池配置
  {
    { names = "CardTypePro", types = "Int32[]", length = 10, data = {} },
    { names = "CardTypeProCount", types = "Byte", data = 0 },
    { names = "cbPoolSwitch", types = "Byte", data = 0 },
    { names = "TaxKind", types = "Byte", data = 0 },
    { names = "Tax", types = "Int32", data = 0 },
    { names = "iFetchPercent", types = "Int32", data = 0 },
  },
  SUB_GM_PoolRecord= --奖池录单
  {
    { names = "sName", types = "Byte[]", length = 80, data = {} },
    { names = "sTime", types = "Byte[]", length = 19, data = {} },
    { names = "bCardType", types = "Byte", data = 0 },
    { names = "cbFace", types = "UInt32", data = 0 },
    { names = "iPoolMoney", types = "Int32", data = 0 },
  },
  SUB_GM_Limit= --限制注码
  {
    { names = "iLimitVlue", types = "Int64", data = 0 },
  },
}