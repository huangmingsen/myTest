local GameRecordCardItem =
{
}

function GameRecordCardItem:new(trans)
	local _instance =
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self
	setmetatable(_instance, self)
	return _instance
end
function GameRecordCardItem:InitUI()
	self.IconCard = FindChildByName(self.transform, "Icon_LD_Target", "UISprite")
	self.IconHe = FindChildByName(self.transform, "Icon_LD_Target1", "gameObject")
	self.isFirst = FindChildByName(self.transform, "Icon_New_Sign", "gameObject")
end

function GameRecordCardItem:SetInfo1(winInfo) --珠盘路
	local nameStr = {"Icon_LD_DL_Hu","Icon_LD_DL_Long"}
	self.IconCard.gameObject:SetActive(false)
	self.IconHe:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1][1]+1]
		if winInfo[1][2] == 1 then
			self.IconHe:SetActive(true)
		end
	end
end
function GameRecordCardItem:SetInfo2(winInfo) --大眼路
	local nameStr = {"Icon_LD_DL_Hu","Icon_LD_DL_Long"}
	self.IconCard.gameObject:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1]+1]
	end
end
function GameRecordCardItem:SetInfo3(winInfo) --小眼路
	local nameStr = {"Icon_LD_DL_Hu","Icon_LD_DL_Long"}
	self.IconCard.gameObject:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1]+1]
	end
end
function GameRecordCardItem:SetInfo4(winInfo) --小强路
	local nameStr = {"Icon_LD_YYL_Hu","Icon_LD_YYL_Long"}
	self.IconCard.gameObject:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1]+1]
	end
end
function GameRecordCardItem:SetInfo5(cardType,flag) --录单总
	local nameStr = {"Icon_LD_ZPL_Hu","Icon_LD_ZPL_Long","Icon_LD_ZPL_He"}
	self.IconCard.gameObject:SetActive(false)
	if(flag) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[cardType + 1]
	end
end
function GameRecordCardItem:SetInfo6(cardType,flag) -- 桌面结果
	local nameStr = {"Icon_LD_Hu","Icon_LD_Long","Icon_LD_He"}
	self.IconCard.gameObject:SetActive(false)
	if(flag) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[cardType + 1]
	end
end

return GameRecordCardItem