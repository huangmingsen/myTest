local bit = require"bit"
local GameLogic = require "642.GameLogic"
local GameHelp = require "642.GameHelp"
local GamePlayerGroup = require "642.GamePlayerGroup"
local GameTimeClock = require "642.GameTimeClock"
local GameRecord = require "642.GameRecord"
local GamePlayerList = require "642.GamePlayerList"
local GameGoldManager = require "642.GameGoldManager"
local GameRecordCardItem = require "642.GameRecordCardItem"
-- local GameUIJiangChi = require "642.GameUIJiangChi"
--local GameUIWinPool = require "642.GameUIWinPool"
local GameUIRecord = require "642.GameUIRecord"
local GameSet = require "642.GameSet"
GameUIManager = 
{
	Game_Group,
	PanelSecond,
	BtnSet,
	BtnHelp,
	BtnExit,
	BtnChat,
	BtnBank1,
	BtnBank2,
	BtnJiangChi,
	
	BtnContinue,
	BtnMenu,--菜单
	BtnRecord,
	BtnUIRecord,
	BtnOnLine,
	BtnBet = {},
	BtnPlayers = {},
	LbMyBets = {},
	LbAllBets = {},
	BtnChips = {},
	LbOnLinePlayer,
	LbJiangChi,
	GoRedDot,
	GoGameBack,
	GoBetFocus,
	TipGroup = {},
	GoWinFlash = {},
	IconWinFlash = {},
	IconCards = {},
	GoCardBacks = {},
    GoFire = {},
    GoWinRay = {},
	AniOpenPrizes = {},
	players = {},
	recordCards = {},
	TwpMenu,
	IconMenuBack,
	GoGoleItem,
	GoLuckyItem,
	GoLuckySign = {},

	SliderLuckys = {},
	LbLucky,

	GoStartAnima,

	IconGameLevel,

	BtnRecharge,
	LbRecharge,
	GoRecharge,

    BetPos = {Vector3.New(294, -45, -15),Vector3.New(-294, -45, -15),Vector3.New(-0, -35, -15)},

	mWinLose = 0,
	dataCard = {},
	dataPrize = {},
	mMyBets = {0,0,0},
	mTotalBets = {0,0,0},
	recordData1 = {},
	recordData2 = {},
	recordCountData = {0,0,0}, -- 桌面红黑

	mStateTime = {},
	mBase = { 2, 2, 3, 4, 10, 15},
	mChips = {},
	mCheckIndex = 1,
	m_CurGameCount, --总下注
	mStation = -1,
	onLineUserList = {},
	JiangChiState = false,


	GoWinPool,
    jiangChiList = {},
    prizeList = {},
    ipoolMoney = 0,
    iTaxVlue = 0,
	iGameCount = -1,

	coroutineParent,
	MainBtnRecharge,
}
local iLowNoteLimit = 0
local noteTime = 0
local openPrizeTime = 0
local LuckyUserStation = -1-- 幸运星座位号
local LuckyPos = {Vector3.New(167, 59, 0),Vector3.New(-411, 59, 0),Vector3.New(-119, 59, 0)}
local isPlayLucky = { false, false, false }
local isRefLucky = true
local isGameAnima = false
local MyWinLose = 0
local PlayerNote = {}


function GameUIManager.Awake()
	GameUIManager.iGameCount = -1
	GameUIManager.Game_Group = FindChildByName(GameUIManager.transform,"UI_LHD/UIStretch/Group/Game_Group")
	GameUIManager.PanelSecond = FindChildByName(GameUIManager.transform,"UI_LHD/PanelSecond/UIStretch/Group")
	--GameUIManager.BtnSet = FindChildByName(GameUIManager.Game_Group,"Btn_Group/Menu/Content/BtnSet","gameObject")
	GameUIManager.BtnHelp = FindChildByName(GameUIManager.Game_Group,"Btn_Group/Menu/Content/BtnRule","gameObject")
	GameUIManager.BtnExit = FindChildByName(GameUIManager.Game_Group,"Btn_Group/BtnClose","gameObject")
	GameUIManager.BtnUIRecord = FindChildByName(GameUIManager.Game_Group,"Btn_Group/Menu/Content/BtnRecord","gameObject")
	GameUIManager.BtnBank1 = FindChildByName(GameUIManager.Game_Group,"Btn_Group/BtnBank","gameObject")
	GameUIManager.BtnBank2 = FindChildByName(GameUIManager.Game_Group,"Btn_Group/Menu/Content/BtnBank","gameObject")
	GameUIManager.BtnContinue = FindChildByName(GameUIManager.Game_Group,"Btn_Group/BtnXuYa","gameObject")
	GameUIManager.BtnMenu = FindChildByName(GameUIManager.Game_Group,"Btn_Group/BtnMenu","gameObject")
	GameUIManager.BtnRecord = FindChildByName(GameUIManager.Game_Group,"Btn_Group/BtnZouShi","gameObject")
	GameUIManager.BtnOnLine = FindChildByName(GameUIManager.Game_Group,"BtnOnLine","gameObject")
	GameUIManager.BtnJiangChi = FindChildByName(GameUIManager.Game_Group,"BtnJiangChi","gameObject")
	GameUIManager.BtnJiangChi:SetActive(false)
	GameUIManager.BtnRecharge = FindChildByName(GameUIManager.Game_Group, "CZ_Tips/BtnRecharge","gameObject")
	GameUIManager.BtnChat = FindChildByName(GameUIManager.Game_Group,"BtnChat","gameObject")
    GameUIManager.BtnChat.gameObject:SetActive(MainMenus.IsShowChat)
    GameUIManager.MainBtnRecharge = FindChildByName(GameUIManager.Game_Group, "Btn_Group/BtnRecharge","gameObject")
	for i = 1, 3 do
		GameUIManager.BtnBet[i] = FindChildByName(GameUIManager.Game_Group,"UIBet/Button_"..(i-1).."/Button","gameObject")
		GameUIManager.LbMyBets[i] = FindChildByName(GameUIManager.Game_Group,"UIBet/Button_"..(i-1).."/Label_Me","UILabel")
		GameUIManager.LbAllBets[i] = FindChildByName(GameUIManager.Game_Group,"UIBet/Button_"..(i-1).."/Label_ZY","UILabel")
		GameUIManager.GoLuckySign[i] = FindChildByName(GameUIManager.Game_Group,"UIBet/Button_"..(i-1).."/Icon_SSZ_Sign","gameObject")
	end
	for i = 1, 6 do
		GameUIManager.BtnChips[i] = FindChildByName(GameUIManager.Game_Group,"Btn_Group/CM_Group/Button_CM"..(i-1),"gameObject")
	end
	GameUIManager.LbRecharge = FindChildByName(GameUIManager.Game_Group,"CZ_Tips/Label_Tips","UILabel")
	GameUIManager.GoRecharge = FindChildByName(GameUIManager.Game_Group,"CZ_Tips","gameObject")
	GameUIManager.LbOnLinePlayer = FindChildByName(GameUIManager.Game_Group,"BtnOnLine/Label_Player","UILabel")
	GameUIManager.LbOnLinePlayer.gameObject:SetActive(false)
	-- GameUIManager.LbJiangChi = FindChildByName(GameUIManager.Game_Group,"BtnJiangChi/Label_Coin","UILabel")
	GameUIManager.GoRedDot = FindChildByName(GameUIManager.Game_Group,"BtnChat/IconRedDot","gameObject")
	GameUIManager.GoGameBack = FindChildByName(GameUIManager.Game_Group,"BtnGameBack","gameObject")
	GameUIManager.GoBetFocus = FindChildByName(GameUIManager.Game_Group,"Btn_Group/CM_Group/Check_Ray","gameObject")
	GameUIManager.GoBetFocus:SetActive(false)

	GameUIManager.SliderLuckys[1] = FindChildByName(GameUIManager.Game_Group,"SSZ_Group/Slider/Icon_Hu","UISlider")
	GameUIManager.SliderLuckys[2] = FindChildByName(GameUIManager.Game_Group,"SSZ_Group/Slider/Icon_Long","UISlider")
	GameUIManager.LbLucky = FindChildByName(GameUIManager.Game_Group,"SSZ_Group/Label","UILabel")

	GameUIManager.GoStartAnima = FindChildByName(GameUIManager.Game_Group,"VS_Ani","gameObject")

	GameUIManager.TipGroup[1] = FindChildByName(GameUIManager.Game_Group,"TipsGroup/Tips_1","gameObject")
	GameUIManager.TipGroup[2] = FindChildByName(GameUIManager.Game_Group,"TipsGroup/Tips_Start","gameObject")
	GameUIManager.TipGroup[3] = FindChildByName(GameUIManager.Game_Group,"TipsGroup/Tips_Stop","gameObject")
    GameUIManager.GoWinFlash[1] = FindChildByName(GameUIManager.Game_Group,"Win_Ani/Win_Hu_Ani","gameObject")
    GameUIManager.GoWinFlash[2] = FindChildByName(GameUIManager.Game_Group,"Win_Ani/Win_Long_Ani","gameObject")
    GameUIManager.GoWinFlash[3] = FindChildByName(GameUIManager.Game_Group,"Win_Ani/Win_He_Ani","gameObject")
	GameUIManager.IconWinFlash[1] = FindChildByName(GameUIManager.Game_Group,"Win_Ani/Win_Hu_Ani/Flash_Hu","UISpriteAnimation")
	GameUIManager.IconWinFlash[2] = FindChildByName(GameUIManager.Game_Group,"Win_Ani/Win_Long_Ani/Flash_Long","UISpriteAnimation")
	GameUIManager.IconWinFlash[3] = FindChildByName(GameUIManager.Game_Group,"Win_Ani/Win_He_Ani/Flash_He","UISpriteAnimation")

	GameUIManager.IconCards[1] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Hu/Card/IconCard0","UISprite")
	GameUIManager.IconCards[2] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Long/Card/IconCard0","UISprite")
	GameUIManager.GoCardBacks[1] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Hu/Card/IconCard0_0","gameObject")
	GameUIManager.GoCardBacks[2] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Long/Card/IconCard0_0","gameObject")
    GameUIManager.GoFire[1] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Hu/Flash_Fire","gameObject")
    GameUIManager.GoFire[2] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Long/Flash_Fire","gameObject")
    GameUIManager.GoWinRay[1] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Hu/Flash_Win_Ray","gameObject")
    GameUIManager.GoWinRay[2] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Long/Flash_Win_Ray","gameObject")

	GameUIManager.AniOpenPrizes[1] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Hu/Card","Animation")
	GameUIManager.AniOpenPrizes[2] = FindChildByName(GameUIManager.Game_Group,"CardTeam/Card_Long/Card","Animation")

	for i = 1, 7 do
		local transPath=nil
		if(i==1) then
			transPath="Playeritems/"..(i-1)
		elseif(i>=3 and i<=5 ) then
			transPath="Playeritems/Left/"..(i-1)
		else
			transPath="Playeritems/Right/"..(i-1)
		end
		local tranItem = FindChildByName(GameUIManager.Game_Group,transPath)
		print("@@@@@@@@@@@@@@@@@@@@@@@@@@@    i:",i,"  transPath:",transPath)
		GameUIManager.players[i] = GamePlayerGroup:new(tranItem)
		GameUIManager.players[i]:InitUI(i)
		GameUIManager.BtnPlayers[i] = FindChildByName(GameUIManager.Game_Group,transPath.."/IconHeadBox","gameObject")
	end
	for i = 1, 12 do
		local tranItem = FindChildByName(GameUIManager.Game_Group,"LD_Group/LD_Team/LD_Items"..tostring(i))
		GameUIManager.recordCards[i] = GameRecordCardItem:new(tranItem)
		GameUIManager.recordCards[i]:InitUI()
	end
	GameUIManager.TwpMenu = FindChildByName(GameUIManager.Game_Group,"Btn_Group/Menu/Content","TweenPosition")
	GameUIManager.IconMenuBack = FindChildByName(GameUIManager.Game_Group,"Btn_Group/Menu/Content/MenuBack","UISprite")
	GameUIManager.GoGoleItem = FindChildByName(GameUIManager.Game_Group,"CMParent/CMItem","gameObject")
	GameUIManager.GoLuckyItem = FindChildByName(GameUIManager.Game_Group,"Icon_LuckySign_Fly","gameObject")
	GameUIManager.IconGameLevel = FindChildByName(GameUIManager.Game_Group, "BtnGameBack/Icon_Level_Target","UISprite")
	-- local gameLVName = {"Txt_ChangCi1","Txt_ChangCi2","Txt_ChangCi3","Txt_ChangCi4"}
	-- GameUIManager.IconGameLevel.spriteName = gameLVName[UIRoom.SelectRoomInfo.iRoomLevel+1]
	GameUIManager.IconGameLevel.gameObject:SetActive(false)

	GameSet.transform = FindChildByName(GameUIManager.Game_Group,"Btn_Group/Menu/Content")
	GameHelp.transform = FindChildByName(GameUIManager.PanelSecond,"GameHelp")
	GameTimeClock.transform = FindChildByName(GameUIManager.Game_Group,"TimeCount")
	GamePlayerList.transform = FindChildByName(GameUIManager.PanelSecond,"Player_List")
	GameGoldManager.transform = FindChildByName(GameUIManager.Game_Group,"CMParent")
	GameRecord.transform = FindChildByName(GameUIManager.PanelSecond,"GameLD")
    GameUIRecord.transform = FindChildByName(GameUIManager.PanelSecond,"GameUIRecord")
    -- GameUIJiangChi.transform = FindChildByName(GameUIManager.PanelSecond,"Game_JiangChi")
    -- GameUIManager.GoWinPool = FindChildByName(GameUIManager.PanelSecond,"Game_JiangChi_Win","gameObject")
    GameTimeClock.Awake()
    GameHelp.Awake()
	GameSet.Awake()
    GameLogic.Awake()
    GameUIManager.EventStart()
    GameRecord.Awake()
    GameUIRecord.Awake()
    GamePlayerList.Awake()
    -- GameUIJiangChi.Awake()
    GameGoldManager.InitUI(GameGoldManager.transform, GameUIManager.GoGoleItem)
    GameUIManager.coroutineParent = coroutine.start(GameUIManager.StartNotking)
    --GameUIManager.ReSetGameUI()

end

function GameUIManager.EventStart()
	UIEventListener.Get(GameUIManager.BtnHelp).onClick = GameUIManager.OnBtnHelp
	UIEventListener.Get(GameUIManager.BtnExit).onClick = GameUIManager.OnBtnExit
	--UIEventListener.Get(GameUIManager.BtnSet).onClick = GameUIManager.OnBtnSet
	UIEventListener.Get(GameUIManager.BtnChat).onClick = GameUIManager.OnBtnChat
	UIEventListener.Get(GameUIManager.BtnBank1).onClick = GameUIManager.OnBtnBank
	UIEventListener.Get(GameUIManager.BtnBank2).onClick = GameUIManager.OnBtnBank
	UIEventListener.Get(GameUIManager.BtnContinue).onClick = GameUIManager.OnBtnContinue
	UIEventListener.Get(GameUIManager.BtnMenu).onClick = GameUIManager.OnBtnMenu
	UIEventListener.Get(GameUIManager.BtnRecord).onClick = GameUIManager.OnBtnRecord
	UIEventListener.Get(GameUIManager.BtnRecharge).onClick = GameUIManager.OpenRecharge
	UIEventListener.Get(GameUIManager.MainBtnRecharge).onClick = GameUIManager.OpenRecharge
	UIEventListener.Get(GameUIManager.BtnUIRecord).onClick = GameUIManager.OnBtnUIRecord
	UIEventListener.Get(GameUIManager.BtnOnLine).onClick = GameUIManager.OnBtnOnLine
	for i=1,3 do
		UIEventListener.Get(GameUIManager.BtnBet[i]).onClick = GameUIManager.OnBetCallback
	end
	for i=1,6 do
		UIEventListener.Get(GameUIManager.BtnChips[i]).onClick = GameUIManager.OnChooseBetCallback
	end

	-- UIEventListener.Get(GameUIManager.BtnJiangChi).onClick = GameUIManager.OpenJiangChiPlane
    if lobyUIRadio ~= nil then
        lobyUIRadio.GameChatTypeFunc = GameUIManager.SetGameChatType
    end
	if IsClosePay then
		GameUIManager.MainBtnRecharge:SetActive(false)
	end
	if(not CommonBase.IsShowBank) then
		GameUIManager.IconMenuBack.transform.localScale = Vector3.New(1, 0.8, 1)
		GameUIManager.BtnBank1:SetActive(false)
		GameUIManager.BtnBank2:SetActive(false)
	end
end

function GameUIManager.StartNotking()
    coroutine.wait(0.2)
    UIRoom.StartListenData()--资源初始化完成，开始接收消息
    GameAudioContro.PlayBG(GameAudioContro.BGM)

	UpdateBeat:Add(GameUIManager.Update)
end

function GameUIManager.ReSetGameUI() -- 重置游戏
	-- mMyBets = {0,0,0}
	-- mTotalBets = {0,0,0}
    -- GameUIManager.prizeList = {}
	if(GameUIManager.coroutineParent ~= nil) then
		coroutine.stop(GameUIManager.coroutineParent)
		GameUIManager.coroutineParent = nil
	end
	for i = 1, 180 do
		PlayerNote[i] = {0,0,0}
	end
	GameUIManager.UpDateChooseBet(1)
	GameUIManager.UpdateLuckyInfo(0)
	GameUIManager.ReSetOpenUI()
	GameUIManager.HideWinFlash()
	GameUIManager.ShowOrHideStartAnima(false)
	GameHelp.transform.gameObject:SetActive(false)
	-- GameUIJiangChi.transform.gameObject:SetActive(false)
	-- GameUIManager.GoWinPool:SetActive(false)
	GameUIManager.RefreshUserInfo()
end

function GameUIManager.OnBtnHelp()--帮助界面
    GameAudioContro.Play(GameAudioContro.ClickAud)
	GameHelp.Show(GameUIManager.iTaxVlue,GameUIManager.JiangChiState)
end
function GameUIManager.OnBtnExit()--退出游戏
    GameAudioContro.Play(GameAudioContro.ClickAud)
	local mybet = 0
	for i=1, #GameUIManager.mMyBets do
		mybet = mybet + GameUIManager.mMyBets[i]
	end
	if mybet > 0 then
		LblMsgText.Show("The game is in progress,you cannot exit the game")
    else
		local func=function()
		end
		MessageBox.Show("Are you sure you want to quit the game?", UIRoom.QuitGame,func)
	end
end

function GameUIManager.OnBtnSet()--打开声音设置
    GameAudioContro.Play(GameAudioContro.ClickAud)
	UIGameLoad.OpenGameSet()
end
function GameUIManager.OnBtnChat()--打开聊天
    GameAudioContro.Play(GameAudioContro.ClickAud)
	HallUIManager.OnBtnChat()
	GameUIManager.GoRedDot:SetActive(false)
end
function GameUIManager.SetGameChatType()
    GameUIManager.GoRedDot:SetActive(true)
end
function GameUIManager.OnBtnBank()--打开银行

end
function GameUIManager.OnBtnContinue()--续压
    GameAudioContro.Play(GameAudioContro.ClickAud)
	local mybet = 0
	for i=1, #GameUIManager.mMyBets do
		mybet = mybet + GameUIManager.mMyBets[i]
	end
	if mybet > 0 then
		LblMsgText.Show("You have placed a bet. You cannot repeat")
    else
    	NetManager:SendData(2000180, GameProtocal.GM_SUB_CONTINUE)
    end
end
function GameUIManager.OnBtnMenu()--菜单
    if (GameUIManager.TwpMenu.transform.localPosition.y < 0) then
		GameUIManager.BtnMenu:GetComponent("UIButton").normalSprite = "UI_BT_Down"
        GameUIManager.TwpMenu.from = Vector3.New(0, -540, 0)
        GameUIManager.TwpMenu.to = Vector3.New(0, 100, 0)
        GameUIManager.TwpMenu.enabled = true
        GameUIManager.TwpMenu:ResetToBeginning()
        GameUIManager.TwpMenu:PlayForward()
    else
		GameUIManager.BtnMenu:GetComponent("UIButton").normalSprite = "UI_BT_Up"
        GameUIManager.TwpMenu.from = Vector3.New(0, 100, 0)
        GameUIManager.TwpMenu.to = Vector3.New(0, -540, 0)
        GameUIManager.TwpMenu.enabled = true
        GameUIManager.TwpMenu:ResetToBeginning()
        GameUIManager.TwpMenu:PlayForward()
    end
end
function GameUIManager.OnBtnRecord()--录单
    GameAudioContro.Play(GameAudioContro.ClickAud)
    GameRecord.ShowUi()
end
function GameUIManager.OnBtnUIRecord()--打开游戏记录
    GameAudioContro.Play(GameAudioContro.ClickAud)
    GameUIRecord.show()
end
function GameUIManager.OpenRecharge()
	HallUIManager.OnBtnRecharge()
end
function GameUIManager.ShowRecharge()
	GameUIManager.LbRecharge.text ="In the watch mode, you need ".. FormatNumToYW(MoneyProportionStr(iLowNoteLimit)).." coins to play the game"
	--"[DBCC89FF]处于观战模式，需要[-][86F351FF]"..GameLogic.FormatNumToStringYW(MoneyProportionStr(iLowNoteLimit)).."[-][DBCC89FF]金币即可参与游戏！[-]"
	GameUIManager.GoRecharge:SetActive(true)
end
function GameUIManager.HideRecharge()
	GameUIManager.GoRecharge:SetActive(false)
end
function GameUIManager.OnBtnOnLine()--在线列表
    GameAudioContro.Play(GameAudioContro.ClickAud)
    GamePlayerList.ShowUI()
end
function GameUIManager.OnBetCallback(obj)--下注
    GameAudioContro.Play(GameAudioContro.ClickAud)
    if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
    	return
    end
    if GameUIManager.mStation ~= 1 then
    	--LblMsgText.Show("不在下注时间，不可下注!")
		LblMsgText.Show("Not Bet Time")
		return
    end
	for i = 1,#GameUIManager.BtnBet do
		if obj == GameUIManager.BtnBet[i] then
		    GameProtocal.CMD_GM_Note[1].data = MyUserInfo.iDeskStation
		    GameProtocal.CMD_GM_Note[2].data = GameUIManager.mCheckIndex-1
		    GameProtocal.CMD_GM_Note[3].data = (i-1)
			local sendbet = DataParseLua.StructToBytes(GameProtocal.CMD_GM_Note)
		    NetManager:SendData(sendbet, 2000180, GameProtocal.GM_SUB_NOTE)
			return
		end
	end
end
function GameUIManager.OnChooseBetCallback(obj)--选择筹码
    GameAudioContro.Play(GameAudioContro.ClickAud)
	for i=1,#GameUIManager.BtnChips do
		if obj == GameUIManager.BtnChips[i] then
			GameUIManager.UpDateChooseBet(i)
			return
		end
	end
end
function GameUIManager.UpDateChooseBet(index)
	GameUIManager.mCheckIndex = index
	GameUIManager.GoBetFocus:SetActive(true)
	GameUIManager.GoBetFocus.transform.parent=GameUIManager.BtnChips[GameUIManager.mCheckIndex].gameObject.transform
	GameUIManager.GoBetFocus.transform.localPosition=Vector3.New(1, 5, 1)
    --SetParent(GameUIManager.BtnChips[GameUIManager.mCheckIndex].gameObject,GameUIManager.GoBetFocus)
end
function GameUIManager.SetChouMaBetButtonIsEnable()
	local myBetMoney = 0
	for i = 1, 3 do
		myBetMoney = myBetMoney + GameUIManager.mMyBets[i]
	end
	local myMoney = tonumber(tostring(MyUserInfo.iMoney)) - myBetMoney
	local chipLen = #GameUIManager.mChips
	if GameUIManager.mChips[1] > myMoney then
		GameUIManager.ShowOrHideChooseBetIndex(0)
	else
		for i = 1,chipLen do
			local chipIndex = chipLen+1-i
			if GameUIManager.mChips[chipIndex] <= myMoney then
				GameUIManager.ShowOrHideChooseBetIndex(chipIndex)
				break
			end
		end
	end
	if GameUIManager.mChips[GameUIManager.mCheckIndex] > myMoney then
		local chipLen = #GameUIManager.mChips
		if GameUIManager.mChips[1] > myMoney then
			GameUIManager.UpDateChooseBet(1)
		else
			for i = 1,chipLen do
				local chipIndex = chipLen+1-i
				if GameUIManager.mChips[chipIndex] <= myMoney then
					GameUIManager.UpDateChooseBet(chipIndex)
					break
				end
			end
		end
	end
end

function GameUIManager.ShowOrHideChooseBetIndex(index)
	for i = 1, #GameUIManager.BtnChips do
		if i<=index then
			GameUIManager.BtnChips[i]:GetComponent("UIButton").isEnabled = true
			GameUIManager.BtnChips[i]:GetComponent("Collider").enabled = true
		else
			GameUIManager.BtnChips[i]:GetComponent("UIButton").isEnabled = false
			GameUIManager.BtnChips[i]:GetComponent("Collider").enabled = false
		end
	end
end



function GameUIManager.UpdateBetInfo(bets)
    local len = 6
    if (#bets > 6) then
        len = 6
	else
		len = #bets
	end
	for i = 1, len do
        local btn = GameUIManager.BtnChips[i]
		if ( btn ) then
			local label = btn:GetComponentInChildren(System.Type.GetType("UILabel"))
			if ( nil ~= label ) then
				label.text = FormatNoteNumToYW(MoneyProportionStr(bets[i]))
			end
		end
	end
end

function GameUIManager.RefreshUserInfo()
	-- 更新总下注
	for i = 1, 3 do
        GameUIManager.LbMyBets[i].text = MoneyProportionStr(GameUIManager.mMyBets[i])
        GameUIManager.LbAllBets[i].text = MoneyProportionStr(GameUIManager.mTotalBets[i])
	end
	--幸运星下注
	if LuckyUserStation >= 0 and LuckyUserStation < 180 then
		local allLucyNote = 0
		for i = 1, 3 do
			allLucyNote = PlayerNote[LuckyUserStation + 1][i] + allLucyNote
		end
		if allLucyNote > 0 then
			GameUIManager.SliderLuckys[1].transform.parent.gameObject:SetActive(true)
			GameUIManager.SliderLuckys[1].value = PlayerNote[LuckyUserStation + 1][1]/allLucyNote
			GameUIManager.SliderLuckys[2].value = PlayerNote[LuckyUserStation + 1][2]/allLucyNote
		else
			GameUIManager.SliderLuckys[1].transform.parent.gameObject:SetActive(false)
		end
	else
		GameUIManager.SliderLuckys[1].transform.parent.gameObject:SetActive(false)
	end
end

--玩家更新
function GameUIManager.UpDateSelfMoney()
	local money = tonumber(tostring(MyUserInfo.iMoney))
	for i = 1, 3 do
		money = money -GameUIManager.mMyBets[i]
	end
	GameUIManager.players[1]:UpdateUserMoney(money)
end
function GameUIManager.UpDateUserInfo(userInfo)
	for i=1,#GameUIManager.players do
		local info = GameUIManager.players[i]:GetPlayerInfo()
		if(info~=nil) then
			if userInfo.uiUserID == info[1] then
				if userInfo.uiUserID == MyUserInfo.uiUserID then
					local money = tonumber(tostring(MyUserInfo.iMoney))
					if GameUIManager.mStation == 1 or GameUIManager.mStation == 2 or isGameAnima then
						for i = 1, 3 do
							money = money -GameUIManager.mMyBets[i]
						end
						money = money - MyWinLose
					end
					GameUIManager.players[i]:UpdateUserMoney(money)
				end
				GameUIManager.players[i]:UpdateUserLV(userInfo.iVipLevel)
			end
		end
	end
end
function GameUIManager.UpDatePlayerInfo()
	local playerList = GameSUserBaseInfo.userinfolist
	GameUIManager.onLineUserList = {}
	for i = 1, #playerList do
		if playerList[i].iDeskStation < 180 then
			if playerList[i].iDeskStation ~= LuckyUserStation then
				local info = {}
				local snopPlayMoney = tonumber(tostring(playerList[i].iMoney)) or 0
				for k = 1, 3 do
					snopPlayMoney = snopPlayMoney -  PlayerNote[playerList[i].iDeskStation + 1][k]
				end
				info = {playerList[i].uiUserID,playerList[i].iImageNO,playerList[i].iPhotoFrame,playerList[i].szNickName,snopPlayMoney,
						playerList[i].szGameSign,playerList[i].iVipLevel,playerList[i].iWinCount,playerList[i].iLostCount,playerList[i].iDrawCount}
				table.insert(GameUIManager.onLineUserList,info)
			end
		end
	end
	local snopMyMoney = tonumber(tostring(MyUserInfo.iMoney))
	for k = 1, 3 do
		snopMyMoney = snopMyMoney -  PlayerNote[MyUserInfo.iDeskStation + 1][k]
	end
	local myInfo = {MyUserInfo.uiUserID,MyUserInfo.iImageNO,MyUserInfo.iPhotoFrame,MyUserInfo.szNickName,snopMyMoney,
					MyUserInfo.szGameSign,MyUserInfo.iVipLevel,MyUserInfo.iWinCount,MyUserInfo.iLostCount,MyUserInfo.iDrawCount}
	GameUIManager.players[1]:Set(myInfo)
	table.sort(GameUIManager.onLineUserList, function(a,b) return a[5] > b[5] end)
	local luckyUserInfo = GameLogic.finduserbyStation(LuckyUserStation)
	local luckyinfo = {}
	local isLucy = false
	if luckyUserInfo == nil then
		luckyinfo = {0,0,0,0,0,0,0,0,0,0}
	else
		local snopluckyMoney = tonumber(tostring(luckyUserInfo.iMoney))
		for k = 1, 3 do
			snopluckyMoney = snopluckyMoney -  PlayerNote[LuckyUserStation + 1][k]
		end
		luckyinfo = {luckyUserInfo.uiUserID,luckyUserInfo.iImageNO,luckyUserInfo.iPhotoFrame,luckyUserInfo.szNickName,tonumber(tostring(luckyUserInfo.iMoney)),
					 luckyUserInfo.szGameSign,luckyUserInfo.iVipLevel,luckyUserInfo.iWinCount,luckyUserInfo.iLostCount,luckyUserInfo.iDrawCount}
		isLucy = true
		table.insert(GameUIManager.onLineUserList,1,luckyinfo)
	end
	GameUIManager.players[2]:Set(luckyinfo)
	GamePlayerList.ReSetData(GameUIManager.onLineUserList,isLucy)
	GameUIManager.LbOnLinePlayer.text = tostring(#GameUIManager.onLineUserList)
end
function GameUIManager.UpDatePlanePlayerInfo(isRef)
	local userNum = 2
	if LuckyUserStation >= 0 and LuckyUserStation < 180 then
		userNum = 1
	end
	if isRef then
		for i=3,7 do
			if i-2 <= #GameUIManager.onLineUserList then
				GameUIManager.players[i]:Set(GameUIManager.onLineUserList[i-userNum])
			else
				local snopInfo = {0,0,0,0,0,0}
				GameUIManager.players[i]:Set(snopInfo)
			end
		end
	else
		if #GameUIManager.onLineUserList < 7 then
			for i=3,7 do
				if i-2 <= #GameUIManager.onLineUserList then
					GameUIManager.players[i]:Set(GameUIManager.onLineUserList[i-userNum])
				else
					local snopInfo = {0,0,0,0,0,0}
					GameUIManager.players[i]:Set(snopInfo)
				end
			end
		end
	end
end
function GameUIManager.AddUserAttri(msgData)
end
function GameUIManager.InsertPlayer(userInfo)
	if isGameAnima then
		return
	end
	for i=1,#GameUIManager.players do
		if(GameUIManager.players[i].transform.gameObject.activeSelf) then
			local info = GameUIManager.players[i]:GetPlayerInfo()
			if(info~=nil) then
				if info[1] == userInfo.uiUserID then
					return
				end
			end
		end
	end
	GameUIManager.UpDatePlayerInfo()
	GameUIManager.UpDatePlanePlayerInfo(false)
end
function GameUIManager.RemovePlayer(userInfo)
	if isGameAnima then
		return
	end
	for i=1,#GameUIManager.players do
		if(GameUIManager.players[i].transform.gameObject.activeSelf) then
			local info = GameUIManager.players[i]:GetPlayerInfo()
			if(info~=nil) then
				if info[1] == userInfo.uiUserID then
					return
				end
			end
		end
	end
	GameUIManager.UpDatePlayerInfo()
	GameUIManager.UpDatePlanePlayerInfo(false)
end

--显示牌背
function GameUIManager.SetAllCard(isstate)
    GameUIManager.IconCards[1].gameObject:SetActive(true)
    GameUIManager.IconCards[2].gameObject:SetActive(true)
	GameUIManager.GoCardBacks[1].gameObject:SetActive(false)
	GameUIManager.GoCardBacks[2].gameObject:SetActive(false)
    if(isstate == 0) then
		GameUIManager.GoFire[1].gameObject:SetActive(true)
		GameUIManager.GoFire[2].gameObject:SetActive(true)
        GameUIManager.SetCardSprite(GameUIManager.IconCards[1], -1)
        GameUIManager.SetCardSprite(GameUIManager.IconCards[2], -1)
    elseif(isstate == 1) then
		GameUIManager.GoFire[1].gameObject:SetActive(false)
		GameUIManager.GoFire[2].gameObject:SetActive(false)
		local point1 = GameUIManager.GetCardPoint(GameUIManager.dataCard[2])
		local point2 = GameUIManager.GetCardPoint(GameUIManager.dataCard[1])
		if(point1 > point2) then
			GameUIManager.GoWinRay[2].gameObject:SetActive(true)
		elseif(point1 < point2) then
			GameUIManager.GoWinRay[1].gameObject:SetActive(true)
		elseif(point1 == point2) then
			GameUIManager.GoWinRay[1].gameObject:SetActive(true)
			GameUIManager.GoWinRay[2].gameObject:SetActive(true)
		end
        GameUIManager.SetCardSprite(GameUIManager.IconCards[1], GameUIManager.dataCard[1])
        GameUIManager.SetCardSprite(GameUIManager.IconCards[2], GameUIManager.dataCard[2])
    end
end
--显示牌背
function GameUIManager.SetLuckySign()
	for i = 1, 3 do
		if PlayerNote[LuckyUserStation + 1][i] > 0 then
			GameUIManager.GoLuckySign[i]:SetActive(true)
		end
	end

end
--显示牌背
function GameUIManager.SetBackCardSprite(image)
    image.gameObject:SetActive(true)
    GetComponent("UISprite").spriteName = "0_0"
end

--设置牌的图片
function GameUIManager.SetCardSprite(image, CardData)
    image.gameObject:SetActive(true)
    if (CardData <= 0) then
        image.spriteName = "0_0"
    else
        local color = bit.band(CardData, 0xF0)  --扑克花色
        local num = bit.band(CardData, 0x0F) --扑克数字
        color = color / 16 + 1
        num = num + 1
        --牌A
        if (num == 14) then
            num = 1
        end
        image.spriteName = color.."_"..num
    end
end
--获取牌点数
function GameUIManager.GetCardPoint(CardData)
    if (CardData <= 0) then
    	return 0
    else
        local num = bit.band(CardData, 0x0F) --扑克数字

        num = num + 1
        --牌A
        if (num == 14) then
            num = 1
        end
    	return num
    end
end
--获取牌点数
function GameUIManager.GetCardValue(CardData)
	local cardValue = {"A","J","Q","K"}
	local resultValue = 0
	if (CardData <= 0) then
		return resultValue
	else
		local num = bit.band(CardData, 0x0F) --扑克数字

		num = num + 1
		--牌A
		if (num == 14) then
			num = 1
		end
		resultValue = num
		if num == 1 then
			resultValue = cardValue[1]
		elseif num > 10 then
			resultValue = cardValue[num-9]
		end
		return resultValue
	end
end

--所有的下注按钮能不能点
function GameUIManager.EnabledBtn( bEnabled )
	-- 下注按钮
	-- for i = 1, #GameUIManager.BtnBet do
 --        GameUIManager.BtnBet[i]:GetComponent("Collider").enabled = bEnabled
	-- end
	GameUIManager.BtnContinue:GetComponent("Collider").enabled = bEnabled             -- 续押按钮
end
--开奖
function GameUIManager.OpenCardAnimation()
    GameUIManager.GoFire[1].gameObject:SetActive(false)
    GameUIManager.GoFire[2].gameObject:SetActive(false)
    GameUIManager.SetCardSprite(GameUIManager.IconCards[1], -1)
    GameUIManager.SetCardSprite(GameUIManager.IconCards[2], -1)
    coroutine.wait(1)
	for i = 1, 2 do
        GameUIManager.GoCardBacks[i]:SetActive(true)
	end
    local point1 = GameUIManager.GetCardPoint(GameUIManager.dataCard[2])
    local point2 = GameUIManager.GetCardPoint(GameUIManager.dataCard[1])
	GameAudioContro.Play(GameAudioContro.KaiPaiAud)
    GameUIManager.SetCardSprite(GameUIManager.IconCards[2], GameUIManager.dataCard[2])
    GameUIManager.AniOpenPrizes[2]:Play("FanPai")
    coroutine.wait(0.3)
    GameAudioContro.Play(GameAudioContro.CardPointAud[point1])
    coroutine.wait(1)
    GameAudioContro.Play(GameAudioContro.KaiPaiAud)
    GameUIManager.SetCardSprite(GameUIManager.IconCards[1], GameUIManager.dataCard[1])
    GameUIManager.AniOpenPrizes[1]:Play("FanPai")
    coroutine.wait(0.3)
    GameAudioContro.Play(GameAudioContro.CardPointAud[point2])
    coroutine.wait(1)
    if(point1 > point2) then
		GameAudioContro.Play(GameAudioContro.LongWinAud)
        GameUIManager.GoWinRay[2].gameObject:SetActive(true)
    elseif(point1 < point2) then
		GameAudioContro.Play(GameAudioContro.HuWinAud)
        GameUIManager.GoWinRay[1].gameObject:SetActive(true)
    elseif(point1 == point2) then
        GameUIManager.GoWinRay[1].gameObject:SetActive(true)
        GameUIManager.GoWinRay[2].gameObject:SetActive(true)
		GameAudioContro.Play(GameAudioContro.HeWinAud)
    end
    coroutine.wait(1)
    GameUIManager.GoCardBacks[1]:SetActive(false)
    GameUIManager.GoCardBacks[2]:SetActive(false)
end

function GameUIManager.OpenGoldAnima(scoreArr,winIndex,doNote)
	isRefLucky = false
	isGameAnima = true
	MyWinLose = scoreArr[MyUserInfo.iDeskStation]
    coroutine.wait(1)
    GameUIManager.PlayOpnePrizeFlash()
    GameGoldManager.AearCollectChip(GameUIManager.dataPrize, winIndex)
    coroutine.wait(0.5)
	for i = 1, #GameUIManager.dataPrize do
		if (GameUIManager.dataPrize[i] > 0) then
			GameAudioContro.Play(GameAudioContro.WinEffctAud[i])
		end
	end
	coroutine.wait(0.5)
    GameGoldManager.AearThrowChip(GameUIManager.dataPrize, winIndex) 
    coroutine.wait(1)
	GameGoldManager.FeiGoldToPlayer(GameUIManager.dataPrize, scoreArr)
    coroutine.wait(0.5)
	for i=1,#GameUIManager.players do
		if(GameUIManager.players[i].transform.gameObject.activeSelf) then
			local info = GameUIManager.players[i]:GetPlayerInfo()
			if(info~=nil) then
				local userinfo = GameSUserBaseInfo.finduserbyid(info[1])
				if(userinfo~=nil and userinfo.iDeskStation <=180) then
					if(scoreArr[userinfo.iDeskStation] ~= nil) then
						local pleyerMoney = tonumber(tostring(userinfo.iMoney))
						GameUIManager.players[i]:OpenPrizeAnimation(scoreArr[userinfo.iDeskStation],pleyerMoney,doNote[userinfo.iDeskStation] == 1)
					end
				end
			end
		end
	end
	coroutine.wait(2)
	isRefLucky = true
	isGameAnima = false
	MyWinLose = 0
	for i = 1, 180 do
		PlayerNote[i] = {0,0,0}
	end
	GameUIManager.UpDatePlayerInfo()
	GameUIManager.UpDatePlanePlayerInfo(true)
	coroutine.wait(1)
    GameGoldManager.HideAllGole()
    GameUIManager.ReSetOpenUI()
end
function GameUIManager.ReSetOpenUI()
	for i = 1, #GameUIManager.GoCardBacks do
        GameUIManager.GoCardBacks[i]:SetActive(true)
        GameUIManager.SetCardSprite(GameUIManager.IconCards[i], -1)
        GameUIManager.IconCards[i].gameObject:SetActive(true)
        GameUIManager.GoFire[i].gameObject:SetActive(true)
        GameUIManager.GoWinRay[i].gameObject:SetActive(false)
	end
	for i = 1, 3 do
		GameUIManager.GoLuckySign[i]:SetActive(false)
	end
end


--播放开奖区域灯光
function GameUIManager.PlayOpnePrizeFlash()
	for i = 1, #GameUIManager.dataPrize do
        if (GameUIManager.dataPrize[i] > 0) then
            GameUIManager.GoWinFlash[i].gameObject:SetActive(true)
			GameUIManager.IconWinFlash[i].enabled = true
			GameUIManager.IconWinFlash[i]:ResetToBeginning()
			GameUIManager.IconWinFlash[i]:Play()
			--GameUIManager.IconWinFlash[1].spriteName = "Flash_Hu_01"
        end
	end
end

function GameUIManager.HideWinFlash()
	for i = 1, #GameUIManager.GoWinFlash do
		if (GameUIManager.GoWinFlash[i].gameObject.activeSelf) then
		    GameUIManager.GoWinFlash[i].gameObject:SetActive(false)
		end
	end
end
function GameUIManager.ShowOrHideStartAnima(flag)
	GameUIManager.GoStartAnima:SetActive(flag)
	if flag then
		GameUIManager.coroutineParent = coroutine.start(GameUIManager.YildeHideStartAnima)
	end
end
function GameUIManager.YildeHideStartAnima()
	coroutine.wait(3)
	if GameUIManager.coroutineParent == nil then
		return
	end
	GameUIManager.GoStartAnima:SetActive(false)
end

function GameUIManager.PlayGoldAnimation(station, areaIndex, checkIndex)
	local formPos = nil
	if(station == MyUserInfo.iDeskStation) then
		formPos = GameUIManager.BtnChips[checkIndex].transform.localPosition
		local goldAnima = GameGoldManager.GetGoldAnima(areaIndex, checkIndex)
		local topos = GameLogic.GetRandomPostion(GameUIManager.BetPos[areaIndex])
		goldAnima:GotoPosition(formPos, topos, 0.4)
	else
		local userInfo = GameLogic.finduserbyStation(station)
		if userInfo ~=nil then
			local userId = userInfo.uiUserID
			for i=1,#GameUIManager.players do
				local info = GameUIManager.players[i]:GetPlayerInfo()
				if(info~=nil) then
					if(info[1] == userInfo.uiUserID) then
						formPos = GameUIManager.players[i].transform.localPosition
						GameUIManager.players[i]:PlayHeadAnima()
						local goldAnima = GameGoldManager.GetGoldAnima(areaIndex, checkIndex)
						local topos = GameLogic.GetRandomPostion(GameUIManager.BetPos[areaIndex])
						goldAnima:GotoPosition(formPos, topos, 0.4)
					end
				end
			end
			if(formPos == nil) then
				formPos = GameUIManager.BtnOnLine.transform.localPosition
				local goldAnima = GameGoldManager.GetGoldAnima(areaIndex, checkIndex)
				local topos = GameLogic.GetRandomPostion(GameUIManager.BetPos[areaIndex])
				goldAnima:GotoPosition(formPos, topos, 0.4)
			end
		end
	end

end
--续压飞金币
function GameUIManager.ContinuePlayGoldGruop(station, money, areaIndex)
    local checkIndexList = {}
    while (money > 0) do
        if (money < GameUIManager.mChips[1]) then
	        table.insert(checkIndexList, 1)
	        break
        end
        for i = 1, #GameUIManager.mChips do
        	local chipIndex = #GameUIManager.mChips-i+1
            if (money >= GameUIManager.mChips[chipIndex]) then
                money = money - GameUIManager.mChips[chipIndex]
        		table.insert(checkIndexList, chipIndex)
                break
            end
        end
    end
    for i = 1, #checkIndexList do
        GameUIManager.PlayGoldAnimation(station, areaIndex, checkIndexList[i])
    end
end
--region 奖池模块
-- 爆池列表
function GameUIManager.SetBtnJiangChiState(state)
	-- GameUIManager.JiangChiState = state
    -- if (not state) then
    --     GameUIManager.BtnJiangChi:SetActive(false)
    -- end
end
function GameUIManager.PoolDataRefresh(data)
	-- local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolData_Fresh)  
    -- GameUIManager.ipoolMoney = msg.iPoolMoney
    -- GameUIManager.LbJiangChi.text = MoneyProportionStr(GameUIManager.ipoolMoney)
    -- if (GameUIJiangChi~= null) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdatePoolData(GameUIManager.ipoolMoney)
    --     end
    -- end
end
function GameUIManager.Update()
	--if(UnityEngine.Input.GetKeyDown(UnityEngine.KeyCode.A)) then
	--	local prizeType = math.random(0,2)
	--	GameUIManager.GameRecordInster(prizeType)
	--end
end
function GameUIManager.PoolDataDistrubute(data) 
    -- GameUIManager.prizeList = {}
    -- local nLen = DataParseLua.GetLuaTableLength(GameProtocal.CMD_GR_PoolData_Distrubute)
    -- local count = data.mainMsg.Length / nLen
    -- local isMyDesk = false
    -- for i=1,count do
    --     local snopBytes = MyLuaInter.NewArray("byte", nLen)
    --     System.Array.Copy(data.mainMsg, (i-1) * nLen, snopBytes, 0, nLen)
	-- 	local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.CMD_GR_PoolData_Distrubute)   
    --     local userInfo = GameSUserBaseInfo.finduserbyid(cmdBigWin.uUserId)
    --     if (userInfo == nil) then
    --         return
    --     end
    --     if (MyUserInfo.iDeskNO == cmdBigWin.uDeskId) then
    --         local prizeInfoItem = {userInfo.szNickName,tostring(cmdBigWin.uPoolMoney), userInfo.iImageNO, cmdBigWin.uCardType,cmdBigWin.uUserId}
    --         table.insert(GameUIManager.prizeList,prizeInfoItem)
    --         isMyDesk = true
    --     end

    --     local nowTime = System.DateTime.Now.Hour..":"..System.DateTime.Now.Minute..":"..System.DateTime.Now.Second
    --     local jiangChiIinfoItem = {tostring(cmdBigWin.uPoolMoney), userInfo.szNickName, nowTime, userInfo.iImageNO, cmdBigWin.uCardType}
    --     if (#GameUIManager.jiangChiList>= 11) then
    --     	table.remove(GameUIManager.jiangChiList,1)
    --     end
    --     table.insert(GameUIManager.jiangChiList,jiangChiIinfoItem)
    -- end
    -- if (GameUIJiangChi ~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdateUI(GameUIManager.jiangChiList)
    --     end
    -- end
    -- if (isMyDesk) then
    --     isMyDesk = false
    --     local obj = UnityEngine.GameObject.Instantiate(GameUIManager.GoWinPool)
    --     obj:SetActive(true)
    --     SetParent(GameUIManager.PanelSecond.gameObject, obj)
    --     GameUIWinPool.transform = obj.transform
    --     GameUIWinPool.Awake()
    --     GameUIWinPool.ShowUi()
    --     GameUIWinPool.UpdateUI(GameUIManager.prizeList)
    --     UnityEngine.GameObject.Destroy(obj, 3)
    -- end
	-- for i=1,#GameUIManager.players do
	-- 	local info = GameUIManager.players[i]:GetPlayerInfo()
	-- 	if(info~=nil) then
	-- 		for j=1,#GameUIManager.prizeList do
	-- 			if(info[1] == GameUIManager.prizeList[j][5]) then
	-- 				GameUIManager.players[i]:PrizePool(tonumber(GameUIManager.prizeList[j][2]))
	-- 			end
	-- 		end
	-- 	end
	-- end
    --StartCoroutine(RefreshUserInfo());
end
function GameUIManager.PoolConfig(data)
	-- local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolConfig)  
	-- GameUIManager.SetBtnJiangChiState(msg.cbPoolSwitch == 1)
	-- if(msg.TaxKind == 2) then
    -- 	GameUIManager.iTaxVlue = msg.Tax
	-- else
    -- 	GameUIManager.iTaxVlue = 0
	-- end
    -- local config = MyLuaInter.NewArray("byte", msg.CardTypeProCount)
    -- System.Array.Copy(data.mainMsg, 0, config, 0, msg.CardTypeProCount)
    -- if (GameUIJiangChi ~= nil) then
	-- 	GameUIJiangChi.SetPlane(config,msg.iFetchPercent)
    -- end
end
function GameUIManager.PoolRecord(data)
    -- GameUIManager.jiangChiList = {}
    -- local nLen = DataParseLua.GetLuaTableLength(GameProtocal.SUB_GM_PoolRecord)
    -- local count = data.mainMsg.Length / nLen
    -- if (count > 10) then
    --     count = 10
    -- end
    -- for i=1,count do
    --     local snopBytes = MyLuaInter.NewArray("byte", nLen)
    --     System.Array.Copy(data.mainMsg, (count - i) * nLen, snopBytes, 0, nLen)
	-- 	local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.SUB_GM_PoolRecord)   
    --     local dTime = LuaInter.ByteArrayToString(cmdBigWin.sTime)
    --     local uName = LuaInter.ByteArrayToString(cmdBigWin.sName)
    --     local infoItem = {tostring(cmdBigWin.iPoolMoney), uName, dTime, cmdBigWin.cbFace, cmdBigWin.bCardType}
    --     table.insert(GameUIManager.jiangChiList,infoItem)
    -- end
end
function GameUIManager.OpenJiangChiPlane()
    -- if (GameUIJiangChi ~= null) then
    --     if (not GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.transform.gameObject:SetActive(true)
    --         GameUIJiangChi.ShowUi(GameUIManager.ipoolMoney)
    --         GameUIJiangChi.UpdateUI(GameUIManager.jiangChiList)
    --     end
    -- end
end
-- 开始或停止下注
function GameUIManager.StartOrStopDownBetBG(flag)
    if (flag) then
		GameUIManager.coroutineParent = coroutine.start(GameUIManager.GameStartAnima)
    else
	    GameAudioContro.Play(GameAudioContro.EndNoteAud)
        GameUIManager.ShowNoteTip(3,true)
    end
end
function GameUIManager.GameStartAnima()
	GameUIManager.ShowOrHideStartAnima(true)
	GameAudioContro.Play(GameAudioContro.StartEffectAud)
	coroutine.wait(1)
	GameAudioContro.Play(GameAudioContro.StartNoteAud)
	GameUIManager.ShowNoteTip(2,true)
end
-- 展示提示消息
function GameUIManager.ShowNoteTip(index,isYilde)
	GameUIManager.HideNoteTip()
    GameUIManager.TipGroup[index]:SetActive(true)
    if(isYilde) then
    	GameUIManager.coroutineParent = coroutine.start(GameUIManager.HideYildeNoteTip)
	end
end
function GameUIManager.HideYildeNoteTip()
    coroutine.wait(2)
	if GameUIManager.coroutineParent == nil then
		return
	end
    GameUIManager.HideNoteTip()
end
function GameUIManager.HideNoteTip()
	for i=1,#GameUIManager.TipGroup do
    	GameUIManager.TipGroup[i]:SetActive(false)
	end
end

function GameUIManager.GameRecordInster(prizeType)
	GameUIManager.iGameCount = GameUIManager.iGameCount + 1
	if GameUIManager.iGameCount > 255 then
		GameUIManager.iGameCount = 0
	end
	if(#GameUIManager.recordData2 > 0) then
		local data1 = GameUIManager.recordData2[#GameUIManager.recordData2]
		if prizeType == 2 then
			if data1[#data1][2] == 1 then
				local newArr = {data1[1][1],1}
				table.insert(GameUIManager.recordData2[#GameUIManager.recordData2],newArr)
			else
				GameUIManager.recordData2[#GameUIManager.recordData2][#data1][2] = 1
			end
		else
			if(data1[1][1] == prizeType) then
				local newArr = {prizeType,0}
				table.insert(GameUIManager.recordData2[#GameUIManager.recordData2],newArr)
			else
				local snopArr = {prizeType,0}
				local newArr = {snopArr}
				table.insert(GameUIManager.recordData2,newArr)
			end
		end
	else
		local newArr = {}
		if prizeType == 2 then
			local snopArr = {1,1}
			newArr = {snopArr}
		else
			local snopArr = {prizeType,0}
			newArr = {snopArr}
		end
		table.insert(GameUIManager.recordData2,newArr)
	end
	GameUIManager.recordCountData[prizeType+1] = GameUIManager.recordCountData[prizeType+1] + 1
	table.insert(GameUIManager.recordData1, prizeType)
	if #GameUIManager.recordData1 >= 100 then
		local snopData1 = {}
		for i = 81, 100 do
			snopData1[i-80] = GameUIManager.recordData1[i]
		end
		GameUIManager.recordData1 = snopData1
		GameUIManager.recordData2 = {}
		GameUIManager.recordCountData = {0,0,0}
		for i = 1, #GameUIManager.recordData1 do
			GameUIManager.recordCountData[GameUIManager.recordData1[i]+1] = GameUIManager.recordCountData[GameUIManager.recordData1[i]+1] + 1
			if(#GameUIManager.recordData2 > 0) then
				local data1 = GameUIManager.recordData2[#GameUIManager.recordData2]
				if GameUIManager.recordData1[i] == 2 then
					if data1[#data1][2] == 1 then
						local newArr = {data1[1][1],1}
						table.insert(GameUIManager.recordData2[#GameUIManager.recordData2],newArr)
					else
						GameUIManager.recordData2[#GameUIManager.recordData2][#data1][2] = 1
					end
				else
					if(data1[1][1] == GameUIManager.recordData1[i]) then
						local newArr = {GameUIManager.recordData1[i],0}
						table.insert(GameUIManager.recordData2[#GameUIManager.recordData2],newArr)
					else
						local snopArr = {GameUIManager.recordData1[i],0}
						local newArr = {snopArr}
						table.insert(GameUIManager.recordData2,newArr)
					end
				end
			else
				local newArr = {}
				if GameUIManager.recordData1[i] == 2 then
					local snopArr = {1,1}
					newArr = {snopArr}
				else
					local snopArr = {GameUIManager.recordData1[i],0}
					newArr = {snopArr}
				end
				table.insert(GameUIManager.recordData2,newArr)
			end
		end
	end
	GameUIManager.UpdateRecordUI()
end
function GameUIManager.GameRecordCatLine(cardTypeData, cardTypeCount,gameCount)
		for i = 1,cardTypeCount do
			local bys1 = MyLuaInter.NewArray("byte", 3)
			System.Array.Copy(cardTypeData, 3*(i-1), bys1, 0, 3)
			local msg = DataParseLua.BytesToStruct(bys1, GameProtocal.CardTypeRecordItem)
			table.insert(GameUIManager.recordData1, msg.cbWinObject)
		end
		GameUIManager.recordData2 = {}
		GameUIManager.recordCountData = {0,0,0}
		for i = 1,#GameUIManager.recordData1 do
			local prizeType = GameUIManager.recordData1[i]
			GameUIManager.recordCountData[prizeType+1] = GameUIManager.recordCountData[prizeType+1] + 1
			if(#GameUIManager.recordData2 > 0) then
				local data1 = GameUIManager.recordData2[#GameUIManager.recordData2]
				if prizeType == 2 then
					if data1[#data1][2] == 1 then
						local newArr = {data1[1][1],1}
						table.insert(GameUIManager.recordData2[#GameUIManager.recordData2],newArr)
					else
						GameUIManager.recordData2[#GameUIManager.recordData2][#data1][2] = 1
					end
				else
					if(data1[1][1] == prizeType) then
						local newArr = {prizeType,0}
						table.insert(GameUIManager.recordData2[#GameUIManager.recordData2],newArr)
					else
						local snopArr = {prizeType,0}
						local newArr = {snopArr}
						table.insert(GameUIManager.recordData2,newArr)
					end
				end
			else
				local newArr = {}
				if prizeType == 2 then
					local snopArr = {1,1}
					newArr = {snopArr}
				else
					local snopArr = {prizeType,0}
					newArr = {snopArr}
				end
				table.insert(GameUIManager.recordData2,newArr)
			end
		end
		GameUIManager.UpdateRecordUI()
end

function GameUIManager.UpdateRecordUI()
	if #GameUIManager.recordData1 <=0 then
		for i = 1, 12 do
			GameUIManager.recordCards[i].gameObject:SetActive(false)
		end
	else
		for i = 1, 12 do
			GameUIManager.recordCards[i].gameObject:SetActive(true)
		end
	end
	if(#GameUIManager.recordData1>12) then
		local dateLen2 = #GameUIManager.recordData1-11
		for i=dateLen2,#GameUIManager.recordData1 do
			GameUIManager.recordCards[12 - i + dateLen2]:SetInfo6(GameUIManager.recordData1[i],true)
		end
	else
		for i=1,#GameUIManager.recordCards do
			if(i <= #GameUIManager.recordData1) then
				GameUIManager.recordCards[i]:SetInfo6(GameUIManager.recordData1[i],true)
			else
				GameUIManager.recordCards[i]:SetInfo6(nil,false)
			end
		end
	end
	GameRecord.ReSet(GameUIManager.recordCountData,GameUIManager.recordData2,GameUIManager.recordData1)
end

function GameUIManager.LimitNote(data)--限制下注
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.SUB_GM_Limit)  
    iLowNoteLimit = tonumber(tostring(msg.iLimitVlue))
    if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
    	GameUIManager.ShowRecharge()
    else
    	GameUIManager.HideRecharge()
    end
end

function GameUIManager.GameNoteReq(data)
	if(GameUIManager.mStation == -1) then
		return
	end
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Note)  
	if (msg.bErrorCode == 0) then
	    GameUIManager.mTotalBets[msg.bNoteObject+1] = tonumber(tostring(GameUIManager.mTotalBets[msg.bNoteObject+1])) + GameUIManager.mChips[msg.bChipIndex+1]
		PlayerNote[msg.bDeskStation + 1][msg.bNoteObject+1] = PlayerNote[msg.bDeskStation + 1][msg.bNoteObject+1] + GameUIManager.mChips[msg.bChipIndex+1]
		if (msg.bDeskStation == LuckyUserStation) then
			GameUIManager.coroutineParent = coroutine.start(GameUIManager.PlayLuckyEffect,msg.bNoteObject+1)
		end
		if (MyUserInfo.iDeskStation == msg.bDeskStation) then
	        GameUIManager.mMyBets[msg.bNoteObject+1] = tonumber(tostring(GameUIManager.mMyBets[msg.bNoteObject+1])) + GameUIManager.mChips[msg.bChipIndex+1]
	        if (tonumber(tostring(MyUserInfo.iMoney)) < GameUIManager.mChips[msg.bChipIndex + 1]) then
				print( "异常，身上的钱为负数！" )
			end
			for i = 1, #GameUIManager.mChips do
	            if (GameUIManager.mChips[i] == GameUIManager.mChips[msg.bChipIndex+1]) then
	                GameUIManager.PlayGoldAnimation(msg.bDeskStation,msg.bNoteObject+1, i)
	                break
	            end
			end
			GameUIManager.SetChouMaBetButtonIsEnable()
	    else
			for i = 1, #GameUIManager.mChips do
	            if (GameUIManager.mChips[i] == GameUIManager.mChips[msg.bChipIndex+1]) then
	                GameUIManager.PlayGoldAnimation(msg.bDeskStation,msg.bNoteObject+1, i)
	                break
	            end
			end
	    end
		for i=1,#GameUIManager.players do
			local info = GameUIManager.players[i]:GetPlayerInfo()
			if(info~=nil) then
				local userinfo = GameSUserBaseInfo.finduserbyid(info[1])
				if(userinfo~=nil) then
					if(msg.bDeskStation == userinfo.iDeskStation) then
						GameUIManager.players[i]:GameNote(GameUIManager.mChips[msg.bChipIndex+1])
					end
				end
			end
		end
	    GameUIManager.RefreshUserInfo()--更新下注和钱
	else
	    if (MyUserInfo.iDeskStation == msg.bDeskStation) then
	        local infoTip = GameLogic.NoteErroCode(msg.bErrorCode)
			LblMsgText.Show(infoTip)
	    end
	end
end
function GameUIManager.PlayLuckyEffect(aearIndex)--幸运星效果
	if isPlayLucky[aearIndex] then
		return
	end
	isPlayLucky[aearIndex] = true
	local obj = UnityEngine.GameObject.Instantiate(GameUIManager.GoLuckyItem)
	obj:SetActive(true)
	SetParent(GameUIManager.GoLuckyItem.transform.parent.gameObject,obj)
	obj.transform.localPosition = Vector3.New(571, 158)
	local tp = obj:GetComponent("TweenPosition")
	tp.from = Vector3.New(410, 200)
	tp.to = LuckyPos[aearIndex]
	tp.duration = 0.4
	tp:PlayForward()
	UnityEngine.GameObject.Destroy(obj.gameObject, 1)
	coroutine.wait(1)
	GameUIManager.GoLuckySign[aearIndex]:SetActive(true)
end
function GameUIManager.GameContinueNoteReq(data)
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_ContinueNote)   
    if (msg.AreaNoteMoney[3] == -1) then
		LblMsgText.Show("Failed to repeat betting")
	elseif(msg.AreaNoteMoney[3] == 0) then
		LblMsgText.Show("You didn't bet last game")
	else
		for i = 1, 3 do
            GameUIManager.mTotalBets[i] = tonumber(tostring(GameUIManager.mTotalBets[i])) + msg.AreaNoteMoney[i-1]
			PlayerNote[msg.nDeskStation + 1][i] = PlayerNote[msg.nDeskStation + 1][i] + msg.AreaNoteMoney[i-1]
            if (msg.nDeskStation == MyUserInfo.iDeskStation) then
                GameUIManager.mMyBets[i] = tonumber(tostring(GameUIManager.mMyBets[i])) + msg.AreaNoteMoney[i-1]
                if (tonumber(tostring(MyUserInfo.iMoney))  < msg.AreaNoteMoney[i-1]) then
                    print("异常，身上的钱为负数！")
                else
                    if (msg.AreaNoteMoney[i-1] > 0) then
						GameUIManager.players[1]:GameNote(msg.AreaNoteMoney[i-1])
                    end
                end
            end
			if (msg.AreaNoteMoney[i-1] > 0) then
				GameUIManager.ContinuePlayGoldGruop(msg.nDeskStation,msg.AreaNoteMoney[i-1], i)
			end
        end
        GameUIManager.RefreshUserInfo()--更新下注和钱
    end
end
function GameUIManager.GameLuckPlayer(data)
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.stLuckPlayer)
	LuckyUserStation = msg.cbDeskStation
	GameUIManager.UpdateLuckyInfo(msg.cbWinRate)
	if isRefLucky then
		GameUIManager.UpDatePlayerInfo()
		GameUIManager.UpDatePlanePlayerInfo(false)
	end
end
function GameUIManager.UpdateLuckyInfo(LuckyWinRate)
	GameUIManager.LbLucky.text = LuckyWinRate.."%"
end

function GameUIManager.GameCurrOver(data)
	print("@@@@ 游戏结算")
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_State_Account)
	GameUIManager.dataPrize = {}
	if(msg.cbPrizeIndex == 0) then
		GameUIManager.dataPrize[1] = 1
		GameUIManager.dataPrize[2] = 0
		GameUIManager.dataPrize[3] = 0
	elseif(msg.cbPrizeIndex == 1) then
		GameUIManager.dataPrize[1] = 0
		GameUIManager.dataPrize[2] = 1
		GameUIManager.dataPrize[3] = 0
	elseif(msg.cbPrizeIndex == 2) then
		GameUIManager.dataPrize[1] = 0
		GameUIManager.dataPrize[2] = 0
		GameUIManager.dataPrize[3] = 1
	end
    GameUIManager.coroutineParent = coroutine.start(GameUIManager.OpenGoldAnima,msg.iWinMoney,msg.cbPrizeIndex,msg.cbNoted) --开奖

	GameUIManager.GameRecordInster(msg.cbPrizeIndex)
end
local bytelist = nil
function GameUIManager.GamePlayerNoteInfo(data)
	for i = 1, 180 do
		PlayerNote[i] = {0,0,0}
	end
	if data.mainMsg.Length == 0 then
		GameUIManager.UpDatePlayerInfo()
		GameUIManager.UpDatePlanePlayerInfo(true)
	else
		if bytelist == nil then
			bytelist = MyLuaInter.NewArray("byte", data.mainMsg.Length)
			System.Array.Copy(data.mainMsg, 0, bytelist, 0, data.mainMsg.Length)
		else
			local allLen = data.mainMsg.Length+bytelist.Length
			local snopBytelist = MyLuaInter.NewArray("byte", data.mainMsg.Length+bytelist.Length)
			for i = bytelist.Length, allLen do
				snopBytelist[i] = data.mainMsg[i - bytelist.Length]
			end
			bytelist = snopBytelist
		end
		if data.headStruct.dwHandleCode == 102 then
			local strLen = DataParseLua.GetLuaTableLength(GameProtocal.stPlayerNoteInfo)
			local count = bytelist.Length/strLen
			for i = 1, count do
				local bys1 = MyLuaInter.NewArray("byte", strLen)
				System.Array.Copy(bytelist, strLen*(i-1), bys1, 0, strLen)
				local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.stPlayerNoteInfo)
				for j = 1, 3 do
					PlayerNote[msg.cbDeskStation + 1][j] = msg.iNote[j-1]
					isPlayLucky[i] = true
				end
			end
			GameUIManager.RefreshUserInfo()
			GameUIManager.UpDatePlayerInfo()
			GameUIManager.UpDatePlanePlayerInfo(true)
			GameUIManager.SetLuckySign()
		end
	end
end

function GameUIManager.GameStation(data)
	print("@@@@@@@@@@@@@@@@@@@@@@@@ GameStation = "..tostring(data.mainMsg.Length))
	GameTimeClock.StopClock()
	GameUIManager.ReSetGameUI()
	
	local state = data.mainMsg[0]
	GameUIManager.mStation = state
	if state == 0 then print("闲置")
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Base)
		noteTime = msg.iXiaZhuTime
		openPrizeTime = msg.iSendCardTime + msg.iAccountTick
		LuckyUserStation = msg.cbLuckerDeskStation

		for i = 1, msg.iChouMaNum do
			GameUIManager.mChips[i] = msg.iChouMa[i-1]
		end
		GameUIManager.ReSetOpenUI()
        GameUIManager.ShowNoteTip(1,false)
		GameUIManager.GameRecordCatLine(msg.tagCardTypeRecordItem,msg.iCardTypeRecordItemCount,msg.cbCurGames)
		GameUIManager.iGameCount = msg.cbCurGames
	    GameUIManager.SetAllCard(0)
	elseif state == 1 then print("下注")
		print("msg =",DataParseLua.GetLuaTableLength(GameProtocal.CMD_GM_Station_Note))
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Note)
		noteTime = msg.iXiaZhuTime
		openPrizeTime = msg.iSendCardTime + msg.iAccountTick
		LuckyUserStation = msg.cbLuckerDeskStation
		for i = 1, msg.iChouMaNum do
			GameUIManager.mChips[i] = msg.iChouMa[i-1]
		end
		for i = 1, 3 do
			GameUIManager.mTotalBets[i] = msg.NoteMoney[i-1]
			GameUIManager.mMyBets[i] = msg.SelfNoteMoney[i-1]
		end
		GameUIManager.GameRecordCatLine(msg.tagCardTypeRecordItem, msg.iCardTypeRecordItemCount,msg.cbCurGames)
		GameUIManager.iGameCount = msg.cbCurGames

		GameUIManager.SetChouMaBetButtonIsEnable()
		GameUIManager.EnabledBtn( true )
		GameUIManager.StartOrStopDownBetBG(true)
	    GameUIManager.SetAllCard(0)
		local time = math.floor(msg.iLeftTick/1000)
		if msg.iLeftTick % 1000 > 500 then
			time = time + 1
		end
        GameTimeClock.StartClock(nil,time,1)
	elseif state == 2 then print("开奖")
		print("msg =",DataParseLua.GetLuaTableLength(GameProtocal.CMD_GM_Station_SendCard))
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_SendCard)
		noteTime = msg.iXiaZhuTime
		openPrizeTime = msg.iSendCardTime + msg.iAccountTick
		LuckyUserStation = msg.cbLuckerDeskStation
		for i = 1, msg.iChouMaNum do
			GameUIManager.mChips[i] = msg.iChouMa[i-1]
		end
		for i = 1, 3 do
			GameUIManager.mTotalBets[i] = msg.NoteMoney[i-1]
			GameUIManager.mMyBets[i] = msg.SelfNoteMoney[i-1]
		end
		GameUIManager.GameRecordCatLine(msg.tagCardTypeRecordItem,msg.iCardTypeRecordItemCount,msg.cbCurGames)
		GameUIManager.iGameCount = msg.cbCurGames
        GameUIManager.dataCard[1] = msg.cbOpenCard[0]
        GameUIManager.dataCard[2] = msg.cbOpenCard[1]
		GameUIManager.EnabledBtn( false )
	    GameUIManager.SetAllCard(1)
		local time = math.floor(msg.iLeftTick/1000)
		if msg.iLeftTick % 1000 > 500 then
			time = time + 1
		end
		time = time + msg.iAccountTick
		GameTimeClock.StartClock(nil,time,2)
	elseif state == 3 then print("结算")
		print("msg =",DataParseLua.GetLuaTableLength(GameProtocal.CMD_GM_Station_Account))
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Account)
		noteTime = msg.iXiaZhuTime
		openPrizeTime = msg.iSendCardTime + msg.iAccountTick
		LuckyUserStation = msg.cbLuckerDeskStation
		for i = 1, msg.iChouMaNum do
			GameUIManager.mChips[i] = msg.iChouMa[i-1]
		end
		for i = 1, 3 do
			GameUIManager.mTotalBets[i] = msg.NoteMoney[i-1]
			GameUIManager.mMyBets[i] = msg.SelfNoteMoney[i-1]
		end
		GameUIManager.GameRecordCatLine(msg.tagCardTypeRecordItem,msg.iCardTypeRecordItemCount,msg.cbCurGames)
		GameUIManager.iGameCount = msg.cbCurGames
        GameUIManager.dataCard[1] = msg.cbOpenCard[0]
        GameUIManager.dataCard[2] = msg.cbOpenCard[1]
		GameUIManager.EnabledBtn( false )
	    GameUIManager.SetAllCard(1)
		local time = math.floor(msg.iLeftTick/1000)
		if msg.iLeftTick % 1000 > 500 then
			time = time + 1
		end
		GameTimeClock.StartClock(nil,time,2)
	elseif state == 4 then print("而外")
		GameUIManager.EnabledBtn( false )
	end
	GameUIManager.UpdateBetInfo(GameUIManager.mChips)
	GameUIManager.RefreshUserInfo()
	GameUIManager.UpDatePlayerInfo()
	GameUIManager.UpDatePlanePlayerInfo(true)
	GameGoldManager.SetAreaGold()
end

function GameUIManager.GameStateUpdate(data)
	print("GameStateUpdate = "..tostring(data.mainMsg.Length))
	if(GameUIManager.mStation == -1) then
		return
	end
	local state = data.mainMsg[0]
	GameUIManager.mStation = state
	if state == 0 then print("闲置")
        GameUIManager.ShowNoteTip(1,false)
	elseif state == 1 then print("下注")
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_State_Note)
    	GameGoldManager.HideAllGole()
		isPlayLucky = { false, false, false }
		for i = 1, 180 do
			PlayerNote[i] = {0,0,0}
		end
		GameUIManager.mTotalBets = {0,0,0}
		GameUIManager.mMyBets = {0,0,0}
		GameUIManager.SetChouMaBetButtonIsEnable()
		GameUIManager.RefreshUserInfo()
		GameUIManager.HideWinFlash()
		GameUIManager.HideNoteTip()
		GameUIManager.UpDatePlayerInfo()
		GameUIManager.UpDatePlanePlayerInfo(true)
		GameUIManager.StartOrStopDownBetBG(true)
		GameUIManager.EnabledBtn(true)
	    GameUIManager.SetAllCard(0)
        GameTimeClock.StartClock(nil,noteTime,1)
    	if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
	    	GameUIManager.ShowRecharge()
	    else
	    	GameUIManager.HideRecharge()
	    end
	elseif state == 2 then print("发牌")
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_State_SendCard)
        GameUIManager.dataCard[1] = msg.cbOpenCard[0]
        GameUIManager.dataCard[2] = msg.cbOpenCard[1]
		GameTimeClock.StopClock()
        -- 关闭下注界面，并禁用功能操作按钮
        GameUIManager.StartOrStopDownBetBG(false)
		GameUIManager.EnabledBtn( false )
		GameTimeClock.StartClock(nil,openPrizeTime,2)
    	GameUIManager.coroutineParent = coroutine.start(GameUIManager.OpenCardAnimation) --开奖
	elseif state == 3 then print("结算")
	elseif state == 4 then print("而外")
	end
end

function GameUIManager.GetDeskUserUserId(index)
	local info = GameUIManager.players[index]:GetPlayerInfo()
	if(info~=nil) then
		return info[1]
	end
	return -1
end

function GameUIManager.OnDestroy()
	if(GameUIManager.coroutineParent ~= nil) then
		coroutine.stop(GameUIManager.coroutineParent)
		GameUIManager.coroutineParent = nil
	end
	UpdateBeat:Remove(GameUIManager.Update)
	GameLogic.OnDestroy()
	GameTimeClock.OnDestroy()
	GameGoldManager.OnDestroy()
	package.loaded["642.GameUIManager"] = nil
	package.loaded["642.GameGoldAnima"] = nil
	package.loaded["642.GameGoldManager"] = nil
	package.loaded["642.GameHelp"] = nil
	package.loaded["642.GamePlayerGroup"] = nil
	package.loaded["642.GamePlayerInfo"] = nil
	package.loaded["642.GamePlayerList"] = nil
	package.loaded["642.GameRecord"] = nil
	package.loaded["642.GameRecordCardItem"] = nil
	package.loaded["642.GameSet"] = nil
	package.loaded["642.GameShowPlayerInfo"] = nil
	package.loaded["642.GameTimeClock"] = nil
	-- package.loaded["642.GameUIJiangChi"] = nil
	package.loaded["642.GameUIRecord"] = nil
	package.loaded["642.GameUIWinPool"] = nil
end