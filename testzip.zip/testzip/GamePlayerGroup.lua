local GameLogic = require "642.GameLogic"
local GamePlayerGroup =
{
}
function GamePlayerGroup:new(trans)
	local _instance = 
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self 
	setmetatable(_instance, self)
	return _instance
end
function GamePlayerGroup:InitUI(index)
    self.userIndex = index
    self.IconHead = FindChildByName(self.transform, "IconHeadBox/ImHead", "UISprite")
    self.IconSignBorder = FindChildByName(self.transform, "IconSign/Icon_HeadBox", "gameObject")
    self.ImHeadBorder = FindChildByName(self.transform, "IconHeadBox/ImHead/Vip_Head_Effect1/HeadBox", "UISprite")
    self.LbVip = FindChildByName(self.transform, "IconHeadBox/LbVip", "UILabel")
    self.LbName = FindChildByName(self.transform, "IconHeadBox/LbName", "UILabel")
    self.LbMoney = FindChildByName(self.transform, "IconHeadBox/LbMoney", "UILabel")
    self.LbWin = FindChildByName(self.transform, "GoLoseOrWin/JS_Group/LbWinScore", "UILabel")
    self.LbLose = FindChildByName(self.transform, "GoLoseOrWin/JS_Group/LbloseScore", "UILabel")
    self.GoWin = FindChildByName(self.transform, "GoLoseOrWin","gameObject")
    self.GoWinFlash = FindChildByName(self.transform, "Win_Ani","gameObject")
    self.BtnHead = FindChildByName(self.transform, "IconHeadBox","gameObject")
    UIEventListener.Get(self.BtnHead).onPress = function(go,flag) self:ShowPlayerInfo(go,flag) end

    self.GoPlayerInfo = FindChildByName(self.transform, "Player_Infor","gameObject")
    self.LbPlayerName = FindChildByName(self.transform, "Player_Infor/LbName", "UILabel")
    self.LbPlayerMoney = FindChildByName(self.transform, "Player_Infor/LbMoney", "UILabel")
    self.IconPlayerHead = FindChildByName(self.transform, "Player_Infor/Icon_HeadBox/ImHead", "UISprite")
    self.LbPlayerQM = FindChildByName(self.transform, "Player_Infor/LbQianMing", "UILabel")
    self.LbPlayerJS = FindChildByName(self.transform, "Player_Infor/LbJuShu", "UILabel")
    self.LbPlayerSL = FindChildByName(self.transform, "Player_Infor/LbShengLv", "UILabel")
end

function GamePlayerGroup:ShowPlayerInfo(go,flag)
    if flag then
        if (self.UserInfo == nil or self.UserInfo[1] <= 0) then
            return
        end
        self.IconPlayerHead.spriteName = GetHeadSpriteName(self.UserInfo[2])
        self.LbPlayerName.text = self.UserInfo[4]
        self.LbPlayerMoney.text = MoneyProportionStr(self.UserInfo[5])
        self.LbPlayerQM.text = self.UserInfo[6]
        local allCount = self.UserInfo[8] + self.UserInfo[9] + self.UserInfo[10]
        if allCount > 0 then
            self.LbPlayerJS.text = allCount
            self.LbPlayerSL.text = getIntPart(self.UserInfo[8]/allCount*100).."%"
        else
            self.LbPlayerJS.text = 0
            self.LbPlayerSL.text = "0%"
        end
        self.GoPlayerInfo:SetActive(true)
    else
        self.GoPlayerInfo:SetActive(false)
    end
end
function GamePlayerGroup:Set(info)
    self.UserInfo = info
    if (info == nil or info[1] <= 0) then
    	self.IconHead.transform.parent.gameObject:SetActive(false)
        if (self.LbName ~= nil) then
    		self.LbName.gameObject:SetActive(false)
        end
        if (self.LbVip ~= nil) then
    		self.LbVip.gameObject:SetActive(false)
        end
        if (self.IconSignBorder ~= nil) then
            self.IconSignBorder:SetActive(true)
        end
    else
        if (self.IconSignBorder ~= nil) then
            self.IconSignBorder:SetActive(false)
        end
        if self.IconHead ~= nil then
            self.IconHead.transform.parent.gameObject:SetActive(true)
            self:UpdateHead(info[2], info[3])

        end
        if self.LbMoney ~= nil then
            self.LbMoney.text = MoneyProportionStr(info[5])
        end
        if (self.LbName ~= nil) then
    		self.LbName.gameObject:SetActive(true)
            local name = info[4]
            if self.userIndex ~= 1 then
                name = GamePlayerGroup.getnewstr(info[4])
            end
            self.LbName.text = name
        end
        if (self.LbVip ~= nil) then
    		self.LbVip.gameObject:SetActive(true)
            self.LbVip.text = tostring(info[7])
        end
    end
    if (self.GoWin ~= nil) then
        self.GoWin:SetActive(false)
    end
    if (self.GoWinFlash ~= nil) then
        self.GoWinFlash:SetActive(false)
    end
end

function GamePlayerGroup.getnewstr(str)
    local getInByte = 0
    local strLen = 0
    local lenInByte = #str
    local j=1
    local result = str
    for i=1,lenInByte do
        if strLen >= 4 then
            result = string.sub(str,0,getInByte).."..."
            break
        end
        local curByte = string.byte(str,j)
        if curByte == nil then
            break
        end
        if curByte<=127 then
            getInByte = getInByte+1
            j=j+1
        else
            getInByte = getInByte+3
            j=j+3
        end
        strLen=strLen+1
    end
    return result
end

function GamePlayerGroup:UpdateHead(headId, borderId)
	if self.ImHeadBorder ~= nil then
	    local HeadBorderName = GetHeadBorderById(borderId)
		self.ImHeadBorder.spriteName = HeadBorderName
		--self.ImHeadBorder:MakePixelPerfect()
	end

    local HeadName = GetHeadSpriteName(headId)
	self.IconHead.spriteName = HeadName
	--self.IconHead:MakePixelPerfect()
end

function GamePlayerGroup:RateUserId(id)
    if (self.UserInfo[1] == id) then
        return true
    end
    return false
end
function GamePlayerGroup:GetPlayerInfo()
    return self.UserInfo
end
function GamePlayerGroup:PlayHeadAnima()
    if self.IconHead ~= nil then
        self.IconHead.gameObject:GetComponent("Animation"):Play()
    end
end
function GamePlayerGroup:GameNote(note)
    self.UserInfo[5] = self.UserInfo[5] - note
    if self.LbMoney ~= nil then
        self.LbMoney.text = MoneyProportionStr(self.UserInfo[5])
    end
end
function GamePlayerGroup:PrizePool(note)
    self.UserInfo[5] = self.UserInfo[5] + note
    if self.LbMoney ~= nil then
        self.LbMoney.text = MoneyProportionStr(self.UserInfo[5])
    end
end
function GamePlayerGroup:UpdateUserMoney(money)
    self.UserInfo[5] = money
    if self.LbMoney ~= nil then
        self.LbMoney.text = MoneyProportionStr(self.UserInfo[5])
    end
end
function GamePlayerGroup:UpdateUserLV(lv)
    self.UserInfo[7] = lv
    if (self.LbVip ~= nil) then
        self.LbVip.text = tostring(self.UserInfo[7])
    end
end

function GamePlayerGroup:OpenPrizeAnimation(score,playerMoney,isNote)
    self.UserInfo[5] = playerMoney
    self.coroutineParent = coroutine.start(GamePlayerGroup.OpenPrizeScore,self,score,isNote)
end
function GamePlayerGroup.OpenPrizeScore(self,score,isNote)
    if not isNote then
        return
    end
    if (self.GoWin ~= nil) then
    	self.GoWin:SetActive(true)
	end
    if(score>=0) then
        self.LbWin.gameObject:SetActive(true)
        self.LbLose.gameObject:SetActive(false)
        self.LbWin.text = "+"..MoneyProportionStr(score)
        if (self.GoWinFlash ~= nil) then
            self.GoWinFlash:SetActive(true)
        end
    else
        self.LbWin.gameObject:SetActive(false)
        self.LbLose.gameObject:SetActive(true)
        self.LbLose.text = MoneyProportionStr(score)
    end
    coroutine.wait(0.5)
    if self.LbMoney ~= nil then
        self.LbMoney.text = MoneyProportionStr(self.UserInfo[5])
    end
    coroutine.wait(1.5)
    --self:Set(self.UserInfo)
    if (self.GoWin ~= nil) then
    	self.GoWin:SetActive(false)
	end
    if (self.GoWinFlash ~= nil) then
        self.GoWinFlash:SetActive(false)
    end
end
return GamePlayerGroup
