local GameLogic =
{
	
}

function GameLogic.Awake()
	require "642.GameProtocal"
	GameDefine.AddEvent(GameDefine.Action_UserSit, GameLogic.Action_UserSit)--玩家坐下
	GameDefine.AddEvent(GameDefine.Action_UserLeft, GameLogic.Action_UserLeft)--玩家离开桌子
	GameDefine.AddEvent(GameDefine.Action_RefleshUserInfo, GameLogic.Action_RefleshUserInfo)--刷新用户经验值
	GameDefine.AddEvent(GameDefine.Action_NoMoneyTickRoom, GameLogic.Action_NoMoneyTickRoom)--游戏币不足，提出房间

	--GameDefine.AddEvent(GameProtocal.GM_SUB_BIGPOOL_RECORD, GameLogic.ErroCode) --错误
	GameDefine.AddEvent(GameProtocal.GM_SUB_GAMESTATION, GameLogic.GameStation) --游戏状态
	GameDefine.AddEvent(GameProtocal.GM_SUB_STATEUPDATE, GameLogic.GameStateUpdate) --游戏状态
	GameDefine.AddEvent(GameProtocal.GM_SUB_NOTE, GameLogic.GameNoteReq) --下注
	GameDefine.AddEvent(GameProtocal.GM_SUB_CONTINUE, GameLogic.GameContinueNoteReq) --续压
	GameDefine.AddEvent(GameProtocal.GM_SUB_LUCKPLAYER, GameLogic.GameLuckPlayer) --幸运星
	GameDefine.AddEvent(GameProtocal.GM_SUB_PLAYERNOTEINFO, GameLogic.GamePlayerNoteInfo) --下注信息
	GameDefine.AddEvent(GameProtocal.GM_SUB_SETTLEMENT, GameLogic.GameCurrOver) --游戏结束
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOLDATA_FRESH, GameLogic.PoolDataRefresh) --奖池刷新
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_DISTRIBUTE, GameLogic.PoolDataDistrubute) --奖池派发
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_CONFIG, GameLogic.PoolConfig) --奖池配置
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_RECORD, GameLogic.PoolRecord) --奖池记录
	
	GameDefine.AddEvent(GameProtocal.SUB_GM_GAME_CONFIG, GameLogic.LimitNote) --限制下注
	math.randomseed(tostring(os.time()):reverse():sub(1,7)) 
end

function GameLogic.Start()
	
end

function GameLogic.OnDestroy()
	package.loaded["642.GameProtocal"] = nil
	GameDefine.Creal()
end


function GameLogic.Action_UserSit(userInfo)
	--PrintLog("Action_UserSit  玩家坐下: "..tostring(userInfo.uiUserID))
	if userInfo.uiUserID == MyUserInfo.uiUserID then
		--print("@@@@@@@@@@@ 请求游戏状态")
		NetManager:SendData(2000150,1) --获取用户的状态
		NetManager:SendData(2000180,1) --发送准备事件
	else
		if(GameUIManager.mStation>=0) then
			GameUIManager.InsertPlayer(userInfo)
		end		
	end
end

function GameLogic.Action_NoMoneyTickRoom()
	UIRoom.QuitGame()
end

function GameLogic.Action_UserLeft(userInfo)
	--print("Action_UserSit  玩家离开: ", userInfo.uiUserID)
	GameUIManager.RemovePlayer(userInfo)
end

function GameLogic.Action_RefleshUserInfo(userInfo)
	GameUIManager.UpDateUserInfo(userInfo)
end


function GameLogic.ErroCode(data)--游戏错误
	local erronum = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.ErrorCode)
	if erronum.uErrorId == 0 then print("数据空")
	elseif erronum.uErrorId == 1 then print("数据包大小不对")
	elseif erronum.uErrorId == 2 then print("座位号错误")
	elseif erronum.uErrorId == 3 then print("线数错误")
	elseif erronum.uErrorId == 4 then print("筹码错误")
	elseif erronum.uErrorId == 5 then print("倍数错误")
	elseif erronum.uErrorId == 6 then print("状态不对")
	elseif erronum.uErrorId == 7 then print("身上钱不足")
	end
end

function GameLogic.NoteErroCode(uErrorId)--游戏错误
	if uErrorId == 0 then return "ok"--无错误
	elseif uErrorId == 1 then return "Chip error"--筹码错误
	elseif uErrorId == 2 then return "Not enough money"--玩家身上钱不足
	elseif uErrorId == 3 then return "No betting object"--没有下注对象
	elseif uErrorId == 4 then return "Cannot play Dragon and Tiger at the same time"--"不能同时下龙虎"
	elseif uErrorId == 5 then return "The Dragon and Tiger areas exceed the limit"--"龙虎限红"
	elseif uErrorId == 6 then return "Tie areas exceed the limit"--"和限红"
	elseif uErrorId == 7 then return "oher error"--而外
	end
end

function GameLogic.ContinueNoteErroCode(uErrorId)--游戏错误
	if uErrorId == 0 then return "ok"--可以续压
	elseif uErrorId == 1 then return "There was no bet in the last round, so it was impossible to continue"--上局没有下注,无法续压
	elseif uErrorId == 2 then return "Not enough money"--身上的钱不足
	end
end

function GameLogic.GameStation(data)--游戏状态
	UIRoom.LoadGameFinish()
	GameUIManager.GameStation(data)
end
function GameLogic.GameStateUpdate(data)--游戏状态更新
	GameUIManager.GameStateUpdate(data)
end
function GameLogic.GameNoteReq(data)--下注
	GameUIManager.GameNoteReq(data)
end
function GameLogic.GameContinueNoteReq(data)--续压
	GameUIManager.GameContinueNoteReq(data)
end
function GameLogic.GameLuckPlayer(data)--幸运星座位号
	GameUIManager.GameLuckPlayer(data)
end
function GameLogic.GamePlayerNoteInfo(data)--玩家信息
	GameUIManager.GamePlayerNoteInfo(data)
end
function GameLogic.GameCurrOver(data)--准备结算
	GameUIManager.GameCurrOver(data)
end
function GameLogic.PoolDataRefresh(data)--奖池刷新
	GameUIManager.PoolDataRefresh(data)
end
function GameLogic.PoolDataDistrubute(data)--奖池派发
	-- local path = "E:/UnityTest/123.txt"
	-- LuaInter.SaveFile(path,data.mainMsg)
	-- print("写入成功")
	GameUIManager.PoolDataDistrubute(data)
end
function GameLogic.PoolConfig(data)--奖池配置
	GameUIManager.PoolConfig(data)
end
function GameLogic.PoolRecord(data)--奖池记录
	GameUIManager.PoolRecord(data)
end
function GameLogic.LimitNote(data)--奖池配置
	GameUIManager.LimitNote(data)
end

function GameLogic.FormatNumToStringYW(score)
	local num = tonumber(score)
	local value = tostring(num)
	local rideValue = 1
	if ( num < 0 ) then
		num = num * -1
		rideValue = -1
	end
	if ( num >= 10000 ) then
		if ( num >= 100000000 ) then
			local v = math.floor(num / 1000000)/100
			value = tostring(v * rideValue).."亿"
		else
			local v = math.floor(num / 100)/100
			value = tostring(v * rideValue).."万"
		end
	end
	return value
end
function GameLogic.FormatNumToYW(score)
	local num = tonumber(score)
	local value = tostring(num)
	if ( num <= 0 ) then
		return value
	end
	if ( num >= 10000 ) then
		if ( num >= 100000000 ) then
			value = tostring(num / 100000000).."Y"
		else
			value = tostring(num / 10000).."W"
		end
	end
	return value
end
function GameLogic.FormatNoteNumToYW(score)
	local num = tonumber(score)
	local value = tostring(num)
	local rideValue = 1
	if ( num < 0 ) then
		num = num * -1
		rideValue = -1
	end
	if ( num >= 1000 ) then
		if ( num >= 100000000 ) then
			local v = math.floor(num / 1000000)/100
			value = tostring(v * rideValue).."Y"
		elseif num >= 10000 then
			local v = math.floor(num / 100)/100
			value = tostring(v * rideValue).."W"
		else
			local v = math.floor(num / 10)/100
			value = tostring(v * rideValue).."K"
		end
	end
	return value
end
function GameLogic.finduserbyStation(userStation)
	for i=1,#GameSUserBaseInfo.userinfolist do
		if GameSUserBaseInfo.userinfolist[i].iDeskStation == userStation then
			return GameSUserBaseInfo.userinfolist[i]
		end
	end
	return nil
end
function GameLogic.GetRandomPostion(v)
    local vx = math.random(v.x - 80, v.x + 80)
    local vy = math.random(v.y - 50, v.y + 50)
    return Vector3.New(vx, vy, 0)
end
function GameLogic.GetRandomDesktopPostion(v)
    local vx = math.random(v.x - 20, v.x + 20)
    local vy = math.random(v.y, v.y + 30)
    return Vector3.New(vx, vy, 0)
end
return GameLogic