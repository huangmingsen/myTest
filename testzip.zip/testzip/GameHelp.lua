local GameHelp = 
{
	BtnClose,
	LbTax,
	Anim,
}

function GameHelp.Awake()
	GameHelp.BtnClose = GameHelp.transform:FindChild("UIGroup/BtnClose").gameObject
	GameHelp.LbTax = GameHelp.transform:FindChild("UIGroup/Label_Tips").gameObject:GetComponent("UILabel")

	UIEventListener.Get(GameHelp.BtnClose).onClick = GameHelp.Hide
end

function GameHelp.Show(taxVlue,state)
	GameHelp.transform.gameObject:SetActive(true)
	if(taxVlue == 0) then
		GameHelp.LbTax.gameObject:SetActive(false)
	else
		GameHelp.LbTax.gameObject:SetActive(true)
		if state then --3% service charge
			--GameHelp.LbTax.text = "收取"..tostring(taxVlue).."%的服务费用于奖金的生成."
			GameHelp.LbTax.text = "Charge "..tostring(taxVlue).." of the service fee to the bonus pool"
		else 
			--GameHelp.LbTax.text = "收取"..tostring(taxVlue).."%的服务费."
			GameHelp.LbTax.text = tostring(taxVlue).."% service charge"
		end
	end
	GameHelp.transform.gameObject:GetComponent("Animation"):Play("LD_Show")
end

function GameHelp.Hide()
	if not GameHelp.transform.gameObject.activeSelf then
		return
	end
	GameHelp.transform.gameObject:GetComponent("Animation"):Play("LD_Hide")
	local time = GameHelp.transform.gameObject:GetComponent("Animation"):GetClip("LD_Hide").length
	coroutine.start(GameHelp.HideObject, time)
end

function GameHelp.HideObject(itime)
	coroutine.wait(itime)
	GameHelp.transform.gameObject:SetActive(false)
end

return GameHelp