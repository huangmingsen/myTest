local GameShowPlayerInfo = 
{
        HeadImage,
        UserName_lb,
        LbMoney,
        LbQianMing,
        BlackCollider,
        Anim,
}
local coroutineParent
function GameShowPlayerInfo.Awake()
    GameShowPlayerInfo.HeadImage = FindChildByName(GameShowPlayerInfo.transform, "UI_Group/ImHead", "UISprite")
    GameShowPlayerInfo.UserName_lb = FindChildByName(GameShowPlayerInfo.transform, "UI_Group/LbName", "UILabel")
    GameShowPlayerInfo.LbMoney = FindChildByName(GameShowPlayerInfo.transform, "UI_Group/LbMoney", "UILabel")
    GameShowPlayerInfo.LbQianMing = FindChildByName(GameShowPlayerInfo.transform, "UI_Group/LbQianMing", "UILabel")
    GameShowPlayerInfo.BlackCollider = FindChildByName(GameShowPlayerInfo.transform, "BlackCollider", "gameObject")
    GameShowPlayerInfo.Anim = GameShowPlayerInfo.transform.gameObject:GetComponent("Animation")
    UIEventListener.Get(GameShowPlayerInfo.BlackCollider).onClick = GameShowPlayerInfo.HideUi
end
function GameShowPlayerInfo.ShowUi(playerInfo)
    local HeadName = GetHeadSpriteName(playerInfo[2])
    GameShowPlayerInfo.HeadImage.spriteName = HeadName
    GameShowPlayerInfo.LbMoney.text = MoneyProportionStr(playerInfo[5])
    GameShowPlayerInfo.UserName_lb.text = playerInfo[4]
    GameShowPlayerInfo.LbQianMing.text = playerInfo[6]
    if (GameShowPlayerInfo.Anim) then
        local animClip = GameShowPlayerInfo.Anim:GetClip("PlayerInfor_Show")
        if (animClip) then
            GameShowPlayerInfo.Anim.enabled = true
            GameShowPlayerInfo.Anim:Play("PlayerInfor_Show")
        end
    end
end
function GameShowPlayerInfo.HideUi()
    local itime = 0
    if (GameShowPlayerInfo.Anim) then
        local animClip = GameShowPlayerInfo.Anim:GetClip("PlayerInfor_Hide");
        if (animClip) then
            GameShowPlayerInfo.Anim.enabled = true;
            GameShowPlayerInfo.Anim:Play("PlayerInfor_Hide");
            itime = animClip.length;
        end
    end
    if(coroutineParent ~= nil) then
        coroutine.stop(coroutineParent)
        coroutineParent = nil
    end
    coroutineParent = coroutine.start(GameShowPlayerInfo.yieldHide,itime)
end
function GameShowPlayerInfo.yieldHide(time)
    coroutine.wait(time)
    coroutineParent = nil
    GameShowPlayerInfo.transform.gameObject:SetActive(false)
end
return GameShowPlayerInfo