local GameUIAnimation = 
{
	--时间到的事件
	OnTimeOut,
	--动画列表
	Obj_Animation = {},
	--下注索引
	mlistIndex = {},
}
function GameUIAnimation.Awake()
	for i=1,13 do
		GameUIAnimation.Obj_Animation[i] = i
	end
	GameUIAnimation.Obj_Animation[4] = GameUIAnimation.transform:FindChild("Ani_Light").gameObject
	GameUIAnimation.Obj_Animation[13] = GameUIAnimation.transform:FindChild("Ani_Caijin").gameObject
	print("-----------",type(GameUIAnimation.Obj_Animation[1]))
end
--播放动画
function GameUIAnimation.StartAnimation(BetIndex,time,timeOutEvent)
	print("--播放动画---",BetIndex,time)
	GameUIAnimation.OnTimeOut = nil
	if nil ~= timeOutEvent then
		GameUIAnimation.OnTimeOut = timeOutEvent
	end

	table.insert(GameUIAnimation.mlistIndex,BetIndex)
	if 0 <= BetIndex and BetIndex < #GameUIAnimation.Obj_Animation then
		local goAnim = GameUIAnimation.Obj_Animation[BetIndex+1]
		if type(goAnim) ~=  "number" then
			goAnim:SetActive(true)
			for i=1,goAnim.childCount do
				local iconAnimation = goAnim:GetChild(i-1).gameObject:GetComponent("UISpriteAnimation")
				if iconAnimation then
					iconAnimation.gameObject:SetActive(true)
					iconAnimation.enabled = true
					iconAnimation:ResetToBeginning()
				end
			end
		end
	end
	--停止时间
	coroutine.stop(GameUIAnimation.StopAnimation)
	coroutine.start(GameUIAnimation.StopAnimation,time)
end
--停止动画
function GameUIAnimation.StopAnimation(time)
	if time ~= nil then
		coroutine.wait(time)
	end
	for i=1,#GameUIAnimation.mlistIndex do
		if #GameUIAnimation.Obj_Animation > GameUIAnimation.mlistIndex[i] then
			local goAnim = GameUIAnimation.Obj_Animation[GameUIAnimation.mlistIndex[i]]
			if type(goAnim) ~=  "number" then
				goAnim:SetActive(false)
			end
		end
	end
	GameUIAnimation.mlistIndex = {}
	if GameUIAnimation.OnTimeOut then
		GameUIAnimation.OnTimeOut()
	end
end
function GameUIAnimation.StopAnimation1(BetIndex)
	if GameUIAnimation.IsInTable(GameUIAnimation.mlistIndex,BetIndex) then
		if #GameUIAnimation.Obj_Animation > BetIndex then
			local goAnim = GameUIAnimation.Obj_Animation[BetIndex]
			if goAnim then
				goAnim:SetActive(false)
			end
		end
		table.insert(GameUIAnimation.mlistIndex,BetIndex)
	end
	if GameUIAnimation.OnTimeOut then
		GameUIAnimation.OnTimeOut()
	end
end
function GameUIAnimation.IsInTable(tal,value)
	for i,v in ipairs(tal) do
		if v == value then
			return true
		end
	end
	return false
	-- body
end
function GameUIAnimation.OnDestroy()
	coroutine.stop(GameUIAnimation.StopAnimation)
	package.loaded["606.GameUIAnimation"] = nil
end
return GameUIAnimation