local GameUIPlayerGroup = 
{

}
function GameUIPlayerGroup:new(trans)
	local _instance = 
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self 
	setmetatable(_instance, self)
	return _instance
end
function GameUIPlayerGroup:Init()
    self.IconHead = FindChildByName(self.transform, "IconHead_Box/Icon_Head","UISprite")
    self.LbName = FindChildByName(self.transform, "Label_Name","UILabel")
    self.LbMoney = FindChildByName(self.transform, "Label_Money","UILabel")
    self.ImHeadBorder = FindChildByName(self.transform, "HeadBorder","UISprite")
    self.LbVip = FindChildByName(self.transform, "LbVip", "UILabel")

    -------GameResult-------
	self.PlayerName = FindChildByName(self.transform, "Label_Name","UILabel")
	self.LbRankCount = FindChildByName(self.transform, "Label_Rank","UILabel")
	self.IconRank = FindChildByName(self.transform, "Icon_Rank","UISprite")
	self.PlayerLoseScore = FindChildByName(self.transform, "Label_Score_Lose","UILabel")
	self.PlayerWinScore = FindChildByName(self.transform, "Label_Score_Win","UILabel")
end
function GameUIPlayerGroup:Set(info)
    self:UpdateHead(info.UserImageNO, info.iPhotoFrame)
    self.LbName.text = info.UserName
    if self.LbMoney then
        self.LbMoney.text = FormatNumToYW(MoneyProportionStr(info.UserMoney))
    end
    if self.LbVip then
    	self.LbVip.text = info.iVipLevel
    end
end

function GameUIPlayerGroup:UpdateHead(headId,borderId)
	if self.ImHeadBorder ~= nil then
	    local HeadBorderName = GetHeadBorderById(borderId)
		self.ImHeadBorder.spriteName = HeadBorderName
		--self.ImHeadBorder:MakePixelPerfect()
	end
    local HeadName = GetHeadSpriteName(headId)
	self.IconHead.spriteName = HeadName

end
function GameUIPlayerGroup:ReSetInstance(rankCount,nickName,money)
	if self.IconRank then
        if self.LbRankCount then
            self.LbRankCount.gameObject:SetActive(not(rankCount < 3))
        end
		if rankCount < 3 then
			self.IconRank.spriteName = "Icon_JS_Rank_"..(rankCount+1)
		else
			self.IconRank.spriteName = "UI_JS_Rank0"
		end
	end
    if self.LbRankCount then
        self.LbRankCount.text = ""..(rankCount+1)
    end
    if self.PlayerName then
        self.PlayerName.text = nickName
    end
    self.PlayerWinScore.gameObject:SetActive(money > 0)
    self.PlayerLoseScore.gameObject:SetActive(not(money > 0))
    if money > 0 then
        self.PlayerWinScore.text = FormatNumToYW(MoneyProportionStr(money))
    else
        self.PlayerLoseScore.text = FormatNumToYW(MoneyProportionStr(money))
    end
end    
return GameUIPlayerGroup