local GameUIGoldAnima = 
{
    goldCoroutine = nil,
    duation = 0.2,
    userId = -1,
    BgName = { "ico_chouma2_1", "ico_chouma2_2", "ico_chouma2_3", "ico_chouma2_4", "ico_chouma2_5","ico_chouma2_6"},
    fromPosToPlayer= Vector3.New(0, 0, 0),
    toPlayerPos = Vector3.New(0, 0, 0),
    fromPostoZhuang = Vector3.New(0, 0, 0),
    ZhuangPos = Vector3.New(-52.3, 139.7, 0),
    isShow = false,
}
function GameUIGoldAnima:new(trans)
    local _instance = 
    {
        transform = trans,
        gameObject = trans.gameObject
    }
    self.__index = self 
    setmetatable(_instance, self)
    return _instance
end
function GameUIGoldAnima:Init()
    self.IconBg = FindChildByName(self.transform, "Background","UISprite") 
    self.IconNum = {}
    for i=1,5 do
        self.IconNum[i] = FindChildByName(self.transform, "IconNum"..i,"UILabel")
    end

    if self.transform.gameObject:GetComponent("TweenPosition") == nil then
        self.goldPos = self.transform.gameObject:AddComponent(System.Type.GetType("TweenPosition"))
    else
        self.goldPos = self.transform.gameObject:GetComponent("TweenPosition")
    end
    self.goldPos:SetOnFinished(EventDelegate.New(function()
        self.transform.gameObject:SetActive(self.isShow)
    end))
end
function GameUIGoldAnima:CreatChouMa(moneyStr,index,count)
    self:ReSetData(moneyStr,index,count)
end
function GameUIGoldAnima:ReSetData(moneyStr,index,count)
    self.IconBg.spriteName = self.BgName[index]
    self.IconBg:MakePixelPerfect()
    self.IconBg.depth = 90 + count % 300
    self.IconNum[1].text = moneyStr
    self.IconNum[1].depth = 91 + count % 300
    for i=2,#self.IconNum do
        self.IconNum[i].gameObject:SetActive(false)
    end
    --[[
    local moneyChar = {}
    for i=1,string.len(moneyStr) do
        moneyChar[i] = string.sub(moneyStr,i,i)
    end
    local numCount = #moneyChar
    local StartX = -10 * (numCount - 1)
    --print("--创建筹码--",numCount,moneyStr,index,count)
    for i=1,#self.IconNum do
        self.IconNum[i]:MakePixelPerfect()
        self.IconNum[i].transform.localScale = Vector3.New(0.82, 0.82, 1)
        if i > numCount then
            self.IconNum[i].gameObject:SetActive(false)
        else
            self.IconNum[i].gameObject:SetActive(true)
            self.IconNum[i].spriteName = "nbr_chouma_"..moneyChar[i]
            self.IconNum[i].transform.localPosition = Vector3.New((StartX + (i-1) * 16), 0, 0)
            self.IconNum[i].depth = 91 + count % 300
        end
        if self.IconNum[i] then
            self.IconNum[i].width = 24
        end
    end
    ]]
end

function GameUIGoldAnima:GotoPosition(fromPos,topos,time)
    self.fromPostoZhuang = topos
    local EndToPos = GameUIManager.GetRandomPostion(topos)
    self.goldPos.from = fromPos
    self.goldPos.to = EndToPos
    self.goldPos.duration = time
    self.goldPos:ResetToBeginning()
    self.goldPos:PlayForward()
    self.isShow = true
end
function GameUIGoldAnima:SetPosition(topos)
    local v = GameUIManager.GetRandomPostion(topos)
    self.goldPos.transform.localPosition = v
    self.goldPos.from = v
    self.goldPos.to = v
    self.isShow = true

end

function GameUIGoldAnima:RevokePosition(time)
    local moveTime = self.duation + time
    self.goldPos.from = self.fromPostoZhuang
    self.goldPos.to = self.ZhuangPos
    self.goldPos.duration = moveTime
    self.goldPos:ResetToBeginning()
    self.goldPos:PlayForward()
    self.isShow = false

end
function GameUIGoldAnima:AllotGoldOne(fromPos,topos,toPlayre_Pos,time)
    if time == nil then
        time = 0.3
    end
    self.toPlayerPos = toPlayre_Pos
    local EndToPos = GameUIManager.GetRandomPostion(topos)
    self.fromPosToPlayer = EndToPos
    self.goldPos.from = fromPos
    self.goldPos.to = EndToPos
    self.goldPos.duration = time
    self.goldPos:ResetToBeginning()
    self.goldPos:PlayForward()
    self.isShow = true
end
function GameUIGoldAnima:RevokePlayerPos(time)
    local moveTime = 0.15 + time
    self.goldPos.from = self.fromPosToPlayer
    self.goldPos.to = self.toPlayerPos
    self.goldPos.duration = moveTime
    self.goldPos:ResetToBeginning()
    self.goldPos:PlayForward()
    self.isShow = false
end
function GameUIGoldAnima.HideGold(self,time)
    if time == nil then
        time = 0.2
    end
    coroutine.wait(time)
    print("等待时间：",time)
    self.transform.gameObject:SetActive(false)
    print("等待时间：",time)
end
function GameUIGoldAnima:HideGold()
    self.transform.gameObject:SetActive(false)
end

function GameUIGoldAnima.OnDestroy()
    GameUIGoldAnima.StopCor()
end
function GameUIGoldAnima.StopCor()
    if GameUIGoldAnima.goldCoroutine ~= nil then
        coroutine.stop(GameUIGoldAnima.goldCoroutine) 
    end
    GameUIGoldAnima.goldCoroutine = nil
end
return GameUIGoldAnima
