GameAudioContro = 
{
	bgaudiosource = nil,
	SoundEffect = nil,
	button = "Public/Audio/Sound/SelectButton.u3d",--按钮
	countDown = "Public/Audio/Sound/countdown.u3d",--倒计时
	ZhuandengClip = "Public/Audio/Sound/zhuandeng.u3d",
	win = "Public/Audio/Game/win.u3d",
	lose = "Public/Audio/Game/lose.u3d",
	TipsClip = 
	{
		"Public/Audio/Sound/startBet.u3d",
		"Public/Audio/Sound/stopBet.u3d",
		-- "Public/Audio/Sound/zhuang-1.u3d",
		-- "Public/Audio/Sound/zhuang-2.u3d",
	}
}

function GameAudioContro.Awake()
	GameAudioContro.bgaudiosource = GameAudioContro.transform:GetComponent("AudioSource")
	GameAudioContro.SoundEffect = GameAudioContro.transform:FindChild("SoundEffect"):GetComponent("AudioSource")
	GameDefine.AddEvent(GameDefine.Action_ResetBGVolume, GameAudioContro.ReSetPlayAudio)
	GameAudioContro.ReSetPlayAudio()
	gameresMrg:LoadPrefab(GameAudioContro.button, nil, nil)--预加载声音
end

function GameAudioContro.Play(AudioPath)
	print("---------",AudioPath)
	if AudioPath == nil or AudioPath == "" then 
		print("====>>AudioPath nil")
		return
	end
	
	if soundMgr.CanPlaySoundEffect then
		gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
			if objects ~= nil then
				GameAudioContro.SoundEffect:PlayOneShot(objects[0])
			end
		end)
    end
end

function GameAudioContro.PlayLoop(AudioPath)
	if soundMgr.CanPlaySoundEffect then
		gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
			GameAudioContro.SoundEffect.clip = objects[0]
			GameAudioContro.SoundEffect.loop = true
			GameAudioContro.SoundEffect:Play()
		end)
    end
end

function GameAudioContro.ReSetPlayAudio()
	if soundMgr.CanPlayBackSound then
		GameAudioContro.bgaudiosource:Play()
	else
		GameAudioContro.bgaudiosource:Stop()
	end
	if not soundMgr.CanPlaySoundEffect then
		GameAudioContro.SoundEffect:Stop()
	end
end

function GameAudioContro.StopEffect()
	GameAudioContro.SoundEffect:Stop()
end
function GameAudioContro.OnDestroy()
    package.loaded["606.GameAudioContro"] = nil
end