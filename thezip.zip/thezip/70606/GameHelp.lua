local GameHelp = 
{
	BtnClose,
	LbTax,
	Scroll_View,
}

function GameHelp.Awake()
	GameHelp.BtnClose = GameHelp.transform:FindChild("UI_Group/BtnClose").gameObject
	GameHelp.LbTax = GameHelp.transform:FindChild("UI_Group/Label_Tips").gameObject:GetComponent("UILabel")
    GameHelp.transform.gameObject:SetActive(false)
	--GameHelp.Scroll_View = GameHelp.transform:FindChild("UI_Group/Scroll_View").gameObject:GetComponent("UIScrollView")

end
function GameHelp.Start()
	UIEventListener.Get(GameHelp.BtnClose).onClick = GameHelp.Hide
end
function GameHelp.Show(taxVlue)
	GameHelp.transform.gameObject:SetActive(true)
	if taxVlue == 0 then
		GameHelp.LbTax.gameObject:SetActive(false)
	else
		GameHelp.LbTax.gameObject:SetActive(true)
		--GameHelp.LbTax.text = "本场次收取"..tostring(taxVlue).."%的服务费用于奖金的生成."
		GameHelp.LbTax.text = "Charge "..tostring(taxVlue).." of the service fee to the bonus pool"
	end
	GameHelp.transform.gameObject:GetComponent("Animation"):Play("Show")
	--GameHelp.Scroll_View:ResetPosition()

end

function GameHelp.Hide()
	if not GameHelp.transform.gameObject.activeSelf then
		return
	end
	GameHelp.transform.gameObject:GetComponent("Animation"):Play("Hide")
	local time = GameHelp.transform.gameObject:GetComponent("Animation"):GetClip("Hide").length
	coroutine.start(GameHelp.OnBtnHelpEnabled, time)
end

function GameHelp.OnBtnHelpEnabled(itime)
	coroutine.wait(itime)
	GameHelp.transform.gameObject:SetActive(false)
end
function GameHelp.OnDestroy()
	coroutine.stop(GameHelp.OnBtnHelpEnabled)
end
return GameHelp