local GameUIPlayerGroup = require "606.GameUIPlayerGroup"
local GameResult = 
{
    BtnClose,
    Anim,
    GoWinObj,
    GoUsZhuang,
    LbUsZhuangName,
    LbUsZhuangWinMoney,
    LbUsZhuangLoseMoney,
    IconUsZhuangLoseOrWin,

    GoUsXian,
    LbZhuangName,
    LbZhuangWinMoney,
    LbZhuangLoseMoney,
    IconZhuangLoseOrWin,
    LbUsXianName,
    LbUsXianWinMoney,
    LbUsXianLoseMoney,
    IconUsXianLoseOrWin,
    IconSignTarget1,
    IconSignTarget1,
    IconCoin,

    GameIconTarget,
    ItemParent,
    Obj_Pos,--路单
    Obj_Iterm,--路单项

    listLDIterm = {},--路单项

    mPlayerCount = 255,
    mMaxPlayerStation = {},
    mMaxPlayerSouce = {},

    mViewPos,--视图位置 
}
function GameResult.Awake()
    GameResult.BtnClose = GameResult.transform:FindChild("UI_Group/BtnClose").gameObject:GetComponent("UIButton")
    if GameResult.BtnClose then
        UIEventListener.Get(GameResult.BtnClose.gameObject).onClick = function()
            GameResult.Hide()
        end
    end
    GameResult.Anim = GameResult.transform:GetComponent("Animation")
    GameResult.GoWinObj = GameResult.transform:FindChild("Big_Win").gameObject
    GameResult.GoUsZhuang = GameResult.transform:FindChild("UI_Group/Score_Group1").gameObject
    GameResult.LbUsZhuangName = GameResult.transform:FindChild("UI_Group/Score_Group1/IconBox_Zhuang/Label_Name").gameObject:GetComponent("UILabel")
    GameResult.LbUsZhuangWinMoney = GameResult.transform:FindChild("UI_Group/Score_Group1/IconBox_Zhuang/Label_Win").gameObject:GetComponent("UILabel")
    GameResult.LbUsZhuangLoseMoney = GameResult.transform:FindChild("UI_Group/Score_Group1/IconBox_Zhuang/Label_Lose").gameObject:GetComponent("UILabel")
    --GameResult.IconUsZhuangLoseOrWin = GameResult.transform:FindChild("UI_Group/Score_Group1/IconBox_Zhuang/Icon_LossOrWin_Target").gameObject:GetComponent("UISprite")

    GameResult.GoUsXian = GameResult.transform:FindChild("UI_Group/Score_Group0").gameObject
    GameResult.LbZhuangName = GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Zhuang/Label_Name").gameObject:GetComponent("UILabel")
    GameResult.LbZhuangWinMoney = GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Zhuang/Label_Win").gameObject:GetComponent("UILabel")
    GameResult.LbZhuangLoseMoney = GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Zhuang/Label_Lose").gameObject:GetComponent("UILabel")
    --GameResult.IconZhuangLoseOrWin = GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Zhuang/Icon_LossOrWin_Target").gameObject:GetComponent("UISprite")
    GameResult.LbUsXianName = GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Xian/Label_Name").gameObject:GetComponent("UILabel")
    GameResult.LbUsXianWinMoney = GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Xian/Label_Win").gameObject:GetComponent("UILabel")
    GameResult.LbUsXianLoseMoney = GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Xian/Label_Lose").gameObject:GetComponent("UILabel")
    --GameResult.IconUsXianLoseOrWin = GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Xian/Icon_LossOrWin_Target").gameObject:GetComponent("UISprite")
    GameResult.IconSignTarget1 =  GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Xian/Icon_Sign_Target1").gameObject:GetComponent("UISprite") 
    GameResult.IconSignTarget2 =  GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Xian/Icon_Sign_Target2").gameObject:GetComponent("UISprite") 
    GameResult.IconCoin =  GameResult.transform:FindChild("UI_Group/Score_Group0/IconBox_Xian/Icon_Coin").gameObject 

    GameResult.GameIconTarget = GameResult.transform:FindChild("UI_Group/Icon_GameIcon_Target").gameObject:GetComponent("UISprite")
    GameResult.Obj_Pos = GameResult.transform:FindChild("UI_Group/ScrollView_Player").gameObject
    GameResult.ItemParent = GameResult.transform:FindChild("UI_Group/ScrollView_Player/Grid").gameObject
    GameResult.Obj_Iterm = GameResult.transform:FindChild("UI_Group/ScrollView_Player/Item_Player").gameObject
    GameResult.mViewPos = GameResult.Obj_Pos.transform.localPosition
    GameResult.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameResult.Obj_Pos.transform.position.x, 0)
    GameResult.InstanceHide()

    GameResult.transform.gameObject:SetActive(false)
end
function GameResult.InstanceHide()
    GameResult.GoWinObj:SetActive(false)
    GameResult.GoUsZhuang:SetActive(false)
    GameResult.GoUsXian:SetActive(false)
end
--region 玩家赢钱排名
function GameResult.ReSetPlayerBank(mplayCount,station,source)
    --恢复
    GameResult.Obj_Pos.transform.localPosition = GameResult.mViewPos
    GameResult.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameResult.Obj_Pos.transform.position.x, 0);

    GameResult.mMaxPlayerStation = {}
    GameResult.mMaxPlayerSouce = {}
    GameResult.mPlayerCount = mplayCount
    for i=1,#station do
        GameResult.mMaxPlayerStation[i] = station[i]
    end
    for i=1,#source do
        GameResult.mMaxPlayerSouce[i] = source[i]
    end
    GameResult.UpdateRecord()
end
--路单项
function GameResult.GetLDItermObj(nIndex)
    if nIndex <= #GameResult.listLDIterm then
        GameResult.listLDIterm[nIndex].gameObject:SetActive(true)
        return GameResult.listLDIterm[nIndex]
    end

    local Obj = UnityEngine.GameObject.Instantiate(GameResult.Obj_Iterm)
    Obj.name = "iterm"..nIndex
    Obj:SetActive(true)

    SetParent(GameResult.ItemParent, Obj)
    Obj.transform.position = Vector3.New(0,0,0)
    Obj.transform.localScale = Vector3.New(1,1,1)
    GameResult.ItemParent:GetComponent("UIGrid"):Reposition()

    local iterm = GameUIPlayerGroup:new(Obj.transform)
    iterm:Init()
    table.insert(GameResult.listLDIterm,iterm)
    return iterm
end
--更新跟单记录
function GameResult.UpdateRecord()
    local nLast = GameResult.mPlayerCount
    for i=1,#GameResult.listLDIterm do
        GameResult.listLDIterm[i].gameObject:SetActive(false)
    end
    for i=1,nLast do
        local user = GameUIManager.GetUserByStation(GameResult.mMaxPlayerStation[i])
        if user ~= nil then
            local uiRecordItem = GameResult.GetLDItermObj(i)
            if uiRecordItem ~= nil then
                uiRecordItem:ReSetInstance(i-1,user.szNickName,GameResult.mMaxPlayerSouce[i])
            end
        else
            print("玩家为空！",GameResult.mMaxPlayerStation[i])
        end
    end
end
function GameResult.Show(myWinLose,zhuangWinLose,zhuangStation,playerStation,playerwinSource,PlayerCount,animaName)
    print("----结算----",myWinLose,zhuangWinLose)
    if myWinLose > 0 then
        if not GameResult.GoWinObj then
            GameResult.GoWinObj:SetActive(true)
        end
    end
    if zhuangStation ~= MyUserInfo.iDeskStation then
        print("----结算---",type(GameResult.GoUsZhuang))
        GameResult.GoUsZhuang:SetActive(false)
        GameResult.GoUsXian:SetActive(true)
        GameResult.LbZhuangWinMoney.text = FormatNumToYW(MoneyProportionStr(zhuangWinLose))
        local zhuangData = GameUIManager.GetUserByStation(zhuangStation)
        if zhuangData ~= nil then
            GameResult.LbZhuangName.text = zhuangData.szNickName
        else
            print("玩家为空！",zhuangStation)
        end
        if zhuangWinLose >= 0 then
            GameResult.LbZhuangLoseMoney.gameObject:SetActive(false)
            GameResult.LbZhuangWinMoney.gameObject:SetActive(true)
            GameResult.LbZhuangWinMoney.text = "+"..FormatNumToYW(MoneyProportionStr(zhuangWinLose))
        else
            GameResult.LbZhuangWinMoney.gameObject:SetActive(false)
            GameResult.LbZhuangLoseMoney.gameObject:SetActive(true)
            GameResult.LbZhuangLoseMoney.text = ""..FormatNumToYW(MoneyProportionStr(zhuangWinLose))
        end
        GameResult.LbUsXianWinMoney.text = FormatNumToYW(MoneyProportionStr(myWinLose))
        GameResult.LbUsXianName.text = MyUserInfo.szNickName
        local nTotalBet = 0
        for i=1,#GameUIManager.mMyBets do
            nTotalBet = nTotalBet + GameUIManager.mMyBets[i] 
        end
        GameResult.IconCoin:SetActive(false)
        GameResult.IconSignTarget1.gameObject:SetActive(false)
        GameResult.IconSignTarget2.gameObject:SetActive(false)
        GameResult.LbUsXianLoseMoney.gameObject:SetActive(false)
        GameResult.LbUsXianWinMoney.gameObject:SetActive(false)
        if nTotalBet <= 0 then
            GameResult.IconSignTarget2.gameObject:SetActive(true)
        else
            GameResult.IconCoin:SetActive(true)
            if myWinLose >= 0 then
                GameResult.LbUsXianWinMoney.gameObject:SetActive(true)
                GameResult.LbUsXianWinMoney.text = "+"..FormatNumToYW(MoneyProportionStr(myWinLose))
                GameAudioContro.Play(GameAudioContro.win)
            else
                GameResult.LbUsXianLoseMoney.gameObject:SetActive(true)
                GameResult.LbUsXianLoseMoney.text = FormatNumToYW(MoneyProportionStr(myWinLose))
                GameAudioContro.Play(GameAudioContro.lose)
            end
        end
    else
        GameResult.GoUsZhuang:SetActive(true)
        GameResult.GoUsXian:SetActive(false)
        GameResult.LbUsZhuangName.text = MyUserInfo.szNickName
        if myWinLose >= 0 then
            GameResult.LbUsZhuangLoseMoney.gameObject:SetActive(false)
            GameResult.LbUsZhuangWinMoney.gameObject:SetActive(true)
            GameResult.LbUsZhuangWinMoney.text = "+"..FormatNumToYW(MoneyProportionStr(myWinLose))
            GameAudioContro.Play(GameAudioContro.win)
        else
            GameResult.LbUsZhuangWinMoney.gameObject:SetActive(false)
            GameResult.LbUsZhuangLoseMoney.gameObject:SetActive(true)
            GameResult.LbUsZhuangLoseMoney.text = FormatNumToYW(MoneyProportionStr(myWinLose))
            GameAudioContro.Play(GameAudioContro.lose)
        end
    end
    GameResult.ReSetPlayerBank(PlayerCount,playerStation,playerwinSource)
    GameResult.GameIconTarget.spriteName = "UI_Game_JS_"..animaName

    if GameResult.Anim then
        local animClip = GameResult.Anim:GetClip("Show")
        if animClip then
            GameResult.Anim.enabled = true
            GameResult.Anim:Play("Show")
        end
    end
    GameResult.transform.gameObject:SetActive(true)
end
function GameResult.Hide()
    if not GameResult.transform.gameObject.activeSelf then
        return
    end
    local time = 0
    if GameResult.Anim then
        local animClip = GameResult.Anim:GetClip("Hide")
        if animClip then
            GameResult.Anim.enabled = true
            GameResult.Anim:Play("Hide")
            time = animClip.length
        end
        coroutine.stop(GameResult.yieldHide)
        coroutine.start(GameResult.yieldHide,time)
    end
end
function GameResult.yieldHide(time)
    coroutine.wait(time)
    GameResult.GoWinObj:SetActive(false)
    GameResult.transform.gameObject:SetActive(false)
end
return GameResult