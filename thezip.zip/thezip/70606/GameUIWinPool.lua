local GameJiangChiPlayerInfo = require "606.GameJiangChiPlayerInfo"
local GameUIWinPool = 
{
        Anim,
        ItemParent,
        Obj_Iterm,-- 路单项
        listData = {}, -- 更新路单数据
}
function GameUIWinPool.Awake()
    GameUIWinPool.listData = {}
    GameUIWinPool.Anim = GameUIWinPool.transform.gameObject:GetComponent("Animation")
    GameUIWinPool.ItemParent = FindChildByName(GameUIWinPool.transform, "UI_Group/Grid", "gameObject")
    GameUIWinPool.Obj_Iterm = FindChildByName(GameUIWinPool.transform, "UI_Group/Player_Item", "gameObject")
end
function GameUIWinPool.UpdateRecord()
    for i=1,#GameUIWinPool.listData do
        local uiRecordItem = GameUIWinPool.GetItermObj(i)
        uiRecordItem:SetInfo3(GameUIWinPool.listData[i])
    end
end
function GameUIWinPool.GetItermObj(nIndex) 
    local Obj = UnityEngine.GameObject.Instantiate(GameUIWinPool.Obj_Iterm)
    Obj.name = "iterm"..nIndex
    Obj:SetActive(true)

    Obj.transform.parent = GameUIWinPool.ItemParent.transform
    Obj.transform.position = Vector3.zero
    Obj.transform.localScale = Vector3.one
    GameUIWinPool.ItemParent:GetComponent("UIGrid"):Reposition()
    local iterm = GameJiangChiPlayerInfo:new(Obj.transform)
    iterm:InitUI()
    return iterm
end
function GameUIWinPool.ShowUi()
    if (GameUIWinPool.Anim) then
        local animClip = GameUIWinPool.Anim:GetClip("JiangChi_Win_Show")
        if (animClip) then
            GameUIWinPool.Anim.enabled = true
            GameUIWinPool.Anim:Play("JiangChi_Win_Show")
        end
    end
end
function GameUIWinPool.UpdateUI(ListInfo)
    listData = {}
    for i = 1, #ListInfo do
        table.insert(GameUIWinPool.listData,ListInfo[i])
    end
    GameUIWinPool.UpdateRecord()
end
function GameUIWinPool.HideUi()
    local itime = 0
    if (GameUIWinPool.Anim) then
        local animClip = GameUIWinPool.Anim:GetClip("JiangChi_Hide");
        if (animClip) then
            GameUIWinPool.Anim.enabled = true;
            GameUIWinPool.Anim:Play("JiangChi_Hide");
            itime = animClip.length;
        end
    end
    coroutine.start(GameUIWinPool.yieldHide,itime)
end
function GameUIWinPool.yieldHide(time)
    coroutine.wait(time)
    GameUIWinPool.transform.gameObject:SetActive(false)
end
return GameUIWinPool