local GameUIGoldAnima = require "606.GameUIGoldAnima"
local GameUIGoldManager = 
{
    goldAnimaList = {},
    goldAnimaListInfo = {},
    GoldCount = 0,
    GoItem,
    areaList = {},
    areMaxCount = 15,
}
function GameUIGoldManager.Awake()
    GameUIGoldManager.goldAnimaList = {}
    GameUIGoldManager.goldAnimaListInfo = {}
    GameUIGoldManager.GoItem = GameUIGoldManager.transform:FindChild("GoldItem").gameObject
    for i=1,12 do
        GameUIGoldManager.areaList[i] = {}
    end
end

function GameUIGoldManager.CreatGold(userId,money,checkIndex,areaIndex)
    areaIndex = areaIndex + 1
    if userId == MyUserInfo.uiUserID then
        print(GameUIGoldManager.GoldCount , #GameUIGoldManager.goldAnimaList,#GameUIGoldManager.goldAnimaListInfo)
    end
    local goldAnima
    if GameUIGoldManager.GoldCount < #GameUIGoldManager.goldAnimaList then
        GameUIGoldManager.goldAnimaList[GameUIGoldManager.GoldCount+1].gameObject:SetActive(true)
        GameUIGoldManager.goldAnimaList[GameUIGoldManager.GoldCount+1].gameObject.name = "GoldItem"..GameUIGoldManager.GoldCount
        goldAnima = GameUIGoldManager.goldAnimaList[GameUIGoldManager.GoldCount+1]
        goldAnima:ReSetData(money, checkIndex, GameUIGoldManager.GoldCount)
        table.insert(GameUIGoldManager.areaList[areaIndex],goldAnima)
    else
        local item = InstantiateObj(GameUIGoldManager.GoItem,GameUIGoldManager.transform)
        item:SetActive(true)
        item.transform.localScale = Vector3.New(1,1,1)
        goldAnima = GameUIGoldAnima:new(item.transform)
		goldAnima:Init()
		goldAnima.transform.gameObject.name = "GoldItem"..GameUIGoldManager.GoldCount
        table.insert(GameUIGoldManager.goldAnimaList,goldAnima)
        table.insert(GameUIGoldManager.areaList[areaIndex],goldAnima)
        goldAnima:CreatChouMa(money, checkIndex, GameUIGoldManager.GoldCount)
    end

    GameUIGoldManager.GoldCount = GameUIGoldManager.GoldCount + 1
        
    if GameUIGoldManager.ContainsKey(GameUIGoldManager.goldAnimaListInfo,userId) then
        local index = GameUIGoldManager.GetIndex(GameUIGoldManager.goldAnimaListInfo,userId)
        table.insert(GameUIGoldManager.goldAnimaListInfo[index].goldAnimaObj,goldAnima)
    else
        local snoplist = {}
        snoplist.Id = userId
        snoplist.goldAnimaObj = {goldAnima}
        table.insert(GameUIGoldManager.goldAnimaListInfo,snoplist)
    end
    if #GameUIGoldManager.areaList[areaIndex] > GameUIGoldManager.areMaxCount then
        local dateLen1 = #GameUIGoldManager.areaList[areaIndex]-GameUIGoldManager.areMaxCount
        for i=1,dateLen1 do
            GameUIGoldManager.areaList[areaIndex][i].gameObject:SetActive(false)
        end
    end
    return goldAnima
end
function GameUIGoldManager.RemoveGold(userId)
    if GameUIGoldManager.ContainsKey(GameUIGoldManager.goldAnimaListInfo,userId) then
        if #GameUIGoldManager.goldAnimaListInfo > 0 then
            local index = GameUIGoldManager.GetIndex(GameUIGoldManager.goldAnimaListInfo,userId)
            for i=1,#GameUIGoldManager.goldAnimaListInfo[index].goldAnimaObj do
                GameUIGoldManager.goldAnimaListInfo[index].goldAnimaObj[i].gameObject:SetActive(false)
            end
            GameUIGoldManager.GoldCount = GameUIGoldManager.GoldCount - #GameUIGoldManager.goldAnimaListInfo[index].goldAnimaObj
            table.remove(GameUIGoldManager.goldAnimaListInfo,index)
        else
            print("userId Is Null")
        end
    else
        print("goldAnimaListInfo Is Zezo")
    end
end
function GameUIGoldManager.HideAllGoldList()
    if #GameUIGoldManager.goldAnimaList > 0 then
        for i=1,#GameUIGoldManager.goldAnimaList do
            if GameUIGoldManager.goldAnimaList[i].gameObject.activeSelf then
                GameUIGoldManager.goldAnimaList[i]:HideGold()
            end
        end
    else
        print("goldAnimaListInfo Is Zezo")
    end
    for i=1,12 do
        GameUIGoldManager.areaList[i] = {}
    end
    GameUIGoldManager.goldAnimaListInfo = {}
    GameUIGoldManager.GoldCount = 0
end
function GameUIGoldManager.RevokePosition()
    if #GameUIGoldManager.goldAnimaList > 0 then
        local goldAll = GameUIGoldManager.GoldCount
        for i=1,#GameUIGoldManager.goldAnimaList do
            if GameUIGoldManager.goldAnimaList[i].gameObject.activeSelf then
                GameUIGoldManager.GoldCount = GameUIGoldManager.GoldCount - 1
                if GameUIGoldManager.GoldCount <= 0 then
                    GameUIGoldManager.GoldCount = 1
                end
                GameUIGoldManager.goldAnimaList[i]:RevokePosition(GameUIGoldManager.GoldCount * 0.5/goldAll)
            end
        end
    end
    GameUIGoldManager.goldAnimaListInfo = {}
    GameUIGoldManager.GoldCount = 0
end
function GameUIGoldManager.RevokePlayerPos()
    if #GameUIGoldManager.goldAnimaList > 0 then
        local goldAll = GameUIGoldManager.GoldCount
        for i=1,#GameUIGoldManager.goldAnimaList do
            if GameUIGoldManager.goldAnimaList[i].gameObject.activeSelf then
                GameUIGoldManager.GoldCount = GameUIGoldManager.GoldCount - 1
                if GameUIGoldManager.GoldCount <= 0 then
                    GameUIGoldManager.GoldCount = 1
                end
                GameUIGoldManager.goldAnimaList[i]:RevokePlayerPos(GameUIGoldManager.GoldCount * 0.5/goldAll)
            end
        end
    end
    GameUIGoldManager.goldAnimaListInfo = {}
    GameUIGoldManager.GoldCount = 0
end

function GameUIGoldManager.ContainsKey(goldAnimaListInfo,userId)
	for i=1,#GameUIGoldManager.goldAnimaListInfo do
		if GameUIGoldManager.goldAnimaListInfo[i].Id == userId then
    		return true
   		end
	end
	return false
end
function GameUIGoldManager.GetIndex(goldAnimaListInfo,userId)
    for i=1,#goldAnimaListInfo do
        if goldAnimaListInfo[i].Id == tonumber(tostring(userId)) then
            return i
        end
    end
end     
function GameUIGoldManager.OnDestroy()
    package.loaded["606.GameUIGoldManager"] = nil

end
return GameUIGoldManager