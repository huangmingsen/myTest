local GamePlayerGroup =
{
}
function GamePlayerGroup:new(trans)
    local _instance =
    {
        transform = trans,
        gameObject = trans.gameObject
    }
    self.__index = self
    setmetatable(_instance, self)
    return _instance
end
function GamePlayerGroup:InitUI()
    self.IconHead = FindChildByName(self.transform, "IconHead_Box/Icon_Head", "UISprite")
    self.LbName = FindChildByName(self.transform, "Label_Name", "UILabel")
    self.LbVip = FindChildByName(self.transform, "LbVip", "UILabel")
    self.LbMoney = FindChildByName(self.transform, "Label_Money", "UILabel")
    self.LbQueue = FindChildByName(self.transform, "Label_Queue", "UILabel")

end
function GamePlayerGroup:SetInfo(info)
    self.userInfo = info
    if info == nil then return end
    self:UpdateHead(info[2],info[3])
    if self.LbName then
        self.LbName.text = info[4]
    end
    if self.LbMoney then
        self.LbMoney.text = FormatNumToYW(MoneyProportionStr(info[5]))
    end
    if self.LbVip then
        self.LbVip.text = tostring(info[7])
    end
end
function GamePlayerGroup:SetBankerInfo(index,info,money)
    self:UpdateHead(info.iImageNO,info.iPhotoFrame)
    if self.LbName then
        self.LbName.text = info.szNickName
    end
    if self.LbMoney then
        self.LbMoney.text = FormatNumToYW(MoneyProportionStr(money))
    end
    if self.LbVip then
        self.LbVip.text = tostring(info.iVipLevel)
    end
    if self.LbQueue then
        self.LbQueue.text = ""..index
    end
end
function GamePlayerGroup:UpdateHead(headId, borderId)
    if self.ImHeadBorder then
        local HeadBorderName = GetHeadBorderById(borderId)
        self.ImHeadBorder.spriteName = HeadBorderName
        --self.ImHeadBorder:MakePixelPerfect()
    end

    local HeadName = GetHeadSpriteName(headId)
    if self.IconHead then
        self.IconHead.spriteName = HeadName
    end
    --self.IconHead:MakePixelPerfect()
end
return GamePlayerGroup
