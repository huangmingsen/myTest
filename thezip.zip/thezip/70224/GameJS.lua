local GameJS =
{
	LbZhuangName,
	GoBacks = {},
	LbWinCardPoint = {},
	LbLoseCardPoint = {},
	RankItems = {},
	IconWinLoseSign = {},

	LbMyWin,
	LbMyLost,
	GoNoBetTis,
}

function GameJS.Awake()
	GameJS.GoBacks[1] = FindChildByName(GameJS.transform, "UIGroup/BG_Team/ImageBG_Win", "gameObject")
	GameJS.GoBacks[2] = FindChildByName(GameJS.transform, "UIGroup/BG_Team/ImageBG_Lose", "gameObject")
	for i = 1, 2 do
		GameJS.LbWinCardPoint[i] = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Label_Dian_Win"..i, "UILabel")
		GameJS.LbLoseCardPoint[i] = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Label_Dian_Lose"..i, "UILabel")
		GameJS.IconWinLoseSign[i] = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Icon_WinOrLose_Target"..i, "UISprite")
	end
	for i = 1, 3 do
		GameJS.RankItems[i] = {}
		GameJS.RankItems[i].transform = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Player_Team/Rank_"..i)
		GameJS.RankItems[i].LbName = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Player_Team/Rank_"..i.."/Label_Name", "UILabel")
		GameJS.RankItems[i].LbCoin = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Player_Team/Rank_"..i.."/Label_Coin", "UILabel")
	end

	GameJS.LbZhuangName = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Label_Zhuang_Name", "UILabel")
	GameJS.LbMyWin = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Label_Score_Win", "UILabel")
	GameJS.LbMyLost = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Label_Score_Lose", "UILabel")
	--GameJS.GoNoBetTis = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Font_Tips", "gameObject")
	GameJS.GoNoBetTis = FindChildByName(GameJS.transform, "UIGroup/Score_Group/Label_Tips", "gameObject")
end

function GameJS.Show(ZhuangInfo,myWinLost,isNote,prizePoint,winInfo)
	GameJS.GoBacks[1]:SetActive(myWinLost >= 0)
	GameJS.GoBacks[2]:SetActive(myWinLost < 0)
	GameJS.LbMyWin.gameObject:SetActive(false)
	GameJS.LbMyLost.gameObject:SetActive(false)
	GameJS.GoNoBetTis:SetActive(false)
	local snopMyWinLost = MoneyProportionStr(myWinLost)
	if myWinLost >= 0 then
		GameJS.LbMyWin.gameObject:SetActive(true)
		GameJS.LbMyWin.text = "+"..FormatNumToYW(snopMyWinLost)
	else
		GameJS.LbMyLost.gameObject:SetActive(true)
		GameJS.LbMyLost.text = FormatNumToYW(snopMyWinLost)
	end
	if ZhuangInfo.uiUserID ~= MyUserInfo.uiUserID then
		if isNote then
			if myWinLost >= 0 then
				GameAudioContro.Play(GameAudioContro.ResultWinAud)
			else
				GameAudioContro.Play(GameAudioContro.ResultLoseAud)
			end
		else
			GameAudioContro.Play(GameAudioContro.ResultNoBetAud)
			GameJS.GoNoBetTis:SetActive(true)
			GameJS.LbMyWin.gameObject:SetActive(false)
			GameJS.LbMyLost.gameObject:SetActive(false)
		end
	else
		if myWinLost >= 0 then
			GameAudioContro.Play(GameAudioContro.ResultWinAud)
		else
			GameAudioContro.Play(GameAudioContro.ResultLoseAud)
		end
	end
	GameJS.LbZhuangName.text = ZhuangInfo.szNickName
	for i = 1, 2 do
		GameJS.LbWinCardPoint[i].gameObject:SetActive(false)
		GameJS.LbLoseCardPoint[i].gameObject:SetActive(false)
	end
	if prizePoint[1] == prizePoint[2] then
		GameJS.LbWinCardPoint[1].gameObject:SetActive(true)
		GameJS.LbWinCardPoint[1].text = tostring(prizePoint[1]).."D"
		GameJS.LbWinCardPoint[2].gameObject:SetActive(true)
		GameJS.LbWinCardPoint[2].text = tostring(prizePoint[2]).."D"
		GameJS.IconWinLoseSign[1].spriteName = "Icon_JS_Win_Ping"
		GameJS.IconWinLoseSign[2].spriteName = "Icon_JS_Win_Ping"
	elseif prizePoint[1] > prizePoint[2] then
		GameJS.LbWinCardPoint[1].gameObject:SetActive(true)
		GameJS.LbWinCardPoint[1].text = tostring(prizePoint[1]).."D"
		GameJS.LbLoseCardPoint[2].gameObject:SetActive(true)
		GameJS.LbLoseCardPoint[2].text = tostring(prizePoint[2]).."D"
		GameJS.IconWinLoseSign[1].spriteName = "Txt_JS_KJ_Win"
		GameJS.IconWinLoseSign[2].spriteName = "Txt_JS_KJ_Lose"
	else
		GameJS.LbWinCardPoint[2].gameObject:SetActive(true)
		GameJS.LbWinCardPoint[2].text = tostring(prizePoint[2]).."D"
		GameJS.LbLoseCardPoint[1].gameObject:SetActive(true)
		GameJS.LbLoseCardPoint[1].text = tostring(prizePoint[1]).."D"
		GameJS.IconWinLoseSign[1].spriteName = "Txt_JS_KJ_Lose"
		GameJS.IconWinLoseSign[2].spriteName = "Txt_JS_KJ_Win"
	end
	for i = 1, 3 do
		if i <= #winInfo then
			GameJS.RankItems[i].transform.gameObject:SetActive(true)
			GameJS.RankItems[i].LbName.text = tostring(winInfo[i][1])
			GameJS.RankItems[i].LbCoin.text = GameUIManager.FormatNumToStringYW(MoneyProportionStr(winInfo[i][2]))
		else
			GameJS.RankItems[i].transform.gameObject:SetActive(false)
		end
	end
	GameJS.transform.gameObject:SetActive(true)
	GameJS.transform.gameObject:GetComponent("Animation"):Play()
end
function GameJS.UpdateHead(imageHead,imageBorder,headId, borderId)
	if imageBorder ~= nil then
		local HeadBorderName = GetHeadBorderById(borderId)
		imageBorder.spriteName = HeadBorderName
		--self.ImHeadBorder:MakePixelPerfect()
	end

	local HeadName = GetHeadSpriteName(headId)
	imageHead.spriteName = HeadName
	--self.IconHead:MakePixelPerfect()
end

function GameJS.Hide()
	GameJS.transform.gameObject:SetActive(false)
end

return GameJS