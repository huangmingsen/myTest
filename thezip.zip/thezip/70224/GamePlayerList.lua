local GamePlayerGroup = require "224.GamePlayerGroup"
local GamePlayerList = 
{
	Close,
	ItemParent,
    Obj_Pos, -- 路单
    Obj_Iterm, -- 路单项
    colliderBlack,
    listLDIterm = {}, --路单项
    listLDData = {}, --更新路单数据
	mViewPos, -- 视图位置                                           
	mDistane = 0.0, -- 间距
	mShowNum = 0, -- 显示个数
    isShow = false,
}
function GamePlayerList.Awake() 
    GamePlayerList.isShow = false
    GamePlayerList.listLDIterm = {}
    GamePlayerList.colliderBlack = FindChildByName(GamePlayerList.transform, "BlackCollider","Collider")
    GamePlayerList.LbPlayerCount = FindChildByName(GamePlayerList.transform, "List_Team/Lb_Player","UILabel")
    GamePlayerList.Close = FindChildByName(GamePlayerList.transform, "List_Team/Button_Close","gameObject")
	--UIEventListener.Get(GamePlayerList.Close).onClick = GamePlayerList.HideUI
    GamePlayerList.Obj_Pos = FindChildByName(GamePlayerList.transform, "List_Team/Player_ScrollView","gameObject")
    GamePlayerList.ItemParent = FindChildByName(GamePlayerList.transform, "List_Team/Player_ScrollView/Player_Grid","gameObject")
    GamePlayerList.Obj_Iterm = FindChildByName(GamePlayerList.transform, "List_Team/Player_ScrollView/Item_Player","gameObject")
	GamePlayerList.mViewPos = GamePlayerList.Obj_Pos.transform.position
	GamePlayerList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GamePlayerList.Obj_Pos.transform.position.x, 0 )
end

function GamePlayerList.ShowUI()
	-- 恢复
    if (not GamePlayerList.isShow) then
        GamePlayerList.isShow = true
        --GamePlayerList.colliderBlack.enabled = true
        GamePlayerList.Obj_Pos.transform.localPosition = GamePlayerList.mViewPos
        GamePlayerList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GamePlayerList.Obj_Pos.transform.position.x, 0)
        --GamePlayerList.transform.gameObject:GetComponent("Animation"):Play("PlayerList_Show")
    end
end
function GamePlayerList.ReSetData(listLD)
    GamePlayerList.LbPlayerCount.text = tostring(#listLD)
    GamePlayerList.listLDData = {}
    for i=1,#listLD do
        table.insert(GamePlayerList.listLDData,listLD[i])
    end
    GamePlayerList.UpdateRecord()
end
function GamePlayerList.HideUI() 
    if (GamePlayerList.isShow) then
        GamePlayerList.isShow = false;
        --GamePlayerList.colliderBlack.enabled = false;
        --GamePlayerList.transform.gameObject:GetComponent("Animation"):Play("PlayerList_Hide")
    end
end
-- 路单项
function GamePlayerList.GetLDItermObj(nIndex)
	if ( nIndex <= #GamePlayerList.listLDIterm ) then
        GamePlayerList.listLDIterm[nIndex].gameObject:SetActive(true)
        GamePlayerList.listLDIterm[nIndex].gameObject.name = "iterm"..nIndex
		return GamePlayerList.listLDIterm[nIndex]
	end

    local Obj = UnityEngine.GameObject.Instantiate(GamePlayerList.Obj_Iterm)
	Obj.name = "iterm"..nIndex
	Obj:SetActive(true)
	SetParent(GamePlayerList.ItemParent ,Obj)
   	GamePlayerList.ItemParent:GetComponent("UIGrid"):Reposition()
	local iterm = GamePlayerGroup:new(Obj.transform)
	iterm:InitUI()
	table.insert(GamePlayerList.listLDIterm,iterm)
	return iterm
end
function GamePlayerList.UpdateRecord()-- 更新信息
    for i = 1,#GamePlayerList.listLDIterm do
        GamePlayerList.listLDIterm[i].gameObject:SetActive(false)
    end
	for n = 1, #GamePlayerList.listLDData do
        local Item = GamePlayerList.GetLDItermObj(n)
        Item:SetInfo(GamePlayerList.listLDData[n])
	end
end
return GamePlayerList