local json = require "cjson"
local WWWManager = require(string.format("%s/Common/WWWManager", ConfigData.HallSkin))
local GameUIRecord =
{
	BtnClose,
	GoTip,
	RecordItem,
	ScrollView,
	Grid,
	RecordList = {},
	ItemData = {},
	RecordLogs = serviceHost.."/GameService/User/GameRecordLogs.ws",
}

function GameUIRecord.Awake()
	GameUIRecord.ItemData ={}
	GameUIRecord.RecordList ={}
	GameUIRecord.BtnClose = FindChildByName(GameUIRecord.transform, "UIGroup/BtnClose","gameObject")
	GameUIRecord.GoTip = FindChildByName(GameUIRecord.transform, "UIGroup/ImageBG/Label_Tips1","gameObject")
	GameUIRecord.RecordItem = FindChildByName(GameUIRecord.transform, "UIGroup/Record_Item","gameObject")
	GameUIRecord.ScrollView = FindChildByName(GameUIRecord.transform, "UIGroup/Record_ScrollView","UIScrollView")
	GameUIRecord.Grid = FindChildByName(GameUIRecord.transform, "UIGroup/Record_ScrollView/Grid","UIGrid")
	UIEventListener.Get(GameUIRecord.BtnClose).onClick = GameUIRecord.Hide
end

function GameUIRecord.show()
	GameUIRecord.transform.gameObject:SetActive(true)
	GameUIRecord.transform.gameObject:GetComponent("Animation"):Play("Help_Show")
	GameUIRecord.GetRecordLogs()
end

function GameUIRecord.Hide()
	GameUIRecord.transform.gameObject:GetComponent("Animation"):Play("Help_Hide")
	coroutine.start(GameUIRecord.HideObject)
end

function GameUIRecord.HideObject()
	coroutine.wait(1)
	GameUIRecord.transform.gameObject:SetActive(false)
end


function GameUIRecord.GetRecordLogs()
	if not GameUIRecord.transform.gameObject.activeSelf then return end
	if GameUIRecord.RecordList == nil or #GameUIRecord.RecordList < 1 then
		LoadingMsg.Show("loading...")
	else
		GameUIRecord.ShowRecord()
	end
	local tabledata = 
	{
		{name = "agentId", value = AppType },
		{name = "userId", value = tostring(MyUserInfo.uiUserID) },
		{name = "gameId", value = 224 },
	}
	local rearurl = WWWManager.GetResultUrl(GameUIRecord.RecordLogs, tabledata, true)
    print(rearurl)
    WWWManager.RequestUrl(rearurl, GameUIRecord.GetRecordLogsReturn, function()
        print("加载游戏记录失败!")
        LoadingMsg.Hied()
    end)
end

function GameUIRecord.GetRecordLogsReturn(resultTxt)
    --print(resultTxt)
    LoadingMsg.Hied()
    local obj = json.decode(resultTxt)
    if obj ~= nil and obj.code == 0 then
    	GameUIRecord.RecordList = {}
    	local snopList = obj.data
    	for i=1,#snopList do
    		local oneTxt = snopList[i].Description
    		if oneTxt ~= nil and oneTxt ~= "" and tostring(oneTxt) ~= "userdata: NULL" then
	    		local twoTxt = string.gsub(oneTxt,"\n","")
	    		local oneObj = json.decode(twoTxt)
	    		if oneObj ~= nil then
	    			table.insert(GameUIRecord.RecordList,oneObj)
	    		end
	    	end
    	end
        GameUIRecord.ShowRecord()
    else
        LblMsgText.Show(obj.msg)
    end
end

function GameUIRecord.ShowRecord()
	-- if #GameUIRecord.RecordList == 0 then
	-- 	GameUIRecord.GoTip:SetActive(true)
	-- 	return
	-- end
	-- GameUIRecord.GoTip:SetActive(false)
	for i=1,#GameUIRecord.RecordList do
		if GameUIRecord.ItemData[i] == nil then
			GameUIRecord.ItemData[i] = {}
			local gobj = UnityEngine.GameObject.Instantiate(GameUIRecord.RecordItem)
			gobj.transform:SetParent(GameUIRecord.Grid.transform)
            gobj.transform.localPosition = Vector3.New(0, 0, 0)
            gobj.transform.localScale = Vector3.New(1, 1, 1)
			GameUIRecord.ItemData[i].itemobj = gobj
			GameUIRecord.ItemData[i].Label_GameNane = FindChildByName(gobj.transform, "Label_GameName","UILabel")
			GameUIRecord.ItemData[i].Label_State = FindChildByName(gobj.transform, "Label_State","UILabel")
			GameUIRecord.ItemData[i].Label_AllDown = FindChildByName(gobj.transform, "Label_AllDown","UILabel")
			GameUIRecord.ItemData[i].Label_AllWin = FindChildByName(gobj.transform, "Label_AllWin","UILabel")
			GameUIRecord.ItemData[i].Label_Win = FindChildByName(gobj.transform, "Label_Win","UILabel")
			GameUIRecord.ItemData[i].Label_Lose = FindChildByName(gobj.transform, "Label_Lose","UILabel")
			GameUIRecord.ItemData[i].Label_Coin = FindChildByName(gobj.transform, "Label_Coin","UILabel")
			GameUIRecord.ItemData[i].Label_Date = FindChildByName(gobj.transform, "Label_Date","UILabel")
			GameUIRecord.ItemData[i].BtnDetail = FindChildByName(gobj.transform, "BtnDetail","gameObject")
            UIEventListener.Get(GameUIRecord.ItemData[i].BtnDetail).onClick = GameUIRecord.OnShowDetail
			gobj:SetActive(true)
		end
		GameUIRecord.ItemData[i].Label_GameNane.text = GameUIRecord.RecordList[i].Name
		GameUIRecord.ItemData[i].Label_State.text = GameUIRecord.RecordList[i].Type
		GameUIRecord.ItemData[i].Label_AllDown.text = FormatNumToStringYW(MoneyProportionStr(GameUIRecord.RecordList[i].Note))
		GameUIRecord.ItemData[i].Label_AllWin.text = FormatNumToStringYW(MoneyProportionStr(GameUIRecord.RecordList[i].Win))
		if GameUIRecord.RecordList[i].Real >= 0 then
			GameUIRecord.ItemData[i].Label_Win.text = FormatNumToStringYW(MoneyProportionStr(GameUIRecord.RecordList[i].Real))
			GameUIRecord.ItemData[i].Label_Win.gameObject:SetActive(true)
			GameUIRecord.ItemData[i].Label_Lose.gameObject:SetActive(false)
		else
			GameUIRecord.ItemData[i].Label_Lose.text = FormatNumToStringYW(MoneyProportionStr(GameUIRecord.RecordList[i].Real))
			GameUIRecord.ItemData[i].Label_Win.gameObject:SetActive(false)
			GameUIRecord.ItemData[i].Label_Lose.gameObject:SetActive(true)
		end
		GameUIRecord.ItemData[i].Label_Coin.text = FormatNumToStringYW(MoneyProportionStr(GameUIRecord.RecordList[i].Money))
		GameUIRecord.ItemData[i].Label_Date.text = GameUIRecord.RecordList[i].Time
	end
	GameUIRecord.ScrollView:ResetPosition()
	GameUIRecord.Grid.repositionNow = true
end
function GameUIRecord.OnShowDetail(go)
    for i = 1, #GameUIRecord.ItemData do
        if(GameUIRecord.ItemData[i].BtnDetail == go) then
            GameUIManager.ShowGameDetail(GameUIRecord.RecordList[i])
            return
        end
    end
end

return GameUIRecord