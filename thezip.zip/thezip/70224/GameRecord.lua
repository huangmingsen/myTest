local GameRecordCardItem = require "224.GameRecordCardItem"
local GameRecord =
{
    BtnClose,
    LbPrizeCout = {},

    HLLItemParent,
    ObjHLL_Iterm, -- 路单项

    AllWinParent,
    ObjAllWinIterm, -- 路单项

    DYParent,
    ObjDYIterm, -- 路单项

    XLParent,
    ObjXLIterm, -- 路单项

    XQParent,
    ObjXQIterm, -- 路单项

    listHLLIterm = {}, -- 红黑单项
    listHLLData = {}, -- 红黑数据

    listAllWinItem = {}, -- 红黑单项
    listAllWinData = {}, -- 红黑数据

    listDYItem = {}, -- 红黑单项
    listDYData = {}, -- 红黑数据

    listXLItem = {}, -- 红黑单项
    listXLData = {}, -- 红黑数据

    listXQItem = {}, -- 红黑单项
    listXQData = {}, -- 红黑数据

    LDSlider = {},

    mDistane = 0.0, -- 间距
    mShowNum = 0, -- 显示个数
    isShow = false,
}
function GameRecord.Awake()
    GameRecord.isShow = false

    GameRecord.listHLLIterm = {}
    GameRecord.listHLLData = {}

    GameRecord.listAllWinItem = {}
    GameRecord.listAllWinData = {}

    GameRecord.listDYItem = {}
    GameRecord.listDYData = {}

    GameRecord.listXLItem = {}
    GameRecord.listXLData = {}

    GameRecord.listXQItem = {}
    GameRecord.listXQData = {}

    GameRecord.BtnClose = FindChildByName(GameRecord.transform,"UIGroup/BtnClose","gameObject")
    UIEventListener.Get(GameRecord.BtnClose).onClick = GameRecord.OnBtnClose

    GameRecord.LbPrizeCout[1] = FindChildByName(GameRecord.transform,"UIGroup/Label_Zhuang","UILabel")
    GameRecord.LbPrizeCout[2] = FindChildByName(GameRecord.transform,"UIGroup/Label_Ping","UILabel")
    GameRecord.LbPrizeCout[3] = FindChildByName(GameRecord.transform,"UIGroup/Label_Xian","UILabel")
    GameRecord.LbPrizeCout[4] = FindChildByName(GameRecord.transform,"UIGroup/Label_ZhuangDui","UILabel")
    GameRecord.LbPrizeCout[5] = FindChildByName(GameRecord.transform,"UIGroup/Label_XianDui","UILabel")
    GameRecord.LbPrizeCout[6] = FindChildByName(GameRecord.transform,"UIGroup/Label_All","UILabel")

    GameRecord.HLLItemParent = FindChildByName(GameRecord.transform,"UIGroup/PaiLu1/LD_Grid","gameObject")
    GameRecord.ObjHLL_Iterm = FindChildByName(GameRecord.transform,"UIGroup/Item_LD1","gameObject")

    GameRecord.AllWinParent = FindChildByName(GameRecord.transform,"UIGroup/PaiLu5/LD_Grid","gameObject")
    GameRecord.ObjAllWinIterm = FindChildByName(GameRecord.transform,"UIGroup/Item_LD5","gameObject")

    GameRecord.DYParent = FindChildByName(GameRecord.transform,"UIGroup/PaiLu2/LD_Grid","gameObject")
    GameRecord.ObjDYIterm = FindChildByName(GameRecord.transform,"UIGroup/Item_LD2","gameObject")

    GameRecord.XLParent = FindChildByName(GameRecord.transform,"UIGroup/PaiLu3/LD_Grid","gameObject")
    GameRecord.ObjXLIterm = FindChildByName(GameRecord.transform,"UIGroup/Item_LD3","gameObject")

    GameRecord.XQParent = FindChildByName(GameRecord.transform,"UIGroup/PaiLu4/LD_Grid","gameObject")
    GameRecord.ObjXQIterm = FindChildByName(GameRecord.transform,"UIGroup/Item_LD4","gameObject")

    for i = 1, 5 do
        GameRecord.LDSlider[i] = FindChildByName(GameRecord.transform,"UIGroup/LDSlider"..i,"UISlider")
    end
    --GameRecord.ReSet({0,0,0,0,0},{},{})
    for i = 1, #GameRecord.LDSlider do
        GameRecord.LDSlider[i].value = 0
    end
    coroutine.start(GameRecord.YiledPlayAnima)
end

function GameRecord.ReSet(countArr,listHLL,listWin)
    GameRecord.LbPrizeCout[1].text = tostring(countArr[1])
    GameRecord.LbPrizeCout[2].text = tostring(countArr[2])
    GameRecord.LbPrizeCout[3].text = tostring(countArr[3])
    GameRecord.LbPrizeCout[4].text = tostring(countArr[4])
    GameRecord.LbPrizeCout[5].text = tostring(countArr[5])
    GameRecord.LbPrizeCout[6].text = tostring(countArr[1] + countArr[2] + countArr[3])
    GameRecord.listHLLData = {}
    GameRecord.listAllWinData = {}
    GameRecord.listDYData = {}
    GameRecord.listXLData = {}
    GameRecord.listXQData = {}
    for i = 1, #listWin do
        table.insert(GameRecord.listAllWinData,listWin[i])
    end
    local listHllArr = {}
    for i = 1, #listHLL do
        table.insert(listHllArr,listHLL[i])
    end
    GameRecord.listHLLData = GameRecord.GetZhuPanData(listHllArr,6,29)
    GameRecord.listDYData = GameRecord.GetDownThreeLuData(listHllArr,2,12)
    GameRecord.listXLData = GameRecord.GetDownThreeLuData(listHllArr,3,12)
    GameRecord.listXQData = GameRecord.GetDownThreeLuData(listHllArr,4,12)
    GameRecord.UpdateRecord()
    for i = 1, #GameRecord.LDSlider do
        GameRecord.LDSlider[i].value = 0.99
    end
    coroutine.start(GameRecord.YiledPlayAnima)
end
function GameRecord.YiledPlayAnima()
    coroutine.wait(0.2)
    for i = 1, #GameRecord.LDSlider do
        GameRecord.LDSlider[i].value = 1
    end
end
--路单项
function GameRecord.GetItermObj(listArr,ItemParent,Iterm,nIndex )
    if ( nIndex <= #listArr ) then
        listArr[nIndex].gameObject:SetActive(true)
        listArr[nIndex].gameObject.name = "iterm"..nIndex
        return listArr[ nIndex ]
    end
    local Obj = UnityEngine.GameObject.Instantiate(Iterm)
    Obj.name = "iterm"..nIndex
    Obj:SetActive(true)
    Obj.transform.parent = ItemParent.transform
    --ItemParent:GetComponent("UIGrid"):AddChild(Obj.transform)
    Obj.transform.position = Vector3.zero
    Obj.transform.localScale = Vector3.one
    local iterm = GameRecordCardItem:new(Obj.transform)
    iterm:InitUI()
    table.insert(listArr,iterm)
    return iterm
end
--更新跟单记录
function GameRecord.UpdateRecord()
    for i=1,#GameRecord.listAllWinItem do
        GameRecord.listAllWinItem[i].gameObject:SetActive(false)
    end
    for i = 1,#GameRecord.listHLLIterm do
        GameRecord.listHLLIterm[i]:SetInfo1({-1,false})
        if i > 174 then
            GameRecord.listHLLIterm[i].gameObject:SetActive(false)
        end
    end
    for i = 1,#GameRecord.listDYItem do
        GameRecord.listDYItem[i]:SetInfo2({-1,false})
        if i > 72 then
            GameRecord.listDYItem[i].gameObject:SetActive(false)
        end
    end
    for i = 1,#GameRecord.listXLItem do
        GameRecord.listXLItem[i]:SetInfo3({-1,false})
        if i > 72 then
            GameRecord.listXLItem[i].gameObject:SetActive(false)
        end
    end
    for i = 1,#GameRecord.listXQItem do
        GameRecord.listXQItem[i]:SetInfo4({-1,false})
        if i > 72 then
            GameRecord.listXQItem[i].gameObject:SetActive(false)
        end
    end
    if #GameRecord.listAllWinData >= 150 then
        for i=1,#GameRecord.listAllWinData do
            local uiRecordItem = GameRecord.GetItermObj(GameRecord.listAllWinItem,GameRecord.AllWinParent,GameRecord.ObjAllWinIterm,i)
            uiRecordItem:SetInfo5(GameRecord.listAllWinData[i][1],GameRecord.listAllWinData[i][2],true)
        end
        GameRecord.AllWinParent:GetComponent("UIGrid"):Reposition()
    else
        for i=1,150 do
            local uiRecordItem = GameRecord.GetItermObj(GameRecord.listAllWinItem,GameRecord.AllWinParent,GameRecord.ObjAllWinIterm,i)
            if i > #GameRecord.listAllWinData then
                uiRecordItem:SetInfo5(1,0,false)
            else
                uiRecordItem:SetInfo5(GameRecord.listAllWinData[i][1],GameRecord.listAllWinData[i][2],true)
            end
        end
        GameRecord.AllWinParent:GetComponent("UIGrid"):Reposition()
    end
    for i = 1, #GameRecord.listHLLData do
        for j = 1, #GameRecord.listHLLData[i] do
            local uiRecordItem = GameRecord.GetItermObj(GameRecord.listHLLIterm,GameRecord.HLLItemParent,GameRecord.ObjHLL_Iterm,(i-1)*6 + j)
            uiRecordItem:SetInfo1(GameRecord.listHLLData[i][j])
        end
        GameRecord.HLLItemParent:GetComponent("UIGrid"):Reposition()
    end
    for i = 1, #GameRecord.listDYData do
        for j = 1, #GameRecord.listDYData[i] do
            local uiRecordItem = GameRecord.GetItermObj(GameRecord.listDYItem,GameRecord.DYParent,GameRecord.ObjDYIterm,(i-1)*6 + j)
            uiRecordItem:SetInfo2(GameRecord.listDYData[i][j])
        end
        GameRecord.DYParent:GetComponent("UIGrid"):Reposition()
    end
    for i = 1, #GameRecord.listXLData do
        for j = 1, #GameRecord.listXLData[i] do
            local uiRecordItem = GameRecord.GetItermObj(GameRecord.listXLItem,GameRecord.XLParent,GameRecord.ObjXLIterm,(i-1)*6 + j)
            uiRecordItem:SetInfo3(GameRecord.listXLData[i][j])
        end
        GameRecord.XLParent:GetComponent("UIGrid"):Reposition()
    end
    for i = 1, #GameRecord.listXQData do
        for j = 1, #GameRecord.listXQData[i] do
            local uiRecordItem = GameRecord.GetItermObj(GameRecord.listXQItem,GameRecord.XQParent,GameRecord.ObjXQIterm,(i-1)*6 + j)
            uiRecordItem:SetInfo4(GameRecord.listXQData[i][j])
        end
        GameRecord.XQParent:GetComponent("UIGrid"):Reposition()
    end

end
-- 弹出录单
function GameRecord.ShowUi()
    GameRecord.transform.gameObject:SetActive(true)
    --恢复
    if (not GameRecord.isShow) then
        GameRecord.isShow = true
        for i = 1, #GameRecord.LDSlider do
            GameRecord.LDSlider[i].value = 0.9
        end
        coroutine.start(GameRecord.YiledPlayAnima)
        GameRecord.transform.gameObject:GetComponent("Animation"):Play("Show")
    end
end

function GameRecord.OnBtnClose()
    --恢复
    if (GameRecord.isShow) then
        GameRecord.isShow = false
        GameRecord.transform.gameObject:GetComponent("Animation"):Play("Hide")
    end
    GameRecord.transform.gameObject:SetActive(false)
end
function GameRecord.GetZhuPanData(listArr,cellNum,maxCellNum)
    local listHllArr = {}
    for i = 1, #listArr do
        if(listHllArr[i]==nil) then
            local jHllArr = {}
            for m = 1, cellNum do
                table.insert(jHllArr,{-1,false})
            end
            table.insert(listHllArr,jHllArr)
        end
        local guaWanPoint = 0
        local YPoint = 1
        for j=1,#listArr[i] do
            if(listHllArr[i + guaWanPoint] == nil) then
                local jHllArr = {}
                for m = 1, cellNum do
                    table.insert(jHllArr,{-1,false})
                end
                table.insert(listHllArr,jHllArr)
            end
            listHllArr[i + guaWanPoint][YPoint] = {listArr[i][j],true}
            YPoint = YPoint + 1
            if(YPoint > cellNum) then
                YPoint = cellNum
                guaWanPoint = guaWanPoint+1
            else
                if(listHllArr[i + guaWanPoint][YPoint][2]) then
                    YPoint = YPoint - 1
                    guaWanPoint = guaWanPoint+1
                end
            end
        end
    end
    if #listHllArr < maxCellNum then
        local startIndex = #listHllArr + 1
        for i = startIndex, maxCellNum do
            local jHllArr = {}
            for m = 1, cellNum do
                table.insert(jHllArr,{-1,false})
            end
            table.insert(listHllArr,jHllArr)
        end
    end
    return listHllArr
end
function GameRecord.GetDownThreeLuData(listArr,cellIndex,maxCellNum)--0是蓝，1是红
    local result = {}
    local indexX = cellIndex
    local indexY = 2
    if #listArr >= cellIndex then
        while indexX <= #listArr do
            if listArr[indexX] == nil then
                break
            end
            local prizeIdnex = nil
            if indexY == 1 then
                if #listArr[indexX-1] == #listArr[indexX-cellIndex] then
                    prizeIdnex = 1
                else
                    prizeIdnex = 0
                end
                indexY = indexY + 1
            else
                if listArr[indexX][indexY] ~= nil then
                    if listArr[indexX - cellIndex + 1][indexY] ~= nil then
                        prizeIdnex = 1
                    else
                        if listArr[indexX - cellIndex + 1][indexY-1] ~= nil then
                            prizeIdnex = 0
                        else
                            prizeIdnex = 1
                        end
                    end
                    indexY = indexY + 1
                    if indexY > #listArr[indexX] then
                        indexX = indexX + 1
                        indexY = 1
                    end
                else
                    indexX = indexX + 1
                    indexY = 1
                end
            end
            if prizeIdnex ~= nil then
                if(#result > 0) then
                    if(result[#result][1] == prizeIdnex) then
                        table.insert(result[#result],prizeIdnex)
                    else
                        local snopArr = {prizeIdnex}
                        table.insert(result,snopArr)
                    end
                else
                    local snopArr = {prizeIdnex}
                    table.insert(result,snopArr)
                end
            end
        end
    end
    return GameRecord.GetZhuPanData(result,6,maxCellNum)
end


return GameRecord