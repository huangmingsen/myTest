local GameRecordCardItem = require "224.GameRecordCardItem"
local GamePlaneRecord =
{
    LbPrizeCout = {},

    HLLItemParent,
    ObjHLL_Iterm, -- 路单项

    AllWinParent,
    ObjAllWinIterm, -- 路单项

    listHLLIterm = {}, -- 红黑单项
    listHLLData = {}, -- 红黑数据

    listAllWinItem = {}, -- 红黑单项
    listAllWinData = {}, -- 红黑数据

    LDSlider = {},

    mDistane = 0.0, -- 间距
    mShowNum = 0, -- 显示个数
    isShow = false,
}
function GamePlaneRecord.Awake()
    GamePlaneRecord.isShow = false

    GamePlaneRecord.listHLLIterm = {}
    GamePlaneRecord.listHLLData = {}

    GamePlaneRecord.listAllWinItem = {}
    GamePlaneRecord.listAllWinData = {}
    GamePlaneRecord.LbPrizeCout[1] = FindChildByName(GamePlaneRecord.transform,"LbZhuang","UILabel")
    GamePlaneRecord.LbPrizeCout[2] = FindChildByName(GamePlaneRecord.transform,"LbPing","UILabel")
    GamePlaneRecord.LbPrizeCout[3] = FindChildByName(GamePlaneRecord.transform,"LbXian","UILabel")
    GamePlaneRecord.LbPrizeCout[4] = FindChildByName(GamePlaneRecord.transform,"LbZhuangDui","UILabel")
    GamePlaneRecord.LbPrizeCout[5] = FindChildByName(GamePlaneRecord.transform,"LbXianDui","UILabel")

    GamePlaneRecord.HLLItemParent = FindChildByName(GamePlaneRecord.transform,"ScrollView_LD_2/Grid","gameObject")
    GamePlaneRecord.ObjHLL_Iterm = FindChildByName(GamePlaneRecord.transform,"ScrollView_LD_2/LD_2_Item2","gameObject")

    GamePlaneRecord.AllWinParent = FindChildByName(GamePlaneRecord.transform,"ScrollView_LD_1/Grid","gameObject")
    GamePlaneRecord.ObjAllWinIterm = FindChildByName(GamePlaneRecord.transform,"ScrollView_LD_1/LD_1_Item","gameObject")

    for i = 1, 2 do
        GamePlaneRecord.LDSlider[i] = FindChildByName(GamePlaneRecord.transform,"ScrollView_LD_"..i.."/LDSlider","UISlider")
    end
    GamePlaneRecord.ReSet({0,0,0,0,0,0},{},{})
    for i = 1, #GamePlaneRecord.LDSlider do
        GamePlaneRecord.LDSlider[i].value = 0
    end
end

function GamePlaneRecord.ReSet(countArr,listHLL,listWin)
    GamePlaneRecord.LbPrizeCout[1].text = tostring(countArr[1])
    GamePlaneRecord.LbPrizeCout[2].text = tostring(countArr[2])
    GamePlaneRecord.LbPrizeCout[3].text = tostring(countArr[3])
    GamePlaneRecord.LbPrizeCout[4].text = tostring(countArr[4])
    GamePlaneRecord.LbPrizeCout[5].text = tostring(countArr[5])
    GamePlaneRecord.listHLLData = {}
    GamePlaneRecord.listAllWinData = {}
    for i = 1, #listWin do
        table.insert(GamePlaneRecord.listAllWinData,listWin[i])
    end
    local listHllArr = {}
    for i = 1, #listHLL do
        table.insert(listHllArr,listHLL[i])
    end
    GamePlaneRecord.listHLLData = GamePlaneRecord.GetZhuPanData(listHllArr,5,7)
    GamePlaneRecord.UpdateRecord()
    for i = 1, #GamePlaneRecord.LDSlider do
        GamePlaneRecord.LDSlider[i].value = 0.99
    end
    coroutine.start(GamePlaneRecord.YiledPlayAnima)
end
function GamePlaneRecord.YiledPlayAnima()
    coroutine.wait(0.2)
    for i = 1, #GamePlaneRecord.LDSlider do
        GamePlaneRecord.LDSlider[i].value = 1
    end
end
--路单项
function GamePlaneRecord.GetItermObj(listArr,ItemParent,Iterm,nIndex )
    if ( nIndex <= #listArr ) then
        listArr[nIndex].gameObject:SetActive(true)
        listArr[nIndex].gameObject.name = "iterm"..nIndex
        return listArr[ nIndex ]
    end
    local Obj = UnityEngine.GameObject.Instantiate(Iterm)
    Obj.name = "iterm"..nIndex
    Obj:SetActive(true)
    Obj.transform.parent = ItemParent.transform
    --ItemParent:GetComponent("UIGrid"):AddChild(Obj.transform)
    Obj.transform.position = Vector3.zero
    Obj.transform.localScale = Vector3.one
    local iterm = GameRecordCardItem:new(Obj.transform)
    iterm:InitUI()
    table.insert(listArr,iterm)
    return iterm
end
--更新跟单记录
function GamePlaneRecord.UpdateRecord()
    for i=1,#GamePlaneRecord.listAllWinItem do
        GamePlaneRecord.listAllWinItem[i].gameObject:SetActive(false)
    end
    for i = 1,#GamePlaneRecord.listHLLIterm do
        GamePlaneRecord.listHLLIterm[i]:SetInfo1({-1,false})
        if i > 35 then
            GamePlaneRecord.listHLLIterm[i].gameObject:SetActive(false)
        end
    end
    if #GamePlaneRecord.listAllWinData >= 35 then
        for i=1,#GamePlaneRecord.listAllWinData do
            local uiRecordItem = GamePlaneRecord.GetItermObj(GamePlaneRecord.listAllWinItem,GamePlaneRecord.AllWinParent,GamePlaneRecord.ObjAllWinIterm,i)
            uiRecordItem:SetInfo6(GamePlaneRecord.listAllWinData[i][1],GamePlaneRecord.listAllWinData[i][2],true)
        end
    else
        for i=1,35 do
            local uiRecordItem = GamePlaneRecord.GetItermObj(GamePlaneRecord.listAllWinItem,GamePlaneRecord.AllWinParent,GamePlaneRecord.ObjAllWinIterm,i)
            if i > #GamePlaneRecord.listAllWinData then
                uiRecordItem:SetInfo6(1,false)
            else
                uiRecordItem:SetInfo6(GamePlaneRecord.listAllWinData[i][1],GamePlaneRecord.listAllWinData[i][2],true)
            end
        end
    end
    for i = 1, #GamePlaneRecord.listHLLData do
        for j = 1, #GamePlaneRecord.listHLLData[i] do
            local uiRecordItem = GamePlaneRecord.GetItermObj(GamePlaneRecord.listHLLIterm,GamePlaneRecord.HLLItemParent,GamePlaneRecord.ObjHLL_Iterm,(i-1)*5 + j)
            uiRecordItem:SetInfo7(GamePlaneRecord.listHLLData[i][j])
        end
    end
end
function GamePlaneRecord.GetZhuPanData(listArr,cellNum,maxCellNum)
    local listHllArr = {}
    for i = 1, #listArr do
        if(listHllArr[i]==nil) then
            local jHllArr = {}
            for m = 1, cellNum do
                table.insert(jHllArr,{-1,false})
            end
            table.insert(listHllArr,jHllArr)
        end
        local guaWanPoint = 0
        local YPoint = 1
        for j=1,#listArr[i] do
            if(listHllArr[i + guaWanPoint] == nil) then
                local jHllArr = {}
                for m = 1, cellNum do
                    table.insert(jHllArr,{-1,false})
                end
                table.insert(listHllArr,jHllArr)
            end
            listHllArr[i + guaWanPoint][YPoint] = {listArr[i][j],true}
            YPoint = YPoint + 1
            if(YPoint > cellNum) then
                YPoint = cellNum
                guaWanPoint = guaWanPoint+1
            else
                if(listHllArr[i + guaWanPoint][YPoint][2]) then
                    YPoint = YPoint - 1
                    guaWanPoint = guaWanPoint+1
                end
            end
        end
    end
    if #listHllArr < maxCellNum then
        local startIndex = #listHllArr + 1
        for i = startIndex, maxCellNum do
            local jHllArr = {}
            for m = 1, cellNum do
                table.insert(jHllArr,{-1,false})
            end
            table.insert(listHllArr,jHllArr)
        end
    end
    return listHllArr
end
return GamePlaneRecord