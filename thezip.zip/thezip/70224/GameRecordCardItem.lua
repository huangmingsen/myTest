local GameRecordCardItem =
{
}

function GameRecordCardItem:new(trans)
	local _instance =
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self
	setmetatable(_instance, self)
	return _instance
end
function GameRecordCardItem:InitUI()
	self.IconCard = FindChildByName(self.transform, "Icon_LD_Target0", "UISprite")
	self.IconHe = FindChildByName(self.transform, "Icon_LD_Target1", "gameObject")
	self.IconDZ = {}
	self.IconDZ[1] = FindChildByName(self.transform, "Icon_LD_Target2", "gameObject")
	self.IconDZ[2] = FindChildByName(self.transform, "Icon_LD_Target3", "gameObject")
	self.isFirst = FindChildByName(self.transform, "Icon_New_Sign", "gameObject")
end

function GameRecordCardItem:SetInfo1(winInfo) --珠盘路
	local nameStr = {"Icon_LD_LD4","","Icon_LD_LD5"}
	self.IconCard.gameObject:SetActive(false)
	self.IconHe:SetActive(false)
	self.IconDZ[1]:SetActive(false)
	self.IconDZ[2]:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1][1]]
		self.IconHe:SetActive(winInfo[1][2] == 1)
		self.IconDZ[1]:SetActive(winInfo[1][3] == 1)
		self.IconDZ[2]:SetActive(winInfo[1][3] == 2)
	end
end
function GameRecordCardItem:SetInfo2(winInfo) --大眼路
	local nameStr = {"Icon_LD_LD5","Icon_LD_LD4"}
	self.IconCard.gameObject:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1]+1]
	end
end
function GameRecordCardItem:SetInfo3(winInfo) --小眼路
	local nameStr = {"Icon_LD_LD9","Icon_LD_LD8"}
	self.IconCard.gameObject:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1]+1]
	end
end
function GameRecordCardItem:SetInfo4(winInfo) --小强路
	local nameStr = {"Icon_LD_LD7","Icon_LD_LD6"}
	self.IconCard.gameObject:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1]+1]
	end
end
function GameRecordCardItem:SetInfo5(cardType,dzIndex,flag) --录单总
	local nameStr = {"Icon_LD_LD1","Icon_LD_LD3","Icon_LD_LD2"}
	self.IconCard.gameObject:SetActive(false)
	self.IconDZ[1]:SetActive(false)
	self.IconDZ[2]:SetActive(false)
	if(flag) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[cardType]
		self.IconDZ[1]:SetActive(dzIndex == 1)
		self.IconDZ[2]:SetActive(dzIndex == 2)
	end
end
function GameRecordCardItem:SetInfo6(cardType,dzIndex,flag) -- 桌面结果
	local nameStr = {"Icon_LD1","Icon_LD3","Icon_LD2"}
	self.IconCard.gameObject:SetActive(false)
	self.IconDZ[1]:SetActive(false)
	self.IconDZ[2]:SetActive(false)
	if(flag) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[cardType]
		self.IconDZ[1]:SetActive(dzIndex == 1)
		self.IconDZ[2]:SetActive(dzIndex == 2)
	end
end
function GameRecordCardItem:SetInfo7(winInfo) --桌面珠盘路
	local nameStr = {"Icon_LD4","","Icon_LD5"}
	self.IconCard.gameObject:SetActive(false)
	self.IconHe:SetActive(false)
	self.IconDZ[1]:SetActive(false)
	self.IconDZ[2]:SetActive(false)
	if(winInfo[2]) then
		self.IconCard.gameObject:SetActive(true)
		self.IconCard.spriteName = nameStr[winInfo[1][1]]
		self.IconHe:SetActive(winInfo[1][2] == 1)
		self.IconDZ[1]:SetActive(winInfo[1][3] == 1)
		self.IconDZ[2]:SetActive(winInfo[1][3] == 2)
	end
end

return GameRecordCardItem