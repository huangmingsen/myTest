GameProtocal =
{
	GM_SUB_GAMESTATION = 1001,--游戏状态

  GM_SUB_BEGIN = 1002,	--游戏开始
  GM_SUB_UPBANKER = 1003,         --上庄 或下庄
  GM_SUB_CHANGENT = 1004,     --庄家下庄请求已接受
  GM_SUB_DOWNRANKER = 1005,   --庄家提前下庄  惩罚提示
  GM_SUB_STATE_NOTE = 1006,   --下注状态切换
  GM_SUB_NOTERESULT = 1007,   --下注结果
  GM_SUB_CONTINUEPRENOTE = 1008,   --续压

  GM_SUB_STATE_OPENCARD = 1010,   --开牌 状态切换
  GM_SUB_SETTLEMENT = 1011,   --游戏结算
  GM_SUB_USERATTRI = 1012,   --玩家属性
  GM_SUB_NTINFO = 1013,		--庄家信息

  SUB_GM_POOLDATA_FRESH = 2,--奖池刷新
  SUB_GM_POOL_DISTRIBUTE = 3,--奖池派发
  SUB_GM_POOL_CONFIG = 4,--奖池配置
  SUB_GM_POOL_RECORD = 5,--奖池记录

  SUB_GM_GAME_CONFIG = 7,--限制下注


  CMD_GM_Begin = --游戏开始
  {
    { names = "iNtChengJi", types = "Int64", data = 0 },
    { names = "iNtPlayNum", types = "Int32", data = 0 },
    { names = "iNtStation", types = "Int32", data = 0 },
    { names = "iNoteLimit", types = "Int64[]", length = 3, data = {} },
  },

  CMD_GM_NoteNotice = --游戏开始
  {
    { names = "iNoteLimit", types = "Int64[]", length = 3, data = {} },
  },

  MD_GM_UpBanker= --游戏选庄结果
  {
   { names = "station", types = "Int32", data = 0 },--申请的位置
	 { names = "shang", types = "Byte", data = 0 },--true为上庄，false 为下庄
   { names = "iNtStaton", types = "Int32", data = 0 },--庄家
	 { names = "bIsHuangZhuang", types = "Byte", data = 0 },
	 { names = "bIsRobot", types = "Byte", data = 0 },--是否机器人
   { names = "iCost", types = "Int64", data = 0 }, --下庄收益
   { names = "TotalIntoMoney", types = "Int64", data = 0 },--上庄总带入
	 { names = "cbAutoFill", types = "Byte", data = 0 },--自动补齐
  },
  MD_GM_ChangeNtBanker = --庄家下庄请求已接受
  {
    { names = "cbNtDeskStation", types = "Byte", data = 0 },
  },
  CMD_GM_DownRanker = --庄家下庄请求已接受
  {
    { names = "cbDeskStation", types = "Byte", data = 0 },
    { names = "Money", types = "Int64", data = 0 },
  },

  CMD_GM_C_NoteResult = --游戏下注请求
  {
    { names = "bDeskStation", types = "Byte", data = 0 },--玩家座位号
    { names = "bNoteObject", types = "Byte", data = 0 },--下注区域索引 8:压满
    { names = "iChip", types = "Byte", data = 0 },--玩家下注索引或者额度
  },
  CMD_GM_S_NoteResult = --游戏下注响应
  {
    { names = "bDeskStation", types = "Byte", data = 0 },--玩家座位号
    { names = "bNoteObject", types = "Byte", data = 0 },--下注区域索引 8:压满
    { names = "iChip", types = "Byte", data = 0 },--玩家下注索引或者额度
    { names = "bNoteCode", types = "Byte", data = 0 },--下注状态码
    { names = "iNoteLimit", types = "Int64[]", length = 3, data = {} },
  },

  CMD_GM_ContinuePreNote = --续压
  {
    { names = "bState", types = "Byte", data = 0 },
    { names = "nDeskStation", types = "Int32", data = 0 },
    { names = "AreaNoteMoney", types = "Int64[]", length = 8, data = {} },
    { names = "iNoteLimit", types = "Int64[]", length = 3, data = {} },
  },
  MD_GM_State_OpenCard = --游戏开牌
  {
    { names = "cbCardData", types = "Byte[]", length = 6, data = {} },
    { names = "cbCardPoint", types = "Byte[]", length = 2, data = {} },
    { names = "cbCardType", types = "Byte", data = 0 },
  },
-- C => S
  CMD_GM_State_Settlement = --游戏结算 
  {
    { names = "iNtChageMoney", types = "Int64", data = 0 }, --庄家输赢钱
    { names = "iDesktionChageMoney", types = "Int64[]", length = 180, data = {} }, --玩家输赢钱
    { names = "iDesktionFanHuanMoney", types = "Int64", data = 0 }, --玩家返还钱
    { names = "iPlayerMoney", types = "Int64", data = 0 }, --身上的钱
    { names = "iNtCountWin", types = "Int64", data = 0 }, --庄家总输赢
    { names = "iNtCountPlay", types = "Int32", data = 0 }, --庄家当庄把数
    { names = "iNtCountNote", types = "Int64", data = 0 }, --庄家金币
    { names = "iBankerFillMoney", types = "Int64", data = 0 }, --庄家补齐额度
    { names = "cbLuckDeskStation", types = "Byte", data = 0 }, --幸运星座位号
    { names = "cbRankingList", types = "Byte[]", length = 3, data = {} }, --排行榜
  },

  UserAttriItem = --玩家属性 
  {
    { names = "iUserId", types = "Int32", data = 0 },
    { names = "cbUserAttri", types = "Byte", data = 0 },
  },
  
  CMD_GM_UserAttri = 
  {
    { names = "UserCount", types = "Int32", data = 0 },
    { names = "Item", types = "Byte", data = 0 },
  },
  CMD_GM_NtInfo= --庄家信息
  {
    { names = "DeskStation", types = "Int64", data = 0 }, --座位号或者庄家输赢
    { names = "TotalIntoMoney", types = "Int64", data = 0 }, --总带入
  },
  
  CMD_GM_Station_Wait= --闲置状态
  {
    { names = "bStation", types = "Byte", data = 0 },
    { names = "cbLuckDeskStation", types = "Byte", data = 0 },
    { names = "iNtStation", types = "Int32", data = 0 },
    { names = "iShengYuTime", types = "Int32", data = 0 },
    { names = "iLeastNtPlay", types = "Int32", data = 0 },
    { names = "iMaxGames", types = "Int32", data = 0 },
    { names = "iLeastNtMoney", types = "Int64", data = 0 },
    { names = "iNoteLimit", types = "Int64[]", length = 3, data = {} },

    { names = "iBeginTime", types = "Int32", data = 0 },
    { names = "iNoteTime", types = "Int32", data = 0 },
    { names = "iOpenCardTime", types = "Int32", data = 0 },
    { names = "iAccoutTime", types = "Int32", data = 0 },
    { names = "iNtCountPlay", types = "Int32", data = 0 },
    { names = "iNtWin", types = "Int64", data = 0 },
    { names = "iNtCountNote", types = "Int64", data = 0 },
    { names = "iChouMaNum", types = "Int32", data = 0 },
    { names = "iChouMa", types = "Int32[]", length = 10, data = {} },

    { names = "cbChangeNt", types = "Byte", data = 0 },

    { names = "cbCardTypeRecord", types = "Byte[]", length = 100, data = {} },
    { names = "cbCardTypePro", types = "Byte[]", length = 3, data = {} },
    { names = "cbCardTypeCount", types = "Byte[]", length = 7, data = {} },
    { names = "cbPrize", types = "Byte[]", length = 24, data = {} },
    { names = "cbGameCount", types = "Byte", data = 0 },
    { names = "cbCurGameCount", types = "Byte", data = 0 },
  },
  CMD_GM_Station_Note= --下注状态
  {
    { names = "bStation", types = "Byte", data = 0 },
    { names = "cbLuckDeskStation", types = "Byte", data = 0 },
    { names = "iNtStation", types = "Int32", data = 0 },
    { names = "iShengYuTime", types = "Int32", data = 0 },
    { names = "iLeastNtPlay", types = "Int32", data = 0 },
    { names = "iMaxGames", types = "Int32", data = 0 },
    { names = "iLeastNtMoney", types = "Int64", data = 0 },
    { names = "iNoteLimit", types = "Int64[]", length = 3, data = {} },

    { names = "iBeginTime", types = "Int32", data = 0 },
    { names = "iNoteTime", types = "Int32", data = 0 },
    { names = "iOpenCardTime", types = "Int32", data = 0 },
    { names = "iAccoutTime", types = "Int32", data = 0 },
    { names = "iNtCountNote", types = "Int64", data = 0 },
    { names = "iNtCountPlay", types = "Int32", data = 0 },
    { names = "iNtWin", types = "Int64", data = 0 },

    { names = "iTotalNote", types = "Int64[]", length = 8, data = {} },
    { names = "iPlayerNote", types = "Int64[]", length = 8, data = {} },

    { names = "iChouMaNum", types = "Int32", data = 0 },
    { names = "iChouMa", types = "Int32[]", length = 10, data = {} },

    { names = "cbChangeNt", types = "Byte", data = 0 },

    { names = "cbCardTypeRecord", types = "Byte[]", length = 100, data = {} },
    { names = "cbCardTypePro", types = "Byte[]", length = 3, data = {} },
    { names = "cbCardTypeCount", types = "Byte[]", length = 7, data = {} },
    { names = "cbPrize", types = "Byte[]", length = 24, data = {} },
    { names = "cbGameCount", types = "Byte", data = 0 },
    { names = "cbCurGameCount", types = "Byte", data = 0 },
  },

  CMD_GM_Station_OpenCard= --开牌状态
  {
    { names = "bStation", types = "Byte", data = 0 },
    { names = "cbLuckDeskStation", types = "Byte", data = 0 },
    { names = "iNtStation", types = "Int32", data = 0 },
    { names = "iShengYuTime", types = "Int32", data = 0 },
    { names = "iLeastNtPlay", types = "Int32", data = 0 },
    { names = "iMaxGames", types = "Int32", data = 0 },
    { names = "iLeastNtMoney", types = "Int64", data = 0 },
    { names = "iNoteLimit", types = "Int64[]", length = 3, data = {} },

    { names = "iBeginTime", types = "Int32", data = 0 },
    { names = "iNoteTime", types = "Int32", data = 0 },
    { names = "iOpenCardTime", types = "Int32", data = 0 },
    { names = "iAccoutTime", types = "Int32", data = 0 },
    { names = "iNtCountNote", types = "Int64", data = 0 },
    { names = "iNtCountPlay", types = "Int32", data = 0 },
    { names = "iNtWin", types = "Int64", data = 0 },
    
    { names = "iTotalNote", types = "Int64[]", length = 8, data = {} },
    { names = "iPlayerNote", types = "Int64[]", length = 8, data = {} },

    { names = "bCard", types = "Byte[]", length = 6, data = {} },
    { names = "cbCardType", types = "Byte", data = 0 },
    { names = "cbCardPoint", types = "Byte[]", length = 2, data = {} },

    { names = "iChouMaNum", types = "Int32", data = 0 },
    { names = "iChouMa", types = "Int32[]", length = 10, data = {} },

    { names = "cbChangeNt", types = "Byte", data = 0 },

    { names = "cbCardTypeRecord", types = "Byte[]", length = 100, data = {} },
    { names = "cbCardTypePro", types = "Byte[]", length = 3, data = {} },
    { names = "cbCardTypeCount", types = "Byte[]", length = 7, data = {} },
    { names = "cbPrize", types = "Byte[]", length = 24, data = {} },
    { names = "cbGameCount", types = "Byte", data = 0 },
    { names = "cbCurGameCount", types = "Byte", data = 0 },
  },

  CMD_GM_Station_Next= --等待下一轮
  {
    { names = "bStation", types = "Byte", data = 0 },
    { names = "cbLuckDeskStation", types = "Byte", data = 0 },
    { names = "iNtStation", types = "Int32", data = 0 },
    { names = "iShengYuTime", types = "Int32", data = 0 },
    { names = "iLeastNtPlay", types = "Int32", data = 0 },
    { names = "iMaxGames", types = "Int32", data = 0 },
    { names = "iLeastNtMoney", types = "Int64", data = 0 },
    { names = "iNoteLimit", types = "Int64[]", length = 3, data = {} },

    { names = "iBeginTime", types = "Int32", data = 0 },
    { names = "iNoteTime", types = "Int32", data = 0 },
    { names = "iOpenCardTime", types = "Int32", data = 0 },
    { names = "iAccoutTime", types = "Int32", data = 0 },

    { names = "iTotalNote", types = "Int64[]", length = 8, data = {} },
    { names = "iPlayerNote", types = "Int64[]", length = 8, data = {} },

    { names = "iNtCountNote", types = "Int64", data = 0 },
    { names = "iNtCountPlay", types = "Int32", data = 0 },
    { names = "iNtWin", types = "Int64", data = 0 },
    

    { names = "bCard", types = "Byte[]", length = 6, data = {} },
    { names = "cbCardType", types = "Byte", data = 0 },
    { names = "cbCardPoint", types = "Byte[]", length = 2, data = {} },

    { names = "iChouMaNum", types = "Int32", data = 0 },
    { names = "iChouMa", types = "Int32[]", length = 10, data = {} },

    { names = "cbChangeNt", types = "Byte", data = 0 },

    { names = "cbCardTypeRecord", types = "Byte[]", length = 100, data = {} },
    { names = "cbCardTypePro", types = "Byte[]", length = 3, data = {} },
    { names = "cbCardTypeCount", types = "Byte[]", length = 7, data = {} },
    { names = "cbPrize", types = "Byte[]", length = 24, data = {} },
    { names = "cbGameCount", types = "Byte", data = 0 },
    { names = "cbCurGameCount", types = "Byte", data = 0 },
  },
  CMD_GR_PoolData_Fresh= --奖池刷新
  {
    { names = "uRoomId", types = "UInt32", data = 0 },
    { names = "iPoolMoney", types = "Int64", data = 0 },
  },
  CMD_GR_PoolData_Distrubute= --派奖
  {
    { names = "uRoomId", types = "UInt32", data = 0 },
    { names = "uDeskId", types = "UInt32", data = 0 },
    { names = "uUserId", types = "UInt32", data = 0 },
    { names = "uCardType", types = "UInt32", data = 0 },
    { names = "uPoolMoney", types = "UInt32", data = 0 },
  },
  CMD_GR_PoolConfig= --奖池配置
  {
    { names = "CardTypePro", types = "Int32[]", length = 10, data = {} },
    { names = "CardTypeProCount", types = "Byte", data = 0 },
    { names = "cbPoolSwitch", types = "Byte", data = 0 },
    { names = "TaxKind", types = "Byte", data = 0 },
    { names = "Tax", types = "Int32", data = 0 },
    { names = "iFetchPercent", types = "Int32", data = 0 },
  },
  SUB_GM_PoolRecord= --奖池录单
  {
    { names = "sName", types = "Byte[]", length = 80, data = {} },
    { names = "sTime", types = "Byte[]", length = 19, data = {} },
    { names = "bCardType", types = "Byte", data = 0 },
    { names = "cbFace", types = "UInt32", data = 0 },
    { names = "iPoolMoney", types = "Int32", data = 0 },
  },
  SUB_GM_Limit= --限制注码
  {
    { names = "iLimitVlue", types = "Int64", data = 0 },
  },
}