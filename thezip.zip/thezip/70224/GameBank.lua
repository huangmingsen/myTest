local GameBank =
{
	BtnRecahrge,
	BtnClose = nil,
	BtnConfirm = nil,
	LblMoneyBank = nil,
	LblMoney = nil,
	SldMoney = nil, --取款滑动条
	BtnMax = nil,--取款最大按钮
	BtnReset = nil,--取款重置按钮
	InpMoney = nil, --取款输入框
	InpPwd = nil,
	passwordstr = nil, --取款密码
}
local outputchange = false
local onoutbtn = false

function GameBank.Awake()
	GameBank.BtnClose = FindChildByName(GameBank.transform,"UIGroup/BtnClose","gameObject")
	GameBank.BtnRecahrge = FindChildByName(GameBank.transform,"UIGroup/Btn_Recahrge","gameObject")
	GameBank.LblMoneyBank = FindChildByName(GameBank.transform,"UIGroup/Label_Bank","UILabel")
	GameBank.LblMoney = FindChildByName(GameBank.transform,"UIGroup/Label_Money","UILabel")
	GameBank.BtnConfirm = FindChildByName(GameBank.transform,"UIGroup/Btn_Confirm","gameObject")
	GameBank.SldMoney = FindChildByName(GameBank.transform,"UIGroup/Slider","UISlider")
	GameBank.InpMoney = FindChildByName(GameBank.transform,"UIGroup/Input_Money","UIInput")
	GameBank.BtnMax = FindChildByName(GameBank.transform,"UIGroup/Btn_Max","gameObject")
	GameBank.BtnReset = FindChildByName(GameBank.transform,"UIGroup/Btn_Reset","gameObject")
	GameBank.InpPwd = FindChildByName(GameBank.transform,"UIGroup/Input_MM","UIInput")

	UIEventListener.Get(GameBank.BtnClose).onClick = GameBank.OnBtnClose
	UIEventListener.Get(GameBank.BtnConfirm).onClick = GameBank.OnBtnConfirm
	UIEventListener.Get(GameBank.BtnRecahrge).onClick = GameBank.OnBtnRecahrge

	GameBank.InpMoney.onChange:Add(EventDelegate.New(GameBank.OnInpMoney))
	GameBank.InpPwd.onChange:Add(EventDelegate.New(GameBank.OnInpPwd))
	GameBank.SldMoney.onChange:Add(EventDelegate.New(GameBank.OnSldMoney))
	if IsClosePay then
		GameBank.BtnRecahrge:SetActive(false)
	end

	UIEventListener.Get(GameBank.BtnMax).onClick = GameBank.OnBtnMax
	UIEventListener.Get(GameBank.BtnReset).onClick = GameBank.OnBtnReset
	GameBank.OnBtnReset()

	NetManager:AddAction(1000014, 2, GameBank.OutPutMoneyReturn) --取款返回
	GameBank.ShowInfo()
	LobyGetDataForomServer.UserRefreshFun = GameBank.ShowInfo
end

function GameBank.ShowInfo()
	if GameBank.transform ~= nil then
		GameBank.LblMoney.text = MoneyProportionStr(MyUserInfo.iMoney)
		GameBank.LblMoneyBank.text = MoneyProportionStr(MyUserInfo.iBank)
	end
end


function GameBank.OnInpMoney()--取款输入框改变
	if onoutbtn then return end
	if GameBank.InpMoney.value == nil or GameBank.InpMoney.value == "" then
		GameBank.SldMoney.value = 0
		return
	end
	outputchange = true
	local iMoney = tonumber(tostring(MyUserInfo.iBank))
	local inmoney = ToCurrencyRateNumber(GameBank.InpMoney.value)
	if iMoney == nil then iMoney = 0 end
	if inmoney == nil then inmoney = 0 end
	if inmoney >= iMoney then
		GameBank.SldMoney.value = 1
	else
		local pressvalue = 0
		if iMoney > 0 then
			pressvalue = inmoney / iMoney
		end
		GameBank.SldMoney.value = pressvalue
	end
	outputchange = false
end
function GameBank.OnInpPwd()
	GameBank.passwordstr = GameBank.InpPwd.value
end
function GameBank.OnSldMoney()
	if outputchange then return end
	onoutbtn = true
	local inmoney = GameBank.SldMoney.value * tonumber(tostring(MyUserInfo.iBank))
	if GameBank.SldMoney.value < 1 then
		inmoney = GameBank.getIntPart(inmoney)
	else
		inmoney = MyUserInfo.iBank
	end
	GameBank.InpMoney.value = MoneyProportionStr(inmoney)
	onoutbtn = false
end

function GameBank.getIntPart(x)--取整
	if x <= 0 then
		return math.ceil(x)
	end
	if math.ceil(x) == x then
		x = math.ceil(x)
	else
		x = math.ceil(x) - 1
	end
	return x
end

function GameBank.OnBtnMax()
	GameBank.SldMoney.value = 1
end
function GameBank.OnBtnReset()
	GameBank.SldMoney.value = 0
	GameBank.InpMoney.value = "0"
end

function GameBank.Show()
	GameBank.passwordstr = ""
	GameBank.InpPwd.value = ""
	GameBank.SldMoney.value = 0
	GameBank.InpMoney.value = "0"
	GameBank.transform.gameObject:SetActive(true)
	GameBank.transform.gameObject:GetComponent("Animation"):Play("Help_Show")
end
function GameBank.OnBtnClose()
	GameBank.transform.gameObject:SetActive(false)
end
function GameBank.OnBtnConfirm()
	if GameBank.passwordstr == nil or GameBank.passwordstr =="" then
		LblMsgText.Show("请输入银行密码")
		return
	end
	GameBank.GetPutMoney()
end
function GameBank.OnBtnRecahrge()
	GameUIManager.OpenRecharge()
end

function GameBank.GetPutMoney()
	local inmoney = ToCurrencyRateNumber(GameBank.InpMoney.value)
	local iMoney = tonumber(tostring(MyUserInfo.iBank))
	if inmoney == nil or inmoney <= 0 then
		LblMsgText.Show("请输入正确的取款数量")
		return
	end
	if iMoney < inmoney then
		LblMsgText.Show("银行金币不足")
		return
	end
	if GameBank.passwordstr ~= nil and GameBank.passwordstr ~= "" then
		GameBank.SendGetBankOutMoney()
	end
	GameBank.passwordstr = ""
	GameBank.InpPwd.value = ""
end
function GameBank.SendGetBankOutMoney()
	CMD_GR_C_BankOutMoney[1].data = ToCurrencyRateNumber(GameBank.InpMoney.value)
	CMD_GR_C_BankOutMoney[2].data = MyUserInfo.uiUserID
	CMD_GR_C_BankOutMoney[3].data = LuaInter.GetPassword(GameBank.passwordstr)
	local OutPutMoney = DataParseLua.StructToBytes(CMD_GR_C_BankOutMoney)
	NetManager:SendData(OutPutMoney,2000114,2)
end

function GameBank.OutPutMoneyReturn(data)--取款返回
	if data.headStruct.dwHandleCode == 0 then
		GameBank.OnReturnMoneyChange(data.mainMsg, false)
	else
		local erromsg = ErroCode(data.headStruct.dwHandleCode)
		if erromsg ~= nil and erromsg ~= "" then
			LblMsgText.Show(erromsg)
		else
			LblMsgText.Show("取款失败！")
		end
		GameBank.passwordstr = nil
	end
end
function GameBank.OnReturnMoneyChange(mainMsg)
	local InOutMoneyChange = DataParseLua.BytesToStruct(mainMsg, CMD_GR_S_BankOutMoney)
	if MyUserInfo.uiUserID ~= InOutMoneyChange.dwUserID then
		return
	end
	LblMsgText.Show("取款成功！")
	GameBank.SldMoney.value = 0
	GameBank.InpMoney.value = "0"
	print("InOutMoneyChange.dwCheckOut : ", tostring(InOutMoneyChange.dwCheckOut))
	print("InOutMoneyChange.dwMoneyInRoom : ", tostring(InOutMoneyChange.dwMoneyInRoom))
	print("InOutMoneyChange.dwMoneyInBank : ", tostring(InOutMoneyChange.dwMoneyInBank))
	MyUserInfo.iMoney = InOutMoneyChange.dwMoneyInRoom
	MyUserInfo.iBank = InOutMoneyChange.dwMoneyInBank
	GameBank.ShowInfo()
	GameUIManager.UpDateSelfMoney()
	HallUIManager.Start()--重新刷新大厅信息UI
	GameBank.OnSldMoney()
end
return GameBank
