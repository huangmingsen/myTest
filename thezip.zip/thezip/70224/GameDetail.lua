local bit = require"bit"
local GameDetail =
{
	BtnClose,
	Label_AllDown,
	Label_AllWin,
	Label_Win,
	Label_Lose,
	ItemData = {},
	IconZhuangCards = {},
	IconXianCards = {},
	LbZhuangPoint,
	LbXianPoint,
	IconIsNtTitle = {},
}

function GameDetail.Awake()
	GameDetail.ItemData = {}
	for i=1,8 do
		if GameDetail.ItemData[i] == nil then
			GameDetail.ItemData[i] = {}
			local gobj = FindChildByName(GameDetail.transform, "UIGroup/Detail_Team/"..i,"gameObject")
			GameDetail.ItemData[i].itemobj = gobj
			GameDetail.ItemData[i].LbPoint = FindChildByName(gobj.transform, "Label_BeiShu","UILabel")
			GameDetail.ItemData[i].LbYaZhu = FindChildByName(gobj.transform, "Label_YaZhu","UILabel")
			GameDetail.ItemData[i].LbWin = FindChildByName(gobj.transform, "Label_Win","UILabel")
		end
	end
	for i=1,3 do
		GameDetail.IconZhuangCards[i] = FindChildByName(GameDetail.transform, "UIGroup/GoZhuang/Icon_Card"..(i-1),"UISprite")
		GameDetail.IconXianCards[i] = FindChildByName(GameDetail.transform, "UIGroup/GoXian/Icon_Card"..(i-1),"UISprite")
	end
	for i=1,3 do
		GameDetail.IconIsNtTitle[i] = FindChildByName(GameDetail.transform,"UIGroup/ImageBG/Font_Title"..(i-1),"UISprite")
	end
	GameDetail.LbZhuangPoint = FindChildByName(GameDetail.transform,"UIGroup/GoZhuang/Label_PaiXing_Target","UILabel")
	GameDetail.LbXianPoint = FindChildByName(GameDetail.transform,"UIGroup/GoXian/Label_PaiXing_Target","UILabel")
	GameDetail.BtnClose = FindChildByName(GameDetail.transform, "UIGroup/BtnClose","gameObject")
	GameDetail.Label_AllDown = FindChildByName(GameDetail.transform,"UIGroup/Label_AllDown","UILabel")
	GameDetail.Label_AllWin = FindChildByName(GameDetail.transform,"UIGroup/Label_AllWin","UILabel")
	GameDetail.Label_Win = FindChildByName(GameDetail.transform,"UIGroup/Label_Win","UILabel")
	GameDetail.Label_Lose = FindChildByName(GameDetail.transform,"UIGroup/Label_Lose","UILabel")
	UIEventListener.Get(GameDetail.BtnClose).onClick = GameDetail.Hide
end

function GameDetail.show(detaidates)
	for i=1,8 do
		if(i <= #detaidates.Data) then
			GameDetail.ItemData[i].itemobj:SetActive(true)
			GameDetail.ItemData[i].LbPoint.text = detaidates.Data[i].Point/100
			GameDetail.ItemData[i].LbYaZhu.text = FormatNumToStringYW(MoneyProportionStr(detaidates.Data[i].Note))
			GameDetail.ItemData[i].LbWin.text = FormatNumToStringYW(MoneyProportionStr(detaidates.Data[i].Win))
		else
			GameDetail.ItemData[i].itemobj:SetActive(false)
		end
	end
	local zhuangPointVlue = tonumber(detaidates.CardData[1].Card)
	local xianPointVlue = tonumber(detaidates.CardData[2].Card)
	local zhuangCardPoints = {}
	local xianCardPoints = {}
	for n=1,3 do
    	zhuangCardPoints[n] = bit.band(zhuangPointVlue, 0xFF)  --与1
		zhuangPointVlue = bit.rshift(zhuangPointVlue, 8)  --移位
    	xianCardPoints[n] = bit.band(xianPointVlue, 0xFF)  --与1
		xianPointVlue = bit.rshift(xianPointVlue, 8)  --移位
	end
	for j=1,3 do
		GameDetail.IconZhuangCards[j].gameObject:SetActive(true)
		GameDetail.SetCardSprite(zhuangCardPoints[j],GameDetail.IconZhuangCards[j])
		if zhuangCardPoints[j] == 0 or zhuangCardPoints[j] == nil then
			GameDetail.IconZhuangCards[j].gameObject:SetActive(false)
		end
		GameDetail.IconXianCards[j].gameObject:SetActive(true)
		GameDetail.SetCardSprite(xianCardPoints[j],GameDetail.IconXianCards[j])
		if xianCardPoints[j] == 0 or xianCardPoints[j] == nil then
			GameDetail.IconXianCards[j].gameObject:SetActive(false)
		end
	end
	if detaidates.IsNt then
		GameDetail.IconIsNtTitle[1].gameObject:SetActive(false)
		GameDetail.IconIsNtTitle[2].gameObject:SetActive(true)
		GameDetail.IconIsNtTitle[3].spriteName = "Txt_Detail_KJ"
		GameDetail.Label_AllWin.text = FormatNoteNumToYW(MoneyProportionStr(detaidates.Open))
	else
		GameDetail.IconIsNtTitle[1].gameObject:SetActive(true)
		GameDetail.IconIsNtTitle[2].gameObject:SetActive(false)
		GameDetail.IconIsNtTitle[3].spriteName = "Txt_Detail_ZYF"
		GameDetail.Label_AllWin.text = FormatNoteNumToYW(MoneyProportionStr(detaidates.Win))
	end
	GameDetail.LbZhuangPoint.text = tostring(detaidates.CardData[1].Point).."点"
	GameDetail.LbXianPoint.text = tostring(detaidates.CardData[2].Point).."点"
	GameDetail.Label_AllDown.text = FormatNoteNumToYW(MoneyProportionStr(detaidates.Note))
	if detaidates.Real >= 0 then
		GameDetail.Label_Win.gameObject:SetActive(true)
		GameDetail.Label_Lose.gameObject:SetActive(false)
		GameDetail.Label_Win.text = FormatNoteNumToYW(MoneyProportionStr(detaidates.Real))
	else
		GameDetail.Label_Win.gameObject:SetActive(false)
		GameDetail.Label_Lose.gameObject:SetActive(true)
		GameDetail.Label_Lose.text = FormatNoteNumToYW(MoneyProportionStr(detaidates.Real))
	end
	GameDetail.transform.gameObject:SetActive(true)
	GameDetail.transform.gameObject:GetComponent("Animation"):Play("Help_Show")
end

--设置牌的图片
function GameDetail.SetCardSprite(cardData,image)
    if (cardData == nil or cardData <= 0) then
        image.spriteName = "0_0"
    else
        local color = bit.band(cardData, 0xF0)  --扑克花色
        local num = bit.band(cardData, 0x0F) --扑克数字

        color = color / 16 + 1

        num = num + 1
        --牌A
        if (num == 14) then
            num = 1
        end
        image.spriteName = color.."_"..num
    end
end
function GameDetail.Hide()
	GameDetail.transform.gameObject:GetComponent("Animation"):Play("Help_Hide")
	GameDetail.transform.gameObject:SetActive(false)
end
return GameDetail