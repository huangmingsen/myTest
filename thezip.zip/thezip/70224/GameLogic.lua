local GameLogic =
{
	
}

function GameLogic.Awake()
	require "224.GameProtocal"
	GameDefine.AddEvent(GameDefine.Action_UserSit, GameLogic.Action_UserSit)--玩家坐下
	GameDefine.AddEvent(GameDefine.Action_UserLeft, GameLogic.Action_UserLeft)--玩家离开桌子
	GameDefine.AddEvent(GameDefine.Action_RefleshUserInfo, GameLogic.Action_RefleshUserInfo)--刷新用户经验值
	GameDefine.AddEvent(GameDefine.Action_NoMoneyTickRoom, GameLogic.Action_NoMoneyTickRoom)--游戏币不足，提出房间

	--GameDefine.AddEvent(GameProtocal.GM_SUB_BIGPOOL_RECORD, GameLogic.ErroCode) --错误
	GameDefine.AddEvent(GameProtocal.GM_SUB_GAMESTATION, GameLogic.GameStation) --游戏状态
	GameDefine.AddEvent(GameProtocal.GM_SUB_BEGIN, GameLogic.GameBegin) --游戏开始
	GameDefine.AddEvent(GameProtocal.GM_SUB_STATE_NOTE, GameLogic.GameNoteBet) --游戏开始
	GameDefine.AddEvent(GameProtocal.GM_SUB_STATE_OPENCARD, GameLogic.GameOpenPrize) --游戏开奖
	GameDefine.AddEvent(GameProtocal.GM_SUB_SETTLEMENT, GameLogic.GameCurrOver) --游戏结束
	GameDefine.AddEvent(GameProtocal.GM_SUB_UPBANKER, GameLogic.GameDownUpZhuang) --上庄 或下庄++
	GameDefine.AddEvent(GameProtocal.GM_SUB_CHANGENT, GameLogic.GameDownUpZhuangReq) --庄家下庄请求已接受
	GameDefine.AddEvent(GameProtocal.GM_SUB_DOWNRANKER, GameLogic.GameGruel) --庄家提前下庄  惩罚提示
	GameDefine.AddEvent(GameProtocal.GM_SUB_NOTERESULT, GameLogic.GameNoteReq) --下注
	GameDefine.AddEvent(GameProtocal.GM_SUB_CONTINUEPRENOTE, GameLogic.GameContinueLastNoteReq) --续压
	GameDefine.AddEvent(GameProtocal.GM_SUB_USERATTRI, GameLogic.GameUserRattri) --玩家属性
	GameDefine.AddEvent(GameProtocal.GM_SUB_NTINFO, GameLogic.GameZhuangInfo) --庄家属性
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOLDATA_FRESH, GameLogic.PoolDataRefresh) --奖池刷新
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_DISTRIBUTE, GameLogic.PoolDataDistrubute) --奖池派发
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_CONFIG, GameLogic.PoolConfig) --奖池配置
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_RECORD, GameLogic.PoolRecord) --奖池记录 
	
	GameDefine.AddEvent(GameProtocal.SUB_GM_GAME_CONFIG, GameLogic.LimitNote) --限制下注
	math.randomseed(tostring(os.time()):reverse():sub(1,7))
end

function GameLogic.Start()
	
end

function GameLogic.OnDestroy()
	package.loaded["224.GameProtocal"] = nil
	GameDefine.Creal()
end


function GameLogic.Action_UserSit(userInfo)
	print("Action_UserSit  玩家坐下: "..tostring(userInfo.uiUserID))
	if userInfo.uiUserID == MyUserInfo.uiUserID then
		print("NetManager:SendData")
		NetManager:SendData(2000150,1) --获取用户的状态
		NetManager:SendData(2000180,1) --发送准备事件
	-- else
		---GameUIManager.InsertPlayer(userInfo)
	end
	GameUIManager.PlayerSit(userInfo)
end

function GameLogic.Action_NoMoneyTickRoom()
	UIRoom.QuitGame()
end

function GameLogic.Action_UserLeft(userInfo)
	print("Action_UserSit  玩家离开: ", userInfo.uiUserID)
	--GameUIManager.RemovePlayer(userInfo)
	GameUIManager.PlayerLeft(userInfo)
end

function GameLogic.Action_RefleshUserInfo(userInfo)
    if (userInfo.uiUserID == MyUserInfo.uiUserID) then
        MyUserInfo.iExperience = userInfo.iExperience
        MyUserInfo.iMoney = userInfo.iMoney
        MyUserInfo.iBank = userInfo.iBank
        MyUserInfo.iTreasure = userInfo.iTreasure
        MyUserInfo.iMatchTicket = userInfo.iMatchTicket
        MyUserInfo.iExchangeBill = userInfo.iExchangeBill
        --GameUIManager.ShowUserInfo()
        GameUIManager.RefreshUserInfo()
	elseif (ZhuangUser ~= nil and userInfo.uiUserID == ZhuangUser.uiUserID) then
		--显示庄家的信息
		GameUIManager.ShowZhuangInfo()
	end
end


function GameLogic.ErroCode(data)--游戏错误
	local erronum = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.ErrorCode)
	if erronum.uErrorId == 0 then print("数据空")
	elseif erronum.uErrorId == 1 then print("数据包大小不对")
	elseif erronum.uErrorId == 2 then print("座位号错误")
	elseif erronum.uErrorId == 3 then print("线数错误")
	elseif erronum.uErrorId == 4 then print("筹码错误")
	elseif erronum.uErrorId == 5 then print("倍数错误")
	elseif erronum.uErrorId == 6 then print("状态不对")
	elseif erronum.uErrorId == 7 then print("身上钱不足")
	end
end

function GameLogic.NoteErroCode(uErrorId)--游戏错误
	if uErrorId == 0 then 
		--return "下注成功"
		return "successful bet"
	elseif uErrorId == 1 then 
		--return "座位号错误"
		return "wrong seat number"
	elseif uErrorId == 2 then 
		--return "筹码索引错误"
		return "chip index error"
	elseif uErrorId == 3 then 
		--return "下注区域错误"
		return "Wrong betting area"
	elseif uErrorId == 4 then 
		--return "不能同时下庄闲"
		return "Cannot bet on Banker and Player at the same time"
	elseif uErrorId == 5 then 
		--return "身上钱不足"
		return "身上钱不足"
	elseif uErrorId == 6 then 
		--return "超过总下注额度"
		return "You don't have enough coins"
	elseif uErrorId == 7 then 
		--return "超出区域限额，无法继续下注"
		return "Exceeded the regional limit, can not continue to bet"
	elseif uErrorId == 8 then 
		--return "其他错误"
		return "other errors"
	end
end

function GameLogic.ContinueNoteErroCode(uErrorId)--游戏错误
	if uErrorId == 0 then 
		--return "续压成功"
		return "keep betting on success"
	elseif uErrorId == 1 then 
		--return "上局没有下注,无法续压"
		return "There was no bet in the last round"
	elseif uErrorId == 2 then 
		--return "下注限红"
		return "Bet over limit"
	elseif uErrorId == 3 then 
		--return "超出自己身上的钱"
		return "more than your own gold coins"
	elseif uErrorId == 4 then 
		--return "和当前下注相同"
		return "Same as current bet"
	end
end

function GameLogic.GameStation(data)--游戏状态
	GameUIManager.GameStation(data)
	UIRoom.LoadGameFinish()
end
function GameLogic.GameBegin(data)--游戏开始
	GameUIManager.GameBegin(data)
end
function GameLogic.GameNoteBet(data)--游戏开始
	GameUIManager.GameNoteBet(data)
end
function GameLogic.GameOpenPrize(data)--游戏开奖
	GameUIManager.GameOpenPrize(data)
end
function GameLogic.GameCurrOver(data)--准备结算
	GameUIManager.GameCurrOver(data)
end
function GameLogic.GameDownUpZhuang(data)--上庄 或下庄
	GameUIManager.GameDownUpZhuang(data)
end
function GameLogic.GameDownUpZhuangReq(data)--庄家下庄请求已接受
	GameUIManager.GameDownUpZhuangReq(data)
end
function GameLogic.GameGruel(data)--庄家提前下庄  惩罚提示
	GameUIManager.GameGruel(data)
end
function GameLogic.GameNoteReq(data)--下注
	GameUIManager.GameNoteReq(data)
end
function GameLogic.GameContinueLastNoteReq(data)--续压
	GameUIManager.GameContinueLastNoteReq(data)
end
function GameLogic.GameUserRattri(data)--玩家信息
	GameUIManager.GameUserRattri(data)
end
function GameLogic.GameZhuangInfo(data)--庄家信息
	GameUIManager.GameZhuangInfo(data)
end
function GameLogic.PoolDataRefresh(data)--奖池刷新
	GameUIManager.PoolDataRefresh(data)
end
function GameLogic.PoolDataDistrubute(data)--奖池派发
	-- local path = "E:/UnityTest/123.txt"
	-- LuaInter.SaveFile(path,data.mainMsg)
	-- print("写入成功")
	GameUIManager.PoolDataDistrubute(data)
end
function GameLogic.PoolConfig(data)--奖池配置
	GameUIManager.PoolConfig(data)
end
function GameLogic.PoolRecord(data)--奖池记录
	GameUIManager.PoolRecord(data)
end
function GameLogic.LimitNote(data)--奖池配置
	GameUIManager.LimitNote(data)
end

function GameLogic.FormatNumToKW(score)
	local num = tonumber(score)
	local value = tostring(num)
	if ( num <= 0 ) then
		return value
	end
	if ( num >= 1000 ) then
		if ( num >= 10000 ) then
			value = tostring(num / 10000).."W"
		else
			value = tostring(num / 1000).."K"
		end
	end
	return value
end
function GameLogic.finduserbyStation(userStation)
	for i=1,#GameSUserBaseInfo.userinfolist do
		if GameSUserBaseInfo.userinfolist[i].iDeskStation == userStation then
			return GameSUserBaseInfo.userinfolist[i]
		end
	end
	return nil
end
function GameLogic.GetRandomPostion(v)
    local vx = math.random(v.x - 70, v.x + 70)
    local vy = math.random(v.y - 20, v.y + 20)
    return Vector3.New(vx, vy, 0)
end
function GameLogic.GetRandomDesktopPostion(v)
    local vx = math.random(v.x - 20, v.x + 20)
    local vy = math.random(v.y, v.y + 20)
    return Vector3.New(vx, vy, 0)
end
return GameLogic