GameAudioContro =
{
    bgaudiosource = nil,
    SoundEffect = nil,
    BGM = "Public/Audio/BGM.u3d",--背景

    ZhuangPointAud = {"Public/Audio/0Point.u3d","Public/Audio/1Point.u3d","Public/Audio/2Point.u3d","Public/Audio/3Point.u3d",
                "Public/Audio/4Point.u3d","Public/Audio/5Point.u3d","Public/Audio/6Point.u3d","Public/Audio/7Point.u3d",
                "Public/Audio/8Point.u3d","Public/Audio/9Point.u3d"},
    XianPointAud = {"Public/Audio/0Point.u3d","Public/Audio/1Point.u3d","Public/Audio/2Point.u3d","Public/Audio/3Point.u3d",
                "Public/Audio/4Point.u3d","Public/Audio/5Point.u3d","Public/Audio/6Point.u3d","Public/Audio/7Point.u3d",
                "Public/Audio/8Point.u3d","Public/Audio/9Point.u3d"},
    ZhuangAud = "Public/Audio/Result_BankerWin.u3d",--庄
    XianAud = "Public/Audio/Result_PlayerWin.u3d",--闲
    PingAud = "Public/Audio/Result_Tie.u3d",--平
    StartNoteAud = "Public/Audio/StartJetton.u3d",--开始下注
    EndNoteAud = "Public/Audio/StopJetton.u3d",--停止下注
    ClickAud = "Public/Audio/choose.u3d",--点击
    TimeAud = "Public/Audio/countdown.u3d",--倒计时1
    NoteAud = "Public/Audio/xiazhu.u3d",--下注筹码
    GetBetAud = "Public/Audio/getbet.u3d",--下注筹码
    FaPaiAud = "Public/Audio/sendcard.u3d",--点击
    ResultWinAud = "Public/Audio/resultwin.u3d",--结算赢
    ResultLoseAud = "Public/Audio/resultlose.u3d",--结算输
    ResultNoBetAud = "Public/Audio/resultwinnobet.u3d",--结算没下注
}

function GameAudioContro.Awake()
    GameAudioContro.bgaudiosource = GameAudioContro.transform:GetComponent("AudioSource")
    GameAudioContro.SoundEffect = GameAudioContro.transform:FindChild("SoundEffect"):GetComponent("AudioSource")
    GameDefine.AddEvent(GameDefine.Action_ResetBGVolume, GameAudioContro.ReSetPlayAudio)
    --gameresMrg:LoadPrefab(GameAudioContro.BGM, nil, nil)--预加载声音
    GameAudioContro.PlayBG(GameAudioContro.BGM,GameAudioContro.ReSetPlayAudio)
    --GameAudioContro.ReSetPlayAudio()
end

function GameAudioContro.Play(AudioPath)
    if soundMgr.CanPlaySoundEffect then
        gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
            if(objects ~= nil) then
                GameAudioContro.SoundEffect:PlayOneShot(objects[0])
            end
        end)
    end
end

function GameAudioContro.PlayBG(AudioPath,func)
    if soundMgr.CanPlayBackSound then
        gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
            if(objects ~= nil) then
                GameAudioContro.bgaudiosource.clip = objects[0]
                GameAudioContro.bgaudiosource.loop = true
                GameAudioContro.bgaudiosource:Play()
                if(func ~= nil)then
                    func()
                end
            end
        end)
    end
end

function GameAudioContro.PlayLoop(AudioPath,func)
    if soundMgr.CanPlaySoundEffect then
        gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
            GameAudioContro.SoundEffect.clip = objects[0]
            GameAudioContro.SoundEffect.loop = true
            GameAudioContro.SoundEffect:Play()
        end)
    end
end

function GameAudioContro.ReSetPlayAudio()
    if soundMgr.CanPlayBackSound then
        GameAudioContro.bgaudiosource:Play()
    else
        GameAudioContro.bgaudiosource:Stop()
    end
    if not soundMgr.CanPlaySoundEffect then
        GameAudioContro.SoundEffect:Stop()
    end
end

function GameAudioContro.StopEffect()
    GameAudioContro.SoundEffect:Stop()
end