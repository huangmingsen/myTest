local GameLogic = require "224.GameLogic"
local GamePlayerGroup = require "224.GamePlayerGroup"
local GameBankerList =
{
    BtnClose,
    BtnShangZhuang,
    BtnXiaZhuang,
    
    SZslider,
    SZtoggle,
    LbLimitMoney,
    LbCarryMoney,

    GoFirst,
    IconZhuangHead,
    ImZhuangHeadBorder,
    LbZhuangName,
    LbZhuangMoney,
    LbZuoZhuangJuShu,
    LbLaterJuShu,
    LbZhuangWin,
    LbZhuangLose,

    Parent,
    Obj_Pos, --路单
    Obj_Iterm, -- 路单项

    listIterm = {}, -- 单项
    listData = {}, -- 数据 

    mViewPos,                                    
	mDistane = 0.0, -- 间距
    mShowNum = 0, -- 显示个数
    isShow = false,
}
local mLeastNtMoney = 0
function GameBankerList.Awake()
    GameBankerList.isShow = false
    GameBankerList.GoFirst = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First","gameObject")
    GameBankerList.IconZhuangHead = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First/IconHead_Box/Icon_Head","UISprite")
    GameBankerList.ImZhuangHeadBorder = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First/HeadBorder","UISprite")
    GameBankerList.LbZhuangName = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First/Label_Name","UILabel")
    GameBankerList.LbZhuangMoney = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First/Label_Money","UILabel")
    GameBankerList.LbZuoZhuangJuShu = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First/Label_ZuoZhuang_JuShu","UILabel")
    GameBankerList.LbLaterJuShu = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First/Label_XiaZhuang_JuShu","UILabel")
    GameBankerList.LbZhuangWin = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First/Label_Win","UILabel")
    GameBankerList.LbZhuangLose = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid/Item_Banker_First/Label_Lose","UILabel")


    GameBankerList.listIterm = {}
    GameBankerList.listData = {}
    GameBankerList.SZslider = FindChildByName(GameBankerList.transform,"UIGroup/Slider","UISlider")
    GameBankerList.SZslider.onChange:Add(EventDelegate.New(GameBankerList.OnSZslider))
    GameBankerList.SZtoggle = FindChildByName(GameBankerList.transform,"UIGroup/Toggle","UIToggle")
    GameBankerList.LbLimitMoney = FindChildByName(GameBankerList.transform,"UIGroup/Label_Limit_Money","UILabel")
    GameBankerList.LbCarryMoney = FindChildByName(GameBankerList.transform,"UIGroup/Label_Money","UILabel")
    GameBankerList.BtnShangZhuang = FindChildByName(GameBankerList.transform,"UIGroup/BtnShangZhuang","gameObject")
    GameBankerList.BtnXiaZhuang = FindChildByName(GameBankerList.transform,"UIGroup/BtnXiaZhuang","gameObject")
    GameBankerList.BtnClose = FindChildByName(GameBankerList.transform,"UIGroup/BtnClose","gameObject")
    UIEventListener.Get(GameBankerList.BtnShangZhuang).onClick = GameBankerList.OnBtnShangZhuang
    UIEventListener.Get(GameBankerList.BtnXiaZhuang).onClick = GameBankerList.OnBtnXiaZhuang
	UIEventListener.Get(GameBankerList.BtnClose).onClick = GameBankerList.OnBtnClose
    GameBankerList.Obj_Pos = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView","gameObject")
    GameBankerList.Parent = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Player_Grid","gameObject")
    GameBankerList.Obj_Iterm = FindChildByName(GameBankerList.transform,"UIGroup/Banker_ScrollView/Item_Banker","gameObject")
    GameBankerList.mViewPos = GameBankerList.Obj_Pos.transform.localPosition

    GameBankerList.isShow = false
end

function GameBankerList.ReSet(ntInFolist,zhuangUser,ntCountWin,totalIntoMoney,zhuangPlayCount,maxGames,leastNtMoney,cbChangeNt)
    local isShowBtnSZ = true
    mLeastNtMoney = leastNtMoney
    GameBankerList.LbLimitMoney.text = FormatNumToStringYW(MoneyProportionStr(mLeastNtMoney))
    if (zhuangUser ~= nil) then
        if(zhuangUser.iDeskStation == MyUserInfo.iDeskStation) then
            isShowBtnSZ = false
        end
        GameBankerList.LbZhuangName.text = zhuangUser.szNickName
        GameUIManager.UpdateHead(GameBankerList.IconZhuangHead, GameBankerList.ImZhuangHeadBorder, zhuangUser.iImageNO, zhuangUser.iPhotoFrame)
        local winmoney = ntCountWin
        if (winmoney > 0) then
            GameBankerList.LbZhuangWin.text = FormatNumToStringYW(MoneyProportionStr(winmoney))
            GameBankerList.LbZhuangWin.gameObject:SetActive(true)
            GameBankerList.LbZhuangLose.gameObject:SetActive(false)
        else
            GameBankerList.LbZhuangLose.text = FormatNumToStringYW(MoneyProportionStr(winmoney))
            GameBankerList.LbZhuangLose.gameObject:SetActive(true)
            GameBankerList.LbZhuangWin.gameObject:SetActive(false)
        end
        GameBankerList.LbZhuangMoney.text = FormatNumToYW(MoneyProportionStr(totalIntoMoney))
        GameBankerList.LbZuoZhuangJuShu.text = tostring(zhuangPlayCount)
        if (cbChangeNt) then
            GameBankerList.LbLaterJuShu.text = "本"
        else
            GameBankerList.LbLaterJuShu.text = tostring(maxGames - zhuangPlayCount)
        end
        GameBankerList.GoFirst:SetActive(true)
    else
        GameBankerList.GoFirst:SetActive(false)
    end
    GameBankerList.listData = {}
    if(#ntInFolist>1) then
        for i=2,#ntInFolist do
            --print("NtInFolist =",ntInFolist[i].DeskStation)
            table.insert(GameBankerList.listData,ntInFolist[i])
            if ntInFolist[i].DeskStation == MyUserInfo.iDeskStation then
                isShowBtnSZ = false
            end
        end
    end
    if(isShowBtnSZ) then
        GameBankerList.BtnShangZhuang.gameObject:SetActive(true)
        GameBankerList.BtnXiaZhuang.gameObject:SetActive(false)
    else
        GameBankerList.BtnShangZhuang.gameObject:SetActive(false)
        GameBankerList.BtnXiaZhuang.gameObject:SetActive(true)
    end

	--恢复
	GameBankerList.Obj_Pos.transform.localPosition = GameBankerList.mViewPos
	GameBankerList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New( -GameBankerList.Obj_Pos.transform.position.x, 0 )

	GameBankerList.UpdateRecord()
end

--路单项
function GameBankerList.GetItermObj( nIndex )
	if ( nIndex <= #GameBankerList.listIterm ) then
        GameBankerList.listIterm[nIndex].gameObject:SetActive(true)
        GameBankerList.listIterm[nIndex].gameObject.name = "iterm"..nIndex
		return GameBankerList.listIterm[ nIndex ]
	end

    local Obj = UnityEngine.GameObject.Instantiate(GameBankerList.Obj_Iterm)
	Obj.name = "iterm"..nIndex
	Obj:SetActive(true)

    Obj.transform.parent = GameBankerList.Parent.transform
	Obj.transform.position = Vector3.zero
	Obj.transform.localScale = Vector3.one
    GameBankerList.Parent:GetComponent("UIGrid"):Reposition()
	local iterm = GamePlayerGroup:new(Obj.transform)
    iterm:InitUI()
	table.insert(GameBankerList.listIterm,iterm)
	return iterm
end
--更新跟单记录
function GameBankerList.UpdateRecord()
    for i = 1,#GameBankerList.listIterm do
        GameBankerList.listIterm[i].gameObject:SetActive(false)
    end
    local index = 1
    for i=1,#GameBankerList.listData do
        local userInfo = GameLogic.finduserbyStation(GameBankerList.listData[i].DeskStation)
        if userInfo ~= nil then
            local uiRecordItem = GameBankerList.GetItermObj(index)
            uiRecordItem:SetBankerInfo(index,userInfo, GameBankerList.listData[i].TotalIntoMoney)
            index = index + 1
        end
    end
end
-- 弹出录单
function GameBankerList.ShowUi()
    GameBankerList.transform.gameObject:SetActive(true)
	--恢复
    if (not GameBankerList.isShow) then
        GameBankerList.isShow = true
        GameBankerList.transform.gameObject:GetComponent("Animation"):Play("Show")
    end
    GameBankerList.OnSZslider()
end
function GameBankerList.OnBtnShangZhuang()
    local SZsliderVlue = GameBankerList.SZslider.value
    local SZtoggleValue = GameBankerList.SZtoggle.value
    GameUIManager.SendShangZhaung(SZsliderVlue,SZtoggleValue)
end
function GameBankerList.OnBtnXiaZhuang()
    GameUIManager.SendXiaZhuang()
end
function GameBankerList.OnBtnClose()
    --恢复
    if (GameBankerList.isShow) then
        GameBankerList.isShow = false
        GameBankerList.transform.gameObject:GetComponent("Animation"):Play("Hide")
    end
    GameBankerList.transform.gameObject:SetActive(false)
end
function GameBankerList.OnSZslider()
    if (tonumber(tostring(MyUserInfo.iMoney)) >= mLeastNtMoney) then
        local AllNtMoney = mLeastNtMoney + (GameBankerList.SZslider.value * (tonumber(tostring(MyUserInfo.iMoney)) - mLeastNtMoney))
        GameBankerList.LbCarryMoney.text = FormatNumToStringYW(MoneyProportionStr(getIntPart(AllNtMoney)))
        GameBankerList.SZslider.enabled = true
        GameBankerList.BtnShangZhuang:GetComponent("Collider").enabled = true
    else
        GameBankerList.SZslider.value = 0
        GameBankerList.LbCarryMoney.text = FormatNumToStringYW(MoneyProportionStr(MyUserInfo.iMoney))
        GameBankerList.SZslider.enabled = false
        GameBankerList.BtnShangZhuang:GetComponent("Collider").enabled = false
    end
end
return GameBankerList