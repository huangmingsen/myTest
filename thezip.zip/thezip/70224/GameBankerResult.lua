local GameBankerResult = 
{
	BtnClose,
	isShow = false,
	anim,
	LbBankerWin,
	LbBankerLose,
	LbBankerCountPlay,
	LbBankerCountMoney,
	lbDate,
}
function GameBankerResult.Awake()
	GameBankerResult.BtnConfirm = GameBankerResult.transform:FindChild("UIGroup/BtnClose").gameObject
	GameBankerResult.LbBankerWin = GameBankerResult.transform:FindChild("UIGroup/Label_Win").gameObject:GetComponent("UILabel")
	GameBankerResult.LbBankerLose = GameBankerResult.transform:FindChild("UIGroup/Label_Lose").gameObject:GetComponent("UILabel")
	GameBankerResult.LbBankerCountPlay = GameBankerResult.transform:FindChild("UIGroup/Label_Ju").gameObject:GetComponent("UILabel")
	GameBankerResult.LbBankerCountMoney = GameBankerResult.transform:FindChild("UIGroup/Label_Coin").gameObject:GetComponent("UILabel")
	GameBankerResult.lbDate = GameBankerResult.transform:FindChild("UIGroup/Label_Date").gameObject:GetComponent("UILabel")
	UIEventListener.Get(GameBankerResult.BtnConfirm).onClick = GameBankerResult.Hide
	GameBankerResult.anim = GameBankerResult.transform.gameObject:GetComponent("Animation")

end
--总带入 局数 输赢
function GameBankerResult.Show(countMoney,countPlay,winLose)
	GameBankerResult.transform.gameObject:SetActive(true)
	GameBankerResult.anim:Play("Show")
	GameBankerResult.isShow = true
	GameBankerResult.LbBankerWin.text = winLose > 0 and MoneyProportionStr(winLose) or ""
	GameBankerResult.LbBankerLose.text = winLose <= 0 and MoneyProportionStr(winLose) or ""
	GameBankerResult.LbBankerCountMoney.text = MoneyProportionStr(countMoney)
	GameBankerResult.LbBankerCountPlay.text = countPlay
    local nowTime = System.DateTime.Now.Year.."年"..System.DateTime.Now.Month.."月"..System.DateTime.Now.Day.."日\n"..System.DateTime.Now.Hour..":"..System.DateTime.Now.Minute..":"..System.DateTime.Now.Second
	GameBankerResult.lbDate.text = nowTime
end
function GameBankerResult.Hide()
	if not GameBankerResult.isShow then return end
	GameBankerResult.isShow = false
    local time = 0
    if GameBankerResult.anim then
        local animClip = GameBankerResult.anim:GetClip("Hide")
        if animClip then
            GameBankerResult.anim.enabled = true
            GameBankerResult.anim:Play("Hide")
            time = animClip.length
        end
        coroutine.stop(GameBankerResult.yieldHide)
        coroutine.start(GameBankerResult.yieldHide,time)
    end
end
function GameBankerResult.yieldHide(time)
	coroutine.wait(time)
    GameBankerResult.transform.gameObject:SetActive(false)
end

function GameBankerResult.OnDestroy()
    coroutine.stop(GameBankerResult.yieldHide)
end
return GameBankerResult