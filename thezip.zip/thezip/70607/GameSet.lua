local GameSet =
{
	TogMusic = nil,
	TogSound = nil,
	CheckmarkMusic = nil,
	BackgroundMusic = nil,
	CheckmarkSound = nil,
	BackgroundSound = nil,
}

function GameSet.Awake()
	GameSet.TogMusic = FindChildByName(GameSet.transform,"BtnMusic","UIToggle")
	GameSet.TogSound = FindChildByName(GameSet.transform,"BtnSound","UIToggle")

	GameSet.CheckmarkMusic = FindChildByName(GameSet.TogMusic.transform,"Checkmark","gameObject")
	GameSet.CheckmarkSound = FindChildByName(GameSet.TogSound.transform,"Checkmark","gameObject")
	GameSet.BackgroundMusic = FindChildByName(GameSet.TogMusic.transform,"Background","gameObject")
	GameSet.BackgroundSound = FindChildByName(GameSet.TogSound.transform,"Background","gameObject")

	GameSet.TogMusic.onChange:Add(EventDelegate.New(GameSet.OnTogMusic))
	GameSet.TogSound.onChange:Add(EventDelegate.New(GameSet.OnTogSound))

	GameSet.TogMusic.value = soundMgr.CanPlayBackSound
	GameSet.TogSound.value = soundMgr.CanPlaySoundEffect
	GameSet.OnTogMusic()
	GameSet.OnTogSound()
end

function GameSet.OnTogMusic()
	soundMgr.CanPlayBackSound = GameSet.TogMusic.value
	GameSet.CheckmarkMusic:SetActive(GameSet.TogMusic.value)
	GameSet.BackgroundMusic:SetActive(not GameSet.TogMusic.value)
	if UIGameLoad ~= nil and UIGameLoad.GameManage ~= nil then
		UIGameLoad.GameManage:Action_ResetBGVolume()
	end
end

function GameSet.OnTogSound()
	soundMgr.CanPlaySoundEffect = GameSet.TogSound.value
	GameSet.CheckmarkSound:SetActive(GameSet.TogSound.value)
	GameSet.BackgroundSound:SetActive(not GameSet.TogSound.value)
	if UIGameLoad ~= nil and UIGameLoad.GameManage ~= nil then
		UIGameLoad.GameManage:Action_ResetBGVolume()
	end
end
return GameSet
