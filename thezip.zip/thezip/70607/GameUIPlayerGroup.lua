local GameUIPlayerGroup = 
{

}
function GameUIPlayerGroup:new(trans)
	local _instance = 
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self 
	setmetatable(_instance, self)
	return _instance
end
function GameUIPlayerGroup:Init()
    self.IconHead = FindChildByName(self.transform, "IconHead_Box/Icon_Head","UISprite")
    self.LbName = FindChildByName(self.transform, "Label_Name","UILabel")
    self.LbMoney = FindChildByName(self.transform, "Label_Money","UILabel")
	self.LbLV = FindChildByName(self.transform, "LbVip","UILabel")
    self.ImHeadBorder = FindChildByName(self.transform, "HeadBorder","UISprite")

    -------GameResult-------
	self.PlayerName = FindChildByName(self.transform, "Label_Name","UILabel")
	self.LbJSWin = FindChildByName(self.transform, "Label_Win","UILabel")
	self.LbJSLose = FindChildByName(self.transform, "Label_Lose","UILabel")
	self.IconBackTarget = FindChildByName(self.transform, "Icon_Box_Target","UISprite")
	self.IconStateTarget = FindChildByName(self.transform, "Icon_State_Target","UISprite")
end
function GameUIPlayerGroup:Set(info)
    self:UpdateHead(info.UserImageNO, info.iPhotoFrame)
    self.LbName.text = info.UserName
    if self.LbMoney then
        self.LbMoney.text = GameUIManager.FormatNumToYW(MoneyProportionStr(info.UserMoney))
    end
	if self.LbLV then
		self.LbLV.text = tostring(info.iVipLevel)
	end
end

function GameUIPlayerGroup:UpdateHead(headId,borderId)
	if self.ImHeadBorder ~= nil then
	    local HeadBorderName = GetHeadBorderById(borderId)
		self.ImHeadBorder.spriteName = HeadBorderName
		--self.ImHeadBorder:MakePixelPerfect()
	end
    local HeadName = GetHeadSpriteName(headId)
	self.IconHead.spriteName = HeadName

end
function GameUIPlayerGroup:ReSetInstance(rank,nickName,money,isNote,isPrize)
	self.PlayerName.text = nickName
	self.LbJSWin.gameObject:SetActive(false)
	self.LbJSLose.gameObject:SetActive(false)
	if money >= 0 then
		if self.IconBackTarget ~= nil then
			self.IconBackTarget.spriteName = "Icon_JS_Win_InputBox"
		end
		self.LbJSWin.gameObject:SetActive(true)
		if rank > 2 then
			self.LbJSWin.text = "+"..GameUIManager.FormatNumToStringYW(MoneyProportionStr(money))
		else
			self.LbJSWin.text = "+"..GameUIManager.FormatNumToYW(MoneyProportionStr(money))
		end
	else
		if self.IconBackTarget ~= nil then
			self.IconBackTarget.spriteName = "Icon_JS_Lose_InputBox"
		end
		self.LbJSLose.gameObject:SetActive(true)
		if rank > 2 then
			self.LbJSLose.text = GameUIManager.FormatNumToStringYW(MoneyProportionStr(money))
		else
			self.LbJSLose.text = GameUIManager.FormatNumToYW(MoneyProportionStr(money))
		end
	end
	if rank == 1 then
		if self.IconBackTarget ~= nil then
			self.IconStateTarget.gameObject:SetActive(false)
			if money == 0 then
				if not isNote then
					self.IconStateTarget.gameObject:SetActive(true)
					self.IconStateTarget.spriteName = "Txt_JS_Win_WXZ"
					self.LbJSWin.gameObject:SetActive(false)
					self.LbJSLose.gameObject:SetActive(false)
				end
			elseif money < 0 then
				if isNote then
					if not isPrize then
						self.IconStateTarget.gameObject:SetActive(true)
						self.IconStateTarget.spriteName = "Txt_JS_Lose_WTZ"
						self.LbJSWin.gameObject:SetActive(false)
						self.LbJSLose.gameObject:SetActive(false)
					end
				else
					self.IconStateTarget.gameObject:SetActive(true)
					self.IconStateTarget.spriteName = "Txt_JS_Lose_WXZ"
					self.LbJSWin.gameObject:SetActive(false)
					self.LbJSLose.gameObject:SetActive(false)
				end
			end
		end
	end
end    
return GameUIPlayerGroup