local GameGoldAnima =
{
}

function GameGoldAnima:new(trans)
    local _instance =
    {
        transform = trans,
        gameObject = trans.gameObject
    }
    self.__index = self
    setmetatable(_instance, self)
    return _instance
end
function GameGoldAnima:InitUI()
    self.IconBg = FindChildByName(self.transform, "Pos/Background", "UISprite")
    self.LbNum = FindChildByName(self.transform, "Pos/Font_Num", "UILabel")
    self.goldPos = self.transform.gameObject:GetComponent("TweenPosition")
    self.goldSca = FindChildByName(self.transform, "Pos","TweenScale")
    self.coroutineParent = nil
end

function GameGoldAnima:SetData(moneyStr, index, count)
    self.IconBg.spriteName = "ico_chouma_"..index
    --self.IconBg:MakePixelPerfect()
    local depthIndex = (count - math.floor(count/60)*60)
    self.IconBg.depth = 200 + depthIndex * 2
    self.LbNum.text = moneyStr
    self.LbNum.depth = 201 + depthIndex * 2
end
function GameGoldAnima:SetDepth(count)
    local depthIndex = (count - math.floor(count/60)*60)
    self.IconBg.depth = 200 + depthIndex * 2
    self.LbNum.depth = 201 + depthIndex * 2
end

function GameGoldAnima:GotoPosition(fromPos, topos, time,isHide,isPlayAud)
    if isPlayAud ~= nil and not isPlayAud then
    else
        GameAudioContro.Play(GameAudioContro.BetAud)
    end
    self.goldPos.transform.localPosition = fromPos
    self.goldPos.from = fromPos
    self.goldPos.to = topos
    self.goldPos.duration = time
    self.goldPos:ResetToBeginning()
    self.goldPos:PlayForward()
    self.coroutineParent = coroutine.start(GameGoldAnima.HideObj,self,time,isHide,isPlayAud)
end
function GameGoldAnima.HideObj(self,time,isHide,isPlayAud)
    local snopTime = time-0.1
    coroutine.wait(snopTime)
    local vec = math.random(300,420)
    self.goldSca.transform.localRotation = Quaternion.Euler(0, 0,vec)
    self.goldSca.enabled = true
    self.goldSca:ResetToBeginning()
    self.goldSca:PlayForward()
    --if isPlayAud ~= nil and not isPlayAud then
    --else
    --    GameAudioContro.Play(GameAudioContro.BetEndAud)
    --end
    coroutine.wait(0.3)
    if(isHide~=nil and isHide) then
        self.transform.gameObject:SetActive(false)
    end
end
function GameGoldAnima:OnDestroy()
    if(self.coroutineParent ~= nil) then
        coroutine.stop(self.coroutineParent)
        self.coroutineParent = nil
    end
    UnityEngine.GameObject.Destroy(self.transform.gameObject)
end
return GameGoldAnima