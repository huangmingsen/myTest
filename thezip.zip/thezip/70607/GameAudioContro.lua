GameAudioContro = 
{
	bgaudiosource = nil,
	SoundEffect = nil,
	AudioClips = {},
	button = "Public/Audio/307countdown.u3d",--按钮
	BGBetAud = "Public/Audio/307BGM1.u3d",--按钮
	BGRunAud = "Public/Audio/307BGM2.u3d",--按钮
	StartBetAud = "Public/Audio/307startbet.u3d",--按钮
	EndBetAud = "Public/Audio/307endbet.u3d",--按钮
	BetAud = "Public/Audio/307bet.u3d",--按钮
	GetBetAud = "Public/Audio/307getbet.u3d",--按钮
	BetEndAud = "Public/Audio/307betend.u3d",--按钮
	CarTurnAud = "Public/Audio/307carturn.u3d",--按钮
	CarTurnEndAud = "Public/Audio/307carturnend.u3d",--按钮
	ClockAud = "Public/Audio/307clock.u3d",--按钮
	GameWinkAud = "Public/Audio/307win.u3d",--按钮
	GameLoseAud = "Public/Audio/307lose.u3d",--按钮
}

function GameAudioContro.Awake()
	GameAudioContro.bgaudiosource = GameAudioContro.transform:GetComponent("AudioSource")
	GameAudioContro.SoundEffect = GameAudioContro.transform:FindChild("SoundEffect"):GetComponent("AudioSource")
	GameDefine.AddEvent(GameDefine.Action_ResetBGVolume, GameAudioContro.ReSetPlayAudio)
	GameAudioContro.ReSetPlayAudio()
	gameresMrg:LoadPrefab(GameAudioContro.button, nil, nil)--预加载声音
end

function GameAudioContro.Play(AudioPath)
	if AudioPath == nil or AudioPath == "" then
		print("====>>AudioPath nil")
		return
	end
	if soundMgr.CanPlaySoundEffect then
		local isContain = false
		local snopClip = nil
		if #GameAudioContro.AudioClips > 0 then
			for i = 1, #GameAudioContro.AudioClips do
				if GameAudioContro.AudioClips[i][1] == AudioPath then
					snopClip = GameAudioContro.AudioClips[i][2]
					isContain = true
					break
				end
			end
		end
		if isContain then
			GameAudioContro.SoundEffect:PlayOneShot(snopClip)
		else
			gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
				if objects ~= nil then
					local snoplist = {AudioPath,objects[0]}
					table.insert(GameAudioContro.AudioClips,snoplist)
					GameAudioContro.SoundEffect:PlayOneShot(objects[0])
				end
			end)
		end
    end
end
function GameAudioContro.PlayBg(AudioPath)
	if AudioPath == nil or AudioPath == "" then
		print("====>>AudioPath nil")
		return
	end
	if soundMgr.CanPlayBackSound then
		gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
			if objects ~= nil then
				GameAudioContro.bgaudiosource.clip = objects[0]
				GameAudioContro.bgaudiosource.loop = true
				GameAudioContro.bgaudiosource:Play()
			end
		end)
    end
end

function GameAudioContro.PlayLoop(AudioPath)
	if soundMgr.CanPlaySoundEffect then
		gameresMrg:LoadPrefab("AudioClip", AudioPath, nil, function(objects)
			GameAudioContro.SoundEffect.clip = objects[0]
			GameAudioContro.SoundEffect.loop = true
			GameAudioContro.SoundEffect:Play()
		end)
    end
end

function GameAudioContro.ReSetPlayAudio()
	if soundMgr.CanPlayBackSound then
		GameAudioContro.bgaudiosource:Play()
	else
		GameAudioContro.bgaudiosource:Stop()
	end
	if not soundMgr.CanPlaySoundEffect then
		GameAudioContro.SoundEffect:Stop()
	end
end

function GameAudioContro.StopEffect()
	GameAudioContro.SoundEffect:Stop()
end