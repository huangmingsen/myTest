GameProtocal = 
{
    GM_SUB_STATION = 1001,--游戏状态
    GM_SUB_STATE_SWITCH = 1002,--游戏状态更新
    GM_SUB_NOTE = 1003,--玩家下注
    GM_SUB_CONTINUE_NOTE = 1004,--续压
    GM_SUB_CANCEL_NOTE = 1005,--清除
    GM_SUB_CANCEL_ALLNOTE = 1006,-- 清除所有
    GM_SUB_STATISTICS = 1010,--下注详情
    GM_SUB_NT_LIST = 1011, --庄家列表
    GM_SUB_NT_INFO = 1012,--庄家信息
    GM_SUB_USERATTRI = 1013,--在线玩家列表
    GM_SUB_START_ACCOUNT = 1015,--即将结算

    ----------------------
    SUB_GM_POOLDATA_FRESH = 2,--奖池刷新
    SUB_GM_POOL_DISTRIBUTE = 3,--奖池派发
    SUB_GM_POOL_CONFIG = 4,--奖池配置
    SUB_GM_POOL_RECORD = 5,--奖池记录
    SUB_GM_GAME_CONFIG = 7,--限制下注
  
}

--define GM_SUB_STATE_SWITCH             1002          //游戏状态更新
GameProtocal.CMD_GM_StateSwitch =
{
  { names = "iState", types = "Byte", data = 0 },
  { names = "Tick", types = "Int32", data = 0 },
}


--开始下注赔率
--define  HANDSEL_COUNT  20
GameProtocal.CMD_GM_StateSwitch_Note =
{
  { names = "iState", types = "Byte", data = 0 },
  { names = "Tick", types = "Int32", data = 0 },
  { names = "BasePoint", types = "Byte[]", length = 8, data = {} },
  { names = "iNtGames", types = "Int32", data = 0 },--庄家已经当庄局数
}

--开奖状态
GameProtocal.CMD_GM_StateSwitch_Open =
{
  { names = "iState", types = "Byte", data = 0 },
  { names = "Tick", types = "Int32", data = 0 },

  { names = "Prize", types = "Byte", data = 0 },
  { names = "PrizeIndex", types = "Byte", data = 0 },
  { names = "RankingCount", types = "Byte", data = 0 },
  { names = "RankingStation", types = "Byte[]", length = 5, data = {} },
  { names = "RankingMoney", types = "Int64[]", length = 5, data = {} },
  { names = "BankerWinMoney", types = "Int64", data = 0 },
  { names = "WinLoseMoney", types = "Int64", data = 0 },--玩家输赢钱
  { names = "PrizeCounts", types = "Byte[]", length = 8, data = {} },--各个车开奖次数
  { names = "iCurGameCount", types = "Int32", data = 0 },
}


--断线重连
GameProtocal.CMD_GM_Station_Base =
{
  { names = "bStation", types = "Byte", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--至少多少局
  { names = "MaxNtGames", types = "Int32", data = 0 },--最多上庄局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置
  { names = "iNtCount", types = "Int32", data = 0 },--当前庄家 已经当庄局数
}

GameProtocal.CMD_GM_Station_Note =
{
  { names = "bStation", types = "Byte", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--至少多少局
  { names = "MaxNtGames", types = "Int32", data = 0 },--最多上庄局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置
  { names = "iNtCount", types = "Int32", data = 0 },--当前庄家 已经当庄局数

  { names = "SelfAreaNotes", types = "Int64[]", length = 8, data = {} },--每个下注区域的下注额度
  { names = "SelfTotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "Chip", types = "Int32[]", length = 6, data = {} },--筹码类型
  { names = "Base", types = "Byte[]", length = 8, data = {} },--各个下注域的倍数
  { names = "ResultList", types = "Byte[]", length = 20, data = {} },--历史记录
  { names = "ResultCount", types = "Int32", data = 0 },--历史记录个数
}


GameProtocal.CMD_GM_Station_Open =
{
  { names = "bStation", types = "Byte", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--至少多少局
  { names = "MaxNtGames", types = "Int32", data = 0 },--最多上庄局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置
  { names = "iNtCount", types = "Int32", data = 0 },--当前庄家 已经当庄局数

  { names = "SelfAreaNotes", types = "Int64[]", length = 8, data = {} },--每个下注区域的下注额度
  { names = "SelfTotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "Chip", types = "Int32[]", length = 6, data = {} },--筹码类型
  { names = "Base", types = "Byte[]", length = 8, data = {} },--各个下注域的倍数
  { names = "ResultList", types = "Byte[]", length = 20, data = {} },--历史记录
  { names = "ResultCount", types = "Int32", data = 0 },--历史记录个数

  { names = "PrizeIndex", types = "Byte", data = 0 }, --普通奖
  { names = "PrizeRoadIndex", types = "Byte", data = 0 },--车子路点索引
  { names = "WinMoney", types = "Int64", data = 0 },--输赢的钱
  { names = "mBankerWinMoney", types = "Int64", data = 0 },
  { names = "RankingCount", types = "Byte", data = 0 },
  { names = "RankingStation", types = "Byte[]", length = 5, data = {} },
  { names = "RankingMoney", types = "Int64[]", length = 5, data = {} },
}



--奖金开奖--结算
GameProtocal.CMD_GM_Station_Settlement =
{
  { names = "bStation", types = "Byte", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--至少多少局
  { names = "MaxNtGames", types = "Int32", data = 0 },--最多上庄局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置
  { names = "iNtCount", types = "Int32", data = 0 },--当前庄家 已经当庄局数

  { names = "SelfAreaNotes", types = "Int64[]", length = 8, data = {} },--每个下注区域的下注额度
  { names = "SelfTotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "Chip", types = "Int32[]", length = 6, data = {} },--筹码类型
  { names = "Base", types = "Byte[]", length = 8, data = {} },--各个下注域的倍数
  { names = "ResultList", types = "Byte[]", length = 20, data = {} },--历史记录
  { names = "ResultCount", types = "Int32", data = 0 },--历史记录个数

  { names = "PrizeIndex", types = "Byte", data = 0 }, --普通奖
  { names = "PrizeRoadIndex", types = "Byte", data = 0 },--车子路点索引
  { names = "WinMoney", types = "Int64", data = 0 },--输赢的钱
  { names = "mBankerWinMoney", types = "Int64", data = 0 },
  { names = "RankingCount", types = "Byte", data = 0 },
  { names = "RankingStation", types = "Byte[]", length = 5, data = {} },
  { names = "RankingMoney", types = "Int64[]", length = 5, data = {} },
}




--游戏未开始 或结束
GameProtocal.CMD_GM_Station_Next =
{
  { names = "bStation", types = "Byte", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--至少多少局
  { names = "MaxNtGames", types = "Int32", data = 0 },--最多上庄局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置
  { names = "iNtCount", types = "Int32", data = 0 },--当前庄家 已经当庄局数

  { names = "Chip", types = "Int32[]", length = 6, data = {} },--筹码类型
  { names = "Base", types = "Byte[]", length = 8, data = {} },--各个下注域的倍数
  { names = "ResultList", types = "Byte[]", length = 20, data = {} },--历史记录
  { names = "ResultCount", types = "Int32", data = 0 },--历史记录个数
}


--define GM_SUB_NOTE                     1003          //玩家下注
GameProtocal.CMD_GM_CurNoteData =
{
  { names = "nDeskStation", types = "Int32", data = 0 },--下注的玩家
  { names = "AreaIndex", types = "Int32", data = 0 },--下注的对象索引
  { names = "NoteKind", types = "Int32", data = 0 },--下注的筹码大小类型
  { names = "NoteMoney", types = "Int64", data = 0 },--下注的钱
  { names = "State", types = "Int32", data = 0 },--状态
}
--define GM_SUB_CONTINUE_NOTE    1004          //续压 无包体
GameProtocal.CMD_GM_ContinueLastNote =
{
  { names = "nDeskStation", types = "Int32", data = 0 },
  { names = "mState", types = "Int32", data = 0 },--续压状态
  { names = "AreaNoteMoney", types = "Int64[]", length = 8, data = {} },
}
--define GM_SUB_CANCEL_NOTE              1005
GameProtocal.CMD_GM_CancelCurNote =
{
  { names = "nDeskStation", types = "Byte", data = 0 },
  { names = "mIndex", types = "Byte", data = 0 },
  { names = "mMoney", types = "Int64", data = 0 },
}
--define GM_SUB_CANCEL_ALLNOTE           1006         // 清除
GameProtocal.CMD_GM_CancelCurAllNote =
{
  { names = "nDeskStation", types = "Byte", data = 0 },
  { names = "mIndex", types = "Byte", data = 0 },
  { names = "NoteMoney", types = "Int64[]", length = 8, data = {} },
}






--define GM_SUB_STATISTICS               1010		 //统计（押注，概率）

GameProtocal.CMD_GM_Station_PrizeCounter =
{
  { names = "AreaNotes", types = "Int64[]", length = 8, data = {} },--每个下注区域的下注额度
  { names = "TotalNotes", types = "Int32", data = 0 },--总下注数
}
--define GM_SUB_NT_LIST                  1011         //发送树的数据给客户端
--庄家列表
GameProtocal.NtListtag = 
{
  { names = "bNtCount", types = "Byte", data = 0 },
  { names = "bStation", types = "Byte[]", length = 1, data = {} },
}
--define GM_SUB_NT_INFO                  1012          //庄家信息
--抢庄
GameProtocal.CMD_GM_NtInfo =
{
  { names = "state", types = "Byte", data = 0 },--0:上庄 1:下庄  2：切换庄家   10:上庄钱不足 11：本局结束后就可以下庄    >20  (还差多少局)
  { names = "bDeskStation", types = "Byte", data = 0 },
}


GameProtocal.CMD_GR_PoolData_Fresh= --奖池刷新   3
{
	{ names = "uRoomId", types = "UInt32", data = 0 },
	{ names = "iPoolMoney", types = "Int64", data = 0 },
}
GameProtocal.CMD_GR_PoolData_Distrubute= --奖池派发  3
{
	{ names = "uRoomId", types = "UInt32", data = 0 },
	{ names = "uDeskId", types = "UInt32", data = 0 },
	{ names = "uUserId", types = "UInt32", data = 0 },
	{ names = "uCardType", types = "UInt32", data = 0 },
	{ names = "uPoolMoney", types = "UInt32", data = 0 },
}
GameProtocal.CMD_GR_PoolConfig= --奖池配置
{
	{ names = "CardTypePro", types = "Int32[]", length = 10, data = {} },
	{ names = "CardTypeProCount", types = "Byte", data = 0 },
	{ names = "cbPoolSwitch", types = "Byte", data = 0 },  --奖池开关 0：关  1：开
	{ names = "TaxKind", types = "Byte", data = 0 }, --房间服务费类型 1 门票 2 税率
	{ names = "Tax", types = "Int32", data = 0 },
	{ names = "iFetchPercent", types = "Int32", data = 0 },
}
GameProtocal.SUB_GM_PoolRecord= --奖池记录
{
	{ names = "sName", types = "Byte[]", length = 80, data = {} }, --玩家昵称
	{ names = "sTime", types = "Byte[]", length = 19, data = {} }, --时间
	{ names = "bCardType", types = "Byte", data = 0 }, --牌型
	{ names = "cbFace", types = "UInt32", data = 0 },  --头像
	{ names = "iPoolMoney", types = "Int32", data = 0 }, --奖池钱
}
GameProtocal.SUB_GM_Limit = --限制注码
{
  { names = "iLimitVlue", types = "Int64", data = 0 },
}



