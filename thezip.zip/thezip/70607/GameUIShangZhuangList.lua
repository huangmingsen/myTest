local GamePlayerInfo = require "607.GamePlayerInfo"
local GameUIShangZhuangList = 
{
    BtnClose,
    BtnShangZhuang,
    BtnXiaZhuang,
    LbLessMoney,
    LbShangZhuangCount,
    ItemParent,
    Obj_Pos,--路单
    Obj_Iterm,--路单项
    listSZIterm = {},--路单项
    mPlayerStation = {},
    mViewPos,--视图位置  
}

function GameUIShangZhuangList.Awake()
    GameUIShangZhuangList.LbShangZhuangCount = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Label_Num","UILabel")
    GameUIShangZhuangList.LbJuShu = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Label_JU","UILabel")
    GameUIShangZhuangList.LbLessMoney = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Label_Coin","UILabel")
    GameUIShangZhuangList.BtnClose = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/BtnClose","gameObject")
    GameUIShangZhuangList.BtnShangZhuang = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Button_ShangZhuang","gameObject")
    GameUIShangZhuangList.BtnXiaZhuang = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Button_XiaZhuang","gameObject")

    GameUIShangZhuangList.Obj_Pos = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Zhuang_ScrollView","gameObject")
    GameUIShangZhuangList.ItemParent = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Zhuang_ScrollView/Zhuang_Grid","gameObject")
    GameUIShangZhuangList.Obj_Iterm = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Zhuang_ScrollView/Item_Zhuang","gameObject")
    GameUIShangZhuangList.mViewPos = GameUIShangZhuangList.Obj_Pos.transform.localPosition
    GameUIShangZhuangList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(0,0)

    UIEventListener.Get(GameUIShangZhuangList.BtnClose).onClick = GameUIShangZhuangList.OnBtnClose
    UIEventListener.Get(GameUIShangZhuangList.BtnShangZhuang).onClick = GameUIShangZhuangList.OnBtnShangZhuang
    UIEventListener.Get(GameUIShangZhuangList.BtnXiaZhuang).onClick = GameUIShangZhuangList.OnBtnXiaZhuang
end
function GameUIShangZhuangList.ShowUI()
    GameUIShangZhuangList.transform.gameObject:SetActive(true)
    GameUIShangZhuangList.transform.gameObject:GetComponent("Animation"):Play("Show1")
    GameUIShangZhuangList.Obj_Pos.transform.localPosition = Vector3.New(GameUIShangZhuangList.Obj_Pos.transform.localPosition.x, GameUIShangZhuangList.mViewPos.y, GameUIShangZhuangList.mViewPos.z)
    GameUIShangZhuangList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(0,0)
end
function GameUIShangZhuangList.OnBtnShangZhuang()
    GameUIManager.BtnShangZhuangPress()
end
function GameUIShangZhuangList.OnBtnXiaZhuang()
    GameUIManager.BtnXiaZhuangPress()
end
function GameUIShangZhuangList.OnBtnClose()
    GameUIShangZhuangList.transform.gameObject:SetActive(false)
    GameUIShangZhuangList.transform.gameObject:GetComponent("Animation"):Play("Hide1")
end
function GameUIShangZhuangList.UpdateData(playerStationList,zhuangStatio,lessMoney,lastCount)
    GameUIShangZhuangList.LbShangZhuangCount.text = tostring(#playerStationList)
    if zhuangStatio >= 0 and zhuangStatio < 180 then
        GameUIShangZhuangList.LbJuShu.gameObject:SetActive(true)
        GameUIShangZhuangList.LbJuShu.text = tostring(lastCount)
    else
        GameUIShangZhuangList.LbJuShu.gameObject:SetActive(false)
    end
    GameUIShangZhuangList.LbLessMoney.text = GameUIManager.FormatNumToYW(MoneyProportionStr(lessMoney))
    GameUIShangZhuangList.mPlayerStation = {}
    local isShowBtnSZ = true
    if(zhuangStatio == MyUserInfo.iDeskStation) then
        isShowBtnSZ = false
    end
    for i=1,#playerStationList do
    	GameUIShangZhuangList.mPlayerStation[i] = playerStationList[i]
        if playerStationList[i] == MyUserInfo.iDeskStation then
            isShowBtnSZ = false
        end
    end
    if isShowBtnSZ then
        GameUIShangZhuangList.BtnShangZhuang.gameObject:SetActive(true)
        GameUIShangZhuangList.BtnXiaZhuang.gameObject:SetActive(false)
    else
        GameUIShangZhuangList.BtnShangZhuang.gameObject:SetActive(false)
        GameUIShangZhuangList.BtnXiaZhuang.gameObject:SetActive(true)
    end
    GameUIShangZhuangList.UpdateRecord()
end
--路单项
function GameUIShangZhuangList.GetLDItermObj(nIndex)
    if GameUIShangZhuangList.Obj_Iterm == nil then
    	print("------------------>>>>>>>UpdateRecord ==>>Obj_Iterm  路单项 nil ! ")
    	return nil
    end
    if nIndex <= #GameUIShangZhuangList.listSZIterm then
        GameUIShangZhuangList.listSZIterm[nIndex].gameObject:SetActive(true)
        return GameUIShangZhuangList.listSZIterm[nIndex]
    end
    local Obj = UnityEngine.GameObject.Instantiate(GameUIShangZhuangList.Obj_Iterm)
    Obj.name = "iterm"..nIndex
    Obj:SetActive(true)
    local grids = GameUIShangZhuangList.ItemParent:GetComponent("UIGrid")
    --grids:AddChild(Obj.transform)
    Obj.transform.parent = grids.transform
    Obj.transform.localScale = Vector3.one

    local iterm = GamePlayerInfo:new(Obj.transform)
    iterm:InitUI()
    table.insert(GameUIShangZhuangList.listSZIterm,iterm)
    return iterm
end
--更新跟单记录
function GameUIShangZhuangList.UpdateRecord()
	for i=1,#GameUIShangZhuangList.listSZIterm do
        GameUIShangZhuangList.listSZIterm[i].gameObject:SetActive(false)
    end
    local rankIndex = 1
    for i=1,#GameUIShangZhuangList.mPlayerStation do
        local user = GameUIManager.GetUserByStation(GameUIShangZhuangList.mPlayerStation[i])
        if user ~= nil then
            local uiRecordItem = GameUIShangZhuangList.GetLDItermObj(rankIndex)
            if uiRecordItem ~= nil then
                uiRecordItem:SetInfo1(user,rankIndex)
                rankIndex = rankIndex + 1
            end
        else
           -- print(string.format("==>>station%d==>Index%d  SUserBaseInfo user is nil ! ", GameUIShangZhuangList.mPlayerStation[i],i))
        end
    end
end
return GameUIShangZhuangList