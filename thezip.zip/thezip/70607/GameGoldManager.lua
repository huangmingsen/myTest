local GameGoldAnima = require "607.GameGoldAnima"
local GameGoldManager =
{
    goldAnimaListInfo = {},
    item,
    zhuangPos,
    MyPos,
    GoldCount = {},
}
function GameGoldManager.Awake()
    GameGoldManager.goldAnimaListInfo = {}
    GameGoldManager.item = FindChildByName(GameGoldManager.transform,"CMItem","gameObject")
    GameGoldManager.GoldCount = {0,0,0,0,0,0,0,0}
    GameGoldManager.zhuangPos = Vector3.New(-290, 216, 0)
    GameGoldManager.MyPos = Vector3.New(-602, -322, 0)
end

function GameGoldManager.GetGoldAnima(AearId, checkIndex)
    local goldAnima
    local userMoney = GameUIManager.FormatNoteNumToYW(MoneyProportionStr(GameUIManager.mChips[checkIndex]))
    GameGoldManager.GoldCount[AearId] = GameGoldManager.GoldCount[AearId]+1
    if(GameGoldManager.goldAnimaListInfo[AearId] == nil) then
        local obj = UnityEngine.GameObject.Instantiate(GameGoldManager.item)
        obj:SetActive(true)
        SetParent(GameGoldManager.transform.gameObject,obj)
        goldAnima = GameGoldAnima:new(obj.transform)
        goldAnima:InitUI()
        goldAnima.transform.gameObject.name = "GoldItem"..AearId..GameGoldManager.GoldCount[AearId]
        GameGoldManager.goldAnimaListInfo[AearId]  = {goldAnima}
    else
        if(GameGoldManager.GoldCount[AearId] <= #GameGoldManager.goldAnimaListInfo[AearId]) then
            goldAnima = GameGoldManager.goldAnimaListInfo[AearId][GameGoldManager.GoldCount[AearId]]
            goldAnima.transform.gameObject:SetActive(true)
            goldAnima.transform.gameObject.name = "GoldItem"..AearId..GameGoldManager.GoldCount[AearId]
        else
            local obj = UnityEngine.GameObject.Instantiate(GameGoldManager.item)
            obj:SetActive(true)
            SetParent(GameGoldManager.transform.gameObject,obj)
            goldAnima = GameGoldAnima:new(obj.transform)
            goldAnima:InitUI()
            goldAnima.transform.gameObject.name = "GoldItem"..AearId..GameGoldManager.GoldCount[AearId]
            table.insert(GameGoldManager.goldAnimaListInfo[AearId],goldAnima)
        end
    end
    goldAnima:SetData(userMoney, checkIndex, GameGoldManager.GoldCount[AearId])
    GameGoldManager.LimitGoldNum()
    return goldAnima
end

function GameGoldManager.LimitGoldNum()
    for i=1,8 do
        if(GameGoldManager.goldAnimaListInfo[i] ~= nil) then
            if(GameGoldManager.GoldCount[i]>50) then
                GameGoldManager.GoldCount[i] = GameGoldManager.GoldCount[i] - 20
                local snopList = {}
                for j=1,20 do
                    snopList[j] = GameGoldManager.goldAnimaListInfo[i][j]
                    snopList[j].transform.gameObject:SetActive(false)
                end
                for j=1,20 do
                    table.remove(GameGoldManager.goldAnimaListInfo[i],1)
                end
                for j=1,20 do
                    table.insert(GameGoldManager.goldAnimaListInfo[i],snopList[j])
                end
                for k = 1, #GameGoldManager.goldAnimaListInfo[i] do
                    GameGoldManager.goldAnimaListInfo[i][k]:SetDepth(k)
                end
            end
        end
    end
end



function GameGoldManager.AearCollectChip(resultIndex)
    local topos = GameGoldManager.zhuangPos
    local isPlayAud = false
    for i=1,8 do
        if i - 1 ~= resultIndex then
            if(GameGoldManager.goldAnimaListInfo[i] ~= nil) then
                for j=1,#GameGoldManager.goldAnimaListInfo[i] do
                    local formPos = GameGoldManager.goldAnimaListInfo[i][j].transform.localPosition
                    GameGoldManager.goldAnimaListInfo[i][j]:GotoPosition(formPos, topos, 0.3,true,false)
                    isPlayAud = true
                end
            end
        end
    end
end

function GameGoldManager.AearThrowChip(resultIndex)
    local isPlayAud = false
    local formPos = GameGoldManager.zhuangPos
    local snopIndex = resultIndex + 1
    if(GameUIManager.CurTotalBet[snopIndex]>0)then
        local count = math.random(20,30)
        local money = tonumber(tostring(GameUIManager.CurTotalBet[snopIndex]))*GameUIManager.mBase[snopIndex]
        local listChips = GameGoldManager.GetChipList(count,money)
        for j=1,#listChips do
            local snop = GameGoldManager.GetGoldAnima(snopIndex,listChips[j])
            local topos = GameUIManager.GetRandomPostion(snopIndex)
            snop:GotoPosition(formPos, topos, 0.4, false, false)
            isPlayAud = true
        end
    end
    if isPlayAud then
        GameAudioContro.Play(GameAudioContro.GetBetAud)
    end
end

function GameGoldManager.FeiGoldToPlayer(resultIndex,myMoney,otherMoney)
    local isPlayAud = false
    local topos = {}
    GameGoldManager.HideAllGole()
    if(myMoney > 0) then
        topos = GameGoldManager.MyPos
        local count = math.random(10,20)
        local listChips = GameGoldManager.GetChipList(count,myMoney)
        for j=1,#listChips do
            local formPos = GameUIManager.GetRandomPostion(resultIndex+1)
            local snop = GameGoldManager.GetGoldAnima(resultIndex+1,listChips[j])
            snop:GotoPosition(formPos, topos, 0.4, true, false)
            isPlayAud = true
        end
    end
    if(otherMoney > 0) then
        topos = GameUIManager.BtnOnLine.transform.localPosition
        local count = math.random(20,30)
        local listChips = GameGoldManager.GetChipList(count,otherMoney)
        for j=1,#listChips do
            local formPos = GameUIManager.GetRandomPostion(resultIndex+1)
            local snop = GameGoldManager.GetGoldAnima(resultIndex+1,listChips[j])
            snop:GotoPosition(formPos, topos, 0.4, true, false)
            isPlayAud = true
        end
    end
    if isPlayAud then
        GameAudioContro.Play(GameAudioContro.GetBetAud)
    end
end

function GameGoldManager.SetAreaGold()
    for i=1,#GameUIManager.CurTotalBet do
        local money = GameUIManager.CurTotalBet[i]
        if(money>0)then
            local count = math.random(5,10)
            local listChips = GameGoldManager.GetChipList(count,money)
            for j=1,#listChips do
                local snop = GameGoldManager.GetGoldAnima(i,listChips[j])
                local topos = GameUIManager.GetRandomPostion(i)
                snop:GotoPosition(topos, topos, 0.1,false,false)
            end
        end
    end
end
function GameGoldManager.HideAllGole()
    GameGoldManager.GoldCount = {0,0,0,0,0,0,0,0}
    for i=1,8 do
        if(GameGoldManager.goldAnimaListInfo[i] ~= nil) then
            for j=1,#GameGoldManager.goldAnimaListInfo[i] do
                GameGoldManager.goldAnimaListInfo[i][j].transform.gameObject:SetActive(false)
            end
        end
    end
end
function GameGoldManager.GetChipList(count,reMoney)
    local money = tonumber(tostring(reMoney))
    local listChips = {}
    while (count > 0) do
        if (money <= GameUIManager.mChips[1]) then
            table.insert(listChips, 1)
            break
        end
        local randomNote = {}
        for k = 1, 6 do
            if money >= GameUIManager.mChips[k] then
                table.insert(randomNote,GameUIManager.mChips[k])
            end
        end
        local ronCheckIndex = math.random(1,#randomNote)
        table.insert(listChips,ronCheckIndex)
        money = money - randomNote[ronCheckIndex]
        count = count - 1
    end
    return listChips
end
function GameGoldManager.OnDestroy()
    for i=1,8 do
        if(GameGoldManager.goldAnimaListInfo[i] ~= nil) then
            for j=1,#GameGoldManager.goldAnimaListInfo[i] do
                GameGoldManager.goldAnimaListInfo[i][j]:OnDestroy()
            end
        end
    end
end
return GameGoldManager