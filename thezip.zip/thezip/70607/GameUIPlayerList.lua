local GameUIPlayerGroup = require "607.GameUIPlayerGroup"
local GameUIPlayerList = 
{
    Close,
	ItemParent,
    Obj_Pos,--路单
    Obj_Iterm,--路单项
    colliderBlack,

    listLDIterm = {},--路单项
    listLDData = {},--更新路单数据


	mViewPos,--视图位置                                           
	mDistane = 0.0,--间距
	mShowNum = 0,--显示个数

    isShow = false,
}
function GameUIPlayerList.Awake()
    GameUIPlayerList.colliderBlack = FindChildByName(GameUIPlayerList.transform, "BlackCollider","Collider")
    GameUIPlayerList.Close = FindChildByName(GameUIPlayerList.transform, "UI_Group/BtnClose","UIButton")
    GameUIPlayerList.Obj_Pos = FindChildByName(GameUIPlayerList.transform, "UI_Group/Player_ScrollView","gameObject")
    GameUIPlayerList.ItemParent = FindChildByName(GameUIPlayerList.transform, "UI_Group/Player_ScrollView/Player_Grid","gameObject")
    GameUIPlayerList.Obj_Iterm = FindChildByName(GameUIPlayerList.transform, "UI_Group/Player_ScrollView/Item_Player","gameObject")
	GameUIPlayerList.mViewPos = GameUIPlayerList.Obj_Pos.transform.position
	GameUIPlayerList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameUIPlayerList.Obj_Pos.transform.position.x, 0)
    UIEventListener.Get(GameUIPlayerList.Close.gameObject).onClick = GameUIPlayerList.HideUI
end

function GameUIPlayerList.ShowUI(listLD)
	--恢复
    if not GameUIPlayerList.isShow then
        GameUIPlayerList.transform.gameObject:SetActive(true)
        GameUIPlayerList.isShow = true
        GameUIPlayerList.colliderBlack.enabled = true
        GameUIPlayerList.Obj_Pos.transform.localPosition = GameUIPlayerList.mViewPos
		GameUIPlayerList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameUIPlayerList.Obj_Pos.transform.position.x, 0)
        GameUIPlayerList.transform.gameObject:GetComponent("Animation"):Play("Show1")
        GameUIPlayerList.listLDData = {}
    end
    GameUIPlayerList.ReSetData(listLD)
end
function GameUIPlayerList.ReSetData(listLD)
    GameUIPlayerList.listLDData = {}
    for i=1,#listLD do
        table.insert(GameUIPlayerList.listLDData,listLD[i])
    end
    GameUIPlayerList.UpdateRecord()
end
function GameUIPlayerList.HideUI()
    if GameUIPlayerList.isShow then
        GameUIPlayerList.isShow = false
        GameUIPlayerList.colliderBlack.enabled = false
        GameUIPlayerList.transform.gameObject:SetActive(false)
        GameUIPlayerList.transform.gameObject:GetComponent("Animation"):Play("Hide1")
    end
end
--路单项
function GameUIPlayerList.GetLDItermObj(nIndex)
	if nIndex <= #GameUIPlayerList.listLDIterm then
		GameUIPlayerList.listLDIterm[nIndex].gameObject:SetActive(true)
		return GameUIPlayerList.listLDIterm[nIndex]
	end

    local Obj = UnityEngine.GameObject.Instantiate(GameUIPlayerList.Obj_Iterm)
	Obj.name = "iterm"..nIndex
	Obj:SetActive(true)
    SetParent(GameUIPlayerList.ItemParent, Obj)
    GameUIPlayerList.ItemParent:GetComponent("UIGrid"):Reposition()

    local iterm = GameUIPlayerGroup:new(Obj.transform)
    iterm:Init()
    table.insert(GameUIPlayerList.listLDIterm,iterm)
	return iterm
end

--更新信息
function GameUIPlayerList.UpdateRecord()
    local nLast = #GameUIPlayerList.listLDData
    for i=1,#GameUIPlayerList.listLDIterm do
        GameUIPlayerList.listLDIterm[i].gameObject:SetActive(false)
    end
	for n=1,nLast do
        local uiRecordItem = GameUIPlayerList.GetLDItermObj(n)
        uiRecordItem:Set(GameUIPlayerList.listLDData[n])
	end
end
return GameUIPlayerList