local json = require "cjson"
--local WWWManager = require(string.format("Hall_%02d/Common/WWWManager", ConfigData.HallSkin))
local WWWManager = require(string.format("%s/Common/WWWManager", ConfigData.HallSkin))
local GameRecord =
{
	BtnClose,
	RecordItem,
	ScrollView,
	Grid,
	RecordList = {},
	ItemData = {},
	LbGameTips,
	RecordLogs = serviceHost.."/GameService/User/GameRecordLogs.ws",
}

function GameRecord.Awake()
	GameRecord.ItemData ={}
	GameRecord.RecordList ={}
	GameRecord.LbGameTips = FindChildByName(GameRecord.transform, "UI_Group/Label_Tips","UILabel")
	GameRecord.BtnClose = FindChildByName(GameRecord.transform, "UI_Group/BtnClose","gameObject")
	GameRecord.RecordItem = FindChildByName(GameRecord.transform, "UI_Group/Record_Item","gameObject")
	GameRecord.ScrollView = FindChildByName(GameRecord.transform, "UI_Group/Record_ScrollView","UIScrollView")
	GameRecord.Grid = FindChildByName(GameRecord.transform, "UI_Group/Record_ScrollView/Grid","UIGrid")
	UIEventListener.Get(GameRecord.BtnClose).onClick = GameRecord.Hide
    GameRecord.LbGameTips.text = ""
	GameRecord.transform.gameObject:SetActive(false)

end

function GameRecord.show()
	GameRecord.transform.gameObject:SetActive(true)
	GameRecord.transform.gameObject:GetComponent("Animation"):Play("Show1")
	GameRecord.GetRecordLogs()
end

function GameRecord.Hide()
	GameRecord.transform.gameObject:GetComponent("Animation"):Play("Hide1")
	coroutine.start(GameRecord.HideObject)
end

function GameRecord.HideObject()
	coroutine.wait(1)
	GameRecord.transform.gameObject:SetActive(false)
end


function GameRecord.GetRecordLogs()
	if not GameRecord.transform.gameObject.activeSelf then return end
	if GameRecord.RecordList == nil or #GameRecord.RecordList < 1 then
		LoadingMsg.Show("正在加载...")
	else
		GameRecord.ShowRecord()
	end
	local tabledata = 
	{
		{name = "agentId", value = AppType },
		{name = "userId", value = tostring(MyUserInfo.uiUserID) },
		{name = "gameId", value = 607 },
	}
	local rearurl = WWWManager.GetResultUrl(GameRecord.RecordLogs, tabledata, true)
    print(rearurl)
    WWWManager.RequestUrl(rearurl, GameRecord.GetRecordLogsReturn, function()
        print("加载游戏记录失败!")
        LoadingMsg.Hied()
    end)
end

function GameRecord.GetRecordLogsReturn(resultTxt)
    print(resultTxt)
    local obj = json.decode(resultTxt)
    if obj ~= nil and obj.code == 0 then
    	GameRecord.RecordList = {}
    	local snopList = obj.data
    	for i=1,#snopList do
    		local oneTxt = snopList[i].Description
    		local twoTxt = string.gsub(oneTxt,"\n","")
    		local oneObj = json.decode(twoTxt)
    		if oneObj ~= nil then
    			GameRecord.RecordList[i] = oneObj
    		end
    	end
        GameRecord.ShowRecord()
        GameRecord.LbGameTips.text = ""
    else
    	GameRecord.LbGameTips.text = obj.msg
        LblMsgText.Show(obj.msg)
    end
    LoadingMsg.Hied()
end

function GameRecord.ShowRecord()
	for i=1,#GameRecord.RecordList do
		if GameRecord.ItemData[i] == nil then
			GameRecord.ItemData[i] = {}
			local gobj = UnityEngine.GameObject.Instantiate(GameRecord.RecordItem)
			gobj.transform:SetParent(GameRecord.Grid.transform)
            gobj.transform.localPosition = Vector3.New(0, 0, 0)
            gobj.transform.localScale = Vector3.New(1, 1, 1)
			GameRecord.ItemData[i].itemobj = gobj
			GameRecord.ItemData[i].Label_GameNane = FindChildByName(gobj.transform, "Label_GameName","UILabel")
			GameRecord.ItemData[i].Label_PrizeFruit = FindChildByName(gobj.transform, "Label_GameIcon","UILabel")
			GameRecord.ItemData[i].Label_State = FindChildByName(gobj.transform, "Label_State","UILabel")
			GameRecord.ItemData[i].Label_AllBet = FindChildByName(gobj.transform, "Label_AllDown","UILabel")
			GameRecord.ItemData[i].Label_AllWin = FindChildByName(gobj.transform, "Label_AllWin","UILabel")
			GameRecord.ItemData[i].Label_Win = FindChildByName(gobj.transform, "Label_Win","UILabel")
			GameRecord.ItemData[i].Label_Lose = FindChildByName(gobj.transform, "Label_Lose","UILabel")
			GameRecord.ItemData[i].Label_Coin = FindChildByName(gobj.transform, "Label_Coin","UILabel")
			GameRecord.ItemData[i].Label_Date = FindChildByName(gobj.transform, "Label_Date","UILabel")
			GameRecord.ItemData[i].BtnDetail = FindChildByName(gobj.transform, "BtnDetail","gameObject")
            UIEventListener.Get(GameRecord.ItemData[i].BtnDetail).onClick = GameRecord.OnShowDetail
			gobj:SetActive(true)
		end
		GameRecord.ItemData[i].Label_GameNane.text = GameRecord.RecordList[i].Name
		GameRecord.ItemData[i].Label_PrizeFruit.text = GameRecord.RecordList[i].Prize
		GameRecord.ItemData[i].Label_State.text = GameRecord.RecordList[i].Type
		GameRecord.ItemData[i].Label_AllBet.text = GameUIManager.FormatNumToStringYW(MoneyProportionStr(GameRecord.RecordList[i].Note))
		GameRecord.ItemData[i].Label_AllWin.text = GameUIManager.FormatNumToStringYW(MoneyProportionStr(GameRecord.RecordList[i].Win))
		if GameRecord.RecordList[i].Real >= 0 then
			GameRecord.ItemData[i].Label_Win.text = GameUIManager.FormatNumToStringYW(MoneyProportionStr(GameRecord.RecordList[i].Real))
			GameRecord.ItemData[i].Label_Win.gameObject:SetActive(true)
			GameRecord.ItemData[i].Label_Lose.gameObject:SetActive(false)
		else
			GameRecord.ItemData[i].Label_Lose.text = GameUIManager.FormatNumToStringYW(MoneyProportionStr(GameRecord.RecordList[i].Real))
			GameRecord.ItemData[i].Label_Win.gameObject:SetActive(false)
			GameRecord.ItemData[i].Label_Lose.gameObject:SetActive(true)
		end
		GameRecord.ItemData[i].Label_Coin.text = GameUIManager.FormatNumToStringYW(MoneyProportionStr(GameRecord.RecordList[i].Money))
		GameRecord.ItemData[i].Label_Date.text = GameRecord.RecordList[i].Time
	end
	GameRecord.ScrollView:ResetPosition()
	GameRecord.Grid.repositionNow = true
end
function GameRecord.OnShowDetail(go)
    for i = 1, #GameRecord.ItemData do
        if(GameRecord.ItemData[i].BtnDetail == go) then
            GameUIManager.ShowGameDetail(GameRecord.RecordList[i])
            return
        end
    end
end

return GameRecord