local GameUIResultIterm = require "607.GameUIResultIterm"
local GameUIResult = 
{
	GoScrollView,
	GoGrid,

	Panel,
	listIterm = {},--记录项

	MaxResultCount = 100,--显示结果的最多条数

	HistoryItem,

	mViewPos,--视图位置                                           
	mDistane = 0.0,--间距
	mShowNum = 0,--显示个数
}
function GameUIResult.Awake()
    GameUIResult.GoScrollView = FindChildByName(GameUIResult.transform, "Scroll View","gameObject")
    GameUIResult.GoGrid = FindChildByName(GameUIResult.transform, "Scroll View/Grid","gameObject")

    GameUIResult.Panel = GameUIResult.GoScrollView:GetComponent("UIPanel")
    GameUIResult.HistoryItem = FindChildByName(GameUIResult.transform, "Scroll View/HistoryItem","gameObject")
    GameUIResult.listIterm = {}
    --for i=1,18 do
    --    GameUIResult.GetLDItermObj(i)
    --end

end
function GameUIResult.GetMaxLimit()
    return GameUIResult.MaxResultCount
end
--初始化
function GameUIResult.UpdateResultList(listResult)
	local nLast = #listResult
	for i=1,#GameUIResult.listIterm do
		GameUIResult.listIterm[i].gameObject:SetActive(false)
	end
	for n=nLast,1,-1 do
        GameUIResult.GetLDItermObj(nLast - n+1):Init(listResult[n], (n == nLast))
    end
end
--路单项
function GameUIResult.GetLDItermObj(nIndex)
	if nIndex <= #GameUIResult.listIterm then
        GameUIResult.listIterm[nIndex].gameObject:SetActive(true)
        GameUIResult.listIterm[nIndex].gameObject.name = "iterm"..nIndex
		return GameUIResult.listIterm[nIndex]
	end

    local Obj = UnityEngine.GameObject.Instantiate(GameUIResult.HistoryItem)
	Obj.name = "iterm"..nIndex
	Obj:SetActive(true)
	SetParent(GameUIResult.GoGrid ,Obj)
   	GameUIResult.GoGrid:GetComponent("UIGrid"):Reposition()
	local iterm = GameUIResultIterm:new(Obj.transform)
	iterm:InitUI()
	table.insert(GameUIResult.listIterm,iterm)
	return iterm  
end

function GameUIResult.DestroyGameObj()
	for i=1,#GameUIResult.listIterm do
        UnityEngine.gameObject.Destroy(GameUIResult.listIterm[i].gameObject)
        table.remove(GameUIResult.listIterm,i)
    end
    GameUIResult.listIterm = {}
    UnityEngine.gameObject.Destroy(GameUIResult.gameObject)
end
return GameUIResult