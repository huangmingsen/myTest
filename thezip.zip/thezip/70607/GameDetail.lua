local bit = require"bit"
local GameDetail =
{
	BtnClose,
	Label_AllDown,
	Label_AllWin,
	Label_Win,
	Label_Lose,
	ItemData = {},
	IconShangCards = {},
	IconXiaCards = {},
	IconIsNtTitle = {},
	LeftTitle,
	CenterTitle,
	RightTitle,
	LbTip,
	LbTitle,
}

function GameDetail.Awake()
	GameDetail.ItemData = {}
	for i=1,8 do
		if GameDetail.ItemData[i] == nil then
			GameDetail.ItemData[i] = {}

			local gobj = FindChildByName(GameDetail.transform, "UI_Group/Detail_Team/Item_"..i,"gameObject")
			GameDetail.ItemData[i].itemobj = gobj
			GameDetail.ItemData[i].Label_Xian = FindChildByName(gobj.transform, "Label_Xian","UILabel")
			GameDetail.ItemData[i].Label_Infor = FindChildByName(gobj.transform, "Label_Infor","UILabel")
			GameDetail.ItemData[i].Label_BeiLv = FindChildByName(gobj.transform, "Label_BeiLv","UILabel")
		end
	end
	--GameDetail.LbTip = FindChildByName(GameDetail.transform, "UI_Group/Label_Special","UILabel")
	--GameDetail.LbTitle = FindChildByName(GameDetail.transform, "UI_Group/Label_Title","UILabel")

	local obj = FindChildByName(GameDetail.transform, "UI_Group/ImageBG/Font_Title0","gameObject")
	if obj then
		obj:SetActive(false)
	end
	GameDetail.LeftTitle = FindChildByName(GameDetail.transform, "UI_Group/ImageBG/Font_Title1","UISprite")
	GameDetail.CenterTitle = FindChildByName(GameDetail.transform, "UI_Group/ImageBG/Font_Title2","UISprite")
	GameDetail.RightTitle = FindChildByName(GameDetail.transform, "UI_Group/ImageBG/Font_Title3","UISprite")
	GameDetail.BtnClose = FindChildByName(GameDetail.transform, "UI_Group/BtnClose","gameObject")
	GameDetail.Label_AllDown = FindChildByName(GameDetail.transform,"UI_Group/Label_AllDown","UILabel")
	GameDetail.Label_AllWin = FindChildByName(GameDetail.transform,"UI_Group/Label_AllWin","UILabel")
	GameDetail.Label_Win = FindChildByName(GameDetail.transform,"UI_Group/Label_Win","UILabel")
	GameDetail.Label_Lose = FindChildByName(GameDetail.transform,"UI_Group/Label_Lose","UILabel")
	UIEventListener.Get(GameDetail.BtnClose).onClick = GameDetail.Hide
	GameDetail.transform.gameObject:SetActive(false)
end

function GameDetail.show(detaidates)
	for i=1,8 do
        GameDetail.ItemData[i].Label_Xian.text = GameUIManager.FormatNumToStringYW(MoneyProportionStr(detaidates.Data[i].Note))
        GameDetail.ItemData[i].Label_BeiLv.text = ""..detaidates.Data[i].Point
		GameDetail.ItemData[i].Label_Infor.text = (detaidates.Data[i].Win and "Yes" or "No") 
	end
	GameDetail.Label_AllDown.text = GameUIManager.FormatNumToYW(MoneyProportionStr(detaidates.Note))
	GameDetail.Label_AllWin.text = GameUIManager.FormatNumToYW(MoneyProportionStr(detaidates.Win))
	if detaidates.Real > 0 then
		GameDetail.Label_Win.gameObject:SetActive(true)
		GameDetail.Label_Lose.gameObject:SetActive(false)
		GameDetail.Label_Win.text = GameUIManager.FormatNumToYW(MoneyProportionStr(detaidates.Real))
	else
		GameDetail.Label_Win.gameObject:SetActive(false)
		GameDetail.Label_Lose.gameObject:SetActive(true)
		GameDetail.Label_Lose.text = GameUIManager.FormatNumToYW(MoneyProportionStr(detaidates.Real))
	end
	--自己是庄家
	if detaidates.IsNt then
    	GameDetail.LeftTitle.spriteName = "Txt_Detail_XJZYF"
       	GameDetail.CenterTitle.spriteName = "Txt_Detail_KJ"
    	GameDetail.RightTitle.spriteName = "Txt_Detail_ZSY"
		GameDetail.Label_AllWin.text = GameUIManager.FormatNumToYW(MoneyProportionStr(detaidates.Open))
    else
    	GameDetail.LeftTitle.spriteName = "Txt_Detail_ZYaF"
    	GameDetail.CenterTitle.spriteName = "Txt_Detail_ZYF"
    	GameDetail.RightTitle.spriteName = "Txt_Record_SJSY"
		GameDetail.Label_AllWin.text = GameUIManager.FormatNumToYW(MoneyProportionStr(detaidates.Win))
    end
    GameDetail.LeftTitle:MakePixelPerfect()
    GameDetail.CenterTitle:MakePixelPerfect()
    GameDetail.RightTitle:MakePixelPerfect()
	--GameDetail.LbTip.gameObject:SetActive(false)
	--GameDetail.LbTitle.gameObject:SetActive(false)
	GameDetail.transform.gameObject:SetActive(true)
	GameDetail.transform.gameObject:GetComponent("Animation"):Play("Show1")
end
function GameDetail.Hide()
	GameDetail.transform.gameObject:GetComponent("Animation"):Play("Hide1")
	GameDetail.transform.gameObject:SetActive(false)
end
return GameDetail