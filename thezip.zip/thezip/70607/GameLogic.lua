local GameLogic = 
{
	--游戏状态
	GAME_STATE =
	{
		ENUM_GAMESTATE_NONE=0,
		ENUM_GAMESTATE_NOTE=1,				--下注 
		ENUM_GAMESTATE_OPENPRIZE=2,			--开奖
		ENUM_GAMESTATE_SETTLEMENT=3,			--结算
		ENUM_GAMESTATE_NEXT=4,			--等待
		ENUM_GAMESTATE_MAX=5,
	},
}

function GameLogic.Awake()
	require "607.GameProtocal"
	GameDefine.AddEvent(GameDefine.Action_UserSit, GameLogic.Action_UserSit)--玩家坐下
	GameDefine.AddEvent(GameDefine.Action_UserLeft, GameLogic.Action_UserLeft)--玩家离开桌子
	GameDefine.AddEvent(GameDefine.Action_RefleshUserInfo, GameLogic.Action_RefleshUserInfo)--刷新用户经验值
	GameDefine.AddEvent(GameDefine.Action_NoMoneyTickRoom, GameLogic.Action_NoMoneyTickRoom)--游戏币不足，提出房间

	GameDefine.AddEvent(GameProtocal.GM_SUB_STATION, GameLogic.GameStation) --游戏状态 1001
	GameDefine.AddEvent(GameProtocal.GM_SUB_STATE_SWITCH, GameLogic.GameStateSwitch) --游戏状态更新 1002
	GameDefine.AddEvent(GameProtocal.GM_SUB_NOTE,GameLogic.GameNoteResult) --玩家下注 1003
	GameDefine.AddEvent(GameProtocal.GM_SUB_CONTINUE_NOTE,GameLogic.GameContinueNote) --玩家续压 1004

	GameDefine.AddEvent(GameProtocal.GM_SUB_CANCEL_ALLNOTE,GameLogic.GameCancelAllNote) --清除所有 1006
	GameDefine.AddEvent(GameProtocal.GM_SUB_STATISTICS,GameLogic.GameStatistice) --下注详情 1010

	GameDefine.AddEvent(GameProtocal.GM_SUB_NT_LIST,GameLogic.GameNtList) -- 庄家列表 1011
	GameDefine.AddEvent(GameProtocal.GM_SUB_NT_INFO,GameLogic.GameNtInfo) -- 庄家信息 1012

	GameDefine.AddEvent(GameProtocal.GM_SUB_USERATTRI,GameLogic.GameUserAttari) -- 在线玩家列表 1013

	GameDefine.AddEvent(GameProtocal.GM_SUB_START_ACCOUNT,GameLogic.GameStartAccount) -- 即将结算 1015

	GameDefine.AddEvent(GameProtocal.SUB_GM_POOLDATA_FRESH, GameLogic.PoolDataRefresh) --奖池刷新
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_DISTRIBUTE, GameLogic.PoolDataDistrubute) --奖池派发
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_CONFIG, GameLogic.PoolConfig) --奖池配置
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_RECORD, GameLogic.PoolRecord) --奖池记录
	
	GameDefine.AddEvent(GameProtocal.SUB_GM_GAME_CONFIG, GameLogic.LimitNote) --限制下注
end

function GameLogic.Action_UserSit(userInfo)--玩家坐下
	print("玩家坐下: userInfo ",userInfo.uiUserID)
	if userInfo.uiUserID == MyUserInfo.uiUserID then
		NetManager:SendData(2000150,1) --获取用户的状态
		NetManager:SendData(2000180,1) --发送准备事件
	print("玩家坐下:"..userInfo.uiUserID,MyUserInfo.uiUserID)
	end
	GameUIManager.PlayerSit(userInfo)

end
function GameLogic.Action_UserLeft(userInfo)--玩家离开
	print(userInfo.uiUserID,"玩家离开")

	GameUIManager.PlayerLeft(userInfo)

end
function GameLogic.Action_NoMoneyTickRoom()--游戏币不足，提出房间
	UIRoom.QuitGame()
end

function GameLogic.Action_RefleshUserInfo(userInfo)--刷新用户经验值
	print("刷新用户经验值")
	if userInfo.uiUserID == MyUserInfo.uiUserID then
		GameUIManager.RefreshUserInfo(MyUserInfo.iMoney)
	end

end
--游戏状态 1001
function GameLogic.GameStation(data)
	print("游戏状态断线重连********",data.mainMsg[0])
	UIRoom.LoadGameFinish()
	GameUIManager.GameStation(data)
	-- body
end
--游戏状态更新 1002
function GameLogic.GameStateSwitch(data)
	print("游戏状态更新********",data.mainMsg[0])
	GameUIManager.GameStateSwitch(data)
	-- body
end
--玩家下注 1003
function GameLogic.GameNoteResult(data)
	local noteResultData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_CurNoteData)
	GameUIManager.GameNoteResult(noteResultData)
    if noteResultData.nDeskStation == MyUserInfo.iDeskStation then
        if noteResultData.State == GameUIManager.ASS_MSG_ERROR_TYPE.NOTE_ERROR_KIND then
            LblMsgText.Show("The betting chip type is wrong!")
        elseif noteResultData.State == GameUIManager.ASS_MSG_ERROR_TYPE.NOTE_ERROR_NOTENOUNGH_MONEY then
            if tonumber(tostring(MyUserInfo.iBank)) > 0  then
                LblMsgText.Show("Insufficient game currency, please withdraw the game currency first!")
            elseif tonumber(tostring(MyUserInfo.iTreasure)) > 0 then
                LblMsgText.Show("Insufficient game currency, please exchange it first!")
            end
        elseif noteResultData.State == GameUIManager.ASS_MSG_ERROR_TYPE.NOTE_ERROR_UNKNOWN then
            LblMsgText.Show("unknown mistake!")
        elseif noteResultData.State == GameUIManager.ASS_MSG_ERROR_TYPE.NOTE_ERROR_DESKSTATION then
            LblMsgText.Show("wrong seat number")
        elseif noteResultData.State == GameUIManager.ASS_MSG_ERROR_TYPE.NOTE_ERROR_ACTIVE then
            LblMsgText.Show("There is no player in the corresponding seat")
        elseif noteResultData.State == GameUIManager.ASS_MSG_ERROR_TYPE.NOTE_ERROR_NOTELIMIT then
            LblMsgText.Show("The betting limit has been reached")
        end
    end
end
--玩家续压 1004
function GameLogic.GameContinueNote(data)
	local continueNoteData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_ContinueLastNote)
	GameUIManager.GameContinueNote(continueNoteData)
    if continueNoteData.nDeskStation == MyUserInfo.iDeskStation then
    	if continueNoteData.mState == 1 then
            LblMsgText.Show("no previous bets")
    	elseif continueNoteData.mState == 2 then
            LblMsgText.Show("not enough money")
        end
    end
end
--清除所有 1006
function GameLogic.GameCancelAllNote(data)
	local cancelAllNoteData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_CancelCurAllNote)
	GameUIManager.GameCancelAllNote(cancelAllNoteData)
end
--下注详情 1010
function GameLogic.GameStatistice(data)
	local userMoneyData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_PrizeCounter)
	GameUIManager.GameStatistice(userMoneyData)
end
function GameLogic.GameNtList(data)-- 庄家列表 1011
	GameProtocal.NtListtag[2].length = data.mainMsg[0]
    local iShangZhuangCount = data.mainMsg[0]
	local ntListData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.NtListtag)
    local shangZhuangStationArr = {}
    GameUIManager.ZhuangList = {}
    for i=1,iShangZhuangCount do
    	GameUIManager.ZhuangList[i] = ntListData.bStation[i-1]
    end
    GameUIManager.RefreshZhuangInfo()
	print("庄家列表 ---1011",data.mainMsg[0])
end
function GameLogic.GameNtInfo(data)--庄家信息 1012
	local ntInfoData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_NtInfo)
	GameUIManager.GameNtInfo(ntInfoData)
end
function GameLogic.GameUserAttari(data) -- 在线玩家列表 1013
end
function GameLogic.GameStartAccount(data) -- 即将结算 1015
	GameUIManager.GameStartAccount(data)
end
function GameLogic.PoolDataRefresh(data)--奖池刷新
	print("奖池刷新")
	GameUIManager.PoolDataRefresh(data)
end
function GameLogic.PoolDataDistrubute(data)--奖池派发
	print("奖池派发")
	GameUIManager.PoolDataDistrubute(data)
end
function GameLogic.PoolConfig(data)--奖池配置
	print("奖池配置")
	GameUIManager.PoolConfig(data)
end
function GameLogic.PoolRecord(data)--奖池记录
	print("奖池记录")
	GameUIManager.PoolRecord(data)
end
function GameLogic.LimitNote(data)--奖池配置
	GameUIManager.LimitNote(data)
end
function GameLogic.OnDestroy()
	GameDefine.Creal()
    package.loaded["607.GameProtocal"] = nil
end
return GameLogic