GameProtocal = 
{
    GM_SUB_GAMESTATION = 1001,--游戏状态
    GM_SUB_BEGIN = 1002,--倒计时开始游戏
    GM_SUB_START = 1003,--游戏开始
    GM_SUB_STATEUPDATE = 1004,--游戏状态更新
    GM_SUB_NT_LIST = 1005,--庄家列表
    GM_SUB_NOTE = 1006,--玩家下注
    GM_SUB_KEYNOTE = 1007,--pc下注
    GM_SUB_CONTINUEPRENOTE = 1008,--续押
    GM_SUB_CANCELCURNOTE = 1009,--取消之前的下注
    GM_SUB_NT_INFO = 1010,--庄家信息
    GM_SUB_PLAYER_NOTEINFO = 1011,--所有用户下注信息
    GM_SUB_SETTLEMENT = 1012,--即将结算
    GM_SUB_TRUSTEESHIP = 1013,--托管消息
    GM_SUB_CHIPUPDATE = 1014,--筹码刷新 
    GM_SUB_STATISTICS = 1015,--统计（押注，概率）
    GM_SUB_USERATTRI = 1016,--在线玩家列表

    PLAY_COUNT = 180,--游戏人数
    PRIZE_MAX = 2,
    RECORD_COUNT = 18,
    RANKING_COUNT = 5,

    NOTE_AREA_COUNT = 12,
    NOTE_MONEY_COUNT = 6,--下注额度个数
    HANDSEL_COUNT = 20,

    SUB_GM_POOLDATA_FRESH = 2,--奖池刷新
    SUB_GM_POOL_DISTRIBUTE = 3,--奖池派发
    SUB_GM_POOL_CONFIG = 4,--奖池配置
    SUB_GM_POOL_RECORD = 5,--奖池记录
    SUB_GM_GAME_CONFIG = 7,  --游戏公用配置
}
--#define GM_SUB_STATEUPDATE              1004       //游戏状态更新
GameProtocal.CMD_GM_StateUpdate =
{
  { names = "iState", types = "UInt32", data = 0 },
  { names = "Tick", types = "Int32", data = 0 },
}
--#define GM_SUB_NT_LIST                  1005     //发送树的数据给客户端
--庄家列表
GameProtocal.CMD_GM_NtList =
{
  { names = "bNtCount", types = "Byte", data = 0 },
  { names = "bStation", types = "Byte[]", length = 1, data = {} },--庄家座位号数组（数组大小就是庄家的个数）
}
--开始下注赔率
GameProtocal.CMD_GM_StateUpdate_Note=
{
  { names = "iState", types = "UInt32", data = 0 },
  { names = "Tick", types = "Int32", data = 0 },
  
  { names = "BasePoint", types = "Byte[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },
  { names = "RecordData", types = "Byte[]", length = GameProtocal.RECORD_COUNT, data = {} },
  { names = "mCurRecord", types = "Int32", data = 0 },
  { names = "mControlPrize", types = "Byte", data = 0 },
  { names = "mNoteLimit", types = "Int64", data = 0 },
  { names = "mHandselData", types = "Int64[]", length = GameProtocal.HANDSEL_COUNT, data = {} },
  { names = "mHandselCount", types = "Int32", data = 0 },
  { names = "mLastHandsel", types = "Int64", data = 0 },
}
--开奖状态
GameProtocal.CMD_GM_StateUpdate_OpenPrize=
{
  { names = "iState", types = "UInt32", data = 0 },
  { names = "Tick", types = "Int32", data = 0 },
 
  { names = "PrizeIndex", types = "Int32[]", length = GameProtocal.PRIZE_MAX, data = {} },--开奖索引
  { names = "StartIndex", types = "Int32", data = 0 },--灯开始跑的索引
  { names = "WinLoseMoney", types = "Int64", data = 0 },--玩家输赢钱
  { names = "iBankerWinMoney", types = "Int64", data = 0 },--庄家输赢钱
  { names = "SecondWinLoseMoney", types = "Int64", data = 0 },--第二个开的奖

  { names = "mCaiJinPoint", types = "Int32", data = 0 },--彩金倍数
  { names = "mHandselMoney", types = "Int64", data = 0 },--彩金所得 刷新玩家自己身上的钱
  { names = "RankingCount", types = "Byte", data = 0 },--排名人数
  { names = "RankingStation", types = "Byte[]", length = GameProtocal.RANKING_COUNT, data = {} },--排名玩家座位号
  { names = "RankingMoney", types = "Int64[]", length = GameProtocal.RANKING_COUNT, data = {} },--排名玩家银行金币
}

GameProtocal.CMD_GM_StateUpdate_Settlement=
{
  { names = "iState", types = "UInt32", data = 0 },
  { names = "Tick", types = "Int32", data = 0 },
  --{ names = "WinLoseMoney", types = "Int64", data = 0 },--玩家输赢钱
}
--define GM_SUB_GAMESTATION        1001                  ///游戏状态
GameProtocal.CMD_GM_Station_Head=
{
  { names = "iCanSelectNotes", types = "Int32[]", length = GameProtocal.NOTE_MONEY_COUNT, data = {} },
  { names = "iNotePoint", types = "Byte[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--各个下注域的倍数
  { names = "iWinLose", types = "Int64", data = 0 },--自己上吧输赢钱
 
  { names = "bStation", types = "UInt32", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--上庄至少局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置
}

GameProtocal.CMD_GM_Station_Note=
{
  { names = "iCanSelectNotes", types = "Int32[]", length = GameProtocal.NOTE_MONEY_COUNT, data = {} },
  { names = "iNotePoint", types = "Byte[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--各个下注域的倍数
  { names = "iWinLose", types = "Int64", data = 0 },--自己上吧输赢钱
 
  { names = "bStation", types = "UInt32", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--上庄至少局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置

  { names = "SelfAreaNotes", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--每个下注区域的下注额度
  { names = "SelfTotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "AreaNotes", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--每个下注区域的下注额度
  { names = "TotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "PreNote", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--之前下注情况
  { names = "PreTotalNote", types = "Int64", data = 0 },--之前总下注
  { names = "PrePrizeIndex", types = "Int32", data = 0 },--之前奖索引
  { names = "mRecordData", types = "Byte[]", length = GameProtocal.RECORD_COUNT, data = {} },
  { names = "mCurRecordIndex", types = "Int32", data = 0 },
  { names = "mConrolPrize", types = "Byte", data = 0 },
  { names = "mNoteLimit", types = "Int64", data = 0 },
  { names = "mHandselData", types = "Int64[]", length = GameProtocal.HANDSEL_COUNT, data = {} },--彩金数据
  { names = "mHandselCount", types = "Int32", data = 0 },--彩金的个数
  { names = "mLastHandsel", types = "Int64", data = 0 },--最后的彩金数据
}

GameProtocal.CMD_GM_Station_OpenPrize=
{
  { names = "iCanSelectNotes", types = "Int32[]", length = GameProtocal.NOTE_MONEY_COUNT, data = {} },
  { names = "iNotePoint", types = "Byte[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--各个下注域的倍数
  { names = "iWinLose", types = "Int64", data = 0 },--自己上吧输赢钱
 
  { names = "bStation", types = "UInt32", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--上庄至少局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置

  { names = "SelfAreaNotes", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--每个下注区域的下注额度
  { names = "SelfTotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "AreaNotes", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--每个下注区域的下注额度
  { names = "TotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "PreNote", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--之前下注情况
  { names = "PreTotalNote", types = "Int64", data = 0 },--之前总下注
  { names = "PrePrizeIndex", types = "Int32", data = 0 },--之前奖索引
  { names = "mRecordData", types = "Byte[]", length = GameProtocal.RECORD_COUNT, data = {} },
  { names = "mCurRecordIndex", types = "Int32", data = 0 },
  { names = "mConrolPrize", types = "Byte", data = 0 },
  { names = "mNoteLimit", types = "Int64", data = 0 },
  { names = "mHandselData", types = "Int64[]", length = GameProtocal.HANDSEL_COUNT, data = {} },--彩金数据
  { names = "mHandselCount", types = "Int32", data = 0 },--彩金的个数
  { names = "mLastHandsel", types = "Int64", data = 0 },--最后的彩金数据

  { names = "mSpecialPrize", types = "Byte", data = 0 },
  { names = "iBankerWinMoney", types = "Int64", data = 0 },--庄家输赢钱
  { names = "RankingCount", types = "Byte", data = 0 },--排名人数
  { names = "RankingStation", types = "Byte[]", length = GameProtocal.RANKING_COUNT, data = {} },--排名玩家座位号
  { names = "RankingMoney", types = "Int64[]", length = GameProtocal.RANKING_COUNT, data = {} },--排名玩家银行金币
}
GameProtocal.CMD_GM_Station_Settlement=
{
  { names = "iCanSelectNotes", types = "Int32[]", length = GameProtocal.NOTE_MONEY_COUNT, data = {} },
  { names = "iNotePoint", types = "Byte[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--各个下注域的倍数
  { names = "iWinLose", types = "Int64", data = 0 },--自己上吧输赢钱
 
  { names = "bStation", types = "UInt32", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--上庄至少局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置

  { names = "SelfAreaNotes", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--每个下注区域的下注额度
  { names = "SelfTotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "AreaNotes", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--每个下注区域的下注额度
  { names = "TotalNotes", types = "Int64", data = 0 },--总下注数
  { names = "PreNote", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--之前下注情况
  { names = "PreTotalNote", types = "Int64", data = 0 },--之前总下注
  { names = "PrePrizeIndex", types = "Int32", data = 0 },--之前奖索引
  { names = "mRecordData", types = "Byte[]", length = GameProtocal.RECORD_COUNT, data = {} },
  { names = "mCurRecordIndex", types = "Int32", data = 0 },
  { names = "mConrolPrize", types = "Byte", data = 0 },
  { names = "mNoteLimit", types = "Int64", data = 0 },
  { names = "mHandselData", types = "Int64[]", length = GameProtocal.HANDSEL_COUNT, data = {} },--彩金数据
  { names = "mHandselCount", types = "Int32", data = 0 },--彩金的个数
  { names = "mLastHandsel", types = "Int64", data = 0 },--最后的彩金数据

  { names = "mSpecialPrize", types = "Byte", data = 0 },
  { names = "iBankerWinMoney", types = "Int64", data = 0 },--庄家输赢钱
  { names = "RankingCount", types = "Byte", data = 0 },--排名人数
  { names = "RankingStation", types = "Byte[]", length = GameProtocal.RANKING_COUNT, data = {} },--排名玩家座位号
  { names = "RankingMoney", types = "Int64[]", length = GameProtocal.RANKING_COUNT, data = {} },--排名玩家银行金币
}
GameProtocal.CMD_GM_Station_Wait=
{
  { names = "iCanSelectNotes", types = "Int32[]", length = GameProtocal.NOTE_MONEY_COUNT, data = {} },
  { names = "iNotePoint", types = "Byte[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--各个下注域的倍数
  { names = "iWinLose", types = "Int64", data = 0 },--自己上吧输赢钱
 
  { names = "bStation", types = "UInt32", data = 0 },--游戏状态
  { names = "iVersion", types = "Byte", data = 0 },--游戏版本号
  { names = "iVersion2", types = "Byte", data = 0 },--游戏版本号
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "iLeftTick", types = "Int32", data = 0 },--剩余时间
  { names = "iTick", types = "Int32", data = 0 },--总的时间
  { names = "iNtLeastMoney", types = "Int64", data = 0 },--上庄最少钱
  { names = "NtLeastGames", types = "Int32", data = 0 },--上庄至少局数
  { names = "iNtStation", types = "Int32", data = 0 },--庄家位置
}
--#define GM_SUB_NOTE                     1006     //玩家下注
--下注数据
GameProtocal.CMD_GM_NoteData=
{
  { names = "nDeskStation", types = "Int32", data = 0 },--下注的玩家
  { names = "AreaIndex", types = "Int32", data = 0 },--下注的对象索引
  { names = "NoteKind", types = "Int32", data = 0 },--下注的筹码大小类型
  { names = "NoteMoney", types = "Int32", data = 0 },--下注的钱
}
--#define GM_SUB_CANCELCURNOTE            1009
--取消之前的下注
GameProtocal.CMD_GM_CancelCurrentNote=
{
  { names = "NoteMoney", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },
  { names = "nDeskStation", types = "Int32", data = 0 },
}
--#define GM_SUB_CONTINUEPRENOTE          1008
--续压
GameProtocal.CMD_GM_ContinuePreNote=
{
  { names = "nDeskStation", types = "Int32", data = 0 },
  { names = "AreaNoteMoney", types = "Int64[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },
}
GameProtocal.CMD_GM_PlayerNoteInfoList=
{
  { names = "mUserCount", types = "Int32", data = 0 },
}
--#define GM_SUB_NT_INFO                  1010      //庄家信息
--抢庄
GameProtocal.CMD_GM_NtInfo =
{
  { names = "state", types = "Byte", data = 0 },--0:上庄 1:下庄  2：切换庄家   10:上庄钱不足 11：本局结束后就可以下庄    >20  (还差多少局)
  { names = "bDeskStation", types = "Byte", data = 0 },
  { names = "cbNtGames", types = "Byte", data = 0 },--庄家当庄局数
  { names = "iEntryMoney", types = "Int64", data = 0 },--庄家带入
  { names = "iWinMoney", types = "Int64", data = 0 },--庄家输赢
}
--define GM_SUB_STATISTICS               1015        //统计（押注，概率）
GameProtocal.CMD_GM_GameStatistics =
{
  { names = "AreaNotes", types = "Int32[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },--每个下注区域的下注额度
  { names = "TotalNotes", types = "Int32", data = 0 },--总下注数
  { names = "mPrizePro", types = "Int32[]", length = GameProtocal.NOTE_AREA_COUNT, data = {} },
  { names = "mTotalGames", types = "Int32", data = 0 },--当前局数
}

GameProtocal.CMD_GR_PoolData_Fresh= --奖池刷新   3
{
	{ names = "uRoomId", types = "UInt32", data = 0 },
	{ names = "iPoolMoney", types = "Int64", data = 0 },
}
GameProtocal.CMD_GR_PoolData_Distrubute= --奖池派发  3
{
	{ names = "uRoomId", types = "UInt32", data = 0 },
	{ names = "uDeskId", types = "UInt32", data = 0 },
	{ names = "uUserId", types = "UInt32", data = 0 },
	{ names = "uCardType", types = "UInt32", data = 0 },
	{ names = "uPoolMoney", types = "UInt32", data = 0 },
}
GameProtocal.CMD_GR_PoolConfig= --奖池配置
{
	{ names = "CardTypePro", types = "Int32[]", length = 10, data = {} },
	{ names = "CardTypeProCount", types = "Byte", data = 0 },
	{ names = "cbPoolSwitch", types = "Byte", data = 0 },  --奖池开关 0：关  1：开
	{ names = "TaxKind", types = "Byte", data = 0 }, --房间服务费类型 1 门票 2 税率
	{ names = "Tax", types = "Int32", data = 0 },
    { names = "iFetchPercent", types = "Int32", data = 0 },
}
GameProtocal.SUB_GM_PoolRecord= --奖池记录
{
	{ names = "sName", types = "Byte[]", length = 80, data = {} }, --玩家昵称
	{ names = "sTime", types = "Byte[]", length = 19, data = {} }, --时间
	{ names = "bCardType", types = "Byte", data = 0 }, --牌型
	{ names = "cbFace", types = "UInt32", data = 0 },  --头像
	{ names = "iPoolMoney", types = "Int32", data = 0 }, --奖池钱
}
GameProtocal.SUB_GM_Limit = --限制注码
{
  { names = "iLimitVlue", types = "Int64", data = 0 },
}
return GameProtocal


