local GameUIBank =
{
	BtnRecahrge,
	BtnClose = nil,
	BtnConfirm = nil,
	LblMoneyBank = nil,
	LblMoney = nil,
	SldMoney = nil, --取款滑动条
	BtnMax = nil,--取款最大按钮
	BtnReset = nil,--取款重置按钮
	InpMoney = nil, --取款输入框
	InpPwd = nil,
	passwordstr = nil, --取款密码
}
local outputchange = false
local onoutbtn = false

function GameUIBank.Awake()
	GameUIBank.BtnClose = FindChildByName(GameUIBank.transform,"UI_Group/BtnClose","gameObject")
	GameUIBank.BtnRecahrge = FindChildByName(GameUIBank.transform,"UI_Group/Btn_Recahrge","gameObject")
	GameUIBank.LblMoneyBank = FindChildByName(GameUIBank.transform,"UI_Group/Label_Bank","UILabel")
	GameUIBank.LblMoney = FindChildByName(GameUIBank.transform,"UI_Group/Label_Money","UILabel")
	GameUIBank.BtnConfirm = FindChildByName(GameUIBank.transform,"UI_Group/Btn_Confirm","gameObject")
	GameUIBank.SldMoney = FindChildByName(GameUIBank.transform,"UI_Group/Slider","UISlider")
	GameUIBank.InpMoney = FindChildByName(GameUIBank.transform,"UI_Group/Input_Money","UIInput")
	GameUIBank.BtnMax = FindChildByName(GameUIBank.transform,"UI_Group/Btn_Max","gameObject")
	GameUIBank.BtnReset = FindChildByName(GameUIBank.transform,"UI_Group/Btn_Reset","gameObject")
	GameUIBank.InpPwd = FindChildByName(GameUIBank.transform,"UI_Group/Input_MM","UIInput")
	UIEventListener.Get(GameUIBank.BtnClose).onClick = GameUIBank.OnBtnClose
	UIEventListener.Get(GameUIBank.BtnConfirm).onClick = GameUIBank.OnBtnConfirm
	UIEventListener.Get(GameUIBank.BtnRecahrge).onClick = GameUIBank.OpenRecharge

	GameUIBank.InpMoney.onChange:Add(EventDelegate.New(GameUIBank.OnInpMoney))
	GameUIBank.InpPwd.onChange:Add(EventDelegate.New(GameUIBank.OnInpPwd))
	GameUIBank.SldMoney.onChange:Add(EventDelegate.New(GameUIBank.OnSldMoney))

	UIEventListener.Get(GameUIBank.BtnMax).onClick = GameUIBank.OnBtnMax
	UIEventListener.Get(GameUIBank.BtnReset).onClick = GameUIBank.OnBtnReset
	GameUIBank.OnBtnReset()
	NetManager:AddAction(1000014, 2, GameUIBank.OutPutMoneyReturn) --取款返回
	GameUIBank.ShowInfo()
	LobyGetDataForomServer.UserRefreshFun = GameUIBank.ShowInfo
	GameUIBank.transform.gameObject:SetActive(false)
	if IsClosePay then
		GameUIBank.BtnRecahrge:SetActive(false)
	end
end
function GameUIBank.OpenRecharge()
    HallUIManager.OnBtnRecharge()
end
function GameUIBank.ShowInfo(money)
	if money == nil then
		money = MyUserInfo.iMoney 
	end
	if GameUIBank.transform ~= nil then
		GameUIBank.LblMoney.text = FormatNumToYW(MoneyProportionStr(MyUserInfo.iMoney))
		GameUIBank.LblMoneyBank.text = FormatNumToYW(MoneyProportionStr(MyUserInfo.iBank))
	end
end

function GameUIBank.OnInpMoney()--取款输入框改变
	if onoutbtn then return end
	if GameUIBank.InpMoney.value == nil or GameUIBank.InpMoney.value == "" then
		GameUIBank.SldMoney.value = 0
		return
	end
	outputchange = true
	local iMoney = tonumber(tostring(MyUserInfo.iBank))
	local inmoney = ToCurrencyRateNumber(GameUIBank.InpMoney.value)
	if iMoney == nil then iMoney = 0 end
	if inmoney == nil then inmoney = 0 end
	if inmoney >= iMoney then
		GameUIBank.SldMoney.value = 1
	else
		local pressvalue = 0
		if iMoney > 0 then
			pressvalue = inmoney / iMoney
		end
		GameUIBank.SldMoney.value = pressvalue
	end
	outputchange = false
end
function GameUIBank.OnInpPwd()
	GameUIBank.passwordstr = GameUIBank.InpPwd.value
end
function GameUIBank.OnSldMoney()
	if outputchange then return end
	onoutbtn = true
	local inmoney = GameUIBank.SldMoney.value * tonumber(tostring(MyUserInfo.iBank))
	if GameUIBank.SldMoney.value < 1 then
		inmoney = GameUIBank.getIntPart(inmoney)
	else
		inmoney = MyUserInfo.iBank
	end
	GameUIBank.InpMoney.value = MoneyProportionStr(inmoney)
	onoutbtn = false
end

function GameUIBank.getIntPart(x)--取整
	if x <= 0 then
		return math.ceil(x)
	end
	if math.ceil(x) == x then
		x = math.ceil(x)
	else
		x = math.ceil(x) - 1
	end
	return x
end

function GameUIBank.OnBtnMax()
	GameUIBank.SldMoney.value = 1
end
function GameUIBank.OnBtnReset()
	GameUIBank.SldMoney.value = 0
	GameUIBank.InpMoney.value = MoneyProportionStr(0)
end

function GameUIBank.Show()
	GameUIBank.passwordstr = ""
	GameUIBank.InpPwd.value = ""
	GameUIBank.SldMoney.value = 0
	GameUIBank.InpMoney.value = "0"
	GameUIBank.transform.gameObject:SetActive(true)
	GameUIBank.transform.gameObject:GetComponent("Animation"):Play("Show")
end
function GameUIBank.OnBtnClose()
	GameUIBank.transform.gameObject:SetActive(false)
end
function GameUIBank.OnBtnConfirm()
	if GameUIBank.passwordstr == nil or GameUIBank.passwordstr =="" then
		LblMsgText.Show("请输入银行密码")
		return
	end
	GameUIBank.GetPutMoney()
end

function GameUIBank.GetPutMoney()
	local inmoney = ToCurrencyRateNumber(GameUIBank.InpMoney.value)
	local iMoney = tonumber(tostring(MyUserInfo.iBank))
	if inmoney == nil or inmoney <= 0 then
		LblMsgText.Show("请输入正确的取款数量")
		return
	end
	if iMoney < inmoney then
		LblMsgText.Show("银行金币不足")
		return
	end
	if GameUIBank.passwordstr ~= nil and GameUIBank.passwordstr ~= "" then
		GameUIBank.SendGetBankOutMoney()
	end
	GameUIBank.passwordstr = ""
	GameUIBank.InpPwd.value = ""
end
function GameUIBank.SendGetBankOutMoney()
	CMD_GR_C_BankOutMoney[1].data = ToCurrencyRateNumber(GameUIBank.InpMoney.value)
	CMD_GR_C_BankOutMoney[2].data = MyUserInfo.uiUserID
	CMD_GR_C_BankOutMoney[3].data = LuaInter.GetPassword(GameUIBank.passwordstr)
	local OutPutMoney = DataParseLua.StructToBytes(CMD_GR_C_BankOutMoney)
	NetManager:SendData(OutPutMoney,2000114,2)
end

function GameUIBank.OutPutMoneyReturn(data)--取款返回
	if data.headStruct.dwHandleCode == 0 then
		LblMsgText.Show("取款成功！")
		GameUIBank.OnReturnMoneyChange(data.mainMsg, false)
	else
		local erromsg = ErroCode(data.headStruct.dwHandleCode)
		if erromsg ~= nil and erromsg ~= "" then
			LblMsgText.Show(erromsg)
		else
			LblMsgText.Show("取款失败！")
		end
		GameUIBank.passwordstr = nil
	end
end
function GameUIBank.OnReturnMoneyChange(mainMsg)
	local InOutMoneyChange = DataParseLua.BytesToStruct(mainMsg, CMD_GR_S_BankOutMoney)
	if MyUserInfo.uiUserID ~= InOutMoneyChange.dwUserID then
		return
	end
	print("InOutMoneyChange.dwCheckOut : ", tostring(InOutMoneyChange.dwCheckOut))
	print("InOutMoneyChange.dwMoneyInRoom : ", tostring(InOutMoneyChange.dwMoneyInRoom))
	print("InOutMoneyChange.dwMoneyInBank : ", tostring(InOutMoneyChange.dwMoneyInBank))
	MyUserInfo.iMoney = InOutMoneyChange.dwMoneyInRoom
	MyUserInfo.iBank = InOutMoneyChange.dwMoneyInBank
	GameUIBank.ShowInfo()
	GameUIManager.UpDateSelfMoney()
	HallUIManager.Start()--重新刷新大厅信息UI
	GameUIBank.OnSldMoney()
end
return GameUIBank
