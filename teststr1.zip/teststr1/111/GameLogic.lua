local GameLogic =
{
	
}

function GameLogic.Awake()
	require "606.GameProtocal"
	GameDefine.AddEvent(GameDefine.Action_UserSit, GameLogic.Action_UserSit)--玩家坐下
	GameDefine.AddEvent(GameDefine.Action_UserLeft, GameLogic.Action_UserLeft)--玩家离开桌子
	GameDefine.AddEvent(GameDefine.Action_RefleshUserInfo, GameLogic.Action_RefleshUserInfo)--刷新用户经验值
	GameDefine.AddEvent(GameDefine.Action_NoMoneyTickRoom, GameLogic.Action_NoMoneyTickRoom)--游戏币不足，提出房间

	GameDefine.AddEvent(GameProtocal.GM_SUB_GAMESTATION, GameLogic.GameStation) --游戏状态 1001
	GameDefine.AddEvent(GameProtocal.GM_SUB_STATEUPDATE, GameLogic.GameStateUpdate) --游戏状态更新 1004
    GameDefine.AddEvent(GameProtocal.GM_SUB_KEYNOTE, GameLogic.GameKeyNote) --键盘下注 1007
	GameDefine.AddEvent(GameProtocal.GM_SUB_SETTLEMENT, GameLogic.GameSettlement) --即将结算 1012 
    GameDefine.AddEvent(GameProtocal.GM_SUB_NOTE, GameLogic.GameNote) --玩家下注 1006
	GameDefine.AddEvent(GameProtocal.GM_SUB_CONTINUEPRENOTE, GameLogic.GameContiuePreNote) --续押 1008
	GameDefine.AddEvent(GameProtocal.GM_SUB_NT_LIST, GameLogic.GameNtList) --庄家列表 1005
	GameDefine.AddEvent(GameProtocal.GM_SUB_CANCELCURNOTE, GameLogic.GameCancelCurNote) --取消之前的下注 1009
	GameDefine.AddEvent(GameProtocal.GM_SUB_NT_INFO, GameLogic.GameNtInfo) --庄家列表 1010
	GameDefine.AddEvent(GameProtocal.GM_SUB_PLAYER_NOTEINFO, GameLogic.GamePlayerNoteInfo) --所有用户下注信息 1011
	GameDefine.AddEvent(GameProtocal.GM_SUB_STATISTICS, GameLogic.GameStatitice) --统计（押注，概率） 1015

	GameDefine.AddEvent(GameProtocal.SUB_GM_POOLDATA_FRESH, GameLogic.PoolDataRefresh) --奖池刷新
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_DISTRIBUTE, GameLogic.PoolDataDistrubute) --奖池派发
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_CONFIG, GameLogic.PoolConfig) --奖池配置
	GameDefine.AddEvent(GameProtocal.SUB_GM_POOL_RECORD, GameLogic.PoolRecord) --奖池记录
    GameDefine.AddEvent(GameProtocal.SUB_GM_GAME_CONFIG, GameLogic.LimitNote) --限制下注
    print("----GameLogic.Awake---")
end

function GameLogic.Start()
	
end

function GameLogic.OnDestroy()
	GameDefine.Creal()
	package.loaded["606.GameProtocal"] = nil
end


function GameLogic.Action_UserSit(userInfo)
	print( "玩家坐下！！！！ 2222222222" )
	print("Action_UserSit  玩家坐下: ")
	if userInfo.uiUserID == MyUserInfo.uiUserID then
		NetManager:SendData(2000150,1) --获取用户的状态
		NetManager:SendData(2000180,1) --发送准备事件
		print("获取用户的状态 ")
	end
	GameUIManager.PlayerSit(userInfo)
end

function GameLogic.Action_NoMoneyTickRoom()
	if GameDefine.isplayback then return end
	UIRoom.QuitGame()
end

function GameLogic.Action_UserLeft(userInfo)
	print("Action_UserLeft  玩家离开: ", userInfo.uiUserID)
	GameUIManager.PlayerLeft(userInfo)
end

function GameLogic.Action_RefleshUserInfo(userInfo)
	-- print("--刷新用户经验值--")
	GameUIManager.RefleshUserInfo(userInfo)
end

function GameLogic.GameStation(data)--游戏状态
	UIRoom.LoadGameFinish()
	GameUIManager.GameStation(data)
end
function GameLogic.GameStateUpdate(data) --游戏状态更新 1004
	GameUIManager.GameStateUpdate(data)
end
function GameLogic.GameNote(data) --玩家下注 1006
	local data = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_NoteData)
	GameUIManager.GameNote(data)
end
function GameLogic.GameKeyNote(data) --键盘下注 1007

end
function GameLogic.GameContiuePreNote(data) --续押 1008
	local data = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_ContinuePreNote)
	print("----续押---")
	GameUIManager.GameContiuePreNote(data)
    --[[
    if data.cbErrorMask == 0 then
	else
    	if data.nDeskStation == MyUserInfo.iDeskStation then
    		if data.cbErrorMask == 1 then
                LblMsgText.Show("下注时间已经结束，无法续压")
    		elseif data.cbErrorMask == 2 then
                LblMsgText.Show("您本局已经押注，无法续压")
    		elseif data.cbErrorMask == 3 then
                LblMsgText.Show("您身上的钱不足，无法续压")
    		elseif data.cbErrorMask == 4 then
                LblMsgText.Show("您筹码索引有误，无法续压")
    		elseif data.cbErrorMask == 5 then
                LblMsgText.Show("您上局没有进行下注，无法续压")
    		end
    		GameUIManager.IsAuto = false
            GameUIManager.SetAutoStation(GameUIManager.IsAuto)
    	end
	end
	]]
end
function GameLogic.GameNtList(data) --庄家列表 1005
   	GameProtocal.CMD_GM_NtList[2].length = data.mainMsg[0]
    local iShangZhuangCount = data.mainMsg[0]
	local ntListData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_NtList)
    local shangZhuangStationArr = {}
    GameUIManager.ZhuangList = {}
    for i=1,iShangZhuangCount do
    	GameUIManager.ZhuangList[i] = ntListData.bStation[i-1]
    end
	print("庄家列表 ---1005",data.mainMsg[0])
    GameUIManager.RefreshZhuangInfo()
	print("庄家列表 ---1005",data.mainMsg[0])
end
function GameLogic.GameNtInfo(data) --庄家列表 1010
	local ntInfoData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_NtInfo)
	GameUIManager.GameNtInfo(ntInfoData)
end
function GameLogic.GameCancelCurNote(data) --取消之前的下注 1009
	local data = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_CancelCurrentNote)
	GameUIManager.GameCancelCurNote(data)
end
function GameLogic.GamePlayerNoteInfo(data) --所有用户下注信息 1011
	--local data = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_PlayerNoteInfo)
	--GameUIManager.GamePlayerNoteInfo(data)
end
function GameLogic.GameSettlement(data) --即将结算 1012
end
function GameLogic.GameStatitice(data) --统计（押注，概率） 1015 
	local statiticeData = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_GameStatistics)
	GameUIManager.GameStatitice(statiticeData)
end

function GameLogic.PoolDataRefresh(data)--奖池刷新
	print("奖池刷新=================2")
	GameUIManager.PoolDataRefresh(data)
end
function GameLogic.PoolDataDistrubute(data)--奖池派发
	-- local path = "E:/UnityTest/123.txt"
	-- LuaInter.SaveFile(path,data.mainMsg)
	-- print("写入成功")
	print("奖池派发=================3")
	GameUIManager.PoolDataDistrubute(data)
end
function GameLogic.PoolConfig(data)--奖池配置
	print("奖池配置=================4")
	GameUIManager.PoolConfig(data)
end
function GameLogic.PoolRecord(data)--奖池记录
	print("奖池记录=================5")
	GameUIManager.PoolRecord(data)
end
function GameLogic.LimitNote(data)--限制
	GameUIManager.LimitNote(data)
end

function GameLogic.FormatNumToKW(money)
    local iFu = 1
    local note = tonumber(money)
    if note < 0 then
        iFu = -1
        note = note * -1
    end
    local v = note
    local str = ""
    if v >= 10000 and v < 100000 then--
        str = string.format("%dW",(v / 10000))
    elseif v >= 100000 then 
        str = string.format("%dY",(v / 10000))
    else
        str = tostring(v)
    end
    if iFu < 0 then
        str = "-"..str
    end

    return str
end
return GameLogic