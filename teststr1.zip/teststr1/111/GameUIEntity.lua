local GameUIEntity = 
{
}
function GameUIEntity:new(trans, index)
	local newplayer = {transform = trans,UIiDesk = index}
	self.__index = self 
	setmetatable(newplayer, self)
	return newplayer
end

function GameUIEntity:InitUI()
	self.bgSprite = self.transform.gameObject:GetComponent("UISprite")
	--self.bgAnimation = self.transform.gameObject:GetComponent("UISpriteAnimation")
	self.bgAlpha = self.transform.gameObject:GetComponent("TweenAlpha")
	self.alphaAnimation = self.transform.gameObject:GetComponent("Animation")

	self.Active = false
	self.Count = 0
	self.ShanDuration = 0
	self.AnimaCoroutine = nil
end
function GameUIEntity:alphaReset(state)
	self.bgAlpha:ResetToBeginning()
	self.alphaAnimation.enabled = state
	--self.bgAnimation.enabled = state
	self.bgAlpha.enabled = state
end

function GameUIEntity:alphaReset1()
	self.bgAlpha:ResetToBeginning()
	self.alphaAnimation.enabled = true
	--self.bgAnimation.enabled = true
	self.bgAlpha.enabled = true
end
--显示但是不播放动画
function GameUIEntity:OnlyShowBG()
	self:Flash_Show(true)
	self:alphaReset(false)
end

--播放一次动画
function GameUIEntity:PlayOnce()
	self.alphaReset(true)
end

function GameUIEntity:PlayLoop()
	self:alphaReset(true)
	self.bgSprite.enabled = true
	self.bgAlpha.enabled = false
end

--显示还是隐藏
--如果显示，顺便播放一次动画
--如果隐藏，播放动画你也看不见
function GameUIEntity:Flash_Show(isShow)
	self:alphaReset(isShow)
	self.bgSprite.enabled = isShow
end
--播放闪动 count 闪动次数  -1时不停的闪动 -2时不闪动而是TweenAlpha消隐
function GameUIEntity:PlayIconBlink(count,time)
	if count == nil then
		count = -1 
	end
	if time == nil then
		time = 0.5
	end
    self.Count = count
    self.Active = true
	self.bgSprite.alpha = 1
	self.ShanDuration = time
	if self.AnimaCoroutine ~= nil then
		coroutine.stop(self.AnimaCoroutine)
		self.AnimaCoroutine = nil
	end
	self.bgSprite.enabled = true
	if count == -2 then
		self.AnimaCoroutine = coroutine.start(GameUIEntity.TweenIconAlpha,self,time)
	else
		self.AnimaCoroutine = coroutine.start(GameUIEntity.BlinkIcon,self,self.ShanDuration)
	end
end
function GameUIEntity.BlinkIcon(self,time)
	self.Count = self.Count - 1
	if self.Count == 0 then
		self:StopIconBlink()
		return
	end
    self.Active = not self.Active
    coroutine.wait(time)
	self.AnimaCoroutine = coroutine.start(GameUIEntity.BlinkIcon,self,self.ShanDuration)
end

--消隐
function GameUIEntity.TweenIconAlpha(self,time)
	coroutine.wait(time)
	local ap1 = TweenAlpha.Begin(self.bgSprite.gameObject, 0.5, 0)
	--ap1.method = UITweener.Method.EaseOut
end
function GameUIEntity:OnDestroy()
	if self.AnimaCoroutine ~= nil then
		coroutine.stop(self.AnimaCoroutine)
		self.AnimaCoroutine = nil
	end
end
--停止闪动
function GameUIEntity:StopIconBlink()
	self.bgSprite.alpha = 0
	if self.AnimaCoroutine ~= nil then
		coroutine.stop(self.AnimaCoroutine)
		self.AnimaCoroutine = nil
	end
end
return GameUIEntity