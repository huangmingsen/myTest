local GameBankerResult = 
{
	BtnClose,
	isShow = false,
	anim,
	LbBankerWin,
	LbBankerLose,
	LbBankerCountPlay,
	LbBankerCountMoney,
	lbDate,
	lbTime,
	BigWin,
}
function GameBankerResult.Awake()
	GameBankerResult.BtnConfirm = GameBankerResult.transform:FindChild("UI_Group/BtnClose").gameObject
	GameBankerResult.LbBankerWin = GameBankerResult.transform:FindChild("UI_Group/Label_Score").gameObject:GetComponent("UILabel")
	--GameBankerResult.LbBankerLose = GameBankerResult.transform:FindChild("UI_Group/Label_Lose").gameObject:GetComponent("UILabel")
	GameBankerResult.LbBankerCountPlay = GameBankerResult.transform:FindChild("UI_Group/Label_Ju").gameObject:GetComponent("UILabel")
	GameBankerResult.LbBankerCountMoney = GameBankerResult.transform:FindChild("UI_Group/Label_Coin").gameObject:GetComponent("UILabel")
	GameBankerResult.lbDate = GameBankerResult.transform:FindChild("UI_Group/Label_Date").gameObject:GetComponent("UILabel")
	GameBankerResult.lbTime = GameBankerResult.transform:FindChild("UI_Group/Label_Time").gameObject:GetComponent("UILabel")
	--GameBankerResult.BigWin = GameBankerResult.transform:FindChild("Big_Win").gameObject
	GameBankerResult.LbBankerWin.gameObject:SetActive(true)
	--GameBankerResult.LbBankerLose.gameObject:SetActive(true)
	UIEventListener.Get(GameBankerResult.BtnConfirm).onClick = GameBankerResult.Hide
	GameBankerResult.anim = GameBankerResult.transform.gameObject:GetComponent("Animation")

end
function GameBankerResult.Start()
	-- body
end
--总带入 局数 输赢
function GameBankerResult.Show(countMoney,countPlay,winLose)
    print("下庄结果:",GameUIManager.StationZhuang ,MyUserInfo.iDeskStation)
	if GameBankerResult.isShow then return end
	print("总带入 局数 输赢",countMoney,countPlay,winLose)
	GameBankerResult.transform.gameObject:SetActive(true)
	GameBankerResult.isShow = true
	GameBankerResult.LbBankerWin.text = FormatNumToYW(MoneyProportionStr(winLose))
	--GameBankerResult.LbBankerLose.text = winLose <= 0 and MoneyProportionStr(winLose) or ""
    --GameBankerResult.BigWin:SetActive(winLose > 0)
	if winLose > 0 then
    	--GameAudioContro.Play(GameAudioContro.bankerWin)
	else
    	--GameAudioContro.Play(GameAudioContro.bankerLose)
	end
	GameBankerResult.LbBankerCountMoney.text = FormatNumToYW(MoneyProportionStr(countMoney))
	GameBankerResult.LbBankerCountPlay.text = countPlay
    local nowDate = System.DateTime.Now.Year.."/"..System.DateTime.Now.Month.."/"..System.DateTime.Now.Day
	local nowTime = System.DateTime.Now.Hour..":"..System.DateTime.Now.Minute..":"..System.DateTime.Now.Second
	GameBankerResult.lbDate.text = nowDate
	GameBankerResult.lbTime.text = nowTime
	GameBankerResult.anim:Play("Show")
end
function GameBankerResult.Hide()
	if not GameBankerResult.isShow then return end
	GameBankerResult.isShow = false
    local time = 0
    if GameBankerResult.anim then
        local animClip = GameBankerResult.anim:GetClip("Hide")
        if animClip then
            GameBankerResult.anim.enabled = true
            GameBankerResult.anim:Play("Hide")
            time = animClip.length
        end
        coroutine.stop(GameBankerResult.yieldHide)
        coroutine.start(GameBankerResult.yieldHide,time)
    end
end
function GameBankerResult.yieldHide(time)
	coroutine.wait(time)
    GameBankerResult.transform.gameObject:SetActive(false)
end

function GameBankerResult.OnDestroy()
    coroutine.stop(GameBankerResult.yieldHide)
    package.loaded["606.GameBankerResult"] = nil
end
return GameBankerResult