local GameJiangChiPlayerInfo = 
{
}
function GameJiangChiPlayerInfo:new(trans)
	local _instance = 
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self 
	setmetatable(_instance, self)
	return _instance
end
function GameJiangChiPlayerInfo:InitUI()
    self.LbPlayerName = FindChildByName(self.transform, "Label_Name", "UILabel")
    self.LbPlayerMoney = FindChildByName(self.transform, "Label_Score", "UILabel")
    self.LbContent = FindChildByName(self.transform, "Label_Content", "UILabel")
    self.LbData = FindChildByName(self.transform, "Label_Time", "UILabel")
    self.IconHead = FindChildByName(self.transform, "IconHead_Box/Icon_Head", "UISprite")
end
function GameJiangChiPlayerInfo:SetInfo1(name, money)
    self.LbPlayerName.text = name
    self.LbPlayerMoney.text = ""..money
end
function GameJiangChiPlayerInfo:SetInfo2(jiangChiInfo)
    --GameJiangChiPlayerInfo:UpdateHead(jiangChiInfo[4])
    local HeadName = GetHeadSpriteName(jiangChiInfo[4])
	self.IconHead.spriteName = HeadName
    self.LbData.text = jiangChiInfo[3]
    local moneys = MoneyProportionStr(jiangChiInfo[1])
    self.LbContent.text = "玩家"..jiangChiInfo[2].."获得[ffec19] "..moneys.."金币[-]"
end
function GameJiangChiPlayerInfo:SetInfo3(poolPrizeInfo)
    --GameJiangChiPlayerInfo:UpdateHead(poolPrizeInfo[3])
    local HeadName = GetHeadSpriteName(poolPrizeInfo[3])
	self.IconHead.spriteName = HeadName
    self.LbPlayerName.text = poolPrizeInfo[1]
    self.LbPlayerMoney.text = MoneyProportionStr(poolPrizeInfo[2])
end

function GameJiangChiPlayerInfo:UpdateHead(headId, borderId)
	if self.ImHeadBorder ~= nil then
	    local HeadBorderName = GetHeadBorderById(borderId)
		self.ImHeadBorder.spriteName = HeadBorderName
		--self.ImHeadBorder:MakePixelPerfect()
	end
    local HeadName = GetHeadSpriteName(headId)
	self.IconHead.spriteName = HeadName
	--self.IconHead:MakePixelPerfect()
end
return GameJiangChiPlayerInfo