local GameTimeClock = 
{
	coroutineParent,
	Label_ClockTime,
	--时间到的事件
	OnTimeOut,
	--倒计时间
	ClockTime,
	IsAddZero,
	transform,
}
function GameTimeClock:new(trans)
	local newplayer = {transform = trans}
	self.__index = self 
	setmetatable(newplayer, self)
	return newplayer
end
function GameTimeClock:Init()
	GameTimeClock.Label_ClockTime = FindChildByName(self.transform, "Label_Time", "UILabel")
	GameTimeClock.transform = self.transform
end
--重置时间超时的事件为null
function GameTimeClock.ResetTimeOutEvent()
	GameTimeClock.OnTimeOut = nil
end

--开始计时
function GameTimeClock.StartClock(time,timeOutEvent,isHide,isAddZero)
	isHide = isHide or true
	isAddZero = isAddZero or false
	GameTimeClock.ClockTime = time
	GameTimeClock.IsAddZero = isAddZero
	if time > 0 then
		GameTimeClock.UpdateLabelClockTime()
	end
	GameTimeClock.StopClock()
	GameTimeClock.OnTimeOut = nil

	if timeOutEvent ~= nil then
		GameTimeClock.OnTimeOut = timeOutEvent
	end
	if time > 0 then
		GameTimeClock.transform.gameObject:SetActive(true)
		GameTimeClock.coroutineParent = coroutine.start(GameTimeClock.ReduceTime)
	else
		if isHide then
			GameTimeClock.transform.gameObject:SetActive(false)
		end
	end
end

--停止 倒计时
function GameTimeClock.StopClock()
	if GameTimeClock.coroutineParent ~= nil then
		coroutine.stop(GameTimeClock.coroutineParent)
		GameTimeClock.coroutineParent = nil
	end
end
--停止 并 隐藏 倒计时
function GameTimeClock.HideClock()
    GameTimeClock.StopClock()
	GameTimeClock.transform.gameObject:SetActive(false)
end
function GameTimeClock.ReduceTime()
	if GameTimeClock.Label_ClockTime~=nil then
		if GameTimeClock.IsAddZero then
			GameTimeClock.Label_ClockTime.text = string.format("%02d",GameTimeClock.ClockTime)
		else
			GameTimeClock.Label_ClockTime.text = tostring(GameTimeClock.ClockTime)
		end
	end
	if GameTimeClock.ClockTime <= 0 then
		GameTimeClock.SetTimeOver()
		if GameTimeClock.IsAddZero and GameTimeClock.ClockTime ==0 then
		end
		if GameTimeClock.OnTimeOut then
			GameTimeClock.OnTimeOut()
		end
		GameTimeClock.StopClock()
	else
		coroutine.wait(1)
		GameTimeClock.UpdateLabelClockTime()
		GameTimeClock.ClockTime = GameTimeClock.ClockTime-1
		GameTimeClock.coroutineParent = coroutine.start(GameTimeClock.ReduceTime)
	end
end

--设置时间已经结束
function GameTimeClock.SetTimeOver()
	GameTimeClock.Label_ClockTime.text = "00"
end

--获得倒计时 当前时间
function GameTimeClock.GetClockTime()
	return GameTimeClock.ClockTime
end
function GameTimeClock.UpdateLabelClockTime()
	if GameTimeClock.ClockTime <= 5 and GameTimeClock.ClockTime > 0 then --倒计时 后面5秒播放声音
		GameAudioContro.Play(GameAudioContro.countDown)
	end
end
function GameTimeClock.OnDestroy()
	GameTimeClock.StopClock()
	GameTimeClock.OnTimeOut = nil
end
return GameTimeClock