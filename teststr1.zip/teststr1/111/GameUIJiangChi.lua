local GameJiangChiPlayerInfo = require "606.GameJiangChiPlayerInfo"
local GameUIJiangChi = 
{
    BtnClose,
    Anim,
    LbPoints = {},
    LbJiangChiMoney,
    LbTopTip,

    ItemParent,
    Obj_Pos,-- 路单
    Obj_Iterm,-- 路单项
    listIterm = {}, -- 路单项
    listData = {}, -- 更新路单数据
    mViewPos, -- 视图位置   
}
function GameUIJiangChi.Awake()
    GameUIJiangChi.listIterm = {}
    GameUIJiangChi.listData = {}
    GameUIJiangChi.Anim = GameUIJiangChi.transform.gameObject:GetComponent("Animation")
    GameUIJiangChi.BtnClose = FindChildByName(GameUIJiangChi.transform, "Black_BoxCollider", "gameObject")
    UIEventListener.Get(GameUIJiangChi.BtnClose).onClick = GameUIJiangChi.OnPressClose
    for i=1,3 do
        GameUIJiangChi.LbPoints[i] = FindChildByName(GameUIJiangChi.transform, "UI_Group/PaiXing_Team/Label_"..tostring(i-1), "UILabel")
    end
    GameUIJiangChi.LbJiangChiMoney = FindChildByName(GameUIJiangChi.transform, "UI_Group/Label_JiangChi", "UILabel")
    GameUIJiangChi.LbTopTip = FindChildByName(GameUIJiangChi.transform, "UI_Group/Label_Tips", "UILabel")

    GameUIJiangChi.Obj_Pos = FindChildByName(GameUIJiangChi.transform, "UI_Group/Rank_Team/Rank_ScrollView", "gameObject")
    GameUIJiangChi.ItemParent = FindChildByName(GameUIJiangChi.transform, "UI_Group/Rank_Team/Rank_ScrollView/Grid", "gameObject")
    GameUIJiangChi.Obj_Iterm = FindChildByName(GameUIJiangChi.transform, "UI_Group/Rank_Team/Rank_ScrollView/Player_Item", "gameObject")
    GameUIJiangChi.mViewPos = GameUIJiangChi.Obj_Pos.transform.localPosition
    GameUIJiangChi.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameUIJiangChi.Obj_Pos.transform.localPosition.x, 0)
    GameUIJiangChi.transform.gameObject:SetActive(false)
end

function GameUIJiangChi.SetPlane(points,fetchPercent)
    if fetchPercent == 100 then
        GameUIJiangChi.LbTopTip.text = "同一类型场次中，系统全部金币计入彩池中,奖金系统随机抽取发放。"
    else
        GameUIJiangChi.LbTopTip.text = "同一类型场次中，系统部分金币计入彩池中,奖金系统随机抽取发放。"
    end
	for i=1, points.Length do
        if (i < #GameUIJiangChi.LbPoints) then
            GameUIJiangChi.LbPoints[i].text = tostring(points[3 - i]).."%";
        end
	end
end

function GameUIJiangChi.UpdateRecord()
    for i = 1,#GameUIJiangChi.listIterm do
        GameUIJiangChi.listIterm[i].transform.gameObject:SetActive(false)
    end
    for i=1,#GameUIJiangChi.listData do
        local uiRecordItem = GameUIJiangChi.GetItermObj(i)
        uiRecordItem:SetInfo2(GameUIJiangChi.listData[i])
    end
end
function GameUIJiangChi.GetItermObj(nIndex) 
	if ( nIndex <= #GameUIJiangChi.listIterm ) then
        GameUIJiangChi.listIterm[nIndex].gameObject:SetActive(true);
        GameUIJiangChi.listIterm[nIndex].gameObject.name = "iterm"..nIndex
		return GameUIJiangChi.listIterm[ nIndex ]
	end

    local Obj = UnityEngine.GameObject.Instantiate(GameUIJiangChi.Obj_Iterm)
	Obj.name = "iterm"..nIndex
	Obj:SetActive(true)

    Obj.transform.parent = GameUIJiangChi.ItemParent.transform
	Obj.transform.position = Vector3.zero
	Obj.transform.localScale = Vector3.one
    GameUIJiangChi.ItemParent:GetComponent("UIGrid"):Reposition()
	local iterm = GameJiangChiPlayerInfo:new(Obj.transform)
    iterm:InitUI()
	table.insert(GameUIJiangChi.listIterm,iterm)
	return iterm
end
function GameUIJiangChi.OnPressClose() 
    GameUIJiangChi.BtnClose:GetComponent("Collider").enabled = false
    GameUIJiangChi.HideUi()
end
function GameUIJiangChi.ShowUi(poolMoney)
    GameUIJiangChi.LbJiangChiMoney.text =MoneyProportionStr(poolMoney)
    GameUIJiangChi.BtnClose:GetComponent("Collider").enabled = true
    if (GameUIJiangChi.Anim) then
        local animClip = GameUIJiangChi.Anim:GetClip("JiangChi_Show")
        if (animClip) then
            GameUIJiangChi.Anim.enabled = true
            GameUIJiangChi.Anim:Play("JiangChi_Show")
        end
    end
    GameUIJiangChi.Obj_Pos.transform.localPosition = GameUIJiangChi.mViewPos 
    GameUIJiangChi.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameUIJiangChi.Obj_Pos.transform.localPosition.x, 0)
end
function GameUIJiangChi.UpdatePoolData(poolMoney)
    GameUIJiangChi.LbJiangChiMoney.text = MoneyProportionStr(poolMoney)
end

function GameUIJiangChi.UpdateUI(ListInfo)
    GameUIJiangChi.listData = {}
	for i = 1, #ListInfo do
		table.insert(GameUIJiangChi.listData,ListInfo[#ListInfo-i+1])
	end
    GameUIJiangChi.UpdateRecord()
    GameUIJiangChi.Obj_Pos.transform.localPosition = GameUIJiangChi.mViewPos 
    GameUIJiangChi.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameUIJiangChi.Obj_Pos.transform.localPosition.x, 0)
end
function GameUIJiangChi.HideUi()
    local itime = 0
    if (GameUIJiangChi.Anim) then
        local animClip = GameUIJiangChi.Anim:GetClip("JiangChi_Hide")
        if (animClip) then
            GameUIJiangChi.Anim.enabled = true;
            GameUIJiangChi.Anim:Play("JiangChi_Hide")
            itime = animClip.length;
        end
    end
    coroutine.start(GameUIJiangChi.yieldHide,itime)
end
function GameUIJiangChi.yieldHide(time)
    coroutine.wait(time)
    GameUIJiangChi.transform.gameObject:SetActive(false)
end
return GameUIJiangChi