local GameLogic = require "606.GameLogic"
local GameHelp = require "606.GameHelp"
-- local GameUIJiangChi = require "606.GameUIJiangChi"
-- local GameUIWinPool = require "606.GameUIWinPool"
local GameUIRecord = require "606.GameUIRecord"
local GameUIDetail = require "606.GameUIDetail"
local GameResult = require "606.GameResult"
local GameUIAnimation = require "606.GameUIAnimation"
local GameTimeClock = require "606.GameTimeClock"
local GameUIEntity = require "606.GameUIEntity"
local GameRecord = require "606.GameRecord"
local GameUIPlayerList = require "606.GameUIPlayerList"
local GameUIShangZhuangList = require "606.GameUIShangZhuangList"
local GameUIGoldManager = require "606.GameUIGoldManager"
local GameUIBank = require "606.GameUIBank"
local GameUISet = require "606.GameUISet"
local GameBankerResult = require "606.GameBankerResult"

GameUIManager = 
{
    FirstGroup,
    SecondGroup,

    Button_Menu,--菜单
    Button_Exit,
    Button_Set,
    Button_Help,
    Button_MainBank,
    Button_Bank,
    Button_Chat,--聊天
    IconRedDot,
    Button_Record,

    IconGameLevel,
    
    Lb_MyVip,
    UILb_MyMoney,--玩家身上的钱

    UILb_AllNoteMoney,--所有下注金额
    --UILb_LastWinLose,--上次输赢
    UILb_Base,--倍数
   
    BtnBets = {},-- 压分列表
    GoBetFocus,

    UIBtn_Continue,--续押按钮

    UIBtn_Auto,--自动
    UIBtn_CancelAuto,-- 取消自动 

    Obj_Bets = {},--下注组按钮

    UILb_MyBets = {},--自己下注
    UILb_MyBets_ZY = {},--玩家总押
    UILb_Bases = {},--倍率组

    Obj_TimeClock, --时钟
    TimeCountUITip,
    IconNum,
    FlashTimeRay,

    Obj_Flash = {}, --闪动画 
    WinRay = {},
    UIEntity = {},

    LeastMoneyZhuang = -1,
    LeastGamesZhuang = -1,
    PeviousZhuangStation = -1,
    StationZhuang = -1,

    mZhuangWinLose = 0,--庄输赢钱

    mWinLose = 0, --第一次开奖
    mSecondWinLose = 0, --第二次开奖

    mCaiJinPoint = 0, -- 彩金

    mCurPrizeIndex = 0, --当前开奖项
    mLastPrizeIndex = 0, --最后开奖项
    --要开奖的列表
    mListPrize = {},
    --已经开出的奖列表
    mLastIndex = {},

    playerCount = 255,
    mMaxWinMoneyStation = {},
    mMaxWinSouce = {},


    mMyBets = {},--自己下注 
    mTotalBets = {},--总下注

    mBase = { 2, 24, 24, 2, 4, 8, 8, 12, 12, 8, 8, 4 },--当前的倍率 
    mChips = {},--筹码列表
    viewIndex = { 1, 8, 8, 8, 9, 9, 9, 2, 10, 10, 10, 11, 11, 11, 1, 4, 4, 4, 5, 5, 5, 2, 6, 6, 6, 7, 7, 7 },

    mCheckIndex = 1,--下注下标
    isShowAllUI = false,

    m_PrizesCount = {},--概率统计
    m_CurGameCount = 0,--总下注
    GoGameBack,

    BetsName = {"FeiQin","Jinsha","Yinsha","Zoushou","Yan","Gezi","Kongque","Ying","Shizi","Xiongmao","Houzi","Tuzi"},
    --播放声音列表
    listAudio = {},
    --动物声
    AnimationAudio = 
    { 
        "/Audio/Game/OpenPrize_FeiQin", "/Audio/Game/Animation_JinYinSa",     "/Audio/Game/Animation_JinYinSa", "/Audio/Game/OpenPrize_ZouShou",
        "/Audio/Game/Animation_YanZi",  "/Audio/Game/Animation_GeZi",         "/Audio/Game/Animation_KongQue",  "/Audio/Game/Animation_LaoYin", 
        "/Audio/Game/Animation_ShiZi",  "/Audio/Game/Animation_XiongMao",     "/Audio/Game/Animation_HouZi",    "/Audio/Game/Animation_TuZi" 
    },

    --开奖声金沙银沙
    SoundOpenPrizeJinYin = "/Audio/Game/OpenPrize_JinYin",
    --开奖声飞禽走兽
    SoundOpenPrizeFeiZou = "/Audio/Game/OpenPrize_FeiZou",
    --人声
    PeopleAudio = 
    { 
        "/Audio/Game/People_FeiQin", "/Audio/Game/People_JinSa",    "/Audio/Game/People_YinSa",   "/Audio/Game/People_ZouShou", 
        "/Audio/Game/People_YanZi",  "/Audio/Game/People_GeZi",     "/Audio/Game/People_KongQue", "/Audio/Game/People_LaoYin", 
        "/Audio/Game/People_ShiZi",  "/Audio/Game/People_XiongMao", "/Audio/Game/People_HouZi",   "/Audio/Game/People_TuZi"
    },
    --金币音效
    GoldAudio = 
    {
        "/Audio/Game/Note", "/Audio/Game/coins"
    },
    mStation = 0,--游戏状态  

    mListRecord = {},--开奖记录

    AllPlayerInfoTag = {},

    IsHuanZhuang = false,

    --是否自动
    IsAuto = false,

    --记录本局开奖 记录
    CurrentPrize = {},
    --用来防止多次修改钱包的钱
    isLockZXZFlag = false,
    --用来解决进入游戏在开奖状态时，记录重复的问题，如为true则已经记录过这个结果了
    isReshowrecord = false,
    --是否隐藏loading
    IsHideLoading = false,

    BtnOnLine,
    TwpMenu,
    btnShangZhuang,
    btnXiaZhuang,
    LbWaitCount,
    LbZhuangName,
    LbZhuangMoney,
    LbZhuangVipLevel,
    LbOnLinePlayer,
    StartDownBet,
    StopDownBet,
    ZhuangList = {},

    uiShangZhuangList,

    IconOpenPrizeAnima,
    IconOpenPrizeTxt,
    IconOpenPrizeBet,
    TipGroup,

    LbUserName,
    IconUserZhuangOrXian,

    GoldItemParent,
    IconBetSprite,
    IconBetNum,
    playerList,
    goldManager,
    XianPos = Vector3.New(-592.2, -209.3, 0),
    ZhuangPos = Vector3.New(-52.3, 139.7, 0),
    MyMoneyPos = Vector3.New(-591.1, -329.4, 0),

    onLinePlayer = {},
    onLineUserList = {},

    GameState = 
    {
        GAMESTATE_NONE = 0, --闲置
        GAMESTATE_NOTE = 1,--下注
        GAMESTATE_OPENPRIZE = 2,--开奖
        GAMESTATE_SETTLEMENT = 3,--结算
        GAMESTATE_WAITNEXT = 4,--等待
        GAMESTATE_MAX = 5
    },
    ---------------------------
    GoWinPool,
    BtnJiangChi,
    jiangChiList = {},
    prizeList = {},
    ipoolMoney = 0,
    iTaxVlue = 0,
    LbJiangChi,  
    PrizeData = {},

    BtnRecharge,
    LbRecharge,
    GoRecharge,
    ----------------------------
    SeverTex = 0,

    KindAnimal =
    {
        --[Description( "飞禽" )]1
        "FeiQin",
        --[Description( "金鲨" )]2
        "JS",
        --[Description( "银鲨" )]3
        "YS",
        --[Description( "走兽" )]4
        "ZouShou",
        --[Description( "燕子" )]5
        "Yan",
        --[Description( "鸽子" )]6
        "Ge",
        --[Description( "孔雀" )]7
        "Kongque",
        --[Description( "老鹰" )]8
        "Ying",
        --[Description( "狮子" )]9
        "Lion",
        --[Description( "熊猫" )]10
        "Panda",
        --[Description( "猴子" )]11
        "Monkey",
        --[Description( "兔子" )]12
        "Rabit",
    },
    MainBtnRecharge,
    isFirstJionGame,

    CallBack = nil,

    CurDuration = 5,--时长
    BlinkCarIconTeam = {},
    Car_Team = {},
    Car_Ray = {},

    CurSpeed = 0,--当前速度
    MaxSpeed = 1.8,--最大速度
    MinSpeed = 0.06,--最小速度
    DownSpeedStep = 24,--减速的步数
    TotalStep = 0,--总步数
    CurStep = 0,--当前步数

    LastPrizeIndex = 0,--上次 开奖索引
    CurPrizeIndex = 0,--此次 开奖
    CarTeamCount = 0,--车标数量  
    Duration = 0,
    CurPerTime = 1000,
    Factor = 0.0,
    PrizeIndex = 0,

}
local ComCoroutine = nil
local ClockTimeCoroutine = nil
local a1 = 0.017
local a2 = 0.3
local a3 = 0.5
local Jisu = 0.016
local JiasuSpeed = 0.02

local tep = 5
local jiansuTep = 3
local iLowNoteLimit = 0 --最低限注
function GameUIManager.Awake()
    GameUIManager.FirstGroup = GameUIManager.transform:FindChild("UIRoot/UIGame/Main")
    GameUIManager.SecondGroup = GameUIManager.transform:FindChild("UIRoot/PanelSecond")

    GameUIManager.Button_Menu = GameUIManager.FirstGroup:FindChild("Game_Right/BtnMenu").gameObject:GetComponent("UIButton")
    GameUIManager.Button_Exit = GameUIManager.FirstGroup:FindChild("Game_Left/Button_Exit").gameObject
    GameUIManager.Button_Set = FindChildByName(GameUIManager.FirstGroup,"Menu/Button_Set","gameObject")
    GameUIManager.Button_Help = GameUIManager.FirstGroup:FindChild("Menu/Button_Help").gameObject
    GameUIManager.Button_Bank = GameUIManager.FirstGroup:FindChild("Menu/Button_Bank").gameObject
    GameUIManager.Button_MainBank = GameUIManager.FirstGroup:FindChild("Game_Down/Player_Team/Button_Bank").gameObject
    GameUIManager.Button_Chat = GameUIManager.FirstGroup:FindChild("Game_Right/BtnChat").gameObject
    GameUIManager.IconRedDot = GameUIManager.FirstGroup:FindChild("Game_Right/BtnChat/IconRedDot").gameObject
    GameUIManager.Button_Record = GameUIManager.FirstGroup:FindChild("Menu/Button_Record").gameObject
    GameUIManager.UILb_MyMoney = GameUIManager.FirstGroup:FindChild("Game_Down/Player_Team/LbMyGold").gameObject:GetComponent("UILabel")--玩家身上的钱
    GameUIManager.Lb_MyVip = GameUIManager.FirstGroup:FindChild("Game_Down/Player_Team/LbVip").gameObject:GetComponent("UILabel")


    GameUIManager.UILb_AllNoteMoney = FindChildByName(GameUIManager.FirstGroup,"Game_Center/UIBet/Label_CurrGameBet","UILabel")--所有下注金额
    GameUIManager.UILb_Base = GameUIManager.FirstGroup:FindChild("PanelAni/Label_Base").gameObject:GetComponent("UILabel")--倍数
   
    GameUIManager.BtnBets = {}-- 压分列表
    for i=1,6 do
        GameUIManager.BtnBets[i] = GameUIManager.FirstGroup:FindChild("Game_Down/CM_Group/Button_CM"..(i-1)).gameObject
    end
    GameUIManager.GoBetFocus = GameUIManager.FirstGroup:FindChild("Game_Down/CM_Group/Check_Ray").gameObject

    GameUIManager.UIBtn_Continue = GameUIManager.FirstGroup:FindChild("Game_Down/Button_XuTou").gameObject:GetComponent("UIButton")  --续押按钮

    GameUIManager.UIBtn_Auto = FindChildByName(GameUIManager.FirstGroup,"Game_Center/UIBet/Button_Auto","UIButton")--自动
    GameUIManager.UIBtn_CancelAuto = FindChildByName(GameUIManager.FirstGroup,"Game_Center/UIBet/Button_AutoCancel","UIButton")-- 取消自动 

    GameUIManager.Obj_Bets = {}--下注组按钮
    for i=1,12 do
        GameUIManager.Obj_Bets[i] = GameUIManager.FirstGroup:FindChild("Game_Center/UIBet/Button_"..GameUIManager.BetsName[i]).gameObject
        GameUIManager.WinRay[i] = GameUIManager.FirstGroup:FindChild("Game_Center/Win_Ray_Ani/"..GameUIManager.BetsName[i]).gameObject
        GameUIManager.FirstGroup:FindChild("Game_Center/UIBet/Button_"..GameUIManager.BetsName[i].."/BackGround").gameObject:GetComponent("UISprite").color = Color.New(1,1,1,0)
    end
    GameUIManager.UILb_MyBets = {}--自己下注
    GameUIManager.UILb_MyBets_ZY = {}--玩家总押
    GameUIManager.UILb_Bases = {}--倍率组  
    for i=1,#GameUIManager.Obj_Bets do
        GameUIManager.UILb_MyBets[i] = GameUIManager.Obj_Bets[i].transform:FindChild("Label_TZ_Me").gameObject:GetComponent("UILabel") 
        GameUIManager.UILb_MyBets_ZY[i] = GameUIManager.Obj_Bets[i].transform:FindChild("Label_TZ_Player").gameObject:GetComponent("UILabel") 
        GameUIManager.UILb_Bases[i] = GameUIManager.Obj_Bets[i].transform:FindChild("Label_TZ_Base").gameObject:GetComponent("UILabel") 
        GameUIManager.mMyBets[i] = 0
        GameUIManager.mTotalBets[i] = 0
    end
 
    GameUIManager.Obj_TimeClock = GameUIManager.FirstGroup:FindChild("Game_Center/Clock/Label_Time").gameObject:GetComponent("UILabel")
    GameUIManager.TimeCountUITip = GameUIManager.FirstGroup:FindChild("Time_Count").gameObject
    GameUIManager.IconNum = GameUIManager.FirstGroup:FindChild("Time_Count/Icon_Num1").gameObject:GetComponent("UISprite")
    GameUIManager.FlashTimeRay = GameUIManager.FirstGroup:FindChild("Time_Count/Flash_Time_Ray").gameObject:GetComponent("UISpriteAnimation")
    GameUIManager.Obj_Flash = {} --闪动画 
    for i=1,28 do
        local flashName = ""
        if i == 1 or i == 15 then
            flashName = "JS_"..string.format("%02d",i/15 + 1).."/FlashLight"
        elseif i == 8 or i == 22 then
            flashName = "YS_"..string.format("%02d",i/22 + 1).."/FlashLight"
        elseif i <=15 then
            flashName = "ZS_"..string.format("%02d",i - i/7).."/FlashLight"
        else
            if i == 21 then
                flashName = "FQ_"..string.format("%02d",7).."/FlashLight"
            elseif i == 28 then
                flashName = "FQ_"..string.format("%02d",1).."/FlashLight"
            else
                flashName = "FQ_"..string.format("%02d",12 - (i - i/7 -12) + 2).."/FlashLight"
            end
        end
        GameUIManager.Obj_Flash[i] = GameUIManager.FirstGroup:FindChild("Middle_Team/"..flashName).gameObject
        GameUIManager.UIEntity[i] = GameUIEntity:new(GameUIManager.Obj_Flash[i],i)
        GameUIManager.UIEntity[i]:InitUI()
    end
    GameUIManager.CarTeamCount = #GameUIManager.UIEntity
    GameUIManager.m_PrizesCount = {}
    for i=1,12 do
        GameUIManager.m_PrizesCount[i] = 0
    end
    GameUIAnimation.transform = GameUIManager.FirstGroup:FindChild("PanelAni")
    GameUIAnimation.Awake()

    GameUIManager.BtnOnLine = GameUIManager.FirstGroup:FindChild("Game_Left/BtnOnLine").gameObject:GetComponent("UIButton")
    GameUIManager.TwpMenu = GameUIManager.FirstGroup:FindChild("Menu").gameObject:GetComponent("TweenPosition")

    -- GameUIManager.btnShangZhuang = GameUIManager.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/Button_ShangZhuang").gameObject:GetComponent("UIButton")
    -- GameUIManager.btnXiaZhuang = GameUIManager.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/Button_XiaZhuang").gameObject:GetComponent("UIButton")
    -- GameUIManager.LbWaitCount = GameUIManager.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/Label_PaiDui").gameObject:GetComponent("UILabel")
    -- GameUIManager.LbZhuangName = GameUIManager.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/LbZhuangName").gameObject:GetComponent("UILabel")
    -- GameUIManager.LbZhuangMoney = GameUIManager.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/LbZhuangGold").gameObject:GetComponent("UILabel")
    -- GameUIManager.LbZhuangVipLevel = GameUIManager.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/LbVip").gameObject:GetComponent("UILabel")
    
    GameUIManager.LbOnLinePlayer = GameUIManager.FirstGroup:FindChild("Game_Left/BtnOnLine/Label_Player").gameObject:GetComponent("UILabel")
    GameUIManager.StartDownBet = FindChildByName(GameUIManager.FirstGroup,"Game_Center/Animal_Team/BlackBox_1","gameObject")
    GameUIManager.StopDownBet = FindChildByName(GameUIManager.FirstGroup,"BlackBox_0","gameObject")

    GameUIPlayerList.transform = GameUIManager.SecondGroup:FindChild("Player_List")
    GameUIPlayerList.Awake()
    GameUIShangZhuangList.transform = GameUIManager.SecondGroup:FindChild("Zhuang_List")
    GameUIShangZhuangList.Awake()

    GameUIManager.IconOpenPrizeAnima = GameUIManager.FirstGroup:FindChild("KaiJiang_Ani/Icon_Target").gameObject:GetComponent("UISprite")
    GameUIManager.IconOpenPrizeTxt = GameUIManager.FirstGroup:FindChild("KaiJiang_Ani/Font_GameIcon_Target").gameObject:GetComponent("UISprite")
    GameUIManager.IconOpenPrizeBet = GameUIManager.FirstGroup:FindChild("KaiJiang_Ani/Label_BeiLv").gameObject:GetComponent("UILabel")
    GameUIManager.TipGroup = {}
    GameUIManager.TipGroup[1] = GameUIManager.FirstGroup:FindChild("Tips_Group/Tips_Wait").gameObject
    GameUIManager.TipGroup[2] = GameUIManager.FirstGroup:FindChild("Tips_Group/Tips_Start").gameObject
    GameUIManager.TipGroup[3] = GameUIManager.FirstGroup:FindChild("Tips_Group/Tips_Stop").gameObject
    GameUIManager.TipGroup[4] = GameUIManager.FirstGroup:FindChild("Tips_Group/Tips_3").gameObject
    GameUIManager.TipGroup[5] = GameUIManager.FirstGroup:FindChild("Tips_Group/Tips_1").gameObject
    GameUIManager.TipGroup[6] = GameUIManager.FirstGroup:FindChild("Tips_Group/Tips_2").gameObject

    GameUIManager.LbUserName = GameUIManager.FirstGroup:FindChild("Game_Down/Player_Team/LbMyName").gameObject:GetComponent("UILabel")
    GameUIManager.IconUserZhuangOrXian = FindChildByName(GameUIManager.FirstGroup,"Game_Down/Player_Team/Label_MyName/Icon_Sign","UISprite")

    GameUIManager.GoldItemParent = GameUIManager.FirstGroup:FindChild("GoldParent").gameObject
    GameUIManager.IconBetSprite = GameUIManager.FirstGroup:FindChild("GoldParent/Background").gameObject:GetComponent("UISprite")
    GameUIManager.IconBetNum = GameUIManager.FirstGroup:FindChild("GoldParent/IconNum").gameObject:GetComponent("UISprite")
    GameUIManager.GoGameBack = GameUIManager.transform:FindChild("UIRoot/UIGame/UIStretch/Group/GameBG" ).gameObject

    GameUIManager.IconGameLevel = GameUIManager.FirstGroup:FindChild("Game_Left/Icon_Level_Target").gameObject:GetComponent("UISprite")
    GameUIManager.IconGameLevel.spriteName = "Txt_ChangCi"..CommonBase.iRoomLevel+1

    GameHelp.transform = GameUIManager.SecondGroup:FindChild("UIHelp")
    GameHelp.Awake()
    GameUIBank.transform = GameUIManager.SecondGroup:FindChild("GameBank")
    GameUIBank.Awake()
    GameUISet.transform = FindChildByName(GameUIManager.FirstGroup,"Menu")
    GameUISet.Awake()
    GameResult.transform = GameUIManager.SecondGroup:FindChild("UIJiesuan")
    GameResult.Awake()
    GameRecord.transform = GameUIManager.FirstGroup:FindChild("Game_Right/LZ Scroll View")
    GameRecord.Awake()
    GameUIGoldManager.transform = GameUIManager.FirstGroup:FindChild("GoldParent")
    GameUIGoldManager.Awake()
    GameUIGoldManager.transform.gameObject:SetActive(false)

    GameUIRecord.transform = GameUIManager.SecondGroup:FindChild("GameUIRecord")
    GameUIRecord.Awake()
    GameUIDetail.transform = GameUIManager.SecondGroup:FindChild("GameUIDetail")
    GameUIDetail.Awake()
    GameBankerResult.transform = FindChildByName(GameUIManager.SecondGroup,"UIJiesuan_Zhuang")
    if GameBankerResult.transform then
        GameBankerResult.Awake()
    end

    GameUIManager.BtnRecharge = FindChildByName(GameUIManager.FirstGroup, "CZ_Tips/BtnRecharge","gameObject")
    GameUIManager.LbRecharge = FindChildByName(GameUIManager.FirstGroup, "CZ_Tips/Label_Tips","UILabel")
    GameUIManager.GoRecharge = FindChildByName(GameUIManager.FirstGroup, "CZ_Tips","gameObject")

    --GameUIManager.BtnJiangChi = GameUIManager.FirstGroup:FindChild("Game_Center/BtnJiangChi").gameObject
    -- GameUIManager.LbJiangChi = GameUIManager.FirstGroup:FindChild("Game_Center/BtnJiangChi/Label_Coin").gameObject:GetComponent("UILabel")

    -- GameUIJiangChi.transform = GameUIManager.SecondGroup:FindChild("Game_JiangChi")
    -- GameUIManager.GoWinPool = GameUIManager.SecondGroup:FindChild("Game_JiangChi_Win").gameObject
    -- GameUIJiangChi.Awake()
    -- GameUIManager.GoWinPool.gameObject:SetActive(false)
    GameUIManager.MainBtnRecharge = FindChildByName(GameUIManager.FirstGroup, "Game_Left/Button_Recharge","gameObject")
    GameLogic.Awake()

    GameUIManager.isFirstJionGame = true
end
function GameUIManager.Start()
    for i=1,6 do
        GameUIManager.mChips[i] = 0
    end
    GameUIManager.UpdateBetInfo(GameUIManager.mChips)

    GameUIManager.InitEvent()
    --闪动画
    for i=1,#GameUIManager.Obj_Flash do
        GameUIManager.Obj_Flash[i]:SetActive(false)
    end
    --倍率
    GameUIManager.UILb_Base.gameObject:SetActive(false)
    GameUIManager.LbUserName.text = ""..MyUserInfo.szNickName
    GameUIManager.UpDatePlayerInfo()--在线列表
    --更新倍率
    GameUIManager.RefreshBase()

    --重新更新一下
    GameUIManager.RefreshUserInfo(0)

    --GameUIManager.UpdateStatusAudio()

    GameUIManager.ShowOrHideWinAnim(false)

    GameLogic.Start()
    GameHelp.Start()
    print("--资源初始化完成，开始接收消息--")
    UIRoom.StartListenData()--资源初始化完成，开始接收消息
    print("--资源初始化完成，开始接收消息--")
    UpdateBeat:Add(GameUIManager.UpData)
end
function GameUIManager.PlayerSit(userInfo)--玩家坐下
    GameUIManager.AddUserAttri(userInfo)
    if userInfo.uiUserID == MyUserInfo.uiUserID then
        GameUIManager.UpdateUserLV(userInfo.iVipLevel)
    end
end
function GameUIManager.PlayerLeft(userInfo)--玩家离开
    GameUIManager.RemoveNotOnLinePlayer(userInfo.uiUserID)
end
function GameUIManager.RefleshUserInfo(userInfo)
    if userInfo.uiUserID == MyUserInfo.uiUserID then
        GameUIManager.SetUpdateWallet(userInfo.iMoney)
        GameUIManager.UpdateUserLV(userInfo.iVipLevel)
        GameUIBank.ShowInfo()
    else

    end
    if GameUIManager.StationZhuang ~= -1 and GameUIManager.StationZhuang ~= 255 then
        if GameUIManager.StationZhuang == userInfo.iDeskStation then
            GameUIManager.UpdateBankerLV(userInfo.iVipLevel)
        end
    end
    GameUIManager.AddUserAttri(userInfo)
    GameUIShangZhuangList.SetShangZhuanglistInfo(GameUIManager.LeastMoneyZhuang,GameUIManager.ZhuangList)
end
--玩家更新
function GameUIManager.UpDateSelfMoney()
    GameUIManager.SetUpdateWallet(MyUserInfo.iMoney)
end
function GameUIManager.SetUpdateWallet(money)
    GameUIManager.UILb_MyMoney.text = FormatNumToYW(MoneyProportionStr(money))
end
function GameUIManager.UpdateUserLV(lv)
    GameUIManager.Lb_MyVip.text = ""..lv
end 
function GameUIManager.UpdateBankerLV(lv)
    -- GameUIManager.LbZhuangVipLevel.text = ""..lv
end 
function GameUIManager.UpDatePlayerInfo()
    local playerList = GameSUserBaseInfo.userinfolist
    local robotList = {}
    local liveList = {}
    GameUIManager.onLineUserList = {}
    print("--玩家坐下---",MyUserInfo.uiUserID)
    if #GameUIManager.onLineUserList == 0 then
        local info = {}
        info.UserId = MyUserInfo.uiUserID
        info.UserMoney = MyUserInfo.iMoney
        info.UserName = MyUserInfo.szNickName
        info.UserImageNO = MyUserInfo.iImageNO
        info.iPhotoFrame = MyUserInfo.iPhotoFrame
        info.iVipLevel = MyUserInfo.iVipLevel
        table.insert(GameUIManager.onLineUserList,info) 
    end 
    for i = 1, #playerList do 
        if playerList[i].uiUserID ~= MyUserInfo.uiUserID then
            local info = {}
            info.UserId = playerList[i].uiUserID
            info.UserMoney = playerList[i].iMoney
            info.UserName = playerList[i].szNickName
            info.UserImageNO = playerList[i].iImageNO
            info.iPhotoFrame = playerList[i].iPhotoFrame
            info.iVipLevel = playerList[i].iVipLevel
            table.insert(GameUIManager.onLineUserList,info)
        end
    end
    GameUIManager.LbOnLinePlayer.text = ""..#GameUIManager.onLineUserList
end
function GameUIManager.AddUserAttri(userInfo)
    if GameUIManager.IsInTable(GameUIManager.onLineUserList,userInfo.uiUserID) then
        for i=1,#GameUIManager.onLineUserList do
            if GameUIManager.onLineUserList[i].UserId == userInfo.uiUserID then
                GameUIManager.onLineUserList[i].UserMoney = userInfo.iMoney
                GameUIManager.onLineUserList[i].UserName = userInfo.szNickName
                GameUIManager.onLineUserList[i].UserImageNO = userInfo.iImageNO
                GameUIManager.onLineUserList[i].iPhotoFrame = userInfo.iPhotoFrame
                GameUIManager.onLineUserList[i].iVipLevel = userInfo.iVipLevel
            end
        end
    else
        local info = {}
        info.UserId = userInfo.uiUserID
        info.UserMoney = userInfo.iMoney
        info.UserName = userInfo.szNickName
        info.UserImageNO = userInfo.iImageNO
        info.iPhotoFrame = userInfo.iPhotoFrame
        info.iVipLevel = userInfo.iVipLevel
        table.insert(GameUIManager.onLineUserList,info)   
    end
    GameUIManager.LbOnLinePlayer.text = ""..#GameUIManager.onLineUserList
    GameUIPlayerList.ReSetData(GameUIManager.onLineUserList)
end
function GameUIManager.RemoveNotOnLinePlayer(userId)
    if GameUIManager.IsInTable(GameUIManager.onLineUserList,userId) then
        for i=1,#GameUIManager.onLineUserList do
            -- print("@@@@@@ 玩家信息:")
            -- pt(GameUIManager.onLineUserList[i])
            if(GameUIManager.onLineUserList[i]~=nil and GameUIManager.onLineUserList[i].UserId == userId) then
                table.remove(GameUIManager.onLineUserList,i)
            end
        end
    end
    GameUIManager.LbOnLinePlayer.text = ""..#GameUIManager.onLineUserList
    GameUIPlayerList.ReSetData(GameUIManager.onLineUserList)
end
function GameUIManager.WaitShowGold()
    coroutine.wait(0.6)
    GameUIGoldManager.transform.gameObject:SetActive(true)
end
function GameUIManager.GameStation(data)--游戏状态  断线重连 1001
    if GameUIManager.isFirstJionGame then
        GameUIManager.FirstGroup.gameObject:GetComponent("Animation"):Play("Game_Join")
        coroutine.stop(GameUIManager.WaitShowGold)
        coroutine.start(GameUIManager.WaitShowGold)
    end
    GameUIManager.isFirstJionGame = false

    --游戏状态
    local state = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_Station_Head)

    GameUIManager.LeastMoneyZhuang = state.iNtLeastMoney
    GameUIManager.LeastGamesZhuang = state.NtLeastGames
    GameUIManager.PeviousZhuangStation = state.iNtStation
    GameUIManager.StationZhuang = state.iNtStation
    -- GameUIManager.RefreshZhuangInfo()
    GameUIManager.mStation = state.bStation
    GameUIGoldManager.HideAllGoldList()
    GameUIManager.ShowOrHideWinAnim(false)
    GameUIManager.StopClockTime()
    GameBankerResult.Hide()
    if GameResult.transform.gameObject then
        GameResult.Hide()
    end
    GameUIManager.EnabledBtn(false)
    GameUIManager.ShowStateTip(GameUIManager.mStation)
    print(state.bStation,"**************GameStation")
    if GameUIManager.mStation == GameUIManager.GameState.GAMESTATE_NOTE then
        local msg = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_Station_Note)
        --region 断线重连 下注
        GameUIAnimation.StopAnimation()
        GameUIManager.InitData(msg)
        for i=1,#GameUIManager.mTotalBets do
            GameUIManager.SetExistGoldPos(GameUIManager.mTotalBets[i], i-1)
        end
        --开始计时
        GameUIManager.StartClock(getIntPart(msg.iLeftTick / 1000),true)
        GameUIManager.isShowAllUI = true
        --显示下注界面 并启用下注按钮
        GameUIManager.StartOrStopDownBetBG(true)
        GameUIManager.EnabledBtn(true)

    --开奖
    elseif GameUIManager.mStation == GameUIManager.GameState.GAMESTATE_OPENPRIZE then
        --断线重连 开奖
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_OpenPrize)
        --#region 断线重连 开奖
        GameUIManager.InitData(msg)

        for i=1,#GameUIManager.mTotalBets do
            GameUIManager.SetExistGoldPos(GameUIManager.mTotalBets[i], i-1)
        end
        GameUIManager.mZhuangWinLose = msg.iBankerWinMoney
        GameUIManager.playerCount = msg.RankingCount
        for i=1,msg.RankingStation.Length do
            GameUIManager.mMaxWinMoneyStation[i] = msg.RankingStation[i-1]
        end
        for i=1,msg.RankingMoney.Length do
            GameUIManager.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end      

        GameUIManager.isReshowrecord = true
        --添加记录项
        GameUIManager.InsertRecordIterm(GameUIManager.View2BetIndex(msg.PrePrizeIndex))
        --上一局开的奖
        GameUIManager.mLastPrizeIndex = msg.PrePrizeIndex
        table.insert(GameUIManager.mLastIndex,GameUIManager.mLastPrizeIndex)
        --最后赢钱
        GameUIManager.mWinLose = msg.iWinLose
        ComCoroutine = coroutine.start(GameUIManager.WaitOpenPrize,msg.mSpecialPrize, msg.PrePrizeIndex, msg.iWinLose, msg.iLeftTick / 1000.0)
        GameUIManager.StartClock(getIntPart(msg.iLeftTick / 1000),false)
    --结算
    elseif GameUIManager.mStation == GameUIManager.GameState.GAMESTATE_SETTLEMENT then
        --断线重连 结算
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Settlement)
        GameUIManager.InitData(msg)
        GameUIManager.playerCount = msg.RankingCount
        for i=1,msg.RankingStation.Length do
            GameUIManager.mMaxWinMoneyStation[i] = msg.RankingStation[i-1]
        end
        for i=1,msg.RankingMoney.Length do
            GameUIManager.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end
        GameUIManager.mZhuangWinLose = msg.iBankerWinMoney

        --上一局开的奖
        GameUIManager.mLastPrizeIndex = msg.PrePrizeIndex
        table.insert(GameUIManager.mLastIndex,GameUIManager.mLastPrizeIndex)

        --非金鲨，修改图片
        GameUIManager.Obj_Flash[GameUIManager.mLastPrizeIndex+1]:SetActive(true)
        --不消隐
        local alpha = GameUIManager.Obj_Flash[GameUIManager.mLastPrizeIndex+1]:GetComponent("TweenAlpha")
        alpha.enabled = false

        GameUIManager.mWinLose = msg.iWinLose
        local animaIndex = GameUIManager.View2BetIndex(GameUIManager.mLastPrizeIndex)

        local animaName = GameUIManager.GetAnimalNameByIndex(animaIndex)
        if GameUIManager.StationZhuang ~= -1 and GameUIManager.StationZhuang ~= 255 then
            if GameResult.transform.gameObject then
                if msg.mSpecialPrize == 255 then
                    GameResult.Show(GameUIManager.mWinLose, GameUIManager.mZhuangWinLose, GameUIManager.StationZhuang, GameUIManager.mMaxWinMoneyStation, GameUIManager.mMaxWinSouce, GameUIManager.playerCount,animaName)
                else
                    GameResult.Show(GameUIManager.mWinLose, GameUIManager.mZhuangWinLose, GameUIManager.StationZhuang, GameUIManager.mMaxWinMoneyStation, GameUIManager.mMaxWinSouce, GameUIManager.playerCount,animaName)
                end
            end
        end
        GameUIManager.StartClock(getIntPart(msg.iLeftTick / 1000),false)
    --下一局
    elseif 0 < data.mainMsg.Length then
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Wait)
        --断线重连 下一局
        --倍率
        print("---------------")
        for i = 1,#GameUIManager.mBase do
            GameUIManager.mBase[i] = msg.iNotePoint[i-1]
        end
        --筹码
        for i = 1,msg.iCanSelectNotes.Length do
            GameUIManager.mChips[i] = msg.iCanSelectNotes[i-1]
        end
        print("---------------")
        for i = 1,12 do
            GameUIManager.mMyBets[i] = 0 --每个下注区域的下注额度
            GameUIManager.mTotalBets[i] = 0 --每个下注区域的下注额度
        end
        print("---------------")
        --关闭下注界面，并禁用功能操作按钮
        if GameUIManager.IsShowBetUi then
            GameUIManager.HideUiBet()
        end
        GameResult.Hide()
    end
    GameUIManager.UpdateBetInfo(GameUIManager.mChips)
    GameUIManager.RefreshBase()
    GameUIManager.RefreshUserInfo()
    GameUIManager.ChooseBetIndex()--匹配筹码
    print("-------断线重连------Over")
end
function GameUIManager.InitData(msg)
    --倍率
    for i=1,#GameUIManager.mBase do
        GameUIManager.mBase[i] = msg.iNotePoint[i-1]
    end
    --筹码
    for i=1,msg.iCanSelectNotes.Length do
        GameUIManager.mChips[i] = msg.iCanSelectNotes[i-1]
    end
    --更新下注
    for i=1,12 do
        GameUIManager.mMyBets[i] = msg.SelfAreaNotes[i-1]--每个下注区域的下注额度
        GameUIManager.mTotalBets[i] = msg.AreaNotes[i-1]
    end
    --路单
    GameUIManager.mListRecord = {}
    local data = 255
    local nBegin = (msg.mCurRecordIndex + 1) % msg.mRecordData.Length
    if msg.mCurRecordIndex < 0 then
        --现在修改得有时候会死
        msg.mCurRecordIndex = msg.mRecordData.Length - 1
    end
    while nBegin ~= msg.mCurRecordIndex do
        data = msg.mRecordData[nBegin]
        if 255 ~= data then
            table.insert(GameUIManager.mListRecord,GameUIManager.View2BetIndex(data))
        end
        nBegin = (nBegin + 1)%msg.mRecordData.Length
    end
    --最后一个
    data = msg.mRecordData[msg.mCurRecordIndex]
    if 255 ~= data then
        table.insert(GameUIManager.mListRecord,GameUIManager.View2BetIndex(data))
    end
    GameRecord.ReSet(GameUIManager.mListRecord)
end
function GameUIManager.GameStateUpdate(data) --游戏状态更新 1004
    --游戏状态
    local state = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_StateUpdate)
    GameUIManager.mStation = state.iState
    GameUIManager.ShowStateTip(GameUIManager.mStation)
    if GameUIManager.mStation == GameUIManager.GameState.GAMESTATE_NOTE then --游戏状态更新
        GameUIManager.ShowOrHideWinAnim(false)
        local msg = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_StateUpdate_Note)
        --#region 下注
        if GameResult.transform.gameObject then
            GameResult.Hide()
        end
        GameBankerResult.Hide()
        GameUIGoldManager.HideAllGoldList()--隐藏所有注码
        GameUIManager.isLockZXZFlag = false
        --用这个来刷新下当前金币，防止金币与服务器不同步
        NetManager:SendData(2000180, GameProtocal.GM_SUB_CANCELCURNOTE)
        GameUIManager.ChooseBetIndex()--匹配筹码
        GameUIAnimation.StopAnimation()

        --停止所有的动画
        GameUIManager.StopAnimalAnimation()

        GameUIAnimation.StopAnimation()
        GameUIManager.isShowAllUI = true
        --[[
        if not GameAudioContro.bgaudiosource.isPlaying then
            GameAudioContro.bgaudiosource:Play()
        end
        ]]
        if GameAudioContro.SoundEffect.isPlaying then
            GameAudioContro.SoundEffect:Stop()
        end
        --region 新的一局开始了，把正在播背景动画的停止并显示
        local entity
        if #GameUIManager.CurrentPrize ~= 0 then
            entity = GameUIManager.UIEntity[GameUIManager.CurrentPrize[#GameUIManager.CurrentPrize]+1]
            entity:OnlyShowBG()
            if #GameUIManager.CurrentPrize > 1 then
                entity = GameUIManager.UIEntity[GameUIManager.CurrentPrize[#GameUIManager.CurrentPrize-1]+1]
                entity:Flash_Show(false)
            end
        end
        --倍率
        for i = 1,#GameUIManager.mBase do
            GameUIManager.mBase[i] = msg.BasePoint[i-1]
        end
        GameUIManager.RefreshBase()
        --路单
        if #GameUIManager.mListRecord <= 0 then
            local data = 255
            local nBegin = ( msg.mCurRecord + 1 ) % msg.RecordData.Length
            if msg.mCurRecord < 0 then
                --现在修改得有时候会死
                msg.mCurRecord = msg.mCurRecord.Length - 1
            end
            while nBegin ~= msg.mCurRecord do
                data = msg.RecordData[nBegin]
                if 255 ~= data then
                    table.insert(GameUIManager.mListRecord,GameUIManager.View2BetIndex(data))
                end
                nBegin = (nBegin + 1)%msg.RecordData.Length
            end
            --最后一个
            data = msg.RecordData[msg.mCurRecord]
            if 255 ~= data then
                table.insert(GameUIManager.mListRecord,GameUIManager.View2BetIndex(data))
            end
            GameRecord.ReSet(GameUIManager.mListRecord)
        end
        --开始计时
        GameUIManager.StartClock(getIntPart(msg.Tick / 1000),true)
        --更新下注
        for i = 1,#GameUIManager.mMyBets do
            GameUIManager.mMyBets[i] = 0 --每个下注区域的下注额度
        end
        for i = 1,#GameUIManager.mTotalBets do
            GameUIManager.mTotalBets[i] = 0 --每个下注区域的下注额度
        end
        GameUIManager.PeviousZhuangStation = GameUIManager.StationZhuang
        GameUIManager.RefreshUserInfo(0)
        --上一局收益
        GameUIManager.mWinLose = 0
        GameUIManager.mSecondWinLose = 0                      --第二次开奖

        GameUIManager.mCaiJinPoint = 0
        if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
            GameUIManager.ShowRecharge()
            GameUIManager.IsAuto = false
            GameUIManager.SetAutoStation(GameUIManager.IsAuto)
        else
            GameUIManager.HideRecharge()
        end
        --自动下注
        GameUIManager.StartOrStopDownBetBG(true)
        GameUIManager.EnabledBtn( true )
        if not GameUIManager.IsAuto or GameUIManager.mStation ~= GameUIManager.GameState.GAMESTATE_NOTE then
            print(state.iState,"**************GameStation      Over")
            return
        end
        --显示下注界面 并启用下注按钮
        NetManager:SendData(2000180, GameProtocal.GM_SUB_CONTINUEPRENOTE)
        --所有按钮都停止
        for n=1,#GameUIManager.Obj_Flash do
            --[[
            if UnityEngine.WrapMode.Once ~= GameUIManager.Obj_Flash[n]:GetComponent("Animation").wrapMode then
                GameUIManager.Obj_Flash[n]:GetComponent("Animation").wrapMode = UnityEngine.WrapMode.Once
            end
            ]]
        end
        print("-----更新下注----",#GameUIManager.mMyBets)
    elseif GameUIManager.mStation == GameUIManager.GameState.GAMESTATE_OPENPRIZE then --开奖
        local msg = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_StateUpdate_OpenPrize)
        --上一局收益
        GameUIManager.mWinLose = msg.WinLoseMoney--第一次开奖
        GameUIManager.mSecondWinLose = msg.SecondWinLoseMoney--第二次开奖
        GameUIManager.mCaiJinPoint = msg.mCaiJinPoint--先保存彩金倍率 
        GameUIManager.mZhuangWinLose = msg.iBankerWinMoney
        GameUIManager.playerCount = msg.RankingCount
        for i=1,msg.RankingStation.Length do
            GameUIManager.mMaxWinMoneyStation[i] = msg.RankingStation[i-1]
        end
        for i=1,msg.RankingMoney.Length do
            GameUIManager.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end
        GameUIManager.m_CurGameCount = GameUIManager.m_CurGameCount + 1
        if GameUIManager.m_CurGameCount > 100 then
            for i=1,#GameUIManager.m_PrizesCount do
                GameUIManager.m_PrizesCount[i] = 0
            end
            GameUIManager.mListRecord = {}
            GameUIManager.m_CurGameCount = 0
        end
        GameUIManager.CurrentPrize = {}
        for i=1,msg.PrizeIndex.Length do
            local prize = msg.PrizeIndex[i-1]
            if prize >= 0 then
                table.insert(GameUIManager.mListPrize,prize)
                table.insert(GameUIManager.CurrentPrize,prize)
                --开奖记录插入路单
                GameUIManager.InsertRecordIterm(GameUIManager.View2BetIndex(prize))
            end
        end
        GameUIManager.isReshowrecord = false
        --统计开奖次数
        GameUIManager.NoteMoneyStatisticsCount(GameUIManager.UnChangePrize(msg.PrizeIndex[0]))
        if msg.PrizeIndex[1] > 0 then
            GameUIManager.NoteMoneyStatisticsCount(GameUIManager.UnChangePrize(msg.PrizeIndex[1]))
        end
        --上一局开奖的索引
        GameUIManager.mLastIndex = {}

        --开始游戏逻辑处理
        GameUIManager.StartGame()

        --关闭下注界面，并禁用功能操作按钮
        GameUIManager.StartOrStopDownBetBG(false)
        GameUIManager.EnabledBtn(false)
        GameUIManager.StartClock(getIntPart(msg.Tick / 1000),false)
    --结算
    elseif GameUIManager.mStation == GameUIManager.GameState.GAMESTATE_SETTLEMENT then
        local msg = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_StateUpdate_Settlement)
        --更新路单
        if not GameUIManager.isReshowrecord then
            GameRecord.ReSet(GameUIManager.mListRecord)
        end
        -- GameUIManager.RefreshZhuangInfo()
        GameUIManager.isLockZXZFlag = true
        GameUIGoldManager.HideAllGoldList()
    end
    print(state.iState,"**************GameStation      Over")

end
function GameUIManager.GameNote(msg) --玩家下注 1006
    if msg.NoteMoney <= 0 then
        print( "下注为负数！" , msg.NoteMoney)
    end
    if -1 <= msg.NoteMoney and msg.NoteMoney <= 0 then
        if MyUserInfo.iDeskStation == msg.nDeskStation then
            LblMsgText.Show(msg.NoteMoney < 0 and "Betting limit exceeded!" or "Your gold coins are insufficient, the bet failed!")
        end
    else
        GameUIManager.mTotalBets[msg.AreaIndex+1] = GameUIManager.mTotalBets[msg.AreaIndex+1] + msg.NoteMoney
        if MyUserInfo.iDeskStation == msg.nDeskStation then
            GameUIManager.mMyBets[msg.AreaIndex+1] = GameUIManager.mMyBets[msg.AreaIndex+1] + msg.NoteMoney

            if tonumber(tostring(MyUserInfo.iMoney)) < msg.NoteMoney then
                print("异常，身上的钱为负数！") 
            end
            for i=1,#GameUIManager.mChips do
                if GameUIManager.mChips[i] == msg.NoteMoney then
                    --PlayGameMusic(GoldAudio[0]);
                    GameAudioContro.Play("Public/"..GameUIManager.GoldAudio[1]..".u3d")
                    GameUIManager.PlayGoldAnimation(MyUserInfo.uiUserID, GameUIManager.BtnBets[i].transform.localPosition, msg.AreaIndex, i)
                    break
                end      
            end
        else
            for i=1,#GameUIManager.mChips do
                if GameUIManager.mChips[i] == msg.NoteMoney then
                    --PlayGameMusic(GoldAudio[0]);
                    GameAudioContro.Play("Public/"..GameUIManager.GoldAudio[1]..".u3d")
                    GameUIManager.PlayGoldAnimation(GameUIManager.GetUserByStation(msg.nDeskStation).uiUserID, GameUIManager.XianPos, msg.AreaIndex, i)
                    break
                end
            end
        end
        GameUIManager.RefreshUserInfo()
    end
end
function GameUIManager.GameKeyNote(data) --键盘下注 1007
end
function GameUIManager.GameContiuePreNote(msg) --续押 1008
    for i=1,msg.AreaNoteMoney.Length do
        GameUIManager.mTotalBets[i] = GameUIManager.mTotalBets[i] + msg.AreaNoteMoney[i-1]
        if msg.nDeskStation == MyUserInfo.iDeskStation then
            GameUIManager.mMyBets[i] = GameUIManager.mMyBets[i] + msg.AreaNoteMoney[i-1]
            if tonumber(tostring(MyUserInfo.iMoney)) < msg.AreaNoteMoney[i-1] then
                print( "异常，身上的钱为负数！" )
            else
                
            end
        end
        if msg.AreaNoteMoney[i-1] > 0 then
            GameUIManager.ContinuePlayGoldGruop(msg.nDeskStation,msg.AreaNoteMoney[i-1], i-1)
        else
            print( "下注为负数！" , msg.AreaNoteMoney[i-1])
        end
    end
    GameUIManager.RefreshUserInfo()
end
function GameUIManager.GameCancelCurNote(msg) --取消之前的下注 1009
    for i=1,msg.NoteMoney.Length do
        GameUIManager.mTotalBets[i] = GameUIManager.mTotalBets[i] + msg.NoteMoney[i-1]
        if msg.nDeskStation == MyUserInfo.iDeskStation and msg.NoteMoney[i-1] ~= 0 then
            GameUIManager.mMyBets[i] = GameUIManager.mMyBets[i] + msg.NoteMoney[i-1]
            if tonumber(tostring(MyUserInfo.iMoney)) < msg.NoteMoney[i-1] then
                print( "异常，身上的钱为负数！" )
            end
        end
    end
    GameUIGoldManager.RemoveGold(MyUserInfo.uiUserID)
    --更新下注
    GameUIManager.RefreshUserInfo()
end
function GameUIManager.GameNtInfo(ntInfoData) --庄家列表 1010
    --0:上庄 1:下庄  2：切换庄家   10:上庄钱不足 11：本局结束后就可以下庄    >20  (还差多少局)
    print("--庄家列表 1010---",ntInfoData.state,ntInfoData.bDeskStation,MyUserInfo.iDeskStation)
    -- if ntInfoData.state == 0 then
    --     if not GameUIManager.ListContains(GameUIManager.ZhuangList,ntInfoData.bDeskStation) then
    --         table.insert(GameUIManager.ZhuangList,ntInfoData.bDeskStation)
    --     end
    --     if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
    --         GameUIManager.btnShangZhuang.gameObject:SetActive(false)
    --         GameUIManager.btnXiaZhuang.gameObject:SetActive(true)
    --         --GameUIShangZhuangList.SetShangZhuanglistInfo(GameUIManager.LeastMoneyZhuang,GameUIManager.ZhuangList)
    --     end  
    -- elseif ntInfoData.state == 1 then
    --     if GameUIManager.ListContains(GameUIManager.ZhuangList,ntInfoData.bDeskStation) then
    --         for i=1,#GameUIManager.ZhuangList do
    --             if GameUIManager.ZhuangList[i] == ntInfoData.bDeskStation then
    --                 table.remove(GameUIManager.ZhuangList,i)
    --                 break
    --             end
    --         end
    --     end
    --     if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
    --         GameUIManager.btnShangZhuang.gameObject:SetActive(true)
    --         GameUIManager.btnXiaZhuang.gameObject:SetActive(false)
    --         --GameUIShangZhuangList.SetShangZhuanglistInfo(GameUIManager.LeastMoneyZhuang,GameUIManager.ZhuangList)
    --     end
    -- elseif ntInfoData.state == 2 then
    --     if GameUIManager.StationZhuang ~= nil and GameUIManager.StationZhuang ~= -1 and GameUIManager.StationZhuang ~= 255 then
    --         GameUIManager.ShowNoteTip(4,ntInfoData.bDeskStation)
    --         --总带入 局数 输赢
    --         if GameBankerResult.transform then
    --             if GameUIManager.StationZhuang == MyUserInfo.iDeskStation then
    --                 GameBankerResult.Show(ntInfoData.iEntryMoney,ntInfoData.cbNtGames,ntInfoData.iWinMoney)
    --             end
    --         end
    --     end
    --     GameUIManager.IsHuanZhuang = true
    --     if ntInfoData.bDeskStation == 255 then
    --         GameUIManager.PeviousZhuangStation = GameUIManager.StationZhuang
    --     else
    --         if GameUIManager.StationZhuang == -1 or GameUIManager.StationZhuang == 255 then
    --             GameUIManager.PeviousZhuangStation = ntInfoData.bDeskStation
    --         else
    --             GameUIManager.PeviousZhuangStation = GameUIManager.StationZhuang
    --         end
    --     end
    --     GameUIManager.StationZhuang = ntInfoData.bDeskStation
    --     if GameUIManager.ListContains(GameUIManager.ZhuangList,ntInfoData.bDeskStation) then
    --         for i=1,#GameUIManager.ZhuangList do
    --             if GameUIManager.ZhuangList[i] == ntInfoData.bDeskStation then
    --                 table.remove(GameUIManager.ZhuangList,i)
    --                 break
    --             end
    --         end
    --     end
    --     if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
    --         GameUIManager.btnShangZhuang.gameObject:SetActive(false)
    --         GameUIManager.btnXiaZhuang.gameObject:SetActive(true)
    --         --GameUIShangZhuangList.SetShangZhuanglistInfo(GameUIManager.LeastMoneyZhuang,GameUIManager.ZhuangList)
    --     end
    -- elseif ntInfoData.state == 10 then
    --     LblMsgText.Show("There is not enough money to go to the banker, please recharge first!")
    -- elseif ntInfoData.state == 11 then
    --     LblMsgText.Show("Success! After the end of the game, you will be automatically replace in the banker!")
    -- else
    --     if ntInfoData.state > 21 then
    --         local msg=string.format("There are still %s rounds before replace the banker!",ntInfoData.state - 20)
    --         LblMsgText.Show(msg)
    --     elseif ntInfoData.state == 21 then
    --         LblMsgText.Show("You will not be the dealer after this round!")
    --     end
    -- end
    -- GameUIShangZhuangList.SetShangZhuanglistInfo(GameUIManager.LeastMoneyZhuang,GameUIManager.ZhuangList)
    -- GameUIManager.RefreshZhuangInfo()
    print("---庄家列表 1010 Over--",ntInfoData.state,ntInfoData.bDeskStation,MyUserInfo.iDeskStation)
end
function GameUIManager.GamePlayerNoteInfo(data) --所有用户下注信息 1011

end
function GameUIManager.GameSettlement(data) --即将结算 1012
end
function GameUIManager.GameStatitice(data) --统计（押注，概率） 1015  
    -- for i=1,#GameUIManager.m_PrizesCount do
    --     GameUIManager.m_PrizesCount[i] = msg.mPrizePro[i-1]
    -- end
    -- GameUIManager.m_CurGameCount = msg.mTotalGames;
    for i=1,#GameUIManager.m_PrizesCount do
        GameUIManager.m_PrizesCount[i] = data.mPrizePro[i-1]
    end
    GameUIManager.m_CurGameCount = data.mTotalGames;
end
function GameUIManager.RunBigPrizeListAnimation(lastIndex,curIndex,OnComplete)
    print("-----------",lastIndex,curIndex)
    if lastIndex == nil or curIndex == nil then
        return
    end
    local isLoop = true
    local tempIndex = lastIndex
    if lastIndex < curIndex then
        lastIndex = lastIndex + 28
    end

    if lastIndex - curIndex < 14 then
        lastIndex = lastIndex + 28
    end

    local time = 0.30 
    while isLoop do
        if lastIndex < (curIndex + 1) then
            isLoop = false
        end
        coroutine.wait(time)
        GameUIManager.Obj_Flash[lastIndex % 28 + 1]:SetActive(true)
        local entity = GameUIManager.UIEntity[lastIndex % 28+1]
        entity:Flash_Show(true)

        entity = GameUIManager.UIEntity[(lastIndex + 28 + 6 ) % 28+1]
        entity:Flash_Show( false )
        if not GameAudioContro.SoundEffect.isPlaying then
            GameAudioContro.Play(GameAudioContro.ZhuandengClip)
        end
        time = Jisu
        lastIndex = lastIndex - 1
    end
    if OnComplete ~= nil then
        OnComplete()
    end
end
function GameUIManager.RunNormalPrizeListAnimation(lastIndex,curIndex,OnComplete )
    print("---开始跑圈---",lastIndex,curIndex)
    local isLoop = true
    local tempIndex = curIndex
    if curIndex >= lastIndex then
        if curIndex - lastIndex < 14 then
            curIndex = curIndex + 28
        end
    else
        curIndex = curIndex + 28
        if curIndex - lastIndex < 14 then
            curIndex = curIndex + 28
        end
    end
    curIndex = curIndex + 28 * 4
    local time = 0.20
    while isLoop do
        if lastIndex > (curIndex - 1) then
            isLoop = false
        end
        coroutine.wait(time)
        --跑灯动画
        GameUIManager.Obj_Flash[lastIndex % 28 + 1]:SetActive(true)
        local entity = GameUIManager.UIEntity[lastIndex % 28+1]
        entity:Flash_Show(true)

        entity = GameUIManager.UIEntity[(lastIndex + 28 - 6 ) % 28+1]
        entity:Flash_Show( false )
        if (curIndex - lastIndex) < tep then --减速
            if (curIndex - lastIndex) < jiansuTep then
                time = Mathf.Lerp(a2, a3, (tep - (curIndex - lastIndex)) / jiansuTep)
            else
                time = Mathf.Lerp(a1, a2, (tep - (curIndex - lastIndex)) / (tep - jiansuTep))
            end
            if (curIndex -lastIndex) <3 then
                GameAudioContro.Play(GameAudioContro.ZhuandengClip)
            end
        
        else   --加速
            time = time - JiasuSpeed
            if time <= Jisu then
                time = Jisu
            end
        end
        lastIndex = lastIndex + 1
    end
    if  OnComplete ~= nil then
        OnComplete()
    end
end    
function GameUIManager.UpData()
    if(UnityEngine.Input.GetKeyDown(UnityEngine.KeyCode.A)) then
        --GameUIManager.PoolDataDistrubute() 
    end
    if GameUIManager.TotalStep > 0 and GameUIManager.CurStep <= GameUIManager.TotalStep then
        if GameUIManager.CurSpeed < GameUIManager.MaxSpeed and GameUIManager.CurStep < 6 then--前四步加速
            GameUIManager.CurSpeed = 0.2--GameUIManager.Linear(0.1, GameUIManager.MaxSpeed, GameUIManager.CurStep / 4.0)
        elseif GameUIManager.CurStep + GameUIManager.DownSpeedStep >= GameUIManager.TotalStep
        and GameUIManager.CurStep + 5 < GameUIManager.TotalStep then--后面的24步开始减速
            local value = (GameUIManager.CurStep + GameUIManager.DownSpeedStep - GameUIManager.TotalStep) * 1.0 / (GameUIManager.DownSpeedStep)
            GameUIManager.CurSpeed = GameUIManager.Linear(GameUIManager.MaxSpeed, GameUIManager.MinSpeed, value)
        elseif GameUIManager.CurStep + 5 >= GameUIManager.TotalStep then--后面的24步开始减速
            --local value = (GameUIManager.CurStep + GameUIManager.DownSpeedStep - GameUIManager.TotalStep) * 1.0 / (GameUIManager.DownSpeedStep)
            local value = math.floor(GameUIManager.CurStep/GameUIManager.TotalStep*1000)/1000
            GameUIManager.CurSpeed = GameUIManager.Linear(GameUIManager.MaxSpeed, GameUIManager.MinSpeed, value)
        else --中间就是最大速度
            GameUIManager.CurSpeed = GameUIManager.MaxSpeed
        end

        GameUIManager.Factor = GameUIManager.Factor + GameUIManager.PerTime() * UnityEngine.Time.deltaTime * GameUIManager.CurSpeed
        --GameUIManager.Factor = math.floor(GameUIManager.Factor*1000)/1000

        local val = Mathf.Clamp01(GameUIManager.Factor)
        if math.floor(val * GameUIManager.TotalStep) >= GameUIManager.CurStep then

            GameUIManager.CurPrizeIndex = (GameUIManager.mLastPrizeIndex + GameUIManager.CurStep) % GameUIManager.CarTeamCount

            --GameUIManager.Car_Team[GameUIManager.CurPrizeIndex+1].gameObject:SetActive(true)
            GameUIManager.Obj_Flash[GameUIManager.CurPrizeIndex+1]:SetActive(true)
            --local entity = GameUIManager.UIEntity[GameUIManager.CurPrizeIndex]
            --entity:Flash_Show(true)

            --entity = GameUIManager.UIEntity[(lastIndex + 28 - 6 ) % 28+1]
            --entity:Flash_Show( false )

            local blink = GameUIManager.UIEntity[GameUIManager.CurPrizeIndex+1]
            if GameUIManager.CurStep == GameUIManager.TotalStep then   --开奖跑完
                GameUIManager.StopLastIndexBlink()
                --记录游戏已经开奖的
                GameUIManager.mLastPrizeIndex = GameUIManager.CurPrizeIndex

                --重置
                GameUIManager.Factor = 0
                GameUIManager.CurStep = 0
                GameUIManager.TotalStep = 0
                if GameUIManager.CallBack ~= nil then
                    GameUIManager.CallBack()
                    GameUIManager.CallBack = nil
                end
                blink:PlayIconBlink(-1, 0.2)--间隔0.2f闪动一下  count = -1不停的闪
            elseif GameUIManager.CurStep + GameUIManager.DownSpeedStep * 0.12 >= GameUIManager.TotalStep then--改变车标闪动 效果 
                blink:PlayIconBlink(-1, 0.2)--间隔0.2f闪动一下——跑动时，底图渐变动画，闪
            else
                blink:PlayIconBlink(-2, 0.1)--间隔0.1f后消隐——跑动时，底图渐变动画，闪
            end

            GameAudioContro.Play(GameAudioContro.ZhuandengClip)
            --GameAudioContro.Play(GameAudioContro.CarTurnAud)
            --if GameUIManager.TotalStep - GameUIManager.CurStep <= 5 and GameUIManager.TotalStep - GameUIManager.CurStep >= 0 then--最后3步 开始播放减速音乐
            --  GameAudioContro.Play("Public/Audio/Game/Loop/zhuandeng.u3d")
            --end
            GameUIManager.CurStep = GameUIManager.CurStep + 1
        end
    end
end
--停止上次奖励 图标的高亮
function GameUIManager.StopLastIndexBlink()
    local lastPrizeIndex = (GameUIManager.mLastPrizeIndex + GameUIManager.CurStep) % GameUIManager.CarTeamCount
    GameUIManager.StopAllIconLight()--所有的灯都停止高亮和闪动
    if GameUIManager.UIEntity[lastPrizeIndex+1] then
        GameUIManager.UIEntity[lastPrizeIndex+1]:StopIconBlink()
    end
    GameUIManager.Obj_Flash[lastPrizeIndex+1]:GetComponent("Animation"):Play("Shan")
end
function GameUIManager.PerTime()
    if GameUIManager.Duration ~= GameUIManager.CurDuration then
        GameUIManager.Duration = GameUIManager.CurDuration
        GameUIManager.CurPerTime = (GameUIManager.CurDuration > 0) and (1 / GameUIManager.CurDuration) or 1
    end
    return GameUIManager.CurPerTime
end
--直线
function GameUIManager.Linear(start,over,value)
    return start + (over - start) * value
    --return Mathf.Lerp(start, over, value)
end
function GameUIManager.OpenPrizeLogic()
    --上一局开奖动物重置回以前的背景图片
    print( "开始跑圈!!!!!!!!!!",GameUIManager.mLastPrizeIndex,GameUIManager.CurrentPrize[1])
    local anima = GameUIManager.Obj_Flash[GameUIManager.mLastPrizeIndex+1]:GetComponent("Animation")
    if 0 ~= GameUIManager.mLastPrizeIndex % 7 then
        --anima.namePrefix = GameUIManager.mLastPrizeIndex < #GameUIManager.Obj_Flash/2 and "GreenBig_" or "RedBig_"
        --anima:Play("Shan")
    end
    --anima.enabled = true
    GameUIManager.StopComCoroutine()
    GameUIManager.PlayOpenPrizeAnimation(GameUIManager.CurrentPrize[1],--[[,GameUIManager.OnAnimationComplete)

    ComCoroutine = coroutine.start(GameUIManager.RunNormalPrizeListAnimation,GameUIManager.mLastPrizeIndex,GameUIManager.CurrentPrize[1],]]function()

        print("跑圈完毕 从"..GameUIManager.mLastPrizeIndex,"到"..GameUIManager.CurrentPrize[1].." CurrentPrize.Count："..#GameUIManager.CurrentPrize)
        --记录游戏已经开奖的
        GameUIManager.mLastPrizeIndex = GameUIManager.CurrentPrize[1]
        table.insert(GameUIManager.mLastIndex,GameUIManager.mLastPrizeIndex)
        if #GameUIManager.CurrentPrize == 1 then
            local nBetIndex = GameUIManager.View2BetIndex(GameUIManager.CurrentPrize[1])
            --播放跑完动画
            GameUIManager.PlayFlash()
            --anima.enabled = true;
        elseif #GameUIManager.CurrentPrize == 2 then
            --倍率
            local nBetIndex = GameUIManager.View2BetIndex(GameUIManager.CurrentPrize[1])
            local entity = GameUIManager.UIEntity[GameUIManager.CurrentPrize[1]+1]
            entity:PlayLoop()
            if nBetIndex == 1 then
                -- 金鲨闪动画
                --anima.enabled = true
                --anima:Play("Shan")

                --金鲨鱼走完，播放人声金鲨鱼
                GameUIManager.listAudio = {}
                -- 金鲨鱼
                local audio = {}
                audio.strAudio = GameUIManager.PeopleAudio[nBetIndex+1]
                --audio.time = 0.5
                audio.time = 2.1
                table.insert(GameUIManager.listAudio,audio)

                --金鲨鱼叫
                -- local audio1 = {}
                -- audio1.strAudio = GameUIManager.AnimationAudio[nBetIndex+1]
                -- audio1.time = 1.0
                -- table.insert(GameUIManager.listAudio,audio1)

                --[[
                --金鲨鱼开奖
                local audio2 = {}
                audio2.strAudio = GameUIManager.SoundOpenPrizeJinYin
                audio2.time = 0.6
                table.insert(GameUIManager.listAudio,audio2)
                ]]

                coroutine.start(GameUIManager.PlayGameMusic,GameUIManager.listAudio)
                print("----播灯动画------")
                --播灯动画
                GameUIAnimation.StartAnimation( 1, 2,function()
                    coroutine.start(GameUIManager.RunBigPrizeListAnimation,GameUIManager.mLastPrizeIndex, GameUIManager.mListPrize[1],function()
                        GameUIManager.StopLightAnimation()
                        GameUIManager.RefreshUserInfo()
                    end)
                end)
            end

            if nBetIndex == 2 then
                --银鲨按钮跳
                local entity1 = GameUIManager.UIEntity[GameUIManager.CurrentPrize[1]+1]
                entity1:PlayLoop()

                --金鲨鱼走完，播放人声金鲨鱼
                GameUIManager.listAudio = {}

                -- 金鲨鱼
                local audio = {}
                audio.strAudio = GameUIManager.PeopleAudio[nBetIndex+1]
                --audio.time = 0.5
                audio.time = 2.1
                table.insert(GameUIManager.listAudio,audio)

                --金鲨鱼叫
                -- local audio1 = {}
                -- audio1.strAudio = GameUIManager.AnimationAudio[nBetIndex+1]
                -- audio1.time = 1.0
                -- table.insert(GameUIManager.listAudio,audio1)

                --[[
                --金鲨鱼开奖
                local audio2 = {}
                audio2.strAudio = GameUIManager.SoundOpenPrizeJinYin
                audio2.time = 0.6
                table.insert(GameUIManager.listAudio,audio2)
                ]]
                coroutine.start(GameUIManager.PlayGameMusic,GameUIManager.listAudio)

                --播灯动画
                print("----播灯动画------")
                --GameUIAnimation.StartAnimation( 3, 6)
                print("----播灯动画------")

                GameUIAnimation.StartAnimation( 2, 2,function()
                    coroutine.start(GameUIManager.RunBigPrizeListAnimation,GameUIManager.mLastPrizeIndex, GameUIManager.mListPrize[1],function()
                        GameUIManager.StopLightAnimation()
                        GameUIManager.RefreshUserInfo()
                    end)
                end)
            end
        end
    end)
end
function GameUIManager.PlayOpenPrizeAnimation(prizeIndex,callBack)
    print("-----开奖动画-----",prizeIndex)
    GameUIManager.PrizeIndex = prizeIndex
    GameUIManager.CallBack = callBack
    GameUIManager.Factor = 0
    GameUIManager.CurStep = 0

    GameUIManager.StopAllIconLight()--所有的灯都停止高亮和闪动
    GameUIManager.TotalStep = (GameUIManager.CarTeamCount * (prizeIndex >= GameUIManager.mLastPrizeIndex and 3 or 4) + (prizeIndex - GameUIManager.mLastPrizeIndex))
    print("总步数："..GameUIManager.TotalStep,"当前步数："..GameUIManager.CurStep)
    --GameAudioContro.Play("Public/Audio/Game/Loop/loop.u3d")
end
function GameUIManager.StopAllIconLight()
    for i=1,#GameUIManager.UIEntity do
        GameUIManager.UIEntity[i]:StopIconBlink()
    end
end
function GameUIManager.WaitOpenPrize(nSpecailIndex,nBetIndex,money,lessTime)
    if lessTime < 1 then
    end
    GameUIManager.TipGroup[1]:SetActive(true)
    coroutine.wait(lessTime)
    GameUIManager.TipGroup[1]:SetActive(false)

    local animaIndex = GameUIManager.View2BetIndex(nBetIndex)
    --非金鲨，修改图片
    GameUIManager.Obj_Flash[nBetIndex+1]:SetActive(true)
    --不消隐
    local alpha = GameUIManager.Obj_Flash[nBetIndex+1]:GetComponent("TweenAlpha")
    alpha.enabled = false

    --停止闪
    local nViewIndex = GameUIManager.mLastPrizeIndex
    GameUIManager.Obj_Flash[nViewIndex+1]:GetComponent("Animation").wrapMode = UnityEngine.WrapMode.Once
    --中间的几个动画
    local animaName = GameUIManager.GetAnimalNameByIndex(animaIndex)
    if GameUIManager.StationZhuang ~= -1 and GameUIManager.StationZhuang ~= 255 then
        if GameResult then
            if nSpecailIndex == 255 then
                GameResult.Show(money, GameUIManager.mZhuangWinLose, GameUIManager.StationZhuang, GameUIManager.mMaxWinMoneyStation, GameUIManager.mMaxWinSouce, GameUIManager.playerCount,animaName)
            else
                GameResult.Show(money, GameUIManager.mZhuangWinLose, GameUIManager.StationZhuang, GameUIManager.mMaxWinMoneyStation, GameUIManager.mMaxWinSouce, GameUIManager.playerCount,animaName)
            end
        end
    end
end
--开奖逻辑
function GameUIManager.StartGame()
    if 0 < #GameUIManager.mListPrize then
        --开奖索引
        local nViewIndex = GameUIManager.mListPrize[1]
        local nBetIndex = GameUIManager.View2BetIndex(nViewIndex)
        if nBetIndex <= 2 then
            --金鲨银鲨 声音 
            GameUIManager.StopJsYsAnimation()
        else
            --其它
            table.remove(GameUIManager.mListPrize,1)
            GameUIManager.OpenPrizeLogic()

            --跑声音
            if GameUIManager.isShowAllUI then
                --GameAudioContro.SoundEffect:Stop()
            end
            --GameAudioContro.Play("Public/Audio/Game/OpenPrize_YinXiao.u3d")
        end
    end
end
--闪动画
function GameUIManager.PlayFlash(viewIndex)
    if viewIndex == nil then
        viewIndex = -1
    end
    local nViewIndex = viewIndex
    if nViewIndex < 0 then
        nViewIndex = GameUIManager.mLastPrizeIndex
    end
    local animShan = GameUIManager.Obj_Flash[nViewIndex+1]:GetComponent("Animation")
    animShan.wrapMode = UnityEngine.WrapMode.Loop
    animShan:Play("Shan")
    local time = animShan:GetClip("Shan").length * 3
    coroutine.start(GameUIManager.StartAnimalAnimation,time)
end
--播放动物动画
function GameUIManager.StartAnimalAnimation(time)
    coroutine.wait(time)
    local nViewIndex = GameUIManager.mLastPrizeIndex
    --停止闪
    GameUIManager.Obj_Flash[nViewIndex+1]:GetComponent("Animation").wrapMode = UnityEngine.WrapMode.Once
    --中间的几个动画
    local nBetIndex = GameUIManager.View2BetIndex(nViewIndex)
    GameUIAnimation.StartAnimation( nBetIndex, 12)
    --飞禽走兽按钮
    if 3 < nBetIndex then
        --飞禽走兽按钮
        if nViewIndex < #GameUIManager.Obj_Flash/2 then
            --走兽声音
            GameUIManager.listAudio = {}
            local audio = {}
            --人声
            audio.strAudio = GameUIManager.PeopleAudio[nBetIndex+1]
            --audio.time = 0.8
            audio.time = 2.1
            table.insert(GameUIManager.listAudio,audio)

            --人叫动物声
            -- local audio1 = {}
            -- audio1.strAudio = GameUIManager.PeopleAudio[4]
            -- audio1.time = 0.8
            -- table.insert(GameUIManager.listAudio,audio1)

            --动物叫声
            -- local audio2 = {}
            -- audio2.strAudio = GameUIManager.AnimationAudio[nBetIndex+1]
            -- audio2.time = 1
            -- table.insert(GameUIManager.listAudio,audio2)

            --[[
            -- 开奖声 
            local audio3 = {}
            audio3.strAudio = GameUIManager.SoundOpenPrizeFeiZou
            audio3.time = 0.8
            table.insert(GameUIManager.listAudio,audio3)
            ]]
            coroutine.start(GameUIManager.PlayGameMusic,GameUIManager.listAudio)
        else
            GameUIManager.listAudio = {}
            local audio = {}
            --人声
            audio.strAudio = GameUIManager.PeopleAudio[nBetIndex+1]
            --audio.time = 0.8
            audio.time = 2.1
            table.insert(GameUIManager.listAudio,audio)

            --人叫动物声
            -- local audio1 = {}
            -- audio1.strAudio = GameUIManager.PeopleAudio[1]
            -- audio1.time = 0.8
            -- table.insert(GameUIManager.listAudio,audio1)

            --动物叫声
            -- local audio2 = {}
            -- audio2.strAudio = GameUIManager.AnimationAudio[nBetIndex+1]
            -- audio2.time = 1
            -- table.insert(GameUIManager.listAudio,audio2)

            --[[
            -- 开奖声 
            local audio3 = {}
            audio3.strAudio = GameUIManager.SoundOpenPrizeFeiZou
            audio3.time = 0.8
            table.insert(GameUIManager.listAudio,audio3)
            ]]
            
            coroutine.start(GameUIManager.PlayGameMusic,GameUIManager.listAudio)
        end
        --修改背景
    else
        --金鲨 银鲨
        GameUIManager.listAudio = {}
        local audio = {}
        --银鲨鱼
        audio.strAudio = GameUIManager.PeopleAudio[nBetIndex+1]
        --audio.time = 0.5
        audio.time = 2.1
        table.insert(GameUIManager.listAudio,audio)

        --银鲨鱼叫
        -- local audio1 = {}
        -- audio1.strAudio = GameUIManager.AnimationAudio[nBetIndex+1]
        -- audio1.time = 1
        -- table.insert(GameUIManager.listAudio,audio1)

        --[[
        --银鲨鱼开奖
        local audio2 = {}
        audio2.strAudio = GameUIManager.SoundOpenPrizeJinYin
        audio2.time = 0.6
        table.insert(GameUIManager.listAudio,audio2)
        ]]

        coroutine.start(GameUIManager.PlayGameMusic,GameUIManager.listAudio)
    end
    --金鲨按钮
    if 0 < #GameUIManager.mLastIndex then
        nBetIndex = GameUIManager.View2BetIndex(GameUIManager.mLastIndex[1])
    end
    local animaName = GameUIManager.GetAnimalNameByIndex(nBetIndex)
    GameUIManager.IconOpenPrizeAnima.spriteName = "UI_Game_JS_"..animaName
    GameUIManager.IconOpenPrizeTxt.spriteName = "Txt_JS_"..animaName
    GameUIManager.IconOpenPrizeBet.text = "X"..GameUIManager.mBase[nBetIndex+1]
    GameUIManager.IconOpenPrizeAnima.transform.parent.gameObject:SetActive(true)
    --停止动画
    coroutine.wait(3)
    GameUIManager.IconOpenPrizeAnima.transform.parent.gameObject:SetActive(false)
    GameUIManager.ShowOrHideWinAnim(true,GameUIManager.CurrentPrize)
    if GameUIManager.StationZhuang ~= -1 or GameUIManager.StationZhuang ~= 255 or GameUIManager.IsHuanZhuang then
        if GameResult then
            local money = 0
            if 0 < GameUIManager.mWinLose then
                money = GameUIManager.mWinLose 
            else
                money = GameUIManager.mWinLose + GameUIManager.mSecondWinLose
            end
            if GameUIManager.IsHuanZhuang then
                GameResult.Show(money, GameUIManager.mZhuangWinLose, GameUIManager.PeviousZhuangStation, GameUIManager.mMaxWinMoneyStation, GameUIManager.mMaxWinSouce, GameUIManager.playerCount,animaName)
            else
                GameResult.Show(money, GameUIManager.mZhuangWinLose, GameUIManager.StationZhuang, GameUIManager.mMaxWinMoneyStation, GameUIManager.mMaxWinSouce, GameUIManager.playerCount,animaName)
            end
            GameUIManager.PeviousZhuangStation = GameUIManager.StationZhuang
            GameUIManager.IsHuanZhuang = false
        end
    end
    --停止动画
    coroutine.wait(3)
    if GameResult.transform.gameObject.activeSelf then
        GameResult.Hide()
    end
    if GameUIManager.StopDownBet then
        GameUIManager.StopDownBet:SetActive(false)
    end
    coroutine.start(GameUIManager.YieldPlayFlyGold)
    coroutine.wait(10)
    GameUIManager.StopAnimalAnimation()
end
--停止动物动画
function GameUIManager.StopAnimalAnimation()
    if #GameUIManager.mLastIndex <= 0 then
        return
    end
    if 0 < #GameUIManager.listAudio then
        GameUIManager.listAudio = {}
    end
    --修改背景
    for n=1,#GameUIManager.mLastIndex do
        local Index = GameUIManager.mLastIndex[n]
        --恢复图片,不能消隐
        local entity = GameUIManager.UIEntity[Index+1]
        entity:OnlyShowBG()
    end
    --中奖索引
    GameUIManager.mLastIndex = {}
    --倍率
    GameUIManager.UILb_Base.gameObject:SetActive(false)
end
--金鲨银鲨动画停止
function GameUIManager.StopJsYsAnimation()
    --金鲨/银鲨播放结束
    if 0 < #GameUIManager.mListPrize then
        --开奖索引
        local nViewIndex = GameUIManager.mListPrize[1]
        table.remove(GameUIManager.mListPrize,1)
        GameUIManager.OpenPrizeLogic()

        --跑声音
        --GameAudioContro.Play("Public/Audio/Game/OpenPrize_YinXiao.u3d")
    end
end
--灯动画停止
function GameUIManager.StopLightAnimation( )
    if #GameUIManager.mListPrize > 0 then
        --开奖索引
        local nViewIndex = GameUIManager.mListPrize[1]
        table.remove(GameUIManager.mListPrize,1)

        --记录游戏已经开奖的
        GameUIManager.mLastPrizeIndex = nViewIndex
        table.insert(GameUIManager.mLastIndex,GameUIManager.mLastPrizeIndex)

        --不能消隐
        local alpha = GameUIManager.Obj_Flash[nViewIndex+1]:GetComponent("TweenAlpha")
        alpha:ResetToBeginning()
        alpha.enabled = false

        --播放跑完动画
        GameUIManager.PlayFlash()
    end
end
function GameUIManager.ShowOrHideWinAnim(isShow,prize)
    for i=1,#GameUIManager.WinRay do
        GameUIManager.WinRay[i]:SetActive(false)
    end
    if isShow then
        for i=1,#GameUIManager.WinRay do
            for j=1,#prize do
                local animaIndex = GameUIManager.View2BetIndex(prize[j])
                local animaIndex1 = GameUIManager.FeiQinOrZouShou(animaIndex) 
                if i == animaIndex + 1 then
                    GameUIManager.WinRay[animaIndex+1]:SetActive(true)
                    if animaIndex ~= 2  then
                        GameUIManager.WinRay[animaIndex1+1]:SetActive(true)
                    end
                end
            end
        end

    end
end  
function GameUIManager.PlayGameMusic(listAudio)
    for i=1,#listAudio do
        GameAudioContro.Play("Public/"..listAudio[i].strAudio..".u3d")
        --等XX毫秒，放下一个声音
        coroutine.wait(listAudio[i].time)
        if i ~= #listAudio then
            GameAudioContro.StopEffect()
        end
    end
    listAudio = {}
end
function GameUIManager.UpdateBetInfo(bets)
    local len = #GameUIManager.BtnBets
    if #bets > #GameUIManager.BtnBets then
        len = #GameUIManager.BtnBets
    else
        len = #bets
    end
    for i=1,len do
        local btn = GameUIManager.BtnBets[i]
        if btn then
            local label = btn.gameObject.transform:FindChild("Label_Num"):GetComponent("UILabel")
            if label then
                label.text = FormatNumToYW(MoneyProportionStr(bets[i]))
            end
        end
    end
end
--开始或停止下注
function GameUIManager.StartOrStopDownBetBG(flag)
    if flag then
        GameUIManager.ShowNoteTip(2)
        if GameUIManager.StartDownBet then
            if not GameUIManager.StartDownBet.activeSelf then
                GameUIManager.StartDownBet:SetActive(true)
            end
        end
        if GameUIManager.StopDownBet then
            if GameUIManager.StopDownBet.activeSelf then
                GameUIManager.StopDownBet:SetActive(false)
            end
        end
    else
        GameUIManager.ShowNoteTip(3)
        if GameUIManager.StartDownBet then
            if GameUIManager.StartDownBet.activeSelf then
                GameUIManager.StartDownBet:SetActive(false)
            end
        end
        if GameUIManager.StopDownBet then
            if not GameUIManager.StopDownBet.activeSelf then
                GameUIManager.StopDownBet:SetActive(true)
            end
        end
    end
end
function GameUIManager.ShowStateTip(state)
    for i=5,6 do
        GameUIManager.TipGroup[i]:SetActive(false)
    end
    if state == GameUIManager.GameState.GAMESTATE_NOTE then 
        GameUIManager.TipGroup[5]:SetActive(true)
    elseif state == GameUIManager.GameState.GAMESTATE_OPENPRIZE then
        GameUIManager.TipGroup[6]:SetActive(true)
    elseif state == GameUIManager.GameState.GAMESTATE_SETTLEMENT then
        GameUIManager.TipGroup[6]:SetActive(true)
    else

    end
    
end
--展示提示消息 2开始下注 3停止下注 4庄家轮换
function GameUIManager.ShowNoteTip(index,deskStation)    
    coroutine.stop(GameUIManager.HideNoteTip)
    coroutine.start(GameUIManager.HideNoteTip,index)
    if index == 4 then
        -- local user = GameUIManager.GetUserByStation(deskStation)
        -- if user then
        --     if user.bBoy == 1 then
        --         GameAudioContro.Play(GameAudioContro.TipsClip[3])
        --     else
        --         GameAudioContro.Play(GameAudioContro.TipsClip[4])
        --     end
        -- end
    else
        GameUIManager.TipGroup[index]:SetActive(true)
        GameAudioContro.Play(GameAudioContro.TipsClip[index-1])
    end
end
function GameUIManager.HideNoteTip(index)
    coroutine.wait(2)
    GameUIManager.TipGroup[index]:SetActive(false)
end
--视图转下注
function GameUIManager.View2BetIndex(nViewIndex)
    return nViewIndex >= #GameUIManager.viewIndex  and 1 or GameUIManager.viewIndex[nViewIndex+1]
end
--region 下注更新
--更新倍率
function GameUIManager.RefreshBase()
    for i=1,#GameUIManager.UILb_Bases do
        GameUIManager.UILb_Bases[i].text = "X"..GameUIManager.mBase[i]
    end
end
--筹码初始选择
function GameUIManager.ChooseBetIndex()
    while true do
        if GameUIManager.mCheckIndex == 1 then
            SetParent(GameUIManager.BtnBets[GameUIManager.mCheckIndex].gameObject, GameUIManager.GoBetFocus)
            break
        end
        if GameUIManager.mChips[GameUIManager.mCheckIndex] < tonumber(tostring(MyUserInfo.iMoney)) then
            SetParent(GameUIManager.BtnBets[GameUIManager.mCheckIndex].gameObject, GameUIManager.GoBetFocus)
            break
        end
        GameUIManager.mCheckIndex = GameUIManager.mCheckIndex - 1 
    end
end

--添加记录项
function GameUIManager.InsertRecordIterm(iterm)
    table.insert(GameUIManager.mListRecord,iterm)
end

function GameUIManager.UnChangePrize(Prize)
    if Prize < 0 or Prize >= 28 then
        return -1
    end
    return GameUIManager.viewIndex[Prize+1]
end
function GameUIManager.NoteMoneyStatisticsCount(PrizeIndex)
    GameUIManager.m_PrizesCount[PrizeIndex] = GameUIManager.m_PrizesCount[PrizeIndex] + 1
    if PrizeIndex > 4 and PrizeIndex < 9 then
        --飞禽
        GameUIManager.m_PrizesCount[1] = GameUIManager.m_PrizesCount[1] + 1
    elseif PrizeIndex >= 9 then
        --走兽
        GameUIManager.m_PrizesCount[4] = GameUIManager.m_PrizesCount[4] + 1
    end
end
--更新用户的钱
function GameUIManager.RefreshUserInfo(isGame)
    isGame = isGame or false
    if MyUserInfo.uiUserID <= 0 then
    end
    --更新总下注
    local nTotalBet = 0
    local MyBets = 0
    for i=1,#GameUIManager.mMyBets do
        GameUIManager.UILb_MyBets[i].text = (GameUIManager.mMyBets[i] >0 and FormatNumToYW(MoneyProportionStr(GameUIManager.mMyBets[i])) or "")
        GameUIManager.UILb_MyBets_ZY[i].text = (GameUIManager.mTotalBets[i] >0 and FormatNumToYW(MoneyProportionStr(GameUIManager.mTotalBets[i])) or "")
        nTotalBet = nTotalBet + GameUIManager.mTotalBets[i] 
        MyBets = MyBets + GameUIManager.mMyBets[i]
    end
    if GameUIManager.UILb_AllNoteMoney then
        --GameUIManager.UILb_AllNoteMoney.text = "ZXZ"..FormatNumToYW(MoneyProportionStr(nTotalBet))
        GameUIManager.UILb_AllNoteMoney.text = FormatNumToYW(MoneyProportionStr(nTotalBet))
    end
    if GameUIManager.UILb_MyMoney then
        if not isGame then
            GameUIManager.SetUpdateWallet(tonumber(tostring(MyUserInfo.iMoney))-MyBets)
        else
            GameUIManager.SetUpdateWallet(tonumber(tostring(MyUserInfo.iMoney)))
        end
    end
    GameUIManager.LbOnLinePlayer.text = ""..#GameUIManager.onLineUserList
    --GameUIManager.RefreshZhuangInfo()
end
--更新庄家信息
function GameUIManager.RefreshZhuangInfo()
    -- if GameUIManager.StationZhuang ~= -1 and GameUIManager.StationZhuang ~= 255 then
    --     local zhuangData = GameUIManager.GetUserByStation(GameUIManager.StationZhuang)
    --     if zhuangData ~= nil then
    --         GameUIManager.LbZhuangName.text = zhuangData.szNickName
    --         GameUIManager.LbZhuangMoney.text = FormatNumToYW(MoneyProportionStr(zhuangData.iMoney))
    --         GameUIManager.UpdateBankerLV(zhuangData.iVipLevel)
    --     else
    --         print(false,"玩家为空！"..GameUIManager.StationZhuang)
    --     end
    -- else
    --     GameUIManager.LbZhuangName.text = ""
    --     GameUIManager.LbZhuangMoney.text = ""
    --     GameUIManager.UpdateBankerLV("")
    -- end
    -- if GameUIManager.StationZhuang == MyUserInfo.iDeskStation then
    --     if GameUIManager.IconUserZhuangOrXian then
    --         GameUIManager.IconUserZhuangOrXian.spriteName = "UI_GameSign_Zhuang"
    --     end
    --     GameUIManager.btnShangZhuang.gameObject:SetActive(false)
    --     GameUIManager.btnXiaZhuang.gameObject:SetActive(true)
    -- else
    --     if GameUIManager.IconUserZhuangOrXian then
    --         GameUIManager.IconUserZhuangOrXian.spriteName = "UI_GameSign_Xian"
    --     end
    --     if GameUIManager.ListContains(GameUIManager.ZhuangList,MyUserInfo.iDeskStation) then
    --         GameUIManager.btnShangZhuang.gameObject:SetActive(false)
    --         GameUIManager.btnXiaZhuang.gameObject:SetActive(true)
    --     else
    --         GameUIManager.btnShangZhuang.gameObject:SetActive(true)
    --         GameUIManager.btnXiaZhuang.gameObject:SetActive(false)
    --     end
    -- end
    -- GameUIManager.LbWaitCount.text = ""..#GameUIManager.ZhuangList
    -- GameUIManager.LbOnLinePlayer.text = ""..#GameUIManager.onLineUserList
end
--飞金币动画
function GameUIManager.PlayGoldAnimation(userId,formPos,areaIndex,checkIndex,time)
    if time == nil then
        time = 0.3
    end
    local goldAnima = GameUIGoldManager.CreatGold(userId,FormatNumToYW(MoneyProportionStr(GameUIManager.mChips[checkIndex])),checkIndex,areaIndex)
    goldAnima.transform.localScale = Vector3.New(1, 1, 1)
    goldAnima:GotoPosition(formPos, GameUIManager.Obj_Bets[areaIndex+1].transform.localPosition, time)
end
--续压飞金币
function GameUIManager.ContinuePlayGoldGruop(deskStation,money,areaIndex)
    local checkIndexList = {}
    GameUIManager.GetBetNumPrefabNameList(money,checkIndexList)
    for i=1,#checkIndexList do
        if deskStation == MyUserInfo.iDeskStation then
            GameUIManager.PlayGoldAnimation(MyUserInfo.uiUserID, GameUIManager.BtnBets[checkIndexList[i]].transform.localPosition, areaIndex, checkIndexList[i])
        else
            GameUIManager.PlayGoldAnimation(GameUIManager.GetUserByStation(deskStation).uiUserID, GameUIManager.BtnBets[checkIndexList[i]].transform.localPosition, areaIndex, checkIndexList[i])
        end
    end
end

--断线设置金币
function GameUIManager.SetExistGoldPos(money,areaIndex)
    local checkIndexList = {}
    GameUIManager.GetBetNumPrefabNameList(money,checkIndexList)
    for i=1,#checkIndexList do
        local goldAnima = GameUIGoldManager.CreatGold(0,FormatNumToYW(MoneyProportionStr(GameUIManager.mChips[checkIndexList[i]])),checkIndexList[i],areaIndex)
        goldAnima:SetPosition(GameUIManager.Obj_Bets[areaIndex+1].transform.localPosition)
    end
end
function GameUIManager.GetBetNumPrefabNameList(money,checkIndexList,limitCount)
    if limitCount == nil then
        limitCount = 30
    end
    while money > 0 do
        if money < GameUIManager.mChips[1] then
            table.insert(checkIndexList,1)
            break
        end
        for i=#GameUIManager.mChips,1,-1 do
            if money >= GameUIManager.mChips[i] then
                money = money - GameUIManager.mChips[i]
                if #checkIndexList < limitCount then
                    table.insert(checkIndexList,i)
                end
                break
            end
        end
    end
end
function GameUIManager.OneByOnePlayGoldAnimation(OpenPrizeIndex,prizeMoney)
    local TotalCount = GameUIManager.getIntPart(prizeMoney / GameUIManager.mChips[1])
    local myMoney = 0
    local myCountlist = {}
    local otherCountlist = {}
    local allCountList = {}

    local mLimitMyCount = 20
    local mLimitOtherCount = 40
    if GameUIManager.mMyBets[OpenPrizeIndex+1] > 0 then
        myMoney = GameUIManager.mMyBets[OpenPrizeIndex+1] *GameUIManager.mBase[OpenPrizeIndex+1]
        
        GameUIManager.GetBetNumPrefabNameList(myMoney,myCountlist,mLimitMyCount)
        
        for i=1,#myCountlist do
            table.insert(allCountList,myCountlist[i])
        end
    end
    local otherMoney = prizeMoney - myMoney
    GameUIManager.GetBetNumPrefabNameList(otherMoney,otherCountlist,mLimitOtherCount)
    for i=1,#otherCountlist do
        table.insert(allCountList,otherCountlist[i])
    end
  
    TotalCount = #allCountList
    local snopFromPos = GameUIManager.ZhuangPos
    local snopToPos = GameUIManager.Obj_Bets[OpenPrizeIndex+1].transform.localPosition
    local IndexCount = math.ceil(TotalCount/10.0)
    for i=1,TotalCount do
        local goldAnima = GameUIGoldManager.CreatGold(0,FormatNumToYW(MoneyProportionStr(GameUIManager.mChips[allCountList[i]])),allCountList[i],OpenPrizeIndex)
        goldAnima.transform.localScale = Vector3.New(1, 1, 1)
        goldAnima.transform.localPosition = snopFromPos

        if i < #myCountlist then
            goldAnima:AllotGoldOne(snopFromPos, snopToPos, GameUIManager.MyMoneyPos)
            myMoney = myMoney - GameUIManager.mChips[1]
        else
            goldAnima:AllotGoldOne(snopFromPos, snopToPos, GameUIManager.XianPos)
        end
        if i % IndexCount == 0 then
        end
    end
end
function GameUIManager.YieldPlayFlyGold()
    coroutine.wait(0.5)
    GameUIGoldManager.RevokePosition()
    coroutine.wait(0.5)
    if #GameUIManager.mLastIndex > 0 then
        for i=1,#GameUIManager.mLastIndex do
            local animaIndex = GameUIManager.View2BetIndex(GameUIManager.mLastIndex[i])
            local prizeMoney = GameUIManager.mTotalBets[animaIndex] * GameUIManager.mBase[animaIndex]
            if prizeMoney > 0 then
                print("---飞金币---",i,animaIndex,GameUIManager.FeiQinOrZouShou(animaIndex),prizeMoney,GameUIManager.mLastIndex[i])
                --PlayGameMusic(GoldAudio[1]);
                GameAudioContro.Play("Public/"..GameUIManager.GoldAudio[2]..".u3d")
                coroutine.start(GameUIManager.OneByOnePlayGoldAnimation,animaIndex, prizeMoney)
            end
            if animaIndex ~= 2 then
                local animaIndex1 = GameUIManager.FeiQinOrZouShou(animaIndex) 
                local prizeMoney1 = GameUIManager.mTotalBets[animaIndex1+1] * GameUIManager.mBase[animaIndex1+1]
                if prizeMoney1 > 0 then
                    coroutine.start(GameUIManager.OneByOnePlayGoldAnimation,animaIndex1, prizeMoney1)
                end
            end
        end
    end 
    coroutine.wait(0.8)
    GameUIGoldManager.RevokePlayerPos()
end
-- function GameUIManager.StringFormDouble(score)
--     local num = tonumber(score)
--     local value = tostring(num)
--     local rideValue = 1
--     if ( num < 0 ) then
--         num = num * -1
--         rideValue = -1
--     end
--     if ( num >= 1000 ) then
--         if ( num >= 100000000 ) then
--             local v = math.floor(num / 1000000)/100
--             value = tostring(v * rideValue).."Y"
--         elseif num >= 10000 then
--             local v = math.floor(num / 100)/100
--             value = tostring(v * rideValue).."W"
--         else
--             local v = math.floor(num / 10)/100
--             value = tostring(v * rideValue).."Q"
--         end
--     end
--     return value
-- end
function GameUIManager.StringFormDouble1(score)
    -- local num = tonumber(score)
    -- local value = tostring(num)
    -- local rideValue = 1
    -- if ( num < 0 ) then
    --     num = num * -1
    --     rideValue = -1
    -- end
    -- if ( num >= 1000 ) then
    --     if ( num >= 100000000 ) then
    --         local v = math.floor(num / 1000000)/100
    --         value = tostring(v * rideValue).."亿"
    --     elseif num >= 10000 then
    --         local v = math.floor(num / 100)/100
    --         value = tostring(v * rideValue).."万"
    --     else
    --         local v = math.floor(num / 10)/100
    --         value = tostring(v * rideValue).."千"
    --     end
    -- end
    -- return value
end
--0是飞禽3是走兽
function GameUIManager.FeiQinOrZouShou(animaIndex)
    if animaIndex > 3 and animaIndex < 8 then
        return 0
    elseif animaIndex > 7 and animaIndex < 12 then
        return 3
    else
        return 1
    end
end
--endregion

function GameUIManager.GetPlayerCount()
    local resultCount = 0
    local CurrPlayer = GameSUserBaseInfo.userinfolist
    for i=1,#CurrPlayer do
        if CurrPlayer[i] ~= nil then
            resultCount = resultCount + 1
        end
    end
    return resultCount
end
--根据位置获取用户
function GameUIManager.GetUserByStation(nDeskStation)
    if nDeskStation == MyUserInfo.iDeskStation then
        if MyUserInfo.iUserState ~= 4 then --旁观游戏
            return MyUserInfo
        else
            return nil
        end
    end
    for i=1,#GameSUserBaseInfo.userinfolist do
        local user = GameSUserBaseInfo.userinfolist[i]
        if user ~= nil then
            if user.iDeskStation == nDeskStation then
                if user.iUserState ~= 4 then
                    return user
                else
                    return nil
                end
            end
        end
    end
    return nil
end
function GameUIManager.ContainsByDeskStation(original,deskStation)
    for i,v in ipairs(original) do
        if v.bDeskStation == deskStation then
            return true
        end
    end
    return false
end
function GameUIManager.ContainsByUserId(original,userId)
    for i,v in ipairs(original) do
        if v.uiUserID == userId then
            return true
        end
    end
    return false
end  
function GameUIManager.ListContains(original,deskStation)
    for i,v in ipairs(original) do
        if v == deskStation then
            return true
        end
    end
    return false
end
function GameUIManager.IsInTable(tal,value)
    for k,v in pairs(tal) do
        if v.UserId == value then
            return true
        end
    end
    return false
end
function GameUIManager.GetAnimalNameByIndex(index)
    print("----动物种类------",index,GameUIManager.KindAnimal[index+1])
    local namePre = ""
    local kindAnimal =  GameUIManager.KindAnimal[index+1]
    return namePre..kindAnimal
end
--开始计时
function GameUIManager.StartClock(timeOut,isTip)
    GameUIManager.StopClockTime()
    ClockTimeCoroutine = coroutine.start(GameUIManager.ShowClockTime,timeOut,isTip)
end
function GameUIManager.ShowClockTime(nTime,isTip)--显示倒计时
    GameUIManager.Obj_TimeClock.transform.parent.gameObject:SetActive(true)
    GameUIManager.Obj_TimeClock.text = string.format("%02d", nTime)
    GameUIManager.TimeCountUITip:SetActive(false)
    local timeout = nTime
    while timeout > 0 do
        if timeout <= 3 and isTip then
            GameAudioContro.Play(GameAudioContro.countDown)
            GameUIManager.IconNum.spriteName = "Txt_DaoShu_"..timeout
            GameUIManager.TimeCountUITip:SetActive(true)
            GameUIManager.FlashTimeRay:RebuildSpriteList()
            GameUIManager.FlashTimeRay:ResetToBeginning()
        end
        coroutine.wait(1)
        if GameUIManager.transform == nil or ClockTimeCoroutine == nil then return end
        timeout = timeout - 1
        GameUIManager.Obj_TimeClock.text = string.format("%02d", timeout)
    end
    GameUIManager.TimeCountUITip:SetActive(false)
    GameUIManager.StopClockTime()
end
function GameUIManager.StopClockTime()--停止倒计时
    if ClockTimeCoroutine ~= nil then
        coroutine.stop(ClockTimeCoroutine)
        ClockTimeCoroutine = nil
    end
    GameUIManager.TimeCountUITip:SetActive(false)
    GameUIManager.Obj_TimeClock.transform.parent.gameObject:SetActive(false)
end

function GameUIManager.InitEvent()
    if not CommonBase.IsShowBank then
        GameUIManager.FirstGroup:FindChild("Menu/Icon_Box").gameObject.transform.localScale = Vector3.New(1,0.8,1)
    end
    GameUIManager.Button_Bank.gameObject:SetActive(CommonBase.IsShowBank)
    GameUIManager.Button_MainBank.gameObject:SetActive(CommonBase.IsShowBank)
    GameUIManager.Button_Chat.gameObject:SetActive(MainMenus.IsShowChat)
    UIEventListener.Get(GameUIManager.Button_Menu.gameObject).onClick = function()
    local TwpMenu = GameUIManager.FirstGroup:FindChild("Menu").gameObject:GetComponent("TweenPosition")
        if TwpMenu.transform.localPosition.y < 300 then
            GameUIManager.Button_Menu.normalSprite = "UI_BT_Down"
            TwpMenu.from = Vector3.New(514, 262, 0)
            TwpMenu.to = Vector3.New(514, 862, 0)
            TwpMenu.enabled = true
            TwpMenu:ResetToBeginning()
            TwpMenu:PlayForward()
        else
            GameUIManager.Button_Menu.normalSprite = "UI_BT_Up"
            TwpMenu.from = Vector3.New(514, 862, 0)
            TwpMenu.to = Vector3.New(514, 262, 0)
            TwpMenu.enabled = true
            TwpMenu:ResetToBeginning()
            TwpMenu:PlayForward()
        end   
        GameAudioContro.Play(GameAudioContro.button)
    end
    if GameUIManager.GoGameBack ~= nil then
        UIEventListener.Get(GameUIManager.GoGameBack).onClick = function()
            if GameUIManager.TwpMenu.transform.localPosition.x < 500 then
                GameUIManager.BtnMenu.normalSprite = "UI_BT_Left"
                GameUIManager.TwpMenu.from = Vector3.New(514, 262, 0)
                GameUIManager.TwpMenu.to = Vector3.New(514, 862, 0)
                GameUIManager.TwpMenu.enabled = true
                GameUIManager.TwpMenu:ResetToBeginning()
                GameUIManager.TwpMenu:PlayForward()
            end
        end
    end
    UIEventListener.Get(GameUIManager.Button_Exit).onClick = function()
        if GameUIManager.StationZhuang == MyUserInfo.iDeskStation then
            LblMsgText.Show("You are the banker, please leave only after placing the banker")
            return
        end
        local nTotalBet = 0
        for n=1,#GameUIManager.mMyBets do
            nTotalBet = nTotalBet + GameUIManager.mMyBets[n]
        end
        if nTotalBet > 0  then
            LblMsgText.Show("You have placed your bet! Please wait for the draw before exiting!")
        else
            MessageBox.Show("Are you sure you want to quit the game?", GameUIManager.QuitGame)
        end
        GameAudioContro.Play(GameAudioContro.button)
    end
    if GameUIManager.Button_Set then
        UIEventListener.Get(GameUIManager.Button_Set).onClick = function()
            UIGameLoad.OpenGameSet()
            GameAudioContro.Play(GameAudioContro.button)
        end
    end
    UIEventListener.Get(GameUIManager.Button_Help).onClick = function()
        GameHelp.Show(GameUIManager.iTaxVlue)
        GameAudioContro.Play(GameAudioContro.button)
    end
    UIEventListener.Get(GameUIManager.Button_Bank).onClick = function()
        if LbIsNeedBindAccount == nil then
            if IsNeedBindGuest or (AccountBindType == 3 and (Network.logintype ~= 4 or not WxRegIsNoUpgrade)) then
                LblMsgText.Show("Please go to the lobby to bind the account!")
                return
            end
            GameUIBank.Show()
        else
            if LbIsNeedBindAccount then
                LblMsgText.Show("Please go to the lobby to bind the account!")
            else
                GameUIBank.Show()
            end
        end
        GameAudioContro.Play(GameAudioContro.button)
    end
    UIEventListener.Get(GameUIManager.Button_MainBank).onClick = function()
        if LbIsNeedBindAccount == nil then
            if IsNeedBindGuest or (AccountBindType == 3 and (Network.logintype ~= 4 or not WxRegIsNoUpgrade)) then
                LblMsgText.Show("Please go to the lobby to bind the account!")
                return
            end
            GameUIBank.Show()
        else
            if LbIsNeedBindAccount then
                LblMsgText.Show("Please go to the lobby to bind the account!")
            else
                GameUIBank.Show()
            end
        end
        GameAudioContro.Play(GameAudioContro.button)
    end
    UIEventListener.Get(GameUIManager.Button_Chat).onClick = function()
        HallUIManager.OnBtnChat()
        GameAudioContro.Play(GameAudioContro.button)
        GameUIManager.IconRedDot:SetActive(false)
    end
    if GameUIManager.Button_Record then
        UIEventListener.Get(GameUIManager.Button_Record).onClick = function() --打开游戏记录
            GameAudioContro.Play(GameAudioContro.button)
            GameUIRecord.show()
        end
    end
    UIEventListener.Get(GameUIManager.BtnRecharge).onClick = GameUIManager.OpenRecharge --充值
    if GameUIManager.MainBtnRecharge then
        GameUIManager.MainBtnRecharge:SetActive(not IsClosePay)
        UIEventListener.Get(GameUIManager.MainBtnRecharge).onClick = GameUIManager.OpenRecharge --充值
    end

    if lobyUIRadio ~= nil then
        lobyUIRadio.GameChatTypeFunc = function()
            GameUIManager.IconRedDot:SetActive(true)
        end
    end
    --奖池
    -- UIEventListener.Get(GameUIManager.BtnJiangChi).onClick = GameUIManager.OpenJiangChiPlane --奖池

    --压分选项
    for i=1,#GameUIManager.BtnBets do
        UIEventListener.Get(GameUIManager.BtnBets[i]).onClick = function()
            GameAudioContro.Play(GameAudioContro.button)
            if GameUIManager.StationZhuang == MyUserInfo.iDeskStation then
                LblMsgText.Show("You are the banker, you cannot choose the chips!")
                return
            end
            GameUIManager.mCheckIndex = i
            SetParent(GameUIManager.BtnBets[GameUIManager.mCheckIndex].gameObject,GameUIManager.GoBetFocus)
        end
    end
   
    for i=1,#GameUIManager.Obj_Bets do
        UIEventListener.Get(GameUIManager.Obj_Bets[i]).onClick = GameUIManager.OnBetCallback
    end

    --上庄按钮
    -- UIEventListener.Get(GameUIManager.btnShangZhuang.gameObject).onClick = function()
    --     GameUIShangZhuangList.ShowUI(true)
    --     GameUIShangZhuangList.SetShangZhuanglistInfo(GameUIManager.LeastMoneyZhuang, GameUIManager.ZhuangList)
    -- end
    -- --下庄按钮
    -- UIEventListener.Get(GameUIManager.btnXiaZhuang.gameObject).onClick = function()
    --     GameUIShangZhuangList.ShowUI(false)
    --     GameUIShangZhuangList.SetShangZhuanglistInfo(GameUIManager.LeastMoneyZhuang, GameUIManager.ZhuangList)
    -- end

    --续押按钮
    UIEventListener.Get(GameUIManager.UIBtn_Continue.gameObject).onClick = function()
        GameAudioContro.Play(GameAudioContro.button)
        if GameUIManager.GoRecharge.gameObject.activeSelf then
            return
        end
        local snopBet = 0
        for n=1,#GameUIManager.mMyBets do
            snopBet = snopBet + GameUIManager.mMyBets[n]
            if snopBet > 0 then
                break
            end
        end
        if snopBet >0 then
            LblMsgText.Show("You have already placed a bet and cannot continue!")
            return
        end
        NetManager:SendData(2000180,GameProtocal.GM_SUB_CONTINUEPRENOTE)
    end
    --在线按钮
    UIEventListener.Get(GameUIManager.BtnOnLine.gameObject).onClick = function()
        --GameUIPlayerList.ShowUI(GameUIManager.onLineUserList)
    end

    -- 一些下注的按钮不能用
    GameUIManager.EnabledBtn(false)
    --自动
    if GameUIManager.UIBtn_Auto then
        UIEventListener.Get(GameUIManager.UIBtn_Auto.gameObject).onClick = function()
            if GameUIManager.GoRecharge.gameObject.activeSelf then
                return
            end
            local snopBet = 0
            for n=1,#GameUIManager.mMyBets do
                snopBet = snopBet + GameUIManager.mMyBets[n]
                if snopBet > 0 then
                    break
                end
            end
            if snopBet == 0  then
                LblMsgText.Show("Please bet first!")
                return
            end
            GameUIManager.IsAuto = true
            GameUIManager.SetAutoStation(GameUIManager.IsAuto)
        end
    end
    if GameUIBank.UIBtn_CancelAuto then
        --取消自动
        UIEventListener.Get(GameUIManager.UIBtn_CancelAuto.gameObject).onClick = function()
            GameUIManager.IsAuto = false
            GameUIManager.SetAutoStation(GameUIManager.IsAuto)
        end
        GameUIManager.SetAutoStation(GameUIManager.IsAuto)
    end
end

function GameUIManager.SetAutoStation(isAuto)
    if GameUIBank.UIBtn_Auto then
        GameUIManager.UIBtn_Auto.gameObject:SetActive(not isAuto)   -- 自动
    end
    if GameUIBank.UIBtn_CancelAuto then
        GameUIManager.UIBtn_CancelAuto.gameObject:SetActive(isAuto) -- 取消自动 
    end
end
--所有的下注按钮能不能点
function GameUIManager.EnabledBtn(bEnabled)
    --下注按钮
    for i=1,#GameUIManager.Obj_Bets do
        GameUIManager.Obj_Bets[i]:GetComponent("BoxCollider").enabled = bEnabled
        GameUIManager.Obj_Bets[i].transform:FindChild("BackGround").gameObject:GetComponent("UISprite").color = Color.New(1,1,1,0)
    end
    GameUIManager.UIBtn_Continue.isEnabled = bEnabled--续押按钮
    if GameUIBank.UIBtn_Auto then
        GameUIManager.UIBtn_Auto.isEnabled = bEnabled--自动
    end
    if GameUIBank.UIBtn_CancelAuto then
        GameUIManager.UIBtn_CancelAuto.isEnabled = bEnabled--取消自动
    end
end
function GameUIManager.QuitGame()
    UIRoom.QuitGame()
end
function GameUIManager.OnBetCallback(obj)
    GameAudioContro.Play(GameAudioContro.button)
    if GameUIManager.mStation ~= GameUIManager.GameState.GAMESTATE_NOTE then
        LblMsgText.Show("Currently not betting stage!")
        return
    end
    if GameUIManager.StationZhuang == -1 or GameUIManager.StationZhuang == 255 then
        LblMsgText.Show("No banker, no betting!")
        return
    end
    if GameUIManager.StationZhuang == MyUserInfo.iDeskStation then
        LblMsgText.Show("You are banker, you cannot bet!")
    end
    if GameUIManager.GoRecharge.activeSelf then 
        return
    end
    local index = 0
    for i=1,#GameUIManager.Obj_Bets do
        if GameUIManager.Obj_Bets[i].gameObject == obj then
            index = i
        end
    end
    GameProtocal.CMD_GM_NoteData[1].data = MyUserInfo.iDeskStation
    GameProtocal.CMD_GM_NoteData[2].data = index-1 --AreaIndex
    GameProtocal.CMD_GM_NoteData[3].data = GameUIManager.mCheckIndex-1  --NoteKind
    GameProtocal.CMD_GM_NoteData[4].data = GameUIManager.mChips[GameUIManager.mCheckIndex] --NoteMoney
    local sendbet = DataParseLua.StructToBytes(GameProtocal.CMD_GM_NoteData)
    NetManager:SendData(sendbet, 2000180, GameProtocal.GM_SUB_NOTE)
end

--获取筹码的字符串
function GameUIManager.GetChouMaStr(chouMa)

    local v= tonumber(chouMa)
    local str = ""
    if v >= 10000 then --万
        str = tostring(v / 10000) .. "W"
    elseif v >= 1000 and v < 10000 then --千
        str = tostring(v / 1000) .. "K"
    else
        str = tostring(v)
    end

    return  str
end
function GameUIManager.GetRandomPostion(v)
    local vx = math.random(v.x - 50, v.x + 50)
    local vy = math.random(v.y - 10, v.y + 20)
    return Vector3.New(vx, vy, 0)
end
function GameUIManager.GetRandomDesktopPostion(v)
    local vx = math.random(v.x - 20, v.x + 20)
    local vy = math.random(v.y, v.y + 30)
    return Vector3.New(vx, vy, 0)
end
function GameUIManager.StopComCoroutine()
    if ComCoroutine ~= nil then
        coroutine.stop(ComCoroutine)
    end
    ComCoroutine = nil
end
function GameUIManager.OnDestroy()
    GameLogic.OnDestroy()
    GameUIManager.StopComCoroutine()
    UpdateBeat:Remove(GameUIManager.UpData)
    GameUIManager.StopClockTime()
    GameRecord.OnDestroy()
    GameUIGoldManager.OnDestroy()
    coroutine.stop(GameUIManager.PlayGameMusic)
    coroutine.stop(GameUIManager.StartAnimalAnimation)
    coroutine.stop(GameUIManager.RunBigPrizeListAnimation)
    for i=1,#GameUIManager.UIEntity do
        GameUIManager.UIEntity[i]:OnDestroy()
    end
    package.loaded["606.GameUIManager"] = nil
    package.loaded["606.GameLogic"] = nil
    package.loaded["606.GameResult"] = nil
    package.loaded["606.GameUIPlayerList"] = nil
    package.loaded["606.GameUIShangZhuangList"] = nil
    package.loaded["606.GameUIAnimation"] = nil
    package.loaded["606.GameUIBank"] = nil
    package.loaded["606.GameUISet"] = nil
    package.loaded["606.GameUIRecord"] = nil
    package.loaded["606.GameUIDetail"] = nil
    package.loaded["606.GameBankerResult"] = nil
end

function GameUIManager.getIntPart(x)--取整
    if x <= 0 then
        return math.ceil(x)
    end
    if math.ceil(x) == x then
        x = math.ceil(x)
    else
        x = math.ceil(x) - 1
    end
    return x
end

function GameUIManager.ShowGameUIDetail(detaidates)--打开游戏记录详情
    GameAudioContro.Play(GameAudioContro.button)
    GameUIDetail.show(detaidates)
end
function GameUIManager.LimitNote(data)--限制下注
    local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.SUB_GM_Limit)  
    iLowNoteLimit = tonumber(tostring(msg.iLimitVlue))
    if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
        GameUIManager.ShowRecharge()
    else
        GameUIManager.HideRecharge()
    end
end

function GameUIManager.OpenRecharge()
    HallUIManager.OnBtnRecharge()
end
function GameUIManager.ShowRecharge()
    local msg="In observation mode, you need [86F351FF]"..FormatNumToYW(MoneyProportionStr(iLowNoteLimit)).."[-] gold coins to participate in the game"
    GameUIManager.LbRecharge.text =msg
    GameUIManager.GoRecharge:SetActive(true)
end
function GameUIManager.HideRecharge()
    GameUIManager.GoRecharge:SetActive(false)
end
-- 爆池列表
function GameUIManager.SetBtnJiangChiState(state)
    -- if (not state) then
    --     GameUIManager.BtnJiangChi:SetActive(false)
    -- end
end
function GameUIManager.PoolDataRefresh(data)
    -- local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolData_Fresh)  
    -- GameUIManager.ipoolMoney = msg.iPoolMoney
    -- GameUIManager.LbJiangChi.text = GameUIManager.StringFormDouble(MoneyProportionStr(GameUIManager.ipoolMoney))
    -- if (GameUIJiangChi~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdatePoolData(GameUIManager.ipoolMoney)
    --     end
    -- end
end
function GameUIManager.PoolDataDistrubute(data) 
    -- GameUIManager.prizeList = {}
    -- local nLen = DataParseLua.GetLuaTableLength(GameProtocal.CMD_GR_PoolData_Distrubute)
    -- local count = data.mainMsg.Length / nLen
    -- local isMyDesk = false
    -- print("*****************"..debug.getinfo(1).name..count)
    -- for i=1,count do
    --     local snopBytes = MyLuaInter.NewArray("byte", nLen)
    --     System.Array.Copy(data.mainMsg, (i-1) * nLen, snopBytes, 0, nLen)
    --     local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.CMD_GR_PoolData_Distrubute)   
    --     local userInfo = GameSUserBaseInfo.finduserbyid(cmdBigWin.uUserId)
    --     if (userInfo == nil) then
    --         return
    --     end
    --     if (MyUserInfo.iDeskNO == cmdBigWin.uDeskId) then
    --         local prizeInfoItem = {userInfo.szNickName,tostring(cmdBigWin.uPoolMoney), userInfo.iImageNO, cmdBigWin.uCardType,cmdBigWin.uUserId}
    --         table.insert(GameUIManager.prizeList,prizeInfoItem)
    --         isMyDesk = true
    --     end

    --     local nowTime = System.DateTime.Now.Hour..":"..System.DateTime.Now.Minute..":"..System.DateTime.Now.Second
    --     local jiangChiIinfoItem = {tostring(cmdBigWin.uPoolMoney), userInfo.szNickName, nowTime, userInfo.iImageNO, cmdBigWin.uCardType}
    --     if (#GameUIManager.jiangChiList>= 11) then
    --         table.remove(GameUIManager.jiangChiList,1)
    --     end
    --     table.insert(GameUIManager.jiangChiList,jiangChiIinfoItem)
    -- end
    -- if (GameUIJiangChi ~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdateUI(GameUIManager.jiangChiList)
    --     end
    -- end

    -- if (isMyDesk) then
    --     isMyDesk = false
    --     local obj = UnityEngine.GameObject.Instantiate(GameUIManager.GoWinPool)
    --     obj:SetActive(true)
    --     SetParent(GameUIManager.SecondGroup.gameObject, obj)
    --     GameUIWinPool.transform = obj.transform
    --     GameUIWinPool.Awake()
    --     GameUIWinPool.ShowUi()
    --     GameUIWinPool.UpdateUI(GameUIManager.prizeList)
    --     UnityEngine.GameObject.Destroy(obj, 3)
    -- end
end
function GameUIManager.PoolConfig(data)
    -- local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolConfig)  
    -- GameUIManager.SetBtnJiangChiState(msg.cbPoolSwitch == 1)
    -- if(msg.TaxKind == 2) then
    --     GameUIManager.iTaxVlue = msg.Tax
    -- else
    --     GameUIManager.iTaxVlue = 0
    -- end
    -- local config = MyLuaInter.NewArray("byte", msg.CardTypeProCount)
    -- System.Array.Copy(data.mainMsg, 0, config, 0, msg.CardTypeProCount)
    -- if (GameUIJiangChi ~= nil) then
    --     GameUIJiangChi.SetPlane(config,msg.iFetchPercent)
    -- end
end
function GameUIManager.PoolRecord(data)
    GameUIManager.jiangChiList = {}
    local nLen = DataParseLua.GetLuaTableLength(GameProtocal.SUB_GM_PoolRecord)
    local count = data.mainMsg.Length / nLen
    if (count > 10) then
        count = 10
    end
    for i=1,count do
        local snopBytes = MyLuaInter.NewArray("byte", nLen)
        System.Array.Copy(data.mainMsg, (count - i) * nLen, snopBytes, 0, nLen)
        local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.SUB_GM_PoolRecord)   
        local dTime = LuaInter.ByteArrayToString(cmdBigWin.sTime)
        local uName = LuaInter.ByteArrayToString(cmdBigWin.sName)
        local infoItem = {tostring(cmdBigWin.iPoolMoney), uName, dTime, cmdBigWin.cbFace, cmdBigWin.bCardType}
        table.insert(GameUIManager.jiangChiList,infoItem)
    end
end
function GameUIManager.OpenJiangChiPlane()
    -- if (GameUIJiangChi ~= nil) then
    --     if (not GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.transform.gameObject:SetActive(true)
    --         GameUIJiangChi.ShowUi(GameUIManager.ipoolMoney)
    --         GameUIJiangChi.UpdateUI(GameUIManager.jiangChiList)
    --     end
    -- end
end
function GameUIManager.FormatNumToKW(money)
    local iFu = 1
    local note = tonumber(money)
    if note < 0 then
        iFu = -1
        note = note * -1
    end
    local v = note
    local str = ""
    --[[
    if v >= 1000 and v < 10000 then--
        str = string.format("%dK",(v / 1000))
        --str = string.format("%0.2f",(v / 1000)).."K"
    elseif v >= 10000 then 
        ]]
    if v >= 10000 then 
        str = string.format("%dW",(v / 10000))
    else
        str = tostring(v)
    end
    if iFu < 0 then
        str = "-"..str
    end

    return str
end