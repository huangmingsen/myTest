local GamePlayerInfo = require "606.GamePlayerInfo"
local GameUIShangZhuangList = 
{
    BtnShangZhuang,
    BtnXiaZhuang,
    LbLeastMoney,
    LbShangZhuangCount,
    colliderBlack,

    ItemParent,
    Obj_Pos,--路单
    Obj_Iterm,--路单项
    Close,

    listSZIterm = {},--路单项

    mPlayerStation = {},

    mViewPos,--视图位置  
    isShow = false,
}
function GameUIShangZhuangList.Awake()
    GameUIShangZhuangList.BtnShangZhuang = FindChildByName(GameUIShangZhuangList.transform,"UI_Group/Button_ShangZhuang","UIButton")
    GameUIShangZhuangList.colliderBlack = FindChildByName(GameUIShangZhuangList.transform,"BlackCollider","Collider")
    if GameUIShangZhuangList.BtnShangZhuang then
        UIEventListener.Get(GameUIShangZhuangList.BtnShangZhuang.gameObject).onClick = GameUIShangZhuangList.BtnShangZhuangPress
    end
    GameUIShangZhuangList.BtnXiaZhuang = FindChildByName(GameUIShangZhuangList.transform,"UI_Group/Button_XiaZhuang","UIButton")
    if GameUIShangZhuangList.BtnXiaZhuang then
        UIEventListener.Get(GameUIShangZhuangList.BtnXiaZhuang.gameObject).onClick = GameUIShangZhuangList.BtnXiaZhuangPress
    end
    GameUIShangZhuangList.LbLeastMoney = FindChildByName(GameUIShangZhuangList.transform,"UI_Group/Label_Coin","UILabel")

    GameUIShangZhuangList.LbShangZhuangCount = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Label_Num","UILabel")
    GameUIShangZhuangList.Close = FindChildByName(GameUIShangZhuangList.transform,"UI_Group/BtnClose","gameObject")
    UIEventListener.Get(GameUIShangZhuangList.Close.gameObject).onClick = GameUIShangZhuangList.HideUI


    GameUIShangZhuangList.Obj_Pos = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Zhuang_ScrollView","gameObject")
    GameUIShangZhuangList.ItemParent = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Zhuang_ScrollView/Zhuang_Grid","gameObject")
    GameUIShangZhuangList.Obj_Iterm = FindChildByName(GameUIShangZhuangList.transform, "UI_Group/Zhuang_ScrollView/Item_Zhuang","gameObject")
    GameUIShangZhuangList.mViewPos = GameUIShangZhuangList.Obj_Pos.transform.localPosition
    GameUIShangZhuangList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(0,0)
end
function GameUIShangZhuangList.BtnShangZhuangPress()
    GameProtocal.CMD_GM_NtInfo[1].data = 0
    GameProtocal.CMD_GM_NtInfo[2].data = MyUserInfo.iDeskStation
    local sendrob = DataParseLua.StructToBytes(GameProtocal.CMD_GM_NtInfo)
    NetManager:SendData(sendrob,2000180,GameProtocal.GM_SUB_NT_INFO)
end
function GameUIShangZhuangList.BtnXiaZhuangPress()
    GameProtocal.CMD_GM_NtInfo[1].data = 1
    GameProtocal.CMD_GM_NtInfo[2].data = MyUserInfo.iDeskStation
    local sendrob = DataParseLua.StructToBytes(GameProtocal.CMD_GM_NtInfo)
    NetManager:SendData(sendrob,2000180,GameProtocal.GM_SUB_NT_INFO)
end
function GameUIShangZhuangList.ShowUI(ShangOrXiaZhuang)
    if ShangOrXiaZhuang == nil then
        ShangOrXiaZhuang = true
    end
    if ShangOrXiaZhuang then
        GameUIShangZhuangList.BtnShangZhuang.gameObject:SetActive(true)
        GameUIShangZhuangList.BtnXiaZhuang.gameObject:SetActive(false)
    else
        GameUIShangZhuangList.BtnShangZhuang.gameObject:SetActive(false)
        GameUIShangZhuangList.BtnXiaZhuang.gameObject:SetActive(true)
    end
    --恢复
    if not GameUIShangZhuangList.isShow then
        GameUIShangZhuangList.isShow = true
        GameUIShangZhuangList.colliderBlack.enabled = true
        GameUIShangZhuangList.Obj_Pos.transform.localPosition = GameUIShangZhuangList.mViewPos
        GameUIShangZhuangList.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameUIShangZhuangList.Obj_Pos.transform.position.x, 0)
        GameUIShangZhuangList.transform.gameObject:SetActive(true)
        GameUIShangZhuangList.transform.gameObject:GetComponent("Animation"):Play("Show")
    end
end
function GameUIShangZhuangList.SetShangZhuanglistInfo(leastMoney,playerStationList)
    GameUIShangZhuangList.LbLeastMoney.text = FormatNumToYW(MoneyProportionStr(leastMoney))
    GameUIShangZhuangList.LbShangZhuangCount.text = ""..#playerStationList
    GameUIShangZhuangList.mPlayerStation = {}
    for i=1,#playerStationList do
        GameUIShangZhuangList.mPlayerStation[i] = playerStationList[i]
    end

    if GameUIManager.ListContains(GameUIShangZhuangList.mPlayerStation,MyUserInfo.iDeskStation) or GameUIManager.StationZhuang == MyUserInfo.iDeskStation then
        GameUIShangZhuangList.BtnShangZhuang.gameObject:SetActive(false)
        GameUIShangZhuangList.BtnXiaZhuang.gameObject:SetActive(true)
    else
        GameUIShangZhuangList.BtnShangZhuang.gameObject:SetActive(true)
        GameUIShangZhuangList.BtnXiaZhuang.gameObject:SetActive(false) 
    end
    GameUIShangZhuangList.UpdateRecord()    
end
function GameUIShangZhuangList.HideUI()
    --恢复
    if GameUIShangZhuangList.isShow then
        GameUIShangZhuangList.isShow = false
        GameUIShangZhuangList.colliderBlack.enabled = false
        GameUIShangZhuangList.transform.gameObject:SetActive(false)
        GameUIShangZhuangList.transform.gameObject:GetComponent("Animation"):Play("Hide")
    end

end
--路单项
function GameUIShangZhuangList.GetLDItermObj(nIndex)
    if GameUIShangZhuangList.Obj_Iterm == nil then
    	print("------------------>>>>>>>UpdateRecord ==>>Obj_Iterm  路单项 null ! ")
    	return nil
    end
    if nIndex <= #GameUIShangZhuangList.listSZIterm then
        GameUIShangZhuangList.listSZIterm[nIndex].gameObject:SetActive(true)
        GameUIShangZhuangList.ItemParent:GetComponent("UIGrid"):Reposition()
        return GameUIShangZhuangList.listSZIterm[nIndex]
    end
    local Obj = UnityEngine.GameObject.Instantiate(GameUIShangZhuangList.Obj_Iterm)
    Obj.name = "iterm"..nIndex
    Obj:SetActive(true)

    SetParent(GameUIShangZhuangList.ItemParent, Obj)
    Obj.transform.localPosition = Vector3.New(0,0,0)
    Obj.transform.localScale = Vector3.New(1,1,1)
    GameUIShangZhuangList.ItemParent:GetComponent("UIGrid"):Reposition()

    local iterm = GamePlayerInfo:new(Obj.transform)
    iterm:InitUI()
    table.insert(GameUIShangZhuangList.listSZIterm,iterm)
    return iterm
end
--更新跟单记录
function GameUIShangZhuangList.UpdateRecord()
	for i=1,#GameUIShangZhuangList.listSZIterm do
        GameUIShangZhuangList.listSZIterm[i].gameObject:SetActive(false)
    end
    local tempBankerList = {}
    for i=1,#GameUIShangZhuangList.mPlayerStation do
        local user = GameUIManager.GetUserByStation(GameUIShangZhuangList.mPlayerStation[i])
        if user ~= nil then
            table.insert(tempBankerList,user)
            --[[
            local uiRecordItem = GameUIShangZhuangList.GetLDItermObj(i)
            if uiRecordItem ~= nil then
                uiRecordItem:SetInfo1(user.szNickName, user.iMoney,i,user.iVipLevel)
            end 
            ]]
        else
            print(string.format("==>>station%d==>Index%d  SUserBaseInfo user is null ! ", GameUIShangZhuangList.mPlayerStation[i],i))
        end
    end
    table.sort(tempBankerList, function(a,b) return a.iMoney > b.iMoney end)
    for i=1,#tempBankerList do
        local uiRecordItem = GameUIShangZhuangList.GetLDItermObj(i)
        if uiRecordItem ~= nil then
            uiRecordItem:SetInfo1(tempBankerList[i].szNickName, tempBankerList[i].iMoney,i,tempBankerList[i].iVipLevel)
        end 
    end
    coroutine.start(GameUIShangZhuangList.WaitRePosition)
end
function GameUIShangZhuangList.WaitRePosition()
    coroutine.wait(0.2)
    GameUIShangZhuangList.ItemParent:GetComponent("UIGrid"):Reposition()
end
return GameUIShangZhuangList