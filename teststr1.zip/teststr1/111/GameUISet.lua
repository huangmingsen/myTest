local GameUISet =
{
	TogMusic = nil,
	TogSound = nil,
	CheckmarkMusic = nil,
	BackgroundMusic = nil,
	CheckmarkSound = nil,
	BackgroundSound = nil,
}

function GameUISet.Awake()
	GameUISet.TogMusic = FindChildByName(GameUISet.transform,"BtnMusic","UIToggle")
	GameUISet.TogSound = FindChildByName(GameUISet.transform,"BtnSound","UIToggle")

	GameUISet.CheckmarkMusic = FindChildByName(GameUISet.TogMusic.transform,"CheckMark","gameObject")
	GameUISet.CheckmarkSound = FindChildByName(GameUISet.TogSound.transform,"CheckMark","gameObject")
	GameUISet.BackgroundMusic = FindChildByName(GameUISet.TogMusic.transform,"Background","gameObject")
	GameUISet.BackgroundSound = FindChildByName(GameUISet.TogSound.transform,"Background","gameObject")

	GameUISet.TogMusic.onChange:Add(EventDelegate.New(GameUISet.OnTogMusic))
	GameUISet.TogSound.onChange:Add(EventDelegate.New(GameUISet.OnTogSound))

	GameUISet.TogMusic.value = soundMgr.CanPlayBackSound
	GameUISet.TogSound.value = soundMgr.CanPlaySoundEffect
	GameUISet.OnTogMusic()
	GameUISet.OnTogSound()
end

function GameUISet.OnTogMusic()
	soundMgr.CanPlayBackSound = GameUISet.TogMusic.value
	GameUISet.CheckmarkMusic:SetActive(GameUISet.TogMusic.value)
	GameUISet.BackgroundMusic:SetActive(not GameUISet.TogMusic.value)
	print("---背景音乐--",GameUISet.TogMusic.value)
	if UIGameLoad ~= nil and UIGameLoad.GameManage ~= nil then
	print("---背景音乐--",GameUISet.TogMusic.value)
		UIGameLoad.GameManage:Action_ResetBGVolume()
	print("---背景音乐--",GameUISet.TogMusic.value)
	end
end

function GameUISet.OnTogSound()
	soundMgr.CanPlaySoundEffect = GameUISet.TogSound.value
	GameUISet.CheckmarkSound:SetActive(GameUISet.TogSound.value)
	GameUISet.BackgroundSound:SetActive(not GameUISet.TogSound.value)
	print("---音效--",GameUISet.TogSound.value)
	if UIGameLoad ~= nil and UIGameLoad.GameManage ~= nil then
	print("---音效--",GameUISet.TogSound.value)
		UIGameLoad.GameManage:Action_ResetBGVolume()
	end
	print("---音效--",GameUISet.TogSound.value)
end
return GameUISet
