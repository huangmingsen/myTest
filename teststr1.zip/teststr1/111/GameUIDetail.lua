local bit = require"bit"
local GameUIDetail =
{
	BtnClose,
	Label_AllDown,
	Label_AllWin,
	Label_Win,
	Label_Lose,
	ItemData = {},
	IconShangCards = {},
	IconXiaCards = {},
	IconIsNtTitle = {},
	LeftTitle1,
	LeftTitle2,
	CenterTitle,
	RightTitle,
}

function GameUIDetail.Awake()
	GameUIDetail.ItemData = {}
	for i=1,12 do
		if GameUIDetail.ItemData[i] == nil then
			GameUIDetail.ItemData[i] = {}
			local gobj = FindChildByName(GameUIDetail.transform, "UI_Group/Detail_Team/Item_"..i,"gameObject")
			GameUIDetail.ItemData[i].itemobj = gobj
			GameUIDetail.ItemData[i].Label_Xian = FindChildByName(gobj.transform, "Label_Xian","UILabel")
			GameUIDetail.ItemData[i].Label_Infor = FindChildByName(gobj.transform, "Label_Infor","UILabel")
			GameUIDetail.ItemData[i].Label_BeiLv = FindChildByName(gobj.transform, "Label_BeiLv","UILabel")
		end
	end
	GameUIDetail.BtnClose = FindChildByName(GameUIDetail.transform, "UI_Group/BtnClose","gameObject")
	GameUIDetail.Label_AllDown = FindChildByName(GameUIDetail.transform,"UI_Group/Label_AllDown","UILabel")
	GameUIDetail.Label_AllWin = FindChildByName(GameUIDetail.transform,"UI_Group/Label_AllWin","UILabel")
	GameUIDetail.Label_Win = FindChildByName(GameUIDetail.transform,"UI_Group/Label_Win","UILabel")
	GameUIDetail.Label_Lose = FindChildByName(GameUIDetail.transform,"UI_Group/Label_Lose","UILabel")
	GameUIDetail.LeftTitle1 = FindChildByName(GameUIDetail.transform, "UI_Group/ImageBG/Font_Title0","gameObject")
	GameUIDetail.LeftTitle2 = FindChildByName(GameUIDetail.transform, "UI_Group/ImageBG/Font_Title1","gameObject")
	GameUIDetail.CenterTitle = FindChildByName(GameUIDetail.transform, "UI_Group/ImageBG/Font_Title2","UISprite")
	GameUIDetail.RightTitle = FindChildByName(GameUIDetail.transform, "UI_Group/ImageBG/Font_Title3","UISprite")
	UIEventListener.Get(GameUIDetail.BtnClose).onClick = GameUIDetail.Hide
	GameUIDetail.transform.gameObject:SetActive(false)
end

function GameUIDetail.show(detaidates)
	for i=1,12 do
		if i <= #detaidates.Data then
	        GameUIDetail.ItemData[i].Label_Xian.text = FormatNumToYW(MoneyProportionStr(detaidates.Data[i].Note))
	        GameUIDetail.ItemData[i].Label_Infor.text = detaidates.Data[i].Win and "Yes" or "No" 
	        GameUIDetail.ItemData[i].Label_BeiLv.text = ""..detaidates.Data[i].Point
		end
	end
	GameUIDetail.Label_AllDown.text = FormatNumToYW(MoneyProportionStr(detaidates.Note))
	GameUIDetail.Label_AllWin.text = FormatNumToYW(MoneyProportionStr(detaidates.Win))
	if detaidates.Real >= 0 then
		GameUIDetail.Label_Win.gameObject:SetActive(true)
		GameUIDetail.Label_Lose.gameObject:SetActive(false)
		GameUIDetail.Label_Win.text = FormatNumToYW(MoneyProportionStr(detaidates.Real))
	else
		GameUIDetail.Label_Win.gameObject:SetActive(false)
		GameUIDetail.Label_Lose.gameObject:SetActive(true)
		GameUIDetail.Label_Lose.text = FormatNumToYW(MoneyProportionStr(detaidates.Real))
	end
	GameUIDetail.LeftTitle1:SetActive(false)
	GameUIDetail.LeftTitle2:SetActive(false)
	--自己是庄家
	if detaidates.IsNt then
    	GameUIDetail.LeftTitle1:SetActive(true)
       	GameUIDetail.CenterTitle.spriteName = "Txt_Detail_KJ"
    	GameUIDetail.RightTitle.spriteName = "Txt_Detail_ZSY"
		GameUIDetail.Label_AllWin.text = FormatNumToYW(MoneyProportionStr(detaidates.Open))
    else

    	GameUIDetail.LeftTitle2:SetActive(true)
    	GameUIDetail.CenterTitle.spriteName = "Txt_Detail_ZYF"
    	GameUIDetail.RightTitle.spriteName = "Txt_Record_SJSY"
		GameUIDetail.Label_AllWin.text = FormatNumToYW(MoneyProportionStr(detaidates.Win))
    end
    GameUIDetail.CenterTitle:MakePixelPerfect()
    GameUIDetail.RightTitle:MakePixelPerfect()
	GameUIDetail.transform.gameObject:SetActive(true)
	GameUIDetail.transform.gameObject:GetComponent("Animation"):Play("Show")
end 

function GameUIDetail.Hide()
	GameUIDetail.transform.gameObject:GetComponent("Animation"):Play("Hide")
	GameUIDetail.transform.gameObject:SetActive(false)
end
return GameUIDetail