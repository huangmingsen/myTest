local GameLogic = require "606.GameLogic"
local GameHelp = require "606.GameHelp"
-- local GameUIJiangChi = require "606.GameUIJiangChi"
-- local GameUIWinPool = require "606.GameUIWinPool"
local GameUIRecord = require "606.GameUIRecord"
local GameUIDetail = require "606.GameUIDetail"
local GameResult = require "606.GameResult"
local GameUIAnimation = require "606.GameUIAnimation"
local GameTimeClock = require "606.GameTimeClock"
local GameUIEntity = require "606.GameUIEntity"
local GameRecord = require "606.GameRecord"
local GameUIPlayerList = require "606.GameUIPlayerList"
local GameUIShangZhuangList = require "606.GameUIShangZhuangList"
local GameUIGoldManager = require "606.GameUIGoldManager"
local GameUIBank = require "606.GameUIBank"
local GameUISet = require "606.GameUISet"
local GameBankerResult = require "606.GameBankerResult"

GameUIManager = 
{
    FirstGroup,
    SecondGroup,

    Button_Menu,--菜单
    Button_Exit,
    Button_Set,
    Button_Help,
    Button_MainBank,
    Button_Bank,
    Button_Chat,--聊天
    IconRedDot,
    Button_Record,

    IconGameLevel,
    
    Lb_MyVip,
    UILb_MyMoney,--玩家身上的钱

    UILb_AllNoteMoney,--所有下注金额
    --UILb_LastWinLose,--上次输赢
    UILb_Base,--倍数
   
    BtnBets = {},-- 压分列表
    GoBetFocus,

    UIBtn_Continue,--续押按钮

    UIBtn_Auto,--自动
    UIBtn_CancelAuto,-- 取消自动 

    Obj_Bets = {},--下注组按钮

    UILb_MyBets = {},--自己下注
    UILb_MyBets_ZY = {},--玩家总押
    UILb_Bases = {},--倍率组

    Obj_TimeClock, --时钟
    TimeCountUITip,
    IconNum,
    FlashTimeRay,

    Obj_Flash = {}, --闪动画 
    WinRay = {},
    UIEntity = {},

    LeastMoneyZhuang = -1,
    LeastGamesZhuang = -1,
    PeviousZhuangStation = -1,
    StationZhuang = -1,

    mZhuangWinLose = 0,--庄输赢钱

    mWinLose = 0, --第一次开奖
    mSecondWinLose = 0, --第二次开奖

    mCaiJinPoint = 0, -- 彩金

    mCurPrizeIndex = 0, --当前开奖项
    mLastPrizeIndex = 0, --最后开奖项
    --要开奖的列表
    mListPrize = {},
    --已经开出的奖列表
    mLastIndex = {},

    playerCount = 255,
    mMaxWinMoneyStation = {},
    mMaxWinSouce = {},


    mMyBets = {},--自己下注 
    mTotalBets = {},--总下注

    mBase = { 2, 24, 24, 2, 4, 8, 8, 12, 12, 8, 8, 4 },--当前的倍率 
    mChips = {},--筹码列表
    viewIndex = { 1, 8, 8, 8, 9, 9, 9, 2, 10, 10, 10, 11, 11, 11, 1, 4, 4, 4, 5, 5, 5, 2, 6, 6, 6, 7, 7, 7 },

    mCheckIndex = 1,--下注下标
    isShowAllUI = false,

    m_PrizesCount = {},--概率统计
    m_CurGameCount = 0,--总下注
    GoGameBack,

    BetsName = {"FeiQin","Jinsha","Yinsha","Zoushou","Yan","Gezi","Kongque","Ying","Shizi","Xiongmao","Houzi","Tuzi"},
    --播放声音列表
    listAudio = {},
    --动物声
    AnimationAudio = 
    { 
        "/Audio/Game/OpenPrize_FeiQin", "/Audio/Game/Animation_JinYinSa",     "/Audio/Game/Animation_JinYinSa", "/Audio/Game/OpenPrize_ZouShou",
        "/Audio/Game/Animation_YanZi",  "/Audio/Game/Animation_GeZi",         "/Audio/Game/Animation_KongQue",  "/Audio/Game/Animation_LaoYin", 
        "/Audio/Game/Animation_ShiZi",  "/Audio/Game/Animation_XiongMao",     "/Audio/Game/Animation_HouZi",    "/Audio/Game/Animation_TuZi" 
    },

    --开奖声金沙银沙
    SoundOpenPrizeJinYin = "/Audio/Game/OpenPrize_JinYin",
    --开奖声飞禽走兽
    SoundOpenPrizeFeiZou = "/Audio/Game/OpenPrize_FeiZou",
    --人声
    PeopleAudio = 
    { 
        "/Audio/Game/People_FeiQin", "/Audio/Game/People_JinSa",    "/Audio/Game/People_YinSa",   "/Audio/Game/People_ZouShou", 
        "/Audio/Game/People_YanZi",  "/Audio/Game/People_GeZi",     "/Audio/Game/People_KongQue", "/Audio/Game/People_LaoYin", 
        "/Audio/Game/People_ShiZi",  "/Audio/Game/People_XiongMao", "/Audio/Game/People_HouZi",   "/Audio/Game/People_TuZi"
    },
    --金币音效
    GoldAudio = 
    {
        "/Audio/Game/Note", "/Audio/Game/coins"
    },
    mStation = 0,--游戏状态  

    mListRecord = {},--开奖记录

    AllPlayerInfoTag = {},

    IsHuanZhuang = false,

    --是否自动
    IsAuto = false,

    --记录本局开奖 记录
    CurrentPrize = {},
    --用来防止多次修改钱包的钱
    isLockZXZFlag = false,
    --用来解决进入游戏在开奖状态时，记录重复的问题，如为true则已经记录过这个结果了
    isReshowrecord = false,
    --是否隐藏loading
    IsHideLoading = false,

    BtnOnLine,
    TwpMenu,
    btnShangZhuang,
    btnXiaZhuang,
    LbWaitCount,
    LbZhuangName,
    LbZhuangMoney,
    LbZhuangVipLevel,
    LbOnLinePlayer,
    StartDownBet,
    StopDownBet,
    ZhuangList = {},

    uiShangZhuangList,

    IconOpenPrizeAnima,
    IconOpenPrizeTxt,
    IconOpenPrizeBet,
    TipGroup,

    LbUserName,
    IconUserZhuangOrXian,

    GoldItemParent,
    IconBetSprite,
    IconBetNum,
    playerList,
    goldManager,
    XianPos = Vector3.New(-592.2, -209.3, 0),
    ZhuangPos = Vector3.New(-52.3, 139.7, 0),
    MyMoneyPos = Vector3.New(-591.1, -329.4, 0),

    onLinePlayer = {},
    onLineUserList = {},

    GameState = 
    {
        GAMESTATE_NONE = 0, --闲置
        GAMESTATE_NOTE = 1,--下注
        GAMESTATE_OPENPRIZE = 2,--开奖
        GAMESTATE_SETTLEMENT = 3,--结算
        GAMESTATE_WAITNEXT = 4,--等待
        GAMESTATE_MAX = 5
    },
    ---------------------------
    GoWinPool,
    BtnJiangChi,
    jiangChiList = {},
    prizeList = {},
    ipoolMoney = 0,
    iTaxVlue = 0,
    LbJiangChi,  
    PrizeData = {},

    BtnRecharge,
    LbRecharge,
    GoRecharge,
    ----------------------------
    SeverTex = 0,

    KindAnimal =
    {
        --[Description( "飞禽" )]1
        "FeiQin",
        --[Description( "金鲨" )]2
        "JS",
        --[Description( "银鲨" )]3
        "YS",
        --[Description( "走兽" )]4
        "ZouShou",
        --[Description( "燕子" )]5
        "Yan",
        --[Description( "鸽子" )]6
        "Ge",
        --[Description( "孔雀" )]7
        "Kongque",
        --[Description( "老鹰" )]8
        "Ying",
        --[Description( "狮子" )]9
        "Lion",
        --[Description( "熊猫" )]10
        "Panda",
        --[Description( "猴子" )]11
        "Monkey",
        --[Description( "兔子" )]12
        "Rabit",
    },
    MainBtnRecharge,
    isFirstJionGame,

    CallBack = nil,

    CurDuration = 5,--时长
    BlinkCarIconTeam = {},
    Car_Team = {},
    Car_Ray = {},

    CurSpeed = 0,--当前速度
    MaxSpeed = 1.8,--最大速度
    MinSpeed = 0.06,--最小速度
    DownSpeedStep = 24,--减速的步数
    TotalStep = 0,--总步数
    CurStep = 0,--当前步数

    LastPrizeIndex = 0,--上次 开奖索引
    CurPrizeIndex = 0,--此次 开奖
    CarTeamCount = 0,--车标数量  
    Duration = 0,
    CurPerTime = 1000,
    Factor = 0.0,
    PrizeIndex = 0,

}
local ComCoroutine = nil
local ClockTimeCoroutine = nil
local a1 = 0.017
local a2 = 0.3
local a3 = 0.5
local Jisu = 0.016
local JiasuSpeed = 0.02

local tep = 5
local jiansuTep = 3
local iLowNoteLimit = 0 --最低限注
local this=GameUIManager
function GameUIManager.InitUI()
    this.FirstGroup = this.transform:FindChild("UIRoot/UIGame/Main")
    this.SecondGroup = this.transform:FindChild("UIRoot/PanelSecond")

    this.Button_Menu = this.FirstGroup:FindChild("Game_Right/BtnMenu").gameObject:GetComponent("UIButton")
    this.Button_Exit = this.FirstGroup:FindChild("Game_Left/Button_Exit").gameObject
    this.Button_Set = FindChildByName(this.FirstGroup,"Menu/Content/Button_Set","gameObject")
    this.Button_Help = this.FirstGroup:FindChild("Menu/Content/Button_Help").gameObject
    -- this.Button_Bank = this.FirstGroup:FindChild("Menu/Content/Button_Bank").gameObject
    -- this.Button_MainBank = this.FirstGroup:FindChild("Game_Down/Player_Team/Button_Bank").gameObject
    -- this.Button_Chat = this.FirstGroup:FindChild("Game_Right/BtnChat").gameObject
    -- this.IconRedDot = this.FirstGroup:FindChild("Game_Right/BtnChat/IconRedDot").gameObject
    this.Button_Record = this.FirstGroup:FindChild("Menu/Content/Button_Record").gameObject
    this.UILb_MyMoney = this.FirstGroup:FindChild("Game_Down/Player_Team/LbMyGold").gameObject:GetComponent("UILabel")--玩家身上的钱
    this.Lb_MyVip = this.FirstGroup:FindChild("Game_Down/Player_Team/LbVip").gameObject:GetComponent("UILabel")
    this.IconHead = this.FirstGroup:FindChild("Game_Down/Player_Team/ImHead"):GetComponent("UISprite")

    this.UILb_AllNoteMoney = FindChildByName(this.FirstGroup,"Game_Center/UIBet/Label_CurrGameBet","UILabel")--所有下注金额
    this.UILb_Base = this.FirstGroup:FindChild("PanelAni/Label_Base").gameObject:GetComponent("UILabel")--倍数
   
    this.BtnBets = {}-- 压分列表
    for i=1,6 do
        this.BtnBets[i] = this.FirstGroup:FindChild("Game_Down/CM_Group/Button_CM"..(i-1)).gameObject
    end
    this.GoBetFocus = this.FirstGroup:FindChild("Game_Down/CM_Group/Check_Ray").gameObject

    this.UIBtn_Continue = this.FirstGroup:FindChild("Game_Down/Button_XuTou").gameObject:GetComponent("UIButton")  --续押按钮

    this.UIBtn_Auto = FindChildByName(this.FirstGroup,"Game_Center/UIBet/Button_Auto","UIButton")--自动
    this.UIBtn_CancelAuto = FindChildByName(this.FirstGroup,"Game_Center/UIBet/Button_AutoCancel","UIButton")-- 取消自动 

    this.Obj_Bets = {}--下注组按钮
    for i=1,12 do
        this.Obj_Bets[i] = this.FirstGroup:FindChild("Game_Center/UIBet/Button_"..this.BetsName[i]).gameObject
        this.WinRay[i] = this.FirstGroup:FindChild("Game_Center/Win_Ray_Ani/"..this.BetsName[i]).gameObject
        this.FirstGroup:FindChild("Game_Center/UIBet/Button_"..this.BetsName[i].."/BackGround").gameObject:GetComponent("UISprite").color = Color.New(1,1,1,0)
    end
    this.UILb_MyBets = {}--自己下注
    this.UILb_MyBets_ZY = {}--玩家总押
    this.UILb_Bases = {}--倍率组  
    for i=1,#this.Obj_Bets do
        this.UILb_MyBets[i] = this.Obj_Bets[i].transform:FindChild("Label_TZ_Me").gameObject:GetComponent("UILabel") 
        this.UILb_MyBets_ZY[i] = this.Obj_Bets[i].transform:FindChild("Label_TZ_Player").gameObject:GetComponent("UILabel") 
        this.UILb_Bases[i] = this.Obj_Bets[i].transform:FindChild("Label_TZ_Base").gameObject:GetComponent("UILabel") 
        this.mMyBets[i] = 0
        this.mTotalBets[i] = 0
    end
 
    this.Obj_TimeClock = this.FirstGroup:FindChild("Game_Center/Clock/Label_Time").gameObject:GetComponent("UILabel")
    this.TimeCountUITip = this.FirstGroup:FindChild("Time_Count").gameObject
    this.IconNum = this.FirstGroup:FindChild("Time_Count/Icon_Num1").gameObject:GetComponent("UISprite")
    this.FlashTimeRay = this.FirstGroup:FindChild("Time_Count/Flash_Time_Ray").gameObject:GetComponent("UISpriteAnimation")
    this.Obj_Flash = {} --闪动画 
    for i=1,28 do
        local flashName = ""
        if i == 1 or i == 15 then
            flashName = "JS_"..string.format("%02d",i/15 + 1).."/FlashLight"
        elseif i == 8 or i == 22 then
            flashName = "YS_"..string.format("%02d",i/22 + 1).."/FlashLight"
        elseif i <=15 then
            flashName = "ZS_"..string.format("%02d",i - i/7).."/FlashLight"
        else
            if i == 21 then
                flashName = "FQ_"..string.format("%02d",7).."/FlashLight"
            elseif i == 28 then
                flashName = "FQ_"..string.format("%02d",1).."/FlashLight"
            else
                flashName = "FQ_"..string.format("%02d",12 - (i - i/7 -12) + 2).."/FlashLight"
            end
        end
        this.Obj_Flash[i] = this.FirstGroup:FindChild("Middle_Team/"..flashName).gameObject
        this.UIEntity[i] = GameUIEntity:new(this.Obj_Flash[i],i)
        this.UIEntity[i]:InitUI()
    end
    this.CarTeamCount = #this.UIEntity
    this.m_PrizesCount = {}
    for i=1,12 do
        this.m_PrizesCount[i] = 0
    end
    GameUIAnimation.transform = this.FirstGroup:FindChild("PanelAni")
    GameUIAnimation.Awake()

    this.BtnOnLine = this.FirstGroup:FindChild("Game_Left/BtnOnLine").gameObject:GetComponent("UIButton")
    this.TwpMenu = this.FirstGroup:FindChild("Menu/Content").gameObject:GetComponent("TweenScale")

    -- this.btnShangZhuang = this.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/Button_ShangZhuang").gameObject:GetComponent("UIButton")
    -- this.btnXiaZhuang = this.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/Button_XiaZhuang").gameObject:GetComponent("UIButton")
    -- this.LbWaitCount = this.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/Label_PaiDui").gameObject:GetComponent("UILabel")
    -- this.LbZhuangName = this.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/LbZhuangName").gameObject:GetComponent("UILabel")
    -- this.LbZhuangMoney = this.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/LbZhuangGold").gameObject:GetComponent("UILabel")
    -- this.LbZhuangVipLevel = this.FirstGroup:FindChild("Game_Center/UIBet/Zhuang_Team/LbVip").gameObject:GetComponent("UILabel")
    
    this.LbOnLinePlayer = this.FirstGroup:FindChild("Game_Left/BtnOnLine/Label_Player").gameObject:GetComponent("UILabel")
    this.StartDownBet = FindChildByName(this.FirstGroup,"Game_Center/Animal_Team/BlackBox_1","gameObject")
    this.StopDownBet = FindChildByName(this.FirstGroup,"BlackBox_0","gameObject")

    GameUIPlayerList.transform = this.SecondGroup:FindChild("Player_List")
    GameUIPlayerList.Awake()
    GameUIShangZhuangList.transform = this.SecondGroup:FindChild("Zhuang_List")
    GameUIShangZhuangList.Awake()

    this.IconOpenPrizeAnima = this.FirstGroup:FindChild("KaiJiang_Ani/Icon_Target").gameObject:GetComponent("UISprite")
    this.IconOpenPrizeTxt = this.FirstGroup:FindChild("KaiJiang_Ani/Font_GameIcon_Target").gameObject:GetComponent("UISprite")
    this.IconOpenPrizeBet = this.FirstGroup:FindChild("KaiJiang_Ani/Label_BeiLv").gameObject:GetComponent("UILabel")
    this.TipGroup = {}
    this.TipGroup[1] = this.FirstGroup:FindChild("Tips_Group/Tips_Wait").gameObject
    this.TipGroup[2] = this.FirstGroup:FindChild("Tips_Group/Tips_Start").gameObject
    this.TipGroup[3] = this.FirstGroup:FindChild("Tips_Group/Tips_Stop").gameObject
    this.TipGroup[4] = this.FirstGroup:FindChild("Tips_Group/Tips_3").gameObject
    this.TipGroup[5] = this.FirstGroup:FindChild("Tips_Group/Tips_1").gameObject
    this.TipGroup[6] = this.FirstGroup:FindChild("Tips_Group/Tips_2").gameObject

    this.LbUserName = this.FirstGroup:FindChild("Game_Down/Player_Team/LbMyName").gameObject:GetComponent("UILabel")
    this.IconUserZhuangOrXian = FindChildByName(this.FirstGroup,"Game_Down/Player_Team/Label_MyName/Icon_Sign","UISprite")

    this.GoldItemParent = this.FirstGroup:FindChild("GoldParent").gameObject
    this.IconBetSprite = this.FirstGroup:FindChild("GoldParent/Background").gameObject:GetComponent("UISprite")
    this.IconBetNum = this.FirstGroup:FindChild("GoldParent/IconNum").gameObject:GetComponent("UISprite")
    this.GoGameBack = this.transform:FindChild("UIRoot/UIGame/UIStretch/Group/GameBG" ).gameObject

    this.IconGameLevel = this.FirstGroup:FindChild("Game_Left/Icon_Level_Target").gameObject:GetComponent("UISprite")
    this.IconGameLevel.spriteName = "Txt_ChangCi"..CommonBase.iRoomLevel+1

    GameHelp.transform = this.SecondGroup:FindChild("UIHelp")
    GameHelp.Awake()
    GameUIBank.transform = this.SecondGroup:FindChild("GameBank")
    GameUIBank.Awake()
    GameUISet.transform = FindChildByName(this.FirstGroup,"Menu/Content")
    GameUISet.Awake()
    GameResult.transform = this.SecondGroup:FindChild("UIJiesuan")
    GameResult.Awake()
    GameRecord.transform = this.FirstGroup:FindChild("Game_Right/LZ Scroll View")
    GameRecord.Awake()
    GameUIGoldManager.transform = this.FirstGroup:FindChild("GoldParent")
    GameUIGoldManager.Awake()
    GameUIGoldManager.transform.gameObject:SetActive(false)
    

    GameUIRecord.transform = this.SecondGroup:FindChild("GameUIRecord")
    GameUIRecord.Awake()
    GameUIDetail.transform = this.SecondGroup:FindChild("GameUIDetail")
    GameUIDetail.Awake()
    GameBankerResult.transform = FindChildByName(this.SecondGroup,"UIJiesuan_Zhuang")
    if GameBankerResult.transform then
        GameBankerResult.Awake()
    end

    this.WinPanel={
		_Obj=FindChildByName(this.SecondGroup,"Animation_Win","gameObject"),
		_lblNick=FindChildByName(this.SecondGroup,"Animation_Win/Headbox/Label_Name","UILabel"),
		_lblWinMoney=FindChildByName(this.SecondGroup,"Animation_Win/Headbox/Label_Money","UILabel"),
		_headSprite=FindChildByName(this.SecondGroup,"Animation_Win/Headbox/ImHead","UISprite"),
	}
	this.WinPanel._Obj:SetActive(false)

    this.BtnRecharge = FindChildByName(this.FirstGroup, "CZ_Tips/BtnRecharge","gameObject")
    this.LbRecharge = FindChildByName(this.FirstGroup, "CZ_Tips/Label_Tips","UILabel")
    this.GoRecharge = FindChildByName(this.FirstGroup, "CZ_Tips","gameObject")

    --this.BtnJiangChi = this.FirstGroup:FindChild("Game_Center/BtnJiangChi").gameObject
    -- this.LbJiangChi = this.FirstGroup:FindChild("Game_Center/BtnJiangChi/Label_Coin").gameObject:GetComponent("UILabel")

    -- GameUIJiangChi.transform = this.SecondGroup:FindChild("Game_JiangChi")
    -- this.GoWinPool = this.SecondGroup:FindChild("Game_JiangChi_Win").gameObject
    -- GameUIJiangChi.Awake()
    -- this.GoWinPool.gameObject:SetActive(false)
    this.MainBtnRecharge = FindChildByName(this.FirstGroup, "Game_Left/Button_Recharge","gameObject")
    GameLogic.Awake()

    this.isFirstJionGame = true
end
function GameUIManager.Start()
    this.InitUI()
    for i=1,6 do
        this.mChips[i] = 0
    end
    this.UpdateBetInfo(this.mChips)

    this.InitEvent()
    --闪动画
    for i=1,#this.Obj_Flash do
        this.Obj_Flash[i]:SetActive(false)
    end
    --倍率
    this.UILb_Base.gameObject:SetActive(false)
    this.LbUserName.text = ""..MyUserInfo.szNickName
    this.UpDatePlayerInfo()--在线列表
    --更新倍率
    this.RefreshBase()

    --重新更新一下
    this.RefreshUserInfo(0)

    --this.UpdateStatusAudio()

    this.ShowOrHideWinAnim(false)

    GameLogic.Start()
    GameHelp.Start()
    print("--资源初始化完成，开始接收消息--")
    UIRoom.StartListenData()--资源初始化完成，开始接收消息
    print("--资源初始化完成，开始接收消息--")
    UpdateBeat:Add(this.UpData)
    this.ShowWinInfo()
end

function GameUIManager.ShowWinInfo()
	this.WinPanel._lblNick.text=MyUserInfo.szNickName
	this.WinPanel._headSprite.spriteName=GetHeadSpriteName(MyUserInfo.iImageNO)
end

function GameUIManager.PlayerSit(userInfo)--玩家坐下
    this.AddUserAttri(userInfo)
    if userInfo.uiUserID == MyUserInfo.uiUserID then
        this.UpdateUserLV(userInfo.iVipLevel)
    end
end
function GameUIManager.PlayerLeft(userInfo)--玩家离开
    this.RemoveNotOnLinePlayer(userInfo.uiUserID)
end
function GameUIManager.RefleshUserInfo(userInfo)
    if userInfo.uiUserID == MyUserInfo.uiUserID then
        this.SetUpdateWallet(userInfo.iMoney)
        this.UpdateUserLV(userInfo.iVipLevel)
        GameUIBank.ShowInfo()
    else

    end
    if this.StationZhuang ~= -1 and this.StationZhuang ~= 255 then
        if this.StationZhuang == userInfo.iDeskStation then
            this.UpdateBankerLV(userInfo.iVipLevel)
        end
    end
    this.AddUserAttri(userInfo)
    GameUIShangZhuangList.SetShangZhuanglistInfo(this.LeastMoneyZhuang,this.ZhuangList)
end
--玩家更新
function GameUIManager.UpDateSelfMoney()
    this.SetUpdateWallet(MyUserInfo.iMoney)
end
function GameUIManager.SetUpdateWallet(money)
    this.UILb_MyMoney.text = FormatNumToYW(MoneyProportionStr(money))
end
function GameUIManager.UpdateUserLV(lv)
    this.Lb_MyVip.text = ""..lv
    local HeadName = GetHeadSpriteName(MyUserInfo.iImageNO)
	this.IconHead.spriteName = HeadName
end 
function GameUIManager.UpdateBankerLV(lv)
    -- this.LbZhuangVipLevel.text = ""..lv
end 
function GameUIManager.UpDatePlayerInfo()
    local playerList = GameSUserBaseInfo.userinfolist
    local robotList = {}
    local liveList = {}
    this.onLineUserList = {}
    print("--玩家坐下---",MyUserInfo.uiUserID)
    if #this.onLineUserList == 0 then
        local info = {}
        info.UserId = MyUserInfo.uiUserID
        info.UserMoney = MyUserInfo.iMoney
        info.UserName = MyUserInfo.szNickName
        info.UserImageNO = MyUserInfo.iImageNO
        info.iPhotoFrame = MyUserInfo.iPhotoFrame
        info.iVipLevel = MyUserInfo.iVipLevel
        table.insert(this.onLineUserList,info) 
    end 
    for i = 1, #playerList do 
        if playerList[i].uiUserID ~= MyUserInfo.uiUserID then
            local info = {}
            info.UserId = playerList[i].uiUserID
            info.UserMoney = playerList[i].iMoney
            info.UserName = playerList[i].szNickName
            info.UserImageNO = playerList[i].iImageNO
            info.iPhotoFrame = playerList[i].iPhotoFrame
            info.iVipLevel = playerList[i].iVipLevel
            table.insert(this.onLineUserList,info)
        end
    end
    this.LbOnLinePlayer.text = ""..#this.onLineUserList
end
function GameUIManager.AddUserAttri(userInfo)
    if this.IsInTable(this.onLineUserList,userInfo.uiUserID) then
        for i=1,#this.onLineUserList do
            if this.onLineUserList[i].UserId == userInfo.uiUserID then
                this.onLineUserList[i].UserMoney = userInfo.iMoney
                this.onLineUserList[i].UserName = userInfo.szNickName
                this.onLineUserList[i].UserImageNO = userInfo.iImageNO
                this.onLineUserList[i].iPhotoFrame = userInfo.iPhotoFrame
                this.onLineUserList[i].iVipLevel = userInfo.iVipLevel
            end
        end
    else
        local info = {}
        info.UserId = userInfo.uiUserID
        info.UserMoney = userInfo.iMoney
        info.UserName = userInfo.szNickName
        info.UserImageNO = userInfo.iImageNO
        info.iPhotoFrame = userInfo.iPhotoFrame
        info.iVipLevel = userInfo.iVipLevel
        table.insert(this.onLineUserList,info)   
    end
    this.LbOnLinePlayer.text = ""..#this.onLineUserList
    GameUIPlayerList.ReSetData(this.onLineUserList)
end
function GameUIManager.RemoveNotOnLinePlayer(userId)
    if this.IsInTable(this.onLineUserList,userId) then
        for i=1,#this.onLineUserList do
            -- print("@@@@@@ 玩家信息:")
            -- pt(this.onLineUserList[i])
            if(this.onLineUserList[i]~=nil and this.onLineUserList[i].UserId == userId) then
                table.remove(this.onLineUserList,i)
            end
        end
    end
    this.LbOnLinePlayer.text = ""..#this.onLineUserList
    GameUIPlayerList.ReSetData(this.onLineUserList)
end
function GameUIManager.WaitShowGold()
    coroutine.wait(0.6)
    GameUIGoldManager.transform.gameObject:SetActive(true)
end
function GameUIManager.GameStation(data)--游戏状态  断线重连 1001
    if this.isFirstJionGame then
        this.FirstGroup.gameObject:GetComponent("Animation"):Play("Game_Join")
        coroutine.stop(this.WaitShowGold)
        coroutine.start(this.WaitShowGold)
    end
    this.isFirstJionGame = false

    --游戏状态
    local state = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_Station_Head)

    this.LeastMoneyZhuang = state.iNtLeastMoney
    this.LeastGamesZhuang = state.NtLeastGames
    this.PeviousZhuangStation = state.iNtStation
    this.StationZhuang = state.iNtStation
    -- this.RefreshZhuangInfo()
    this.mStation = state.bStation
    GameUIGoldManager.HideAllGoldList()
    this.ShowOrHideWinAnim(false)
    this.StopClockTime()
    GameBankerResult.Hide()
    if GameResult.transform.gameObject then
        GameResult.Hide()
    end
    --隐藏
	this.WinPanel._Obj:SetActive(false)
    this.EnabledBtn(false)
    this.ShowStateTip(this.mStation)
    print(state.bStation,"**************GameStation")
    if this.mStation == this.GameState.GAMESTATE_NOTE then
        local msg = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_Station_Note)
        --region 断线重连 下注
        GameUIAnimation.StopAnimation()
        this.InitData(msg)
        for i=1,#this.mTotalBets do
            this.SetExistGoldPos(this.mTotalBets[i], i-1)
        end
        --开始计时
        this.StartClock(getIntPart(msg.iLeftTick / 1000),true)
        this.isShowAllUI = true
        --显示下注界面 并启用下注按钮
        this.StartOrStopDownBetBG(true)
        this.EnabledBtn(true)

    --开奖
    elseif this.mStation == this.GameState.GAMESTATE_OPENPRIZE then
        --断线重连 开奖
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_OpenPrize)
        --#region 断线重连 开奖
        this.InitData(msg)

        for i=1,#this.mTotalBets do
            this.SetExistGoldPos(this.mTotalBets[i], i-1)
        end
        this.mZhuangWinLose = msg.iBankerWinMoney
        this.playerCount = msg.RankingCount
        for i=1,msg.RankingStation.Length do
            this.mMaxWinMoneyStation[i] = msg.RankingStation[i-1]
        end
        for i=1,msg.RankingMoney.Length do
            this.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end      

        this.isReshowrecord = true
        --添加记录项
        this.InsertRecordIterm(this.View2BetIndex(msg.PrePrizeIndex))
        --上一局开的奖
        this.mLastPrizeIndex = msg.PrePrizeIndex
        table.insert(this.mLastIndex,this.mLastPrizeIndex)
        --最后赢钱
        this.mWinLose = msg.iWinLose
        ComCoroutine = coroutine.start(this.WaitOpenPrize,msg.mSpecialPrize, msg.PrePrizeIndex, msg.iWinLose, msg.iLeftTick / 1000.0)
        this.StartClock(getIntPart(msg.iLeftTick / 1000),false)
    --结算
    elseif this.mStation == this.GameState.GAMESTATE_SETTLEMENT then
        --断线重连 结算
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Settlement)
        this.InitData(msg)
        this.playerCount = msg.RankingCount
        for i=1,msg.RankingStation.Length do
            this.mMaxWinMoneyStation[i] = msg.RankingStation[i-1]
        end
        for i=1,msg.RankingMoney.Length do
            this.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end
        this.mZhuangWinLose = msg.iBankerWinMoney

        --上一局开的奖
        this.mLastPrizeIndex = msg.PrePrizeIndex
        table.insert(this.mLastIndex,this.mLastPrizeIndex)

        --非金鲨，修改图片
        this.Obj_Flash[this.mLastPrizeIndex+1]:SetActive(true)
        --不消隐
        local alpha = this.Obj_Flash[this.mLastPrizeIndex+1]:GetComponent("TweenAlpha")
        alpha.enabled = false

        this.mWinLose = msg.iWinLose
        local animaIndex = this.View2BetIndex(this.mLastPrizeIndex)

        local animaName = this.GetAnimalNameByIndex(animaIndex)
        if this.StationZhuang ~= -1 and this.StationZhuang ~= 255 then
            if GameResult.transform.gameObject then
                if msg.mSpecialPrize == 255 then
                    GameResult.Show(this.mWinLose, this.mZhuangWinLose, this.StationZhuang, this.mMaxWinMoneyStation, this.mMaxWinSouce, this.playerCount,animaName)
                else
                    GameResult.Show(this.mWinLose, this.mZhuangWinLose, this.StationZhuang, this.mMaxWinMoneyStation, this.mMaxWinSouce, this.playerCount,animaName)
                end
            end
        end
        this.StartClock(getIntPart(msg.iLeftTick / 1000),false)
    --下一局
    elseif 0 < data.mainMsg.Length then
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Wait)
        --断线重连 下一局
        --倍率
        print("---------------")
        for i = 1,#this.mBase do
            this.mBase[i] = msg.iNotePoint[i-1]
        end
        --筹码
        for i = 1,msg.iCanSelectNotes.Length do
            this.mChips[i] = msg.iCanSelectNotes[i-1]
        end
        print("---------------")
        for i = 1,12 do
            this.mMyBets[i] = 0 --每个下注区域的下注额度
            this.mTotalBets[i] = 0 --每个下注区域的下注额度
        end
        print("---------------")
        --关闭下注界面，并禁用功能操作按钮
        if this.IsShowBetUi then
            this.HideUiBet()
        end
        GameResult.Hide()
    end
    this.UpdateBetInfo(this.mChips)
    this.RefreshBase()
    this.RefreshUserInfo()
    this.ChooseBetIndex()--匹配筹码
    print("-------断线重连------Over")
end
function GameUIManager.InitData(msg)
    --倍率
    for i=1,#this.mBase do
        this.mBase[i] = msg.iNotePoint[i-1]
    end
    --筹码
    for i=1,msg.iCanSelectNotes.Length do
        this.mChips[i] = msg.iCanSelectNotes[i-1]
    end
    --更新下注
    for i=1,12 do
        this.mMyBets[i] = msg.SelfAreaNotes[i-1]--每个下注区域的下注额度
        this.mTotalBets[i] = msg.AreaNotes[i-1]
    end
    --路单
    this.mListRecord = {}
    local data = 255
    local nBegin = (msg.mCurRecordIndex + 1) % msg.mRecordData.Length
    if msg.mCurRecordIndex < 0 then
        --现在修改得有时候会死
        msg.mCurRecordIndex = msg.mRecordData.Length - 1
    end
    while nBegin ~= msg.mCurRecordIndex do
        data = msg.mRecordData[nBegin]
        if 255 ~= data then
            table.insert(this.mListRecord,this.View2BetIndex(data))
        end
        nBegin = (nBegin + 1)%msg.mRecordData.Length
    end
    --最后一个
    data = msg.mRecordData[msg.mCurRecordIndex]
    if 255 ~= data then
        table.insert(this.mListRecord,this.View2BetIndex(data))
    end
    GameRecord.ReSet(this.mListRecord)
end
function GameUIManager.GameStateUpdate(data) --游戏状态更新 1004
    --游戏状态
    local state = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_StateUpdate)
    this.mStation = state.iState
    this.ShowStateTip(this.mStation)
    if this.mStation == this.GameState.GAMESTATE_NOTE then --游戏状态更新
        this.ShowOrHideWinAnim(false)
        local msg = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_StateUpdate_Note)
        --#region 下注
        if GameResult.transform.gameObject then
            GameResult.Hide()
        end
        GameBankerResult.Hide()
        GameUIGoldManager.HideAllGoldList()--隐藏所有注码
        this.isLockZXZFlag = false
        --用这个来刷新下当前金币，防止金币与服务器不同步
        NetManager:SendData(2000180, GameProtocal.GM_SUB_CANCELCURNOTE)
        this.ChooseBetIndex()--匹配筹码
        GameUIAnimation.StopAnimation()

        --停止所有的动画
        this.StopAnimalAnimation()

        GameUIAnimation.StopAnimation()
        this.isShowAllUI = true
        --[[
        if not GameAudioContro.bgaudiosource.isPlaying then
            GameAudioContro.bgaudiosource:Play()
        end
        ]]
        if GameAudioContro.SoundEffect.isPlaying then
            GameAudioContro.SoundEffect:Stop()
        end
        --region 新的一局开始了，把正在播背景动画的停止并显示
        local entity
        if #this.CurrentPrize ~= 0 then
            entity = this.UIEntity[this.CurrentPrize[#this.CurrentPrize]+1]
            entity:OnlyShowBG()
            if #this.CurrentPrize > 1 then
                entity = this.UIEntity[this.CurrentPrize[#this.CurrentPrize-1]+1]
                entity:Flash_Show(false)
            end
        end
        --倍率
        for i = 1,#this.mBase do
            this.mBase[i] = msg.BasePoint[i-1]
        end
        this.RefreshBase()
        --路单
        if #this.mListRecord <= 0 then
            local data = 255
            local nBegin = ( msg.mCurRecord + 1 ) % msg.RecordData.Length
            if msg.mCurRecord < 0 then
                --现在修改得有时候会死
                msg.mCurRecord = msg.mCurRecord.Length - 1
            end
            while nBegin ~= msg.mCurRecord do
                data = msg.RecordData[nBegin]
                if 255 ~= data then
                    table.insert(this.mListRecord,this.View2BetIndex(data))
                end
                nBegin = (nBegin + 1)%msg.RecordData.Length
            end
            --最后一个
            data = msg.RecordData[msg.mCurRecord]
            if 255 ~= data then
                table.insert(this.mListRecord,this.View2BetIndex(data))
            end
            GameRecord.ReSet(this.mListRecord)
        end
        --开始计时
        this.StartClock(getIntPart(msg.Tick / 1000),true)
        --更新下注
        for i = 1,#this.mMyBets do
            this.mMyBets[i] = 0 --每个下注区域的下注额度
        end
        for i = 1,#this.mTotalBets do
            this.mTotalBets[i] = 0 --每个下注区域的下注额度
        end
        this.PeviousZhuangStation = this.StationZhuang
        this.RefreshUserInfo(0)
        --上一局收益
        this.mWinLose = 0
        this.mSecondWinLose = 0                      --第二次开奖

        this.mCaiJinPoint = 0
        if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
            this.ShowRecharge()
            this.IsAuto = false
            this.SetAutoStation(this.IsAuto)
        else
            this.HideRecharge()
        end
        --自动下注
        this.StartOrStopDownBetBG(true)
        this.EnabledBtn( true )
        if not this.IsAuto or this.mStation ~= this.GameState.GAMESTATE_NOTE then
            print(state.iState,"**************GameStation      Over")
            return
        end
        --显示下注界面 并启用下注按钮
        NetManager:SendData(2000180, GameProtocal.GM_SUB_CONTINUEPRENOTE)
        --所有按钮都停止
        for n=1,#this.Obj_Flash do
            --[[
            if UnityEngine.WrapMode.Once ~= this.Obj_Flash[n]:GetComponent("Animation").wrapMode then
                this.Obj_Flash[n]:GetComponent("Animation").wrapMode = UnityEngine.WrapMode.Once
            end
            ]]
        end
        print("-----更新下注----",#this.mMyBets)
    elseif this.mStation == this.GameState.GAMESTATE_OPENPRIZE then --开奖
        local msg = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_StateUpdate_OpenPrize)
        --上一局收益
        this.mWinLose = msg.WinLoseMoney--第一次开奖
        this.mSecondWinLose = msg.SecondWinLoseMoney--第二次开奖
        this.mCaiJinPoint = msg.mCaiJinPoint--先保存彩金倍率 
        this.mZhuangWinLose = msg.iBankerWinMoney
        this.playerCount = msg.RankingCount
        for i=1,msg.RankingStation.Length do
            this.mMaxWinMoneyStation[i] = msg.RankingStation[i-1]
        end
        for i=1,msg.RankingMoney.Length do
            this.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end
        this.m_CurGameCount = this.m_CurGameCount + 1
        if this.m_CurGameCount > 100 then
            for i=1,#this.m_PrizesCount do
                this.m_PrizesCount[i] = 0
            end
            this.mListRecord = {}
            this.m_CurGameCount = 0
        end
        this.CurrentPrize = {}
        for i=1,msg.PrizeIndex.Length do
            local prize = msg.PrizeIndex[i-1]
            if prize >= 0 then
                table.insert(this.mListPrize,prize)
                table.insert(this.CurrentPrize,prize)
                --开奖记录插入路单
                this.InsertRecordIterm(this.View2BetIndex(prize))
            end
        end
        this.isReshowrecord = false
        --统计开奖次数
        this.NoteMoneyStatisticsCount(this.UnChangePrize(msg.PrizeIndex[0]))
        if msg.PrizeIndex[1] > 0 then
            this.NoteMoneyStatisticsCount(this.UnChangePrize(msg.PrizeIndex[1]))
        end
        --上一局开奖的索引
        this.mLastIndex = {}

        --开始游戏逻辑处理
        this.StartGame()

        --关闭下注界面，并禁用功能操作按钮
        this.StartOrStopDownBetBG(false)
        this.EnabledBtn(false)
        this.StartClock(getIntPart(msg.Tick / 1000),false)
    --结算
    elseif this.mStation == this.GameState.GAMESTATE_SETTLEMENT then
        local msg = DataParseLua.BytesToStruct(data.mainMsg,GameProtocal.CMD_GM_StateUpdate_Settlement)
        --更新路单
        if not this.isReshowrecord then
            GameRecord.ReSet(this.mListRecord)
        end
        -- this.RefreshZhuangInfo()
        this.isLockZXZFlag = true
        GameUIGoldManager.HideAllGoldList()
    end
    print(state.iState,"**************GameStation      Over")

end
function GameUIManager.GameNote(msg) --玩家下注 1006
    if msg.NoteMoney <= 0 then
        print( "下注为负数！" , msg.NoteMoney)
    end
    if -1 <= msg.NoteMoney and msg.NoteMoney <= 0 then
        if MyUserInfo.iDeskStation == msg.nDeskStation then
            LblMsgText.Show(msg.NoteMoney < 0 and "Betting limit exceeded!" or "Your gold coins are insufficient, the bet failed!")
        end
    else
        this.mTotalBets[msg.AreaIndex+1] = this.mTotalBets[msg.AreaIndex+1] + msg.NoteMoney
        if MyUserInfo.iDeskStation == msg.nDeskStation then
            this.mMyBets[msg.AreaIndex+1] = this.mMyBets[msg.AreaIndex+1] + msg.NoteMoney

            if tonumber(tostring(MyUserInfo.iMoney)) < msg.NoteMoney then
                print("异常，身上的钱为负数！") 
            end
            for i=1,#this.mChips do
                if this.mChips[i] == msg.NoteMoney then
                    --PlayGameMusic(GoldAudio[0]);
                    GameAudioContro.Play("Public/"..this.GoldAudio[1]..".u3d")
                    this.PlayGoldAnimation(MyUserInfo.uiUserID, this.BtnBets[i].transform.localPosition, msg.AreaIndex, i)
                    break
                end      
            end
        else
            for i=1,#this.mChips do
                if this.mChips[i] == msg.NoteMoney then
                    --PlayGameMusic(GoldAudio[0]);
                    GameAudioContro.Play("Public/"..this.GoldAudio[1]..".u3d")
                    this.PlayGoldAnimation(this.GetUserByStation(msg.nDeskStation).uiUserID, this.XianPos, msg.AreaIndex, i)
                    break
                end
            end
        end
        this.RefreshUserInfo()
    end
end
function GameUIManager.GameKeyNote(data) --键盘下注 1007
end
function GameUIManager.GameContiuePreNote(msg) --续押 1008
    for i=1,msg.AreaNoteMoney.Length do
        this.mTotalBets[i] = this.mTotalBets[i] + msg.AreaNoteMoney[i-1]
        if msg.nDeskStation == MyUserInfo.iDeskStation then
            this.mMyBets[i] = this.mMyBets[i] + msg.AreaNoteMoney[i-1]
            if tonumber(tostring(MyUserInfo.iMoney)) < msg.AreaNoteMoney[i-1] then
                print( "异常，身上的钱为负数！" )
            else
                
            end
        end
        if msg.AreaNoteMoney[i-1] > 0 then
            this.ContinuePlayGoldGruop(msg.nDeskStation,msg.AreaNoteMoney[i-1], i-1)
        else
            print( "下注为负数！" , msg.AreaNoteMoney[i-1])
        end
    end
    this.RefreshUserInfo()
end
function GameUIManager.GameCancelCurNote(msg) --取消之前的下注 1009
    for i=1,msg.NoteMoney.Length do
        this.mTotalBets[i] = this.mTotalBets[i] + msg.NoteMoney[i-1]
        if msg.nDeskStation == MyUserInfo.iDeskStation and msg.NoteMoney[i-1] ~= 0 then
            this.mMyBets[i] = this.mMyBets[i] + msg.NoteMoney[i-1]
            if tonumber(tostring(MyUserInfo.iMoney)) < msg.NoteMoney[i-1] then
                print( "异常，身上的钱为负数！" )
            end
        end
    end
    GameUIGoldManager.RemoveGold(MyUserInfo.uiUserID)
    --更新下注
    this.RefreshUserInfo()
end
function GameUIManager.GameNtInfo(ntInfoData) --庄家列表 1010
    --0:上庄 1:下庄  2：切换庄家   10:上庄钱不足 11：本局结束后就可以下庄    >20  (还差多少局)
    print("--庄家列表 1010---",ntInfoData.state,ntInfoData.bDeskStation,MyUserInfo.iDeskStation)
    -- if ntInfoData.state == 0 then
    --     if not this.ListContains(this.ZhuangList,ntInfoData.bDeskStation) then
    --         table.insert(this.ZhuangList,ntInfoData.bDeskStation)
    --     end
    --     if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
    --         this.btnShangZhuang.gameObject:SetActive(false)
    --         this.btnXiaZhuang.gameObject:SetActive(true)
    --         --GameUIShangZhuangList.SetShangZhuanglistInfo(this.LeastMoneyZhuang,this.ZhuangList)
    --     end  
    -- elseif ntInfoData.state == 1 then
    --     if this.ListContains(this.ZhuangList,ntInfoData.bDeskStation) then
    --         for i=1,#this.ZhuangList do
    --             if this.ZhuangList[i] == ntInfoData.bDeskStation then
    --                 table.remove(this.ZhuangList,i)
    --                 break
    --             end
    --         end
    --     end
    --     if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
    --         this.btnShangZhuang.gameObject:SetActive(true)
    --         this.btnXiaZhuang.gameObject:SetActive(false)
    --         --GameUIShangZhuangList.SetShangZhuanglistInfo(this.LeastMoneyZhuang,this.ZhuangList)
    --     end
    -- elseif ntInfoData.state == 2 then
    --     if this.StationZhuang ~= nil and this.StationZhuang ~= -1 and this.StationZhuang ~= 255 then
    --         this.ShowNoteTip(4,ntInfoData.bDeskStation)
    --         --总带入 局数 输赢
    --         if GameBankerResult.transform then
    --             if this.StationZhuang == MyUserInfo.iDeskStation then
    --                 GameBankerResult.Show(ntInfoData.iEntryMoney,ntInfoData.cbNtGames,ntInfoData.iWinMoney)
    --             end
    --         end
    --     end
    --     this.IsHuanZhuang = true
    --     if ntInfoData.bDeskStation == 255 then
    --         this.PeviousZhuangStation = this.StationZhuang
    --     else
    --         if this.StationZhuang == -1 or this.StationZhuang == 255 then
    --             this.PeviousZhuangStation = ntInfoData.bDeskStation
    --         else
    --             this.PeviousZhuangStation = this.StationZhuang
    --         end
    --     end
    --     this.StationZhuang = ntInfoData.bDeskStation
    --     if this.ListContains(this.ZhuangList,ntInfoData.bDeskStation) then
    --         for i=1,#this.ZhuangList do
    --             if this.ZhuangList[i] == ntInfoData.bDeskStation then
    --                 table.remove(this.ZhuangList,i)
    --                 break
    --             end
    --         end
    --     end
    --     if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
    --         this.btnShangZhuang.gameObject:SetActive(false)
    --         this.btnXiaZhuang.gameObject:SetActive(true)
    --         --GameUIShangZhuangList.SetShangZhuanglistInfo(this.LeastMoneyZhuang,this.ZhuangList)
    --     end
    -- elseif ntInfoData.state == 10 then
    --     LblMsgText.Show("There is not enough money to go to the banker, please recharge first!")
    -- elseif ntInfoData.state == 11 then
    --     LblMsgText.Show("Success! After the end of the game, you will be automatically replace in the banker!")
    -- else
    --     if ntInfoData.state > 21 then
    --         local msg=string.format("There are still %s rounds before replace the banker!",ntInfoData.state - 20)
    --         LblMsgText.Show(msg)
    --     elseif ntInfoData.state == 21 then
    --         LblMsgText.Show("You will not be the dealer after this round!")
    --     end
    -- end
    -- GameUIShangZhuangList.SetShangZhuanglistInfo(this.LeastMoneyZhuang,this.ZhuangList)
    -- this.RefreshZhuangInfo()
    print("---庄家列表 1010 Over--",ntInfoData.state,ntInfoData.bDeskStation,MyUserInfo.iDeskStation)
end
function GameUIManager.GamePlayerNoteInfo(data) --所有用户下注信息 1011

end
function GameUIManager.GameSettlement(data) --即将结算 1012
end
function GameUIManager.GameStatitice(data) --统计（押注，概率） 1015  
    -- for i=1,#this.m_PrizesCount do
    --     this.m_PrizesCount[i] = msg.mPrizePro[i-1]
    -- end
    -- this.m_CurGameCount = msg.mTotalGames;
    for i=1,#this.m_PrizesCount do
        this.m_PrizesCount[i] = data.mPrizePro[i-1]
    end
    this.m_CurGameCount = data.mTotalGames;
end
function GameUIManager.RunBigPrizeListAnimation(lastIndex,curIndex,OnComplete)
    print("-----------",lastIndex,curIndex)
    if lastIndex == nil or curIndex == nil then
        return
    end
    local isLoop = true
    local tempIndex = lastIndex
    if lastIndex < curIndex then
        lastIndex = lastIndex + 28
    end

    if lastIndex - curIndex < 14 then
        lastIndex = lastIndex + 28
    end

    local time = 0.30 
    while isLoop do
        if lastIndex < (curIndex + 1) then
            isLoop = false
        end
        coroutine.wait(time)
        this.Obj_Flash[lastIndex % 28 + 1]:SetActive(true)
        local entity = this.UIEntity[lastIndex % 28+1]
        entity:Flash_Show(true)

        entity = this.UIEntity[(lastIndex + 28 + 6 ) % 28+1]
        entity:Flash_Show( false )
        if not GameAudioContro.SoundEffect.isPlaying then
            GameAudioContro.Play(GameAudioContro.ZhuandengClip)
        end
        time = Jisu
        lastIndex = lastIndex - 1
    end
    if OnComplete ~= nil then
        OnComplete()
    end
end
function GameUIManager.RunNormalPrizeListAnimation(lastIndex,curIndex,OnComplete )
    print("---开始跑圈---",lastIndex,curIndex)
    local isLoop = true
    local tempIndex = curIndex
    if curIndex >= lastIndex then
        if curIndex - lastIndex < 14 then
            curIndex = curIndex + 28
        end
    else
        curIndex = curIndex + 28
        if curIndex - lastIndex < 14 then
            curIndex = curIndex + 28
        end
    end
    curIndex = curIndex + 28 * 4
    local time = 0.20
    while isLoop do
        if lastIndex > (curIndex - 1) then
            isLoop = false
        end
        coroutine.wait(time)
        --跑灯动画
        this.Obj_Flash[lastIndex % 28 + 1]:SetActive(true)
        local entity = this.UIEntity[lastIndex % 28+1]
        entity:Flash_Show(true)

        entity = this.UIEntity[(lastIndex + 28 - 6 ) % 28+1]
        entity:Flash_Show( false )
        if (curIndex - lastIndex) < tep then --减速
            if (curIndex - lastIndex) < jiansuTep then
                time = Mathf.Lerp(a2, a3, (tep - (curIndex - lastIndex)) / jiansuTep)
            else
                time = Mathf.Lerp(a1, a2, (tep - (curIndex - lastIndex)) / (tep - jiansuTep))
            end
            if (curIndex -lastIndex) <3 then
                GameAudioContro.Play(GameAudioContro.ZhuandengClip)
            end
        
        else   --加速
            time = time - JiasuSpeed
            if time <= Jisu then
                time = Jisu
            end
        end
        lastIndex = lastIndex + 1
    end
    if  OnComplete ~= nil then
        OnComplete()
    end
end    
function GameUIManager.UpData()
    if(UnityEngine.Input.GetKeyDown(UnityEngine.KeyCode.A)) then
        --this.PoolDataDistrubute() 
    end
    if this.TotalStep > 0 and this.CurStep <= this.TotalStep then
        if this.CurSpeed < this.MaxSpeed and this.CurStep < 6 then--前四步加速
            this.CurSpeed = 0.2--this.Linear(0.1, this.MaxSpeed, this.CurStep / 4.0)
        elseif this.CurStep + this.DownSpeedStep >= this.TotalStep
        and this.CurStep + 5 < this.TotalStep then--后面的24步开始减速
            local value = (this.CurStep + this.DownSpeedStep - this.TotalStep) * 1.0 / (this.DownSpeedStep)
            this.CurSpeed = this.Linear(this.MaxSpeed, this.MinSpeed, value)
        elseif this.CurStep + 5 >= this.TotalStep then--后面的24步开始减速
            --local value = (this.CurStep + this.DownSpeedStep - this.TotalStep) * 1.0 / (this.DownSpeedStep)
            local value = math.floor(this.CurStep/this.TotalStep*1000)/1000
            this.CurSpeed = this.Linear(this.MaxSpeed, this.MinSpeed, value)
        else --中间就是最大速度
            this.CurSpeed = this.MaxSpeed
        end

        this.Factor = this.Factor + this.PerTime() * UnityEngine.Time.deltaTime * this.CurSpeed
        --this.Factor = math.floor(this.Factor*1000)/1000

        local val = Mathf.Clamp01(this.Factor)
        if math.floor(val * this.TotalStep) >= this.CurStep then

            this.CurPrizeIndex = (this.mLastPrizeIndex + this.CurStep) % this.CarTeamCount

            --this.Car_Team[this.CurPrizeIndex+1].gameObject:SetActive(true)
            this.Obj_Flash[this.CurPrizeIndex+1]:SetActive(true)
            --local entity = this.UIEntity[this.CurPrizeIndex]
            --entity:Flash_Show(true)

            --entity = this.UIEntity[(lastIndex + 28 - 6 ) % 28+1]
            --entity:Flash_Show( false )

            local blink = this.UIEntity[this.CurPrizeIndex+1]
            if this.CurStep == this.TotalStep then   --开奖跑完
                this.StopLastIndexBlink()
                --记录游戏已经开奖的
                this.mLastPrizeIndex = this.CurPrizeIndex

                --重置
                this.Factor = 0
                this.CurStep = 0
                this.TotalStep = 0
                if this.CallBack ~= nil then
                    this.CallBack()
                    this.CallBack = nil
                end
                blink:PlayIconBlink(-1, 0.2)--间隔0.2f闪动一下  count = -1不停的闪
            elseif this.CurStep + this.DownSpeedStep * 0.12 >= this.TotalStep then--改变车标闪动 效果 
                blink:PlayIconBlink(-1, 0.2)--间隔0.2f闪动一下——跑动时，底图渐变动画，闪
            else
                blink:PlayIconBlink(-2, 0.1)--间隔0.1f后消隐——跑动时，底图渐变动画，闪
            end

            GameAudioContro.Play(GameAudioContro.ZhuandengClip)
            --GameAudioContro.Play(GameAudioContro.CarTurnAud)
            --if this.TotalStep - this.CurStep <= 5 and this.TotalStep - this.CurStep >= 0 then--最后3步 开始播放减速音乐
            --  GameAudioContro.Play("Public/Audio/Game/Loop/zhuandeng.u3d")
            --end
            this.CurStep = this.CurStep + 1
        end
    end
end
--停止上次奖励 图标的高亮
function GameUIManager.StopLastIndexBlink()
    local lastPrizeIndex = (this.mLastPrizeIndex + this.CurStep) % this.CarTeamCount
    this.StopAllIconLight()--所有的灯都停止高亮和闪动
    if this.UIEntity[lastPrizeIndex+1] then
        this.UIEntity[lastPrizeIndex+1]:StopIconBlink()
    end
    this.Obj_Flash[lastPrizeIndex+1]:GetComponent("Animation"):Play("Shan")
end
function GameUIManager.PerTime()
    if this.Duration ~= this.CurDuration then
        this.Duration = this.CurDuration
        this.CurPerTime = (this.CurDuration > 0) and (1 / this.CurDuration) or 1
    end
    return this.CurPerTime
end
--直线
function GameUIManager.Linear(start,over,value)
    return start + (over - start) * value
    --return Mathf.Lerp(start, over, value)
end
function GameUIManager.OpenPrizeLogic()
    --上一局开奖动物重置回以前的背景图片
    print( "开始跑圈!!!!!!!!!!",this.mLastPrizeIndex,this.CurrentPrize[1])
    local anima = this.Obj_Flash[this.mLastPrizeIndex+1]:GetComponent("Animation")
    if 0 ~= this.mLastPrizeIndex % 7 then
        --anima.namePrefix = this.mLastPrizeIndex < #this.Obj_Flash/2 and "GreenBig_" or "RedBig_"
        --anima:Play("Shan")
    end
    --anima.enabled = true
    this.StopComCoroutine()
    this.PlayOpenPrizeAnimation(this.CurrentPrize[1],--[[,this.OnAnimationComplete)

    ComCoroutine = coroutine.start(this.RunNormalPrizeListAnimation,this.mLastPrizeIndex,this.CurrentPrize[1],]]function()

        print("跑圈完毕 从"..this.mLastPrizeIndex,"到"..this.CurrentPrize[1].." CurrentPrize.Count："..#this.CurrentPrize)
        --记录游戏已经开奖的
        this.mLastPrizeIndex = this.CurrentPrize[1]
        table.insert(this.mLastIndex,this.mLastPrizeIndex)
        if #this.CurrentPrize == 1 then
            local nBetIndex = this.View2BetIndex(this.CurrentPrize[1])
            --播放跑完动画
            this.PlayFlash()
            --anima.enabled = true;
        elseif #this.CurrentPrize == 2 then
            --倍率
            local nBetIndex = this.View2BetIndex(this.CurrentPrize[1])
            local entity = this.UIEntity[this.CurrentPrize[1]+1]
            entity:PlayLoop()
            if nBetIndex == 1 then
                -- 金鲨闪动画
                --anima.enabled = true
                --anima:Play("Shan")

                --金鲨鱼走完，播放人声金鲨鱼
                this.listAudio = {}
                -- 金鲨鱼
                local audio = {}
                audio.strAudio = this.PeopleAudio[nBetIndex+1]
                --audio.time = 0.5
                audio.time = 2.1
                table.insert(this.listAudio,audio)

                --金鲨鱼叫
                -- local audio1 = {}
                -- audio1.strAudio = this.AnimationAudio[nBetIndex+1]
                -- audio1.time = 1.0
                -- table.insert(this.listAudio,audio1)

                --[[
                --金鲨鱼开奖
                local audio2 = {}
                audio2.strAudio = this.SoundOpenPrizeJinYin
                audio2.time = 0.6
                table.insert(this.listAudio,audio2)
                ]]

                coroutine.start(this.PlayGameMusic,this.listAudio)
                print("----播灯动画------")
                --播灯动画
                GameUIAnimation.StartAnimation( 1, 2,function()
                    coroutine.start(this.RunBigPrizeListAnimation,this.mLastPrizeIndex, this.mListPrize[1],function()
                        this.StopLightAnimation()
                        this.RefreshUserInfo()
                    end)
                end)
            end

            if nBetIndex == 2 then
                --银鲨按钮跳
                local entity1 = this.UIEntity[this.CurrentPrize[1]+1]
                entity1:PlayLoop()

                --金鲨鱼走完，播放人声金鲨鱼
                this.listAudio = {}

                -- 金鲨鱼
                local audio = {}
                audio.strAudio = this.PeopleAudio[nBetIndex+1]
                --audio.time = 0.5
                audio.time = 2.1
                table.insert(this.listAudio,audio)

                --金鲨鱼叫
                -- local audio1 = {}
                -- audio1.strAudio = this.AnimationAudio[nBetIndex+1]
                -- audio1.time = 1.0
                -- table.insert(this.listAudio,audio1)

                --[[
                --金鲨鱼开奖
                local audio2 = {}
                audio2.strAudio = this.SoundOpenPrizeJinYin
                audio2.time = 0.6
                table.insert(this.listAudio,audio2)
                ]]
                coroutine.start(this.PlayGameMusic,this.listAudio)

                --播灯动画
                print("----播灯动画------")
                --GameUIAnimation.StartAnimation( 3, 6)
                print("----播灯动画------")

                GameUIAnimation.StartAnimation( 2, 2,function()
                    coroutine.start(this.RunBigPrizeListAnimation,this.mLastPrizeIndex, this.mListPrize[1],function()
                        this.StopLightAnimation()
                        this.RefreshUserInfo()
                    end)
                end)
            end
        end
    end)
end
function GameUIManager.PlayOpenPrizeAnimation(prizeIndex,callBack)
    print("-----开奖动画-----",prizeIndex)
    this.PrizeIndex = prizeIndex
    this.CallBack = callBack
    this.Factor = 0
    this.CurStep = 0

    this.StopAllIconLight()--所有的灯都停止高亮和闪动
    this.TotalStep = (this.CarTeamCount * (prizeIndex >= this.mLastPrizeIndex and 3 or 4) + (prizeIndex - this.mLastPrizeIndex))
    print("总步数："..this.TotalStep,"当前步数："..this.CurStep)
    --GameAudioContro.Play("Public/Audio/Game/Loop/loop.u3d")
end
function GameUIManager.StopAllIconLight()
    for i=1,#this.UIEntity do
        this.UIEntity[i]:StopIconBlink()
    end
end
function GameUIManager.WaitOpenPrize(nSpecailIndex,nBetIndex,money,lessTime)
    if lessTime < 1 then
    end
    this.TipGroup[1]:SetActive(true)
    coroutine.wait(lessTime)
    this.TipGroup[1]:SetActive(false)

    local animaIndex = this.View2BetIndex(nBetIndex)
    --非金鲨，修改图片
    this.Obj_Flash[nBetIndex+1]:SetActive(true)
    --不消隐
    local alpha = this.Obj_Flash[nBetIndex+1]:GetComponent("TweenAlpha")
    alpha.enabled = false

    --停止闪
    local nViewIndex = this.mLastPrizeIndex
    this.Obj_Flash[nViewIndex+1]:GetComponent("Animation").wrapMode = UnityEngine.WrapMode.Once
    --中间的几个动画
    local animaName = this.GetAnimalNameByIndex(animaIndex)
    if this.StationZhuang ~= -1 and this.StationZhuang ~= 255 then
        if GameResult then
            if nSpecailIndex == 255 then
                GameResult.Show(money, this.mZhuangWinLose, this.StationZhuang, this.mMaxWinMoneyStation, this.mMaxWinSouce, this.playerCount,animaName)
            else
                GameResult.Show(money, this.mZhuangWinLose, this.StationZhuang, this.mMaxWinMoneyStation, this.mMaxWinSouce, this.playerCount,animaName)
            end
        end
    end
end
--开奖逻辑
function GameUIManager.StartGame()
    if 0 < #this.mListPrize then
        --开奖索引
        local nViewIndex = this.mListPrize[1]
        local nBetIndex = this.View2BetIndex(nViewIndex)
        if nBetIndex <= 2 then
            --金鲨银鲨 声音 
            this.StopJsYsAnimation()
        else
            --其它
            table.remove(this.mListPrize,1)
            this.OpenPrizeLogic()

            --跑声音
            if this.isShowAllUI then
                --GameAudioContro.SoundEffect:Stop()
            end
            --GameAudioContro.Play("Public/Audio/Game/OpenPrize_YinXiao.u3d")
        end
    end
end
--闪动画
function GameUIManager.PlayFlash(viewIndex)
    if viewIndex == nil then
        viewIndex = -1
    end
    local nViewIndex = viewIndex
    if nViewIndex < 0 then
        nViewIndex = this.mLastPrizeIndex
    end
    local animShan = this.Obj_Flash[nViewIndex+1]:GetComponent("Animation")
    animShan.wrapMode = UnityEngine.WrapMode.Loop
    animShan:Play("Shan")
    local time = animShan:GetClip("Shan").length * 3
    coroutine.start(this.StartAnimalAnimation,time)
end
--播放动物动画
function GameUIManager.StartAnimalAnimation(time)
    coroutine.wait(time)
    local nViewIndex = this.mLastPrizeIndex
    --停止闪
    this.Obj_Flash[nViewIndex+1]:GetComponent("Animation").wrapMode = UnityEngine.WrapMode.Once
    --中间的几个动画
    local nBetIndex = this.View2BetIndex(nViewIndex)
    GameUIAnimation.StartAnimation( nBetIndex, 12)
    --飞禽走兽按钮
    if 3 < nBetIndex then
        --飞禽走兽按钮
        if nViewIndex < #this.Obj_Flash/2 then
            --走兽声音
            this.listAudio = {}
            local audio = {}
            --人声
            audio.strAudio = this.PeopleAudio[nBetIndex+1]
            --audio.time = 0.8
            audio.time = 2.1
            table.insert(this.listAudio,audio)

            --人叫动物声
            -- local audio1 = {}
            -- audio1.strAudio = this.PeopleAudio[4]
            -- audio1.time = 0.8
            -- table.insert(this.listAudio,audio1)

            --动物叫声
            -- local audio2 = {}
            -- audio2.strAudio = this.AnimationAudio[nBetIndex+1]
            -- audio2.time = 1
            -- table.insert(this.listAudio,audio2)

            --[[
            -- 开奖声 
            local audio3 = {}
            audio3.strAudio = this.SoundOpenPrizeFeiZou
            audio3.time = 0.8
            table.insert(this.listAudio,audio3)
            ]]
            coroutine.start(this.PlayGameMusic,this.listAudio)
        else
            this.listAudio = {}
            local audio = {}
            --人声
            audio.strAudio = this.PeopleAudio[nBetIndex+1]
            --audio.time = 0.8
            audio.time = 2.1
            table.insert(this.listAudio,audio)

            --人叫动物声
            -- local audio1 = {}
            -- audio1.strAudio = this.PeopleAudio[1]
            -- audio1.time = 0.8
            -- table.insert(this.listAudio,audio1)

            --动物叫声
            -- local audio2 = {}
            -- audio2.strAudio = this.AnimationAudio[nBetIndex+1]
            -- audio2.time = 1
            -- table.insert(this.listAudio,audio2)

            --[[
            -- 开奖声 
            local audio3 = {}
            audio3.strAudio = this.SoundOpenPrizeFeiZou
            audio3.time = 0.8
            table.insert(this.listAudio,audio3)
            ]]
            
            coroutine.start(this.PlayGameMusic,this.listAudio)
        end
        --修改背景
    else
        --金鲨 银鲨
        this.listAudio = {}
        local audio = {}
        --银鲨鱼
        audio.strAudio = this.PeopleAudio[nBetIndex+1]
        --audio.time = 0.5
        audio.time = 2.1
        table.insert(this.listAudio,audio)

        --银鲨鱼叫
        -- local audio1 = {}
        -- audio1.strAudio = this.AnimationAudio[nBetIndex+1]
        -- audio1.time = 1
        -- table.insert(this.listAudio,audio1)

        --[[
        --银鲨鱼开奖
        local audio2 = {}
        audio2.strAudio = this.SoundOpenPrizeJinYin
        audio2.time = 0.6
        table.insert(this.listAudio,audio2)
        ]]

        coroutine.start(this.PlayGameMusic,this.listAudio)
    end
    --金鲨按钮
    if 0 < #this.mLastIndex then
        nBetIndex = this.View2BetIndex(this.mLastIndex[1])
    end
    local animaName = this.GetAnimalNameByIndex(nBetIndex)
    this.IconOpenPrizeAnima.spriteName = "UI_Game_JS_"..animaName
    this.IconOpenPrizeTxt.spriteName = "Txt_JS_"..animaName
    this.IconOpenPrizeBet.text = "X"..this.mBase[nBetIndex+1]
    this.IconOpenPrizeAnima.transform.parent.gameObject:SetActive(true)
    --停止动画
    coroutine.wait(3)
    this.IconOpenPrizeAnima.transform.parent.gameObject:SetActive(false)
    this.ShowOrHideWinAnim(true,this.CurrentPrize)
    if this.StationZhuang ~= -1 or this.StationZhuang ~= 255 or this.IsHuanZhuang then
        if GameResult then
            local money = 0
            if 0 < this.mWinLose then
                money = this.mWinLose 
            else
                money = this.mWinLose + this.mSecondWinLose
            end
            if this.IsHuanZhuang then
                GameResult.Show(money, this.mZhuangWinLose, this.PeviousZhuangStation, this.mMaxWinMoneyStation, this.mMaxWinSouce, this.playerCount,animaName)
            else
                GameResult.Show(money, this.mZhuangWinLose, this.StationZhuang, this.mMaxWinMoneyStation, this.mMaxWinSouce, this.playerCount,animaName)
            end
            this.PeviousZhuangStation = this.StationZhuang
            this.IsHuanZhuang = false
        end
    end
    --停止动画
    coroutine.wait(3)
    if GameResult.transform.gameObject.activeSelf then
        GameResult.Hide()
    end
    if this.StopDownBet then
        this.StopDownBet:SetActive(false)
    end
    coroutine.start(this.YieldPlayFlyGold)
    coroutine.wait(10)
    this.StopAnimalAnimation()
end
--停止动物动画
function GameUIManager.StopAnimalAnimation()
    if #this.mLastIndex <= 0 then
        return
    end
    if 0 < #this.listAudio then
        this.listAudio = {}
    end
    --修改背景
    for n=1,#this.mLastIndex do
        local Index = this.mLastIndex[n]
        --恢复图片,不能消隐
        local entity = this.UIEntity[Index+1]
        entity:OnlyShowBG()
    end
    --中奖索引
    this.mLastIndex = {}
    --倍率
    this.UILb_Base.gameObject:SetActive(false)
end
--金鲨银鲨动画停止
function GameUIManager.StopJsYsAnimation()
    --金鲨/银鲨播放结束
    if 0 < #this.mListPrize then
        --开奖索引
        local nViewIndex = this.mListPrize[1]
        table.remove(this.mListPrize,1)
        this.OpenPrizeLogic()

        --跑声音
        --GameAudioContro.Play("Public/Audio/Game/OpenPrize_YinXiao.u3d")
    end
end
--灯动画停止
function GameUIManager.StopLightAnimation( )
    if #this.mListPrize > 0 then
        --开奖索引
        local nViewIndex = this.mListPrize[1]
        table.remove(this.mListPrize,1)

        --记录游戏已经开奖的
        this.mLastPrizeIndex = nViewIndex
        table.insert(this.mLastIndex,this.mLastPrizeIndex)

        --不能消隐
        local alpha = this.Obj_Flash[nViewIndex+1]:GetComponent("TweenAlpha")
        alpha:ResetToBeginning()
        alpha.enabled = false

        --播放跑完动画
        this.PlayFlash()
    end
end
function GameUIManager.ShowOrHideWinAnim(isShow,prize)
    for i=1,#this.WinRay do
        this.WinRay[i]:SetActive(false)
    end
    if isShow then
        for i=1,#this.WinRay do
            for j=1,#prize do
                local animaIndex = this.View2BetIndex(prize[j])
                local animaIndex1 = this.FeiQinOrZouShou(animaIndex) 
                if i == animaIndex + 1 then
                    this.WinRay[animaIndex+1]:SetActive(true)
                    if animaIndex ~= 2  then
                        this.WinRay[animaIndex1+1]:SetActive(true)
                    end
                end
            end
        end

    end
end  
function GameUIManager.PlayGameMusic(listAudio)
    for i=1,#listAudio do
        GameAudioContro.Play("Public/"..listAudio[i].strAudio..".u3d")
        --等XX毫秒，放下一个声音
        coroutine.wait(listAudio[i].time)
        if i ~= #listAudio then
            GameAudioContro.StopEffect()
        end
    end
    listAudio = {}
end
function GameUIManager.UpdateBetInfo(bets)
    local len = #this.BtnBets
    if #bets > #this.BtnBets then
        len = #this.BtnBets
    else
        len = #bets
    end
    for i=1,len do
        local btn = this.BtnBets[i]
        if btn then
            local label = btn.gameObject.transform:FindChild("Label_Num"):GetComponent("UILabel")
            if label then
                label.text = FormatNumToYW(MoneyProportionStr(bets[i]))
            end
        end
    end
end
--开始或停止下注
function GameUIManager.StartOrStopDownBetBG(flag)
    if flag then
        this.ShowNoteTip(2)
        if this.StartDownBet then
            if not this.StartDownBet.activeSelf then
                this.StartDownBet:SetActive(true)
            end
        end
        if this.StopDownBet then
            if this.StopDownBet.activeSelf then
                this.StopDownBet:SetActive(false)
            end
        end
    else
        this.ShowNoteTip(3)
        if this.StartDownBet then
            if this.StartDownBet.activeSelf then
                this.StartDownBet:SetActive(false)
            end
        end
        if this.StopDownBet then
            if not this.StopDownBet.activeSelf then
                this.StopDownBet:SetActive(true)
            end
        end
    end
end
function GameUIManager.ShowStateTip(state)
    for i=5,6 do
        this.TipGroup[i]:SetActive(false)
    end
    if state == this.GameState.GAMESTATE_NOTE then 
        this.TipGroup[5]:SetActive(true)
    elseif state == this.GameState.GAMESTATE_OPENPRIZE then
        this.TipGroup[6]:SetActive(true)
    elseif state == this.GameState.GAMESTATE_SETTLEMENT then
        this.TipGroup[6]:SetActive(true)
    else

    end
    
end
--展示提示消息 2开始下注 3停止下注 4庄家轮换
function GameUIManager.ShowNoteTip(index,deskStation)    
    coroutine.stop(this.HideNoteTip)
    coroutine.start(this.HideNoteTip,index)
    if index == 4 then
        -- local user = this.GetUserByStation(deskStation)
        -- if user then
        --     if user.bBoy == 1 then
        --         GameAudioContro.Play(GameAudioContro.TipsClip[3])
        --     else
        --         GameAudioContro.Play(GameAudioContro.TipsClip[4])
        --     end
        -- end
    else
        this.TipGroup[index]:SetActive(true)
        GameAudioContro.Play(GameAudioContro.TipsClip[index-1])
    end
end
function GameUIManager.HideNoteTip(index)
    coroutine.wait(2)
    this.TipGroup[index]:SetActive(false)
end
--视图转下注
function GameUIManager.View2BetIndex(nViewIndex)
    return nViewIndex >= #this.viewIndex  and 1 or this.viewIndex[nViewIndex+1]
end
--region 下注更新
--更新倍率
function GameUIManager.RefreshBase()
    for i=1,#this.UILb_Bases do
        this.UILb_Bases[i].text = "X"..this.mBase[i]
    end
end
--筹码初始选择
function GameUIManager.ChooseBetIndex()
    while true do
        if this.mCheckIndex == 1 then
            SetParent(this.BtnBets[this.mCheckIndex].gameObject, this.GoBetFocus)
            break
        end
        if this.mChips[this.mCheckIndex] < tonumber(tostring(MyUserInfo.iMoney)) then
            SetParent(this.BtnBets[this.mCheckIndex].gameObject, this.GoBetFocus)
            break
        end
        this.mCheckIndex = this.mCheckIndex - 1 
    end
end

--添加记录项
function GameUIManager.InsertRecordIterm(iterm)
    table.insert(this.mListRecord,iterm)
end

function GameUIManager.UnChangePrize(Prize)
    if Prize < 0 or Prize >= 28 then
        return -1
    end
    return this.viewIndex[Prize+1]
end
function GameUIManager.NoteMoneyStatisticsCount(PrizeIndex)
    this.m_PrizesCount[PrizeIndex] = this.m_PrizesCount[PrizeIndex] + 1
    if PrizeIndex > 4 and PrizeIndex < 9 then
        --飞禽
        this.m_PrizesCount[1] = this.m_PrizesCount[1] + 1
    elseif PrizeIndex >= 9 then
        --走兽
        this.m_PrizesCount[4] = this.m_PrizesCount[4] + 1
    end
end
--更新用户的钱
function GameUIManager.RefreshUserInfo(isGame)
    isGame = isGame or false
    if MyUserInfo.uiUserID <= 0 then
    end
    --更新总下注
    local nTotalBet = 0
    local MyBets = 0
    for i=1,#this.mMyBets do
        this.UILb_MyBets[i].text = (this.mMyBets[i] >0 and FormatNumToYW(MoneyProportionStr(this.mMyBets[i])) or "")
        this.UILb_MyBets_ZY[i].text = (this.mTotalBets[i] >0 and FormatNumToYW(MoneyProportionStr(this.mTotalBets[i])) or "")
        nTotalBet = nTotalBet + this.mTotalBets[i] 
        MyBets = MyBets + this.mMyBets[i]
    end
    if this.UILb_AllNoteMoney then
        --this.UILb_AllNoteMoney.text = "ZXZ"..FormatNumToYW(MoneyProportionStr(nTotalBet))
        this.UILb_AllNoteMoney.text = FormatNumToYW(MoneyProportionStr(nTotalBet))
    end
    if this.UILb_MyMoney then
        if not isGame then
            this.SetUpdateWallet(tonumber(tostring(MyUserInfo.iMoney))-MyBets)
        else
            this.SetUpdateWallet(tonumber(tostring(MyUserInfo.iMoney)))
        end
    end
    this.LbOnLinePlayer.text = ""..#this.onLineUserList
    --this.RefreshZhuangInfo()
end
--更新庄家信息
function GameUIManager.RefreshZhuangInfo()
    -- if this.StationZhuang ~= -1 and this.StationZhuang ~= 255 then
    --     local zhuangData = this.GetUserByStation(this.StationZhuang)
    --     if zhuangData ~= nil then
    --         this.LbZhuangName.text = zhuangData.szNickName
    --         this.LbZhuangMoney.text = FormatNumToYW(MoneyProportionStr(zhuangData.iMoney))
    --         this.UpdateBankerLV(zhuangData.iVipLevel)
    --     else
    --         print(false,"玩家为空！"..this.StationZhuang)
    --     end
    -- else
    --     this.LbZhuangName.text = ""
    --     this.LbZhuangMoney.text = ""
    --     this.UpdateBankerLV("")
    -- end
    -- if this.StationZhuang == MyUserInfo.iDeskStation then
    --     if this.IconUserZhuangOrXian then
    --         this.IconUserZhuangOrXian.spriteName = "UI_GameSign_Zhuang"
    --     end
    --     this.btnShangZhuang.gameObject:SetActive(false)
    --     this.btnXiaZhuang.gameObject:SetActive(true)
    -- else
    --     if this.IconUserZhuangOrXian then
    --         this.IconUserZhuangOrXian.spriteName = "UI_GameSign_Xian"
    --     end
    --     if this.ListContains(this.ZhuangList,MyUserInfo.iDeskStation) then
    --         this.btnShangZhuang.gameObject:SetActive(false)
    --         this.btnXiaZhuang.gameObject:SetActive(true)
    --     else
    --         this.btnShangZhuang.gameObject:SetActive(true)
    --         this.btnXiaZhuang.gameObject:SetActive(false)
    --     end
    -- end
    -- this.LbWaitCount.text = ""..#this.ZhuangList
    -- this.LbOnLinePlayer.text = ""..#this.onLineUserList
end
--飞金币动画
function GameUIManager.PlayGoldAnimation(userId,formPos,areaIndex,checkIndex,time)
    if time == nil then
        time = 0.3
    end
    local goldAnima = GameUIGoldManager.CreatGold(userId,FormatNumToYW(MoneyProportionStr(this.mChips[checkIndex])),checkIndex,areaIndex)
    goldAnima.transform.localScale = Vector3.New(1, 1, 1)
    goldAnima:GotoPosition(formPos, this.Obj_Bets[areaIndex+1].transform.localPosition, time)
end
--续压飞金币
function GameUIManager.ContinuePlayGoldGruop(deskStation,money,areaIndex)
    local checkIndexList = {}
    this.GetBetNumPrefabNameList(money,checkIndexList)
    for i=1,#checkIndexList do
        if deskStation == MyUserInfo.iDeskStation then
            this.PlayGoldAnimation(MyUserInfo.uiUserID, this.BtnBets[checkIndexList[i]].transform.localPosition, areaIndex, checkIndexList[i])
        else
            this.PlayGoldAnimation(this.GetUserByStation(deskStation).uiUserID, this.BtnBets[checkIndexList[i]].transform.localPosition, areaIndex, checkIndexList[i])
        end
    end
end

--断线设置金币
function GameUIManager.SetExistGoldPos(money,areaIndex)
    local checkIndexList = {}
    this.GetBetNumPrefabNameList(money,checkIndexList)
    for i=1,#checkIndexList do
        local goldAnima = GameUIGoldManager.CreatGold(0,FormatNumToYW(MoneyProportionStr(this.mChips[checkIndexList[i]])),checkIndexList[i],areaIndex)
        goldAnima:SetPosition(this.Obj_Bets[areaIndex+1].transform.localPosition)
    end
end
function GameUIManager.GetBetNumPrefabNameList(money,checkIndexList,limitCount)
    if limitCount == nil then
        limitCount = 30
    end
    while money > 0 do
        if money < this.mChips[1] then
            table.insert(checkIndexList,1)
            break
        end
        for i=#this.mChips,1,-1 do
            if money >= this.mChips[i] then
                money = money - this.mChips[i]
                if #checkIndexList < limitCount then
                    table.insert(checkIndexList,i)
                end
                break
            end
        end
    end
end
function GameUIManager.OneByOnePlayGoldAnimation(OpenPrizeIndex,prizeMoney)
    local TotalCount = this.getIntPart(prizeMoney / this.mChips[1])
    local myMoney = 0
    local myCountlist = {}
    local otherCountlist = {}
    local allCountList = {}

    local mLimitMyCount = 20
    local mLimitOtherCount = 40
    if this.mMyBets[OpenPrizeIndex+1] > 0 then
        myMoney = this.mMyBets[OpenPrizeIndex+1] *this.mBase[OpenPrizeIndex+1]
        
        this.GetBetNumPrefabNameList(myMoney,myCountlist,mLimitMyCount)
        
        for i=1,#myCountlist do
            table.insert(allCountList,myCountlist[i])
        end
    end
    local otherMoney = prizeMoney - myMoney
    this.GetBetNumPrefabNameList(otherMoney,otherCountlist,mLimitOtherCount)
    for i=1,#otherCountlist do
        table.insert(allCountList,otherCountlist[i])
    end
  
    TotalCount = #allCountList
    local snopFromPos = this.ZhuangPos
    local snopToPos = this.Obj_Bets[OpenPrizeIndex+1].transform.localPosition
    local IndexCount = math.ceil(TotalCount/10.0)
    for i=1,TotalCount do
        local goldAnima = GameUIGoldManager.CreatGold(0,FormatNumToYW(MoneyProportionStr(this.mChips[allCountList[i]])),allCountList[i],OpenPrizeIndex)
        goldAnima.transform.localScale = Vector3.New(1, 1, 1)
        goldAnima.transform.localPosition = snopFromPos

        if i < #myCountlist then
            goldAnima:AllotGoldOne(snopFromPos, snopToPos, this.MyMoneyPos)
            myMoney = myMoney - this.mChips[1]
        else
            goldAnima:AllotGoldOne(snopFromPos, snopToPos, this.XianPos)
        end
        if i % IndexCount == 0 then
        end
    end
end
function GameUIManager.YieldPlayFlyGold()
    coroutine.wait(0.5)
    GameUIGoldManager.RevokePosition()
    coroutine.wait(0.5)
    if #this.mLastIndex > 0 then
        for i=1,#this.mLastIndex do
            local animaIndex = this.View2BetIndex(this.mLastIndex[i])
            local prizeMoney = this.mTotalBets[animaIndex] * this.mBase[animaIndex]
            if prizeMoney > 0 then
                print("---飞金币---",i,animaIndex,this.FeiQinOrZouShou(animaIndex),prizeMoney,this.mLastIndex[i])
                --PlayGameMusic(GoldAudio[1]);
                GameAudioContro.Play("Public/"..this.GoldAudio[2]..".u3d")
                coroutine.start(this.OneByOnePlayGoldAnimation,animaIndex, prizeMoney)
            end
            if animaIndex ~= 2 then
                local animaIndex1 = this.FeiQinOrZouShou(animaIndex) 
                local prizeMoney1 = this.mTotalBets[animaIndex1+1] * this.mBase[animaIndex1+1]
                if prizeMoney1 > 0 then
                    coroutine.start(this.OneByOnePlayGoldAnimation,animaIndex1, prizeMoney1)
                end
            end
        end
    end 
    coroutine.wait(0.8)
    GameUIGoldManager.RevokePlayerPos()
end
-- function GameUIManager.StringFormDouble(score)
--     local num = tonumber(score)
--     local value = tostring(num)
--     local rideValue = 1
--     if ( num < 0 ) then
--         num = num * -1
--         rideValue = -1
--     end
--     if ( num >= 1000 ) then
--         if ( num >= 100000000 ) then
--             local v = math.floor(num / 1000000)/100
--             value = tostring(v * rideValue).."Y"
--         elseif num >= 10000 then
--             local v = math.floor(num / 100)/100
--             value = tostring(v * rideValue).."W"
--         else
--             local v = math.floor(num / 10)/100
--             value = tostring(v * rideValue).."Q"
--         end
--     end
--     return value
-- end
function GameUIManager.StringFormDouble1(score)
    -- local num = tonumber(score)
    -- local value = tostring(num)
    -- local rideValue = 1
    -- if ( num < 0 ) then
    --     num = num * -1
    --     rideValue = -1
    -- end
    -- if ( num >= 1000 ) then
    --     if ( num >= 100000000 ) then
    --         local v = math.floor(num / 1000000)/100
    --         value = tostring(v * rideValue).."亿"
    --     elseif num >= 10000 then
    --         local v = math.floor(num / 100)/100
    --         value = tostring(v * rideValue).."万"
    --     else
    --         local v = math.floor(num / 10)/100
    --         value = tostring(v * rideValue).."千"
    --     end
    -- end
    -- return value
end
--0是飞禽3是走兽
function GameUIManager.FeiQinOrZouShou(animaIndex)
    if animaIndex > 3 and animaIndex < 8 then
        return 0
    elseif animaIndex > 7 and animaIndex < 12 then
        return 3
    else
        return 1
    end
end
--endregion

function GameUIManager.GetPlayerCount()
    local resultCount = 0
    local CurrPlayer = GameSUserBaseInfo.userinfolist
    for i=1,#CurrPlayer do
        if CurrPlayer[i] ~= nil then
            resultCount = resultCount + 1
        end
    end
    return resultCount
end
--根据位置获取用户
function GameUIManager.GetUserByStation(nDeskStation)
    if nDeskStation == MyUserInfo.iDeskStation then
        if MyUserInfo.iUserState ~= 4 then --旁观游戏
            return MyUserInfo
        else
            return nil
        end
    end
    for i=1,#GameSUserBaseInfo.userinfolist do
        local user = GameSUserBaseInfo.userinfolist[i]
        if user ~= nil then
            if user.iDeskStation == nDeskStation then
                if user.iUserState ~= 4 then
                    return user
                else
                    return nil
                end
            end
        end
    end
    return nil
end
function GameUIManager.ContainsByDeskStation(original,deskStation)
    for i,v in ipairs(original) do
        if v.bDeskStation == deskStation then
            return true
        end
    end
    return false
end
function GameUIManager.ContainsByUserId(original,userId)
    for i,v in ipairs(original) do
        if v.uiUserID == userId then
            return true
        end
    end
    return false
end  
function GameUIManager.ListContains(original,deskStation)
    for i,v in ipairs(original) do
        if v == deskStation then
            return true
        end
    end
    return false
end
function GameUIManager.IsInTable(tal,value)
    for k,v in pairs(tal) do
        if v.UserId == value then
            return true
        end
    end
    return false
end
function GameUIManager.GetAnimalNameByIndex(index)
    print("----动物种类------",index,this.KindAnimal[index+1])
    local namePre = ""
    local kindAnimal =  this.KindAnimal[index+1]
    return namePre..kindAnimal
end
--开始计时
function GameUIManager.StartClock(timeOut,isTip)
    this.StopClockTime()
    ClockTimeCoroutine = coroutine.start(this.ShowClockTime,timeOut,isTip)
end
function GameUIManager.ShowClockTime(nTime,isTip)--显示倒计时
    this.Obj_TimeClock.transform.parent.gameObject:SetActive(true)
    this.Obj_TimeClock.text = string.format("%02d", nTime)
    this.TimeCountUITip:SetActive(false)
    local timeout = nTime
    while timeout > 0 do
        if timeout <= 3 and isTip then
            GameAudioContro.Play(GameAudioContro.countDown)
            this.IconNum.spriteName = "Txt_DaoShu_"..timeout
            this.TimeCountUITip:SetActive(true)
            this.FlashTimeRay:RebuildSpriteList()
            this.FlashTimeRay:ResetToBeginning()
        end
        coroutine.wait(1)
        if this.transform == nil or ClockTimeCoroutine == nil then return end
        timeout = timeout - 1
        this.Obj_TimeClock.text = string.format("%02d", timeout)
    end
    this.TimeCountUITip:SetActive(false)
    this.StopClockTime()
end
function GameUIManager.StopClockTime()--停止倒计时
    if ClockTimeCoroutine ~= nil then
        coroutine.stop(ClockTimeCoroutine)
        ClockTimeCoroutine = nil
    end
    this.TimeCountUITip:SetActive(false)
    this.Obj_TimeClock.transform.parent.gameObject:SetActive(false)
end

function GameUIManager.InitEvent()
    -- if not CommonBase.IsShowBank then
    --     this.FirstGroup:FindChild("Menu/Content/Icon_Box").gameObject.transform.localScale = Vector3.New(1,0.8,1)
    -- end
    -- this.Button_Bank.gameObject:SetActive(CommonBase.IsShowBank)
    -- this.Button_MainBank.gameObject:SetActive(CommonBase.IsShowBank)
    -- this.Button_Chat.gameObject:SetActive(MainMenus.IsShowChat)
    UIEventListener.Get(this.Button_Menu.gameObject).onClick = function()
    -- local TwpMenu = this.FirstGroup:FindChild("Menu/Content").gameObject:GetComponent("TweenPosition")
        if this.TwpMenu.transform.localScale.y < 1 then
            this.Button_Menu.normalSprite = "UI_BT_Up"
            this.TwpMenu.from = Vector3.New(1, 0, 1)
            this.TwpMenu.to = Vector3.New(1, 1, 1)
            this.TwpMenu.enabled = true
            this.TwpMenu:ResetToBeginning()
            this.TwpMenu:PlayForward()
        else
            this.Button_Menu.normalSprite = "UI_BT_Down"
            this.TwpMenu.from = Vector3.New(1, 1, 1)
            this.TwpMenu.to = Vector3.New(1, 0, 1)
            this.TwpMenu.enabled = true
            this.TwpMenu:ResetToBeginning()
            this.TwpMenu:PlayForward()
        end   
        GameAudioContro.Play(GameAudioContro.button)
    end
    if this.GoGameBack ~= nil then
        UIEventListener.Get(this.GoGameBack).onClick = function()
            if this.TwpMenu.transform.localScale.y == 1 then
                this.BtnMenu.normalSprite = "UI_BT_Down"
                this.TwpMenu.from = Vector3.New(1, 1, 1)
                this.TwpMenu.to = Vector3.New(1, 0, 1)
                this.TwpMenu.enabled = true
                this.TwpMenu:ResetToBeginning()
                this.TwpMenu:PlayForward()
            end
        end
    end
    UIEventListener.Get(this.Button_Exit).onClick = function()
        -- if this.StationZhuang == MyUserInfo.iDeskStation then
        --     LblMsgText.Show("You are the banker, please leave only after placing the banker")
        --     return
        -- end
        local nTotalBet = 0
        for n=1,#this.mMyBets do
            nTotalBet = nTotalBet + this.mMyBets[n]
        end
        if nTotalBet > 0  then
            LblMsgText.Show("You have placed your bet! Please wait for the draw before exiting!")
        else
            local func=function()
            end
            MessageBox.Show("Are you sure you want to quit the game?", UIRoom.QuitGame,func)
        end
        GameAudioContro.Play(GameAudioContro.button)
    end
    if this.Button_Set then
        UIEventListener.Get(this.Button_Set).onClick = function()
            UIGameLoad.OpenGameSet()
            GameAudioContro.Play(GameAudioContro.button)
        end
    end
    UIEventListener.Get(this.Button_Help).onClick = function()
        GameHelp.Show(this.iTaxVlue)
        GameAudioContro.Play(GameAudioContro.button)
    end
    -- UIEventListener.Get(this.Button_Bank).onClick = function()
    --     if LbIsNeedBindAccount == nil then
    --         if IsNeedBindGuest or (AccountBindType == 3 and (Network.logintype ~= 4 or not WxRegIsNoUpgrade)) then
    --             LblMsgText.Show("Please go to the lobby to bind the account!")
    --             return
    --         end
    --         GameUIBank.Show()
    --     else
    --         if LbIsNeedBindAccount then
    --             LblMsgText.Show("Please go to the lobby to bind the account!")
    --         else
    --             GameUIBank.Show()
    --         end
    --     end
    --     GameAudioContro.Play(GameAudioContro.button)
    -- end
    -- UIEventListener.Get(this.Button_MainBank).onClick = function()
    --     if LbIsNeedBindAccount == nil then
    --         if IsNeedBindGuest or (AccountBindType == 3 and (Network.logintype ~= 4 or not WxRegIsNoUpgrade)) then
    --             LblMsgText.Show("Please go to the lobby to bind the account!")
    --             return
    --         end
    --         GameUIBank.Show()
    --     else
    --         if LbIsNeedBindAccount then
    --             LblMsgText.Show("Please go to the lobby to bind the account!")
    --         else
    --             GameUIBank.Show()
    --         end
    --     end
    --     GameAudioContro.Play(GameAudioContro.button)
    -- end
    -- UIEventListener.Get(this.Button_Chat).onClick = function()
    --     HallUIManager.OnBtnChat()
    --     GameAudioContro.Play(GameAudioContro.button)
    --     this.IconRedDot:SetActive(false)
    -- end
    if this.Button_Record then
        UIEventListener.Get(this.Button_Record).onClick = function() --打开游戏记录
            GameAudioContro.Play(GameAudioContro.button)
            GameUIRecord.show()
        end
    end
    -- UIEventListener.Get(this.BtnRecharge).onClick = this.OpenRecharge --充值
    -- if this.MainBtnRecharge then
    --     this.MainBtnRecharge:SetActive(not IsClosePay)
    --     UIEventListener.Get(this.MainBtnRecharge).onClick = this.OpenRecharge --充值
    -- end

    -- if lobyUIRadio ~= nil then
    --     lobyUIRadio.GameChatTypeFunc = function()
    --         this.IconRedDot:SetActive(true)
    --     end
    -- end
    --奖池
    -- UIEventListener.Get(this.BtnJiangChi).onClick = this.OpenJiangChiPlane --奖池

    --压分选项
    for i=1,#this.BtnBets do
        UIEventListener.Get(this.BtnBets[i]).onClick = function()
            GameAudioContro.Play(GameAudioContro.button)
            if this.StationZhuang == MyUserInfo.iDeskStation then
                LblMsgText.Show("You are the banker, you cannot choose the chips!")
                return
            end
            this.mCheckIndex = i
            SetParent(this.BtnBets[this.mCheckIndex].gameObject,this.GoBetFocus)
        end
    end
   
    for i=1,#this.Obj_Bets do
        UIEventListener.Get(this.Obj_Bets[i]).onClick = this.OnBetCallback
    end

    --上庄按钮
    -- UIEventListener.Get(this.btnShangZhuang.gameObject).onClick = function()
    --     GameUIShangZhuangList.ShowUI(true)
    --     GameUIShangZhuangList.SetShangZhuanglistInfo(this.LeastMoneyZhuang, this.ZhuangList)
    -- end
    -- --下庄按钮
    -- UIEventListener.Get(this.btnXiaZhuang.gameObject).onClick = function()
    --     GameUIShangZhuangList.ShowUI(false)
    --     GameUIShangZhuangList.SetShangZhuanglistInfo(this.LeastMoneyZhuang, this.ZhuangList)
    -- end

    --续押按钮
    UIEventListener.Get(this.UIBtn_Continue.gameObject).onClick = function()
        GameAudioContro.Play(GameAudioContro.button)
        if this.GoRecharge.gameObject.activeSelf then
            return
        end
        local snopBet = 0
        for n=1,#this.mMyBets do
            snopBet = snopBet + this.mMyBets[n]
            if snopBet > 0 then
                break
            end
        end
        if snopBet >0 then
            LblMsgText.Show("You have already placed a bet and cannot continue!")
            return
        end
        NetManager:SendData(2000180,GameProtocal.GM_SUB_CONTINUEPRENOTE)
    end
    --在线按钮
    UIEventListener.Get(this.BtnOnLine.gameObject).onClick = function()
        --GameUIPlayerList.ShowUI(this.onLineUserList)
    end

    -- 一些下注的按钮不能用
    this.EnabledBtn(false)
    --自动
    if this.UIBtn_Auto then
        UIEventListener.Get(this.UIBtn_Auto.gameObject).onClick = function()
            if this.GoRecharge.gameObject.activeSelf then
                return
            end
            local snopBet = 0
            for n=1,#this.mMyBets do
                snopBet = snopBet + this.mMyBets[n]
                if snopBet > 0 then
                    break
                end
            end
            if snopBet == 0  then
                LblMsgText.Show("Please bet first!")
                return
            end
            this.IsAuto = true
            this.SetAutoStation(this.IsAuto)
        end
    end
    if GameUIBank.UIBtn_CancelAuto then
        --取消自动
        UIEventListener.Get(this.UIBtn_CancelAuto.gameObject).onClick = function()
            this.IsAuto = false
            this.SetAutoStation(this.IsAuto)
        end
        this.SetAutoStation(this.IsAuto)
    end
end

function GameUIManager.SetAutoStation(isAuto)
    if GameUIBank.UIBtn_Auto then
        this.UIBtn_Auto.gameObject:SetActive(not isAuto)   -- 自动
    end
    if GameUIBank.UIBtn_CancelAuto then
        this.UIBtn_CancelAuto.gameObject:SetActive(isAuto) -- 取消自动 
    end
end
--所有的下注按钮能不能点
function GameUIManager.EnabledBtn(bEnabled)
    --下注按钮
    for i=1,#this.Obj_Bets do
        this.Obj_Bets[i]:GetComponent("BoxCollider").enabled = bEnabled
        this.Obj_Bets[i].transform:FindChild("BackGround").gameObject:GetComponent("UISprite").color = Color.New(1,1,1,0)
    end
    this.UIBtn_Continue.isEnabled = bEnabled--续押按钮

    for i = 1, #this.BtnBets do
		this.BtnBets[i]:GetComponent("UIButton").isEnabled = bEnabled
		this.BtnBets[i]:GetComponent("Collider").enabled = bEnabled
	end
    -- if GameUIBank.UIBtn_Auto then
    --     this.UIBtn_Auto.isEnabled = bEnabled--自动
    -- end
    -- if GameUIBank.UIBtn_CancelAuto then
    --     this.UIBtn_CancelAuto.isEnabled = bEnabled--取消自动
    -- end
end
function GameUIManager.QuitGame()
    UIRoom.QuitGame()
end
function GameUIManager.OnBetCallback(obj)
    GameAudioContro.Play(GameAudioContro.button)
    if this.mStation ~= this.GameState.GAMESTATE_NOTE then
        LblMsgText.Show("Currently not betting stage!")
        return
    end
    if this.StationZhuang == -1 or this.StationZhuang == 255 then
        LblMsgText.Show("No banker, no betting!")
        return
    end
    if this.StationZhuang == MyUserInfo.iDeskStation then
        LblMsgText.Show("You are banker, you cannot bet!")
    end
    if this.GoRecharge.activeSelf then 
        return
    end
    local index = 0
    for i=1,#this.Obj_Bets do
        if this.Obj_Bets[i].gameObject == obj then
            index = i
        end
    end
    GameProtocal.CMD_GM_NoteData[1].data = MyUserInfo.iDeskStation
    GameProtocal.CMD_GM_NoteData[2].data = index-1 --AreaIndex
    GameProtocal.CMD_GM_NoteData[3].data = this.mCheckIndex-1  --NoteKind
    GameProtocal.CMD_GM_NoteData[4].data = this.mChips[this.mCheckIndex] --NoteMoney
    local sendbet = DataParseLua.StructToBytes(GameProtocal.CMD_GM_NoteData)
    NetManager:SendData(sendbet, 2000180, GameProtocal.GM_SUB_NOTE)
end

--获取筹码的字符串
function GameUIManager.GetChouMaStr(chouMa)

    local v= tonumber(chouMa)
    local str = ""
    if v >= 10000 then --万
        str = tostring(v / 10000) .. "W"
    elseif v >= 1000 and v < 10000 then --千
        str = tostring(v / 1000) .. "K"
    else
        str = tostring(v)
    end

    return  str
end
function GameUIManager.GetRandomPostion(v)
    local vx = math.random(v.x - 50, v.x + 50)
    local vy = math.random(v.y - 10, v.y + 20)
    return Vector3.New(vx, vy, 0)
end
function GameUIManager.GetRandomDesktopPostion(v)
    local vx = math.random(v.x - 20, v.x + 20)
    local vy = math.random(v.y, v.y + 30)
    return Vector3.New(vx, vy, 0)
end
function GameUIManager.StopComCoroutine()
    if ComCoroutine ~= nil then
        coroutine.stop(ComCoroutine)
    end
    ComCoroutine = nil
end
function GameUIManager.OnDestroy()
    GameLogic.OnDestroy()
    this.StopComCoroutine()
    UpdateBeat:Remove(this.UpData)
    this.StopClockTime()
    GameRecord.OnDestroy()
    GameUIGoldManager.OnDestroy()
    coroutine.stop(this.PlayGameMusic)
    coroutine.stop(this.StartAnimalAnimation)
    coroutine.stop(this.RunBigPrizeListAnimation)
    for i=1,#this.UIEntity do
        this.UIEntity[i]:OnDestroy()
    end
    package.loaded["606.GameUIManager"] = nil
    package.loaded["606.GameLogic"] = nil
    package.loaded["606.GameResult"] = nil
    package.loaded["606.GameUIPlayerList"] = nil
    package.loaded["606.GameUIShangZhuangList"] = nil
    package.loaded["606.GameUIAnimation"] = nil
    package.loaded["606.GameUIBank"] = nil
    package.loaded["606.GameUISet"] = nil
    package.loaded["606.GameUIRecord"] = nil
    package.loaded["606.GameUIDetail"] = nil
    package.loaded["606.GameBankerResult"] = nil
end

function GameUIManager.getIntPart(x)--取整
    if x <= 0 then
        return math.ceil(x)
    end
    if math.ceil(x) == x then
        x = math.ceil(x)
    else
        x = math.ceil(x) - 1
    end
    return x
end

function GameUIManager.ShowGameUIDetail(detaidates)--打开游戏记录详情
    GameAudioContro.Play(GameAudioContro.button)
    GameUIDetail.show(detaidates)
end
function GameUIManager.LimitNote(data)--限制下注
    local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.SUB_GM_Limit)  
    iLowNoteLimit = tonumber(tostring(msg.iLimitVlue))
    if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
        this.ShowRecharge()
    else
        this.HideRecharge()
    end
end

function GameUIManager.OpenRecharge()
    HallUIManager.OnBtnRecharge()
end
function GameUIManager.ShowRecharge()
    local msg="In observation mode, you need [86F351FF]"..FormatNumToYW(MoneyProportionStr(iLowNoteLimit)).."[-] gold coins to participate in the game"
    this.LbRecharge.text =msg
    this.GoRecharge:SetActive(true)
end
function GameUIManager.HideRecharge()
    this.GoRecharge:SetActive(false)
end
-- 爆池列表
function GameUIManager.SetBtnJiangChiState(state)
    -- if (not state) then
    --     this.BtnJiangChi:SetActive(false)
    -- end
end
function GameUIManager.PoolDataRefresh(data)
    -- local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolData_Fresh)  
    -- this.ipoolMoney = msg.iPoolMoney
    -- this.LbJiangChi.text = this.StringFormDouble(MoneyProportionStr(this.ipoolMoney))
    -- if (GameUIJiangChi~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdatePoolData(this.ipoolMoney)
    --     end
    -- end
end
function GameUIManager.PoolDataDistrubute(data) 
    -- this.prizeList = {}
    -- local nLen = DataParseLua.GetLuaTableLength(GameProtocal.CMD_GR_PoolData_Distrubute)
    -- local count = data.mainMsg.Length / nLen
    -- local isMyDesk = false
    -- print("*****************"..debug.getinfo(1).name..count)
    -- for i=1,count do
    --     local snopBytes = MyLuaInter.NewArray("byte", nLen)
    --     System.Array.Copy(data.mainMsg, (i-1) * nLen, snopBytes, 0, nLen)
    --     local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.CMD_GR_PoolData_Distrubute)   
    --     local userInfo = GameSUserBaseInfo.finduserbyid(cmdBigWin.uUserId)
    --     if (userInfo == nil) then
    --         return
    --     end
    --     if (MyUserInfo.iDeskNO == cmdBigWin.uDeskId) then
    --         local prizeInfoItem = {userInfo.szNickName,tostring(cmdBigWin.uPoolMoney), userInfo.iImageNO, cmdBigWin.uCardType,cmdBigWin.uUserId}
    --         table.insert(this.prizeList,prizeInfoItem)
    --         isMyDesk = true
    --     end

    --     local nowTime = System.DateTime.Now.Hour..":"..System.DateTime.Now.Minute..":"..System.DateTime.Now.Second
    --     local jiangChiIinfoItem = {tostring(cmdBigWin.uPoolMoney), userInfo.szNickName, nowTime, userInfo.iImageNO, cmdBigWin.uCardType}
    --     if (#this.jiangChiList>= 11) then
    --         table.remove(this.jiangChiList,1)
    --     end
    --     table.insert(this.jiangChiList,jiangChiIinfoItem)
    -- end
    -- if (GameUIJiangChi ~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdateUI(this.jiangChiList)
    --     end
    -- end

    -- if (isMyDesk) then
    --     isMyDesk = false
    --     local obj = UnityEngine.GameObject.Instantiate(this.GoWinPool)
    --     obj:SetActive(true)
    --     SetParent(this.SecondGroup.gameObject, obj)
    --     GameUIWinPool.transform = obj.transform
    --     GameUIWinPool.Awake()
    --     GameUIWinPool.ShowUi()
    --     GameUIWinPool.UpdateUI(this.prizeList)
    --     UnityEngine.GameObject.Destroy(obj, 3)
    -- end
end
function GameUIManager.PoolConfig(data)
    -- local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolConfig)  
    -- this.SetBtnJiangChiState(msg.cbPoolSwitch == 1)
    -- if(msg.TaxKind == 2) then
    --     this.iTaxVlue = msg.Tax
    -- else
    --     this.iTaxVlue = 0
    -- end
    -- local config = MyLuaInter.NewArray("byte", msg.CardTypeProCount)
    -- System.Array.Copy(data.mainMsg, 0, config, 0, msg.CardTypeProCount)
    -- if (GameUIJiangChi ~= nil) then
    --     GameUIJiangChi.SetPlane(config,msg.iFetchPercent)
    -- end
end
function GameUIManager.PoolRecord(data)
    this.jiangChiList = {}
    local nLen = DataParseLua.GetLuaTableLength(GameProtocal.SUB_GM_PoolRecord)
    local count = data.mainMsg.Length / nLen
    if (count > 10) then
        count = 10
    end
    for i=1,count do
        local snopBytes = MyLuaInter.NewArray("byte", nLen)
        System.Array.Copy(data.mainMsg, (count - i) * nLen, snopBytes, 0, nLen)
        local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.SUB_GM_PoolRecord)   
        local dTime = LuaInter.ByteArrayToString(cmdBigWin.sTime)
        local uName = LuaInter.ByteArrayToString(cmdBigWin.sName)
        local infoItem = {tostring(cmdBigWin.iPoolMoney), uName, dTime, cmdBigWin.cbFace, cmdBigWin.bCardType}
        table.insert(this.jiangChiList,infoItem)
    end
end
function GameUIManager.OpenJiangChiPlane()
    -- if (GameUIJiangChi ~= nil) then
    --     if (not GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.transform.gameObject:SetActive(true)
    --         GameUIJiangChi.ShowUi(this.ipoolMoney)
    --         GameUIJiangChi.UpdateUI(this.jiangChiList)
    --     end
    -- end
end
function GameUIManager.FormatNumToKW(money)
    local iFu = 1
    local note = tonumber(money)
    if note < 0 then
        iFu = -1
        note = note * -1
    end
    local v = note
    local str = ""
    --[[
    if v >= 1000 and v < 10000 then--
        str = string.format("%dK",(v / 1000))
        --str = string.format("%0.2f",(v / 1000)).."K"
    elseif v >= 10000 then 
        ]]
    if v >= 10000 then 
        str = string.format("%dW",(v / 10000))
    else
        str = tostring(v)
    end
    if iFu < 0 then
        str = "-"..str
    end

    return str
end