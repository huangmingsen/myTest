local GameRecordIterm = 
{
    IcomName ={"","LD_JS", "LD_YS", "", "LD_Yan", "LD_Ge", "LD_Kongque", "LD_Ying", "LD_Lion", "LD_Panda", "LD_Monkey", "LD_Rabit" },
}
function GameRecordIterm:new(trans)
    local _instance = {transform = trans,gameObject = trans.gameObject}
    self.__index = self 
    setmetatable(_instance, self)
    return _instance
end

function GameRecordIterm:InitUI()
    self.UISprite_Icon = FindChildByName(self.transform, "LZIcon","UISprite")
    self.Obj_First = FindChildByName(self.transform, "IsFirstBg","gameObject")
end

function GameRecordIterm:ReSet(Index,bFirst)
    self.Obj_First:SetActive(bFirst)
    self.UISprite_Icon.spriteName = GameRecordIterm.IcomName[Index+1]
end
return GameRecordIterm