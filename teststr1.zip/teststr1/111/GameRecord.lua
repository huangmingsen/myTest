local GameRecordIterm = require "606.GameRecordIterm"
local GameRecord = 
{
	ItemParent,
	Obj_Pos,-- 路单
	Obj_Iterm,--路单项

	listLDIterm = {},--路单项
	listLDData = {},--更新路单数据


	mViewPos,--视图位置                                           
	mDistane = 0.0,--间距
	mShowNum = 0,--显示个数
}
function GameRecord.Awake()
	GameRecord.ItemParent = GameRecord.transform:FindChild("UITable_First").gameObject
	GameRecord.Obj_Pos = GameRecord.transform.gameObject
	GameRecord.Obj_Iterm = GameRecord.transform:FindChild("Item_LZ").gameObject

	GameRecord.mViewPos = Vector3.New(584,0,0)
	GameRecord.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameRecord.Obj_Pos.transform.position.x, 0)
end

function GameRecord.ReSet(listLD )
	--恢复
	GameRecord.Obj_Pos.transform.localPosition = GameRecord.mViewPos
	GameRecord.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameRecord.Obj_Pos.transform.position.x, 0)

	GameRecord.listLDData = {}
	for i=1,#listLD do
		table.insert(GameRecord.listLDData,listLD[i])
	end
	GameRecord.UpdateRecord()
	print("-----录单------Over")
end
--路单项
function GameRecord.GetLDItermObj(nIndex)
	if nIndex <= #GameRecord.listLDIterm then
		GameRecord.listLDIterm[nIndex].gameObject:SetActive(true)
		return GameRecord.listLDIterm[nIndex]
	end
    local Obj = UnityEngine.GameObject.Instantiate(GameRecord.Obj_Iterm)
	Obj.name = "iterm"..nIndex
	Obj:SetActive(true)

    Obj.transform.parent = GameRecord.ItemParent.transform
	Obj.transform.position = Vector3.zero
	Obj.transform.localScale = Vector3.one
	GameRecord.ItemParent:GetComponent("UIGrid"):Reposition()
	local iterm = GameRecordIterm:new(Obj.transform)
    --GameRecord.LDParent:Reposition()
    iterm:InitUI()
	table.insert(GameRecord.listLDIterm,iterm)
	return iterm
end
--插入历史记录
function GameRecord.InsertRecordIterm(iterm)
	--40条记录就够了
	while 100 <= #GameRecord.listLDData do
		table.remove(GameRecord.listLDData,1)
	end

	table.insert(GameRecord.listLDData,iterm)
	--恢复
	GameRecord.Obj_Pos.transform.localPosition = GameRecord.mViewPos
	GameRecord.Obj_Pos:GetComponent("UIPanel").clipOffset = Vector2.New(-GameRecord.Obj_Pos.transform.position.x, 0)
	GameRecord.UpdateRecord()
end
--更新跟单记录
function GameRecord.UpdateRecord()
	local nLast = #GameRecord.listLDData
	if nLast < 18 then
		for i=1,#GameRecord.listLDIterm do
			GameRecord.listLDIterm[i].gameObject:SetActive(false)
		end
	end
	for n=nLast,1,-1 do
		local iterm = GameRecord.GetLDItermObj(nLast-n+1)
		iterm:ReSet(GameRecord.listLDData[n],(n==nLast))
	end
end
--清空
function GameRecord.ClearLDIterm()
	for n=1,#GameRecord.listLDIterm do
		local recordIterm = GameRecord.listLDIterm[n]
		if recordIterm then
			UnityEngine.GameObject.Destroy(recordIterm.gameObject)
		end
		table.remove(GameRecord.listLDIterm,n) 
	end
	GameRecord.listLDIterm = {}
end
function GameRecord.DestroyGameObj()
	GameRecord.ClearLDIterm()
	UnityEngine.GameObject.Destroy(gameObject)
end
    
function GameRecord.OnDestroy()
	GameRecord.DestroyGameObj()
    package.loaded["606.GameRecord"] = nil
end
return GameRecord