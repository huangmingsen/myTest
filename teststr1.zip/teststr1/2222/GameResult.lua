local GameUIPlayerGroup = require "607.GameUIPlayerGroup"
local GameResult = 
{
    BtnClose,
    GoWinObj,
    players = {},
    IconCarLogo,
    LbCarBet,
    GoBacks = {},
    IconLights = {},

    mPlayerCount = 255,
    mMaxPlayerStation = {},
    mMaxPlayerSouce = {},

    CarName = { "Icon_Game_JS_1", "Icon_Game_JS_5", "Icon_Game_JS_2", "Icon_Game_JS_6", "Icon_Game_JS_3", "Icon_Game_JS_7",
        "Icon_Game_JS_4", "Icon_Game_JS_8" },
    CarBet = { 40, 5, 30, 5, 20, 5, 10, 5 },
}
function GameResult.Awake()
    GameResult.BtnClose = FindChildByName(GameResult.transform, "UIGroup_Win/BtnClose","gameObject")
    UIEventListener.Get(GameResult.BtnClose).onClick = GameResult.Hide
    for i = 1, 7 do
        local trans = FindChildByName(GameResult.transform, "UIGroup_Win/Player"..i)
        GameResult.players[i] = GameUIPlayerGroup:new(trans)
        GameResult.players[i]:Init()
    end
    GameResult.IconCarLogo = FindChildByName(GameResult.transform,"UIGroup_Win/IconCarLogo","UISprite")
    GameResult.LbCarBet = FindChildByName(GameResult.transform,"UIGroup_Win/LbCarBet","UILabel")
    GameResult.GoNoteTip = FindChildByName(GameResult.transform, "UIGroup_Win/LbNoteTip","gameObject")
    GameResult.GoBacks[1] = FindChildByName(GameResult.transform,"UIGroup_Win/ImageBG_Win","gameObject")
    GameResult.GoBacks[2] = FindChildByName(GameResult.transform,"UIGroup_Win/ImageBG_Lose","gameObject")
    for i = 1, 4 do
        GameResult.IconLights[i] = FindChildByName(GameResult.transform,"UIGroup_Win/Icon_Ray_"..i,"UISprite")
    end
    GameResult.GoWinObj = FindChildByName(GameResult.transform,"Big_Win","gameObject")
    GameResult.GoWinObj:SetActive(false)
end
function GameResult.Show(prizeIndex,myWinLose,myIsNote,myIsPrize,zhuangWinLose,zhuangStation,playerName,playerwinSource,PlayerCount)
    GameResult.IconCarLogo.spriteName = GameResult.CarName[prizeIndex+1]
    GameResult.LbCarBet.text = GameResult.CarBet[prizeIndex+1]
    GameResult.GoBacks[1]:SetActive(false)
    GameResult.GoBacks[2]:SetActive(false)
    if myWinLose >= 0 then
        if not GameResult.GoWinObj then
            GameResult.GoWinObj:SetActive(true)
        end
        GameResult.GoBacks[1]:SetActive(true)
        for i = 1, 4 do
            GameResult.IconLights[i].spriteName = "Icon_JS_Win_Light"..i
        end
        GameAudioContro.Play(GameAudioContro.GameWinkAud)
    else
        GameResult.GoBacks[2]:SetActive(true)
        for i = 1, 4 do
            GameResult.IconLights[i].spriteName = "Icon_JS_Lose_Light"..i
        end
        GameAudioContro.Play(GameAudioContro.GameLoseAud)
    end
    if zhuangStation ~= MyUserInfo.iDeskStation then
        --if not myIsNote then
        --    coroutine.start(GameResult.ShowNoteTip)
        --end
        GameResult.players[1].transform.gameObject:SetActive(true)
        GameResult.players[1]:ReSetInstance(1,MyUserInfo.szNickName,myWinLose,myIsNote,myIsPrize)
        local zhuangData = GameUIManager.GetUserByStation(zhuangStation)
        if zhuangData ~= nil then
            GameResult.players[2]:ReSetInstance(2,zhuangData.szNickName,zhuangWinLose)
        else
            GameResult.players[2]:ReSetInstance(2,"",0,true)
            print("玩家为空！",zhuangStation)
        end
    else
        GameResult.players[1].transform.gameObject:SetActive(false)
        GameResult.players[2]:ReSetInstance(2,MyUserInfo.szNickName,zhuangWinLose)
    end
    for i = 3, 7 do
        if i - 2 <= PlayerCount then
            GameResult.players[i].transform.gameObject:SetActive(true)
            GameResult.players[i]:ReSetInstance(i,playerName[i - 2],playerwinSource[i - 2])
        else
            GameResult.players[i].transform.gameObject:SetActive(false)
        end
    end
    GameResult.transform.gameObject:GetComponent("Animation"):Play("Game_JS")
end
function GameResult.ShowNoteTip()
    GameResult.GoNoteTip:SetActive(true)
    coroutine.wait(2)
    GameResult.GoNoteTip:SetActive(false)
end

function GameResult.Hide()
    GameResult.GoWinObj:SetActive(false)
    GameResult.transform.gameObject:SetActive(false)
end
return GameResult