local GameUIResultIterm = 
{

}
function GameUIResultIterm:new(trans)
	local _instance = 
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self 
	setmetatable(_instance, self)
	return _instance
end
function GameUIResultIterm:InitUI()
	self.IconLogo = FindChildByName(self.transform, "Icon","UISprite")
	self.GoFlash = FindChildByName(self.transform, "Flash","gameObject")
end
--初始化
function GameUIResultIterm:Init(byResultIndex,IsFirst)
	IsFirst = IsFirst or false
    --普通奖
    self.GoFlash:SetActive(IsFirst)
    local iconId = math.floor(byResultIndex/2) + 1
    if byResultIndex % 2 ~= 0 then
        iconId = iconId + 4
    end
    self.IconLogo.spriteName = "Icon_LD_"..iconId
end
return GameUIResultIterm