local GameLogic = require "607.GameLogic"
--local GameUIJiangChi = require "607.GameUIJiangChi"
--local GameUIWinPool = require "607.GameUIWinPool"
local GameHelp = require "607.GameHelp"
local GameResult = require "607.GameResult"
local GameUIResult = require "607.GameUIResult"
local GameUIBetIterm = require "607.GameUIBetIterm"
local GameTimeClock = require "607.GameTimeClock"
local GameBlinkController = require "607.GameBlinkController"
local ChoumaManager = require "607.ChoumaManager"
-- local GameUIPlayerList = require "607.GameUIPlayerList"
-- local GameUIShangZhuangList = require "607.GameUIShangZhuangList"
-- local GameGoldManager = require "607.GameGoldManager"
local GameDetail = require "607.GameDetail"
local GameRecord = require "607.GameRecord"
local GameSet = require "607.GameSet"
-- local GameBank = require "607.GameBank"
local bit = require"bit"

GameUIManager =
{
    FirstGroup,
    SecondGroup,
    Button_Menu,--菜单
    Button_Exit,
    Button_Help,
    Button_Bank1,
    Button_Bank2,
    Button_Chat,--聊天
    BtnRecord,
    IconRedDot,
    Button_Record,
    TrasMenuBack,

    Station = 0,--游戏状态

    TotalPercentCount = 0,--游戏状态  //todo
    Icon_Team,--车标数组

    BtnZhangKai,--显示下注
    BtnShouQi,--隐藏下注

    BtnContinueBet,--继续下注
    BtnCancelBet,--取消下注

    AnimaXiaZhuPlane,

    TwpMenu,

    BtnChips = {},
    LbZhuMa = {},

    TransIconSelected,
    IconGameLevel,

    mCheckIndex = 5,--筹码下标

    mBase = {40, 5, 30, 5, 20, 5, 10, 5},--倍率
    mChips = {},--筹码
    CurMyBet = {},--用户的下注信息
    CurTotalBet = {},--用户的下注信息
    m_PrizesCount = {},--概率
    mBetIterm = {},

    ResultList = {},--开奖记录

    LbMyGode,--自己的金币
    LbMyName,--玩家名字
    LbMyLV,--玩家名字
    LbAllDownBet,--总下注的豆豆

    userNoteInfoList = {},



    AllNoteMoney = 0,--总下注的游戏币
    AllPlayerNoteMoney = 0,--总下注的游戏币
    WinLoseMoney = 0,--赢的游戏币
    mZhuangWinLose = 0,--庄输赢钱

    IsHuanZhuang = false,--当局是否是换庄
    IsContinueBet = false,--是否已经续压

    IsHideLoading = false,--初始化隐藏loading
    currentTime = 0.0,

    --------新增-------------
    LeastMoneyZhuang = -1,
    LeastGamesZhuang = 0,
    MaxGamesZhuang = 0,
    CurrNTCount = 0,
    PeviousZhuangStation = -1,
    StationZhuang = -1,

    playerCount = 255,
    mMaxWinMoneyName = {},
    mMaxWinSouce = {},

    BtnOnLine,
    btnShangZhuang,
    btnXiaZhuang,
    LbZhuangName,
    LbZhuangLV,
    LbZhuangMoney,
    LbWaitUpZhuang,
    LbOnLine,--在线列表
    ZhuangList = {},

    TipGroup = {},
    GoWinFlash = {},

    onLinePlayer = {},
    onLineUserList = {},

    XianPos = Vector3.New(-576, -164, -15),
    ZhuangPos = Vector3.New(-418, 85, -15),
    MyMoneyPos = Vector3.New(-594, -329, -15),
    ASS_MSG_ERROR_TYPE =
    {
        NOTE_ERROR_NONE = 0,--无错误
        NOTE_ERROR_KIND = 1,--下注筹码类型不对
        NOTE_ERROR_DESKSTATION = 2,--座位号不对
        NOTE_ERROR_ACTIVE = 3,--对应座位上没有玩家
        NOTE_ERROR_NOTENOUNGH_MONEY = 4,--钱不足
        NOTE_ERROR_NOTELIMIT = 5,
        NOTE_ERROR_UNKNOWN = 6,--未知错误
    },
    ----------------------
    GoWinPool,
    BtnJiangChi,
    JiangChiState = false,
    jiangChiList = {},
    prizeList = {},
    ipoolMoney = 0,
    iTaxVlue = 0,
    LbJiangChi,
    PrizeData = {},

    BtnRecharge,
    LbRecharge,
    GoRecharge,
    ----------------------
    coroutineParent,
    MainBtnRecharge,
    BetPos = {{Vector3.New(-313, 111, 0),Vector3.New(-350, 59, 0)},
              {Vector3.New(-320, -50, 0),Vector3.New(-300, -80, 0)},
              {Vector3.New(-90, 102, 0),Vector3.New(-136, 59, 0)},
              {Vector3.New(-90, -56, 0),Vector3.New(-118, -101, 0)},
              {Vector3.New(143, 102, 0),Vector3.New(97, 59, 0)},
              {Vector3.New(140, -56, 0),Vector3.New(105, -101, 0)},
              {Vector3.New(357, 102, 0),Vector3.New(328, 59, 0)},
              {Vector3.New(350, -28, 0),Vector3.New(335, -59, 0),Vector3.New(278, -92, 0)}}
}
local TipsCoroutine = nil
local ComCoroutine = nil
local iLowNoteLimit = 0
local isGameOverAnima = false
local ListGolds = {}
local isFirstInGame = false
local isFirstPlayList = false

local this=GameUIManager
function GameUIManager.InitUI()
    this.InstanceData()
	this.FirstGroup = this.transform:FindChild("UI_Game/PanelFirst/UIStretch/Group/Game_Group")
    this.SecondGroup = this.transform:FindChild("UI_Game/PanelSecond/UIStretch/Group")

	this.Button_Menu = this.FirstGroup:FindChild("Game_Right/BtnMenu").gameObject:GetComponent("UIButton")
	this.Button_Exit = this.FirstGroup:FindChild("Game_Left/BtnClose").gameObject
	this.Button_Help = this.FirstGroup:FindChild("Menu_Panel/Menu/BtnHelp").gameObject
	-- this.Button_Chat = this.FirstGroup:FindChild("Game_Right/BtnChat").gameObject
    -- this.IconRedDot = this.FirstGroup:FindChild("Game_Right/BtnChat/IconRedDot").gameObject
	-- this.Button_Bank1 = this.FirstGroup:FindChild("Game_Down/BtnBank").gameObject
    -- this.Button_Bank2 = this.FirstGroup:FindChild("Menu_Panel/Menu/BtnBank").gameObject
    this.TrasMenuBack = this.FirstGroup:FindChild("Menu_Panel/Menu/MenuBack")--点击背景

    this.BtnContinueBet = this.FirstGroup:FindChild("Game_Down/BtnContinueBet").gameObject:GetComponent("UIButton")
    if this.BtnContinueBet then
        UIEventListener.Get(this.BtnContinueBet.gameObject).onClick = this.OnContinueBetBtnPress
    end

    this.LbMyGode = this.FirstGroup:FindChild("Game_Down/Player_Team/LbMyGold").gameObject:GetComponent("UILabel")
    this.LbMyName = this.FirstGroup:FindChild("Game_Down/Player_Team/LbMyName").gameObject:GetComponent("UILabel")
    -- this.LbMyLV = this.FirstGroup:FindChild("Game_Down/Player_Team/LbVip").gameObject:GetComponent("UILabel")
    this.LbMyName.text = MyUserInfo.szNickName

    for i = 1,5 do
        this.TipGroup[i] = this.FirstGroup:FindChild("Game_Center/Tips_Group/Tips_"..i).gameObject
        this.TipGroup[i]:SetActive(false)
    end
    --this.btnShangZhuang = this.FirstGroup:FindChild("Game_Center/UI_Xiazhu/BtnShangZhuang").gameObject:GetComponent("UIButton")
    --if this.btnShangZhuang then
    --    UIEventListener.Get(this.btnShangZhuang.gameObject).onClick = this.BtnShangZhuangPress
    --end
    this.BtnOnLine = this.FirstGroup:FindChild("Game_Left/BtnOnLine").gameObject:GetComponent("UIButton")
    if this.BtnOnLine then
        UIEventListener.Get(this.BtnOnLine.gameObject).onClick = this.BtnOnLinePress
    end
    this.btnShangZhuang = this.FirstGroup:FindChild("Game_Center/UI_Xiazhu/BtnShangZhuang").gameObject:GetComponent("UIButton")
    --this.btnXiaZhuang = this.FirstGroup:FindChild("Game_Center/UI_Xiazhu/BtnXiaZhuang").gameObject:GetComponent("UIButton")
    --if this.btnXiaZhuang then
    --    UIEventListener.Get(this.btnXiaZhuang.gameObject).onClick = this.BtnXiaZhuangPress
    --end
    --this.btnXiaZhuang.gameObject:SetActive(false)

    for i=1,8 do
        local trans = this.FirstGroup:FindChild("Game_Center/XiaZhuPlane/Btn"..i)
        this.mBetIterm[i] = GameUIBetIterm:new(trans)
        this.mBetIterm[i]:InitUI(i)
    end
    for i=1,6 do
        this.BtnChips[i] = this.FirstGroup:FindChild("Game_Down/BetBtnList/Btn"..(i-1)).gameObject --注码事件
    	UIEventListener.Get(this.BtnChips[i]).onClick = this.OnGameChouMa
        this.LbZhuMa[i] = this.FirstGroup:FindChild("Game_Down/BetBtnList/Btn"..(i-1).."/Label").gameObject:GetComponent("UILabel") --注码Text
    end
    this.LbAllDownBet = this.FirstGroup:FindChild("Game_Center/LbAllDownBet").gameObject:GetComponent("UILabel")
    for i = 1, 8 do
        this.GoWinFlash[i] = FindChildByName(this.FirstGroup,"Game_Center/Win_Ray/Ani_"..i,"gameObject")
    end
    -- this.LbZhuangName = this.FirstGroup:FindChild("Game_Center/UI_Xiazhu/LbZhuangName").gameObject:GetComponent("UILabel")
    -- this.LbZhuangMoney = this.FirstGroup:FindChild("Game_Center/UI_Xiazhu/LbZhuangGold").gameObject:GetComponent("UILabel")
    -- this.LbZhuangLV = this.FirstGroup:FindChild("Game_Center/UI_Xiazhu/LbVip").gameObject:GetComponent("UILabel")
    -- this.LbWaitUpZhuang = this.FirstGroup:FindChild("Game_Center/UI_Xiazhu/Lb_PaiDui").gameObject:GetComponent("UILabel")

    this.LbOnLine = this.FirstGroup:FindChild("Game_Left/BtnOnLine/Label_Player").gameObject:GetComponent("UILabel")
    this.LbOnLine.gameObject:SetActive(false)
    this.TransIconSelected = this.FirstGroup:FindChild("Game_Down/BetBtnList/IconSelected").gameObject.transform --注码选中光环
    this.IconGameLevel = FindChildByName(this.FirstGroup, "Game_Left/IconGameLevel","UISprite")
    local gameLVName = {"Txt_ChangCi1","Txt_ChangCi2","Txt_ChangCi3","Txt_ChangCi4"}
    this.IconGameLevel.spriteName = gameLVName[UIRoom.SelectRoomInfo.iRoomLevel+1]

    ----------------------------
    GameLogic.Awake()

    this.Button_Record = FindChildByName(this.FirstGroup,"Menu_Panel/Menu/BtnRecord","gameObject")
    
    -- this.MainBtnRecharge = FindChildByName(this.FirstGroup, "Game_Left/BtnRecharge","gameObject")
   
    -- this.BtnRecharge = FindChildByName(this.FirstGroup, "Game_Down/CZ_Tips/BtnRecharge","gameObject")
    -- this.LbRecharge = FindChildByName(this.FirstGroup, "Game_Down/CZ_Tips/Label_Tips","UILabel")
    -- this.GoRecharge = FindChildByName(this.FirstGroup, "Game_Down/CZ_Tips","gameObject")

    -- this.BtnJiangChi = this.FirstGroup:FindChild("Game_Center/BtnJiangChi").gameObject
    -- this.LbJiangChi = this.FirstGroup:FindChild("Game_Center/BtnJiangChi/Label_Coin").gameObject.gameObject:GetComponent("UILabel")
    -- this.BtnJiangChi:SetActive(false)
    GameTimeClock.transform = this.FirstGroup:FindChild("Game_Center/TimeCount")
    GameTimeClock:Awake()
    -- GameBank.transform = this.SecondGroup:FindChild("GameBank")
    -- GameBank.Awake()
    GameSet.transform = this.FirstGroup:FindChild("Menu_Panel/Menu")
    GameSet.Awake()
    GameHelp.transform = this.SecondGroup:FindChild("UIHelp")
    GameHelp.Awake()
    --GameUIJiangChi.transform = this.SecondGroup:FindChild("Game_JiangChi")
    --this.GoWinPool = this.SecondGroup:FindChild("Game_JiangChi_Win").gameObject
    --GameUIJiangChi.Awake()

    -- GameUIPlayerList.transform = this.SecondGroup:FindChild("Player_List")
    -- GameUIPlayerList.Awake()
    -- GameUIShangZhuangList.transform = this.SecondGroup:FindChild("Zhuang_List")
    -- GameUIShangZhuangList.Awake()
    -- GameGoldManager.transform = this.FirstGroup:FindChild("ChouMaParent")
    -- GameGoldManager.Awake()


    GameBlinkController.transform = this.FirstGroup:FindChild("Game_Center/Icon_Team")
    GameBlinkController.Awake()
    GameUIResult.transform = this.FirstGroup:FindChild("Game_Right/HistoryTeam")
    GameUIResult.Awake()
    GameResult.transform = this.SecondGroup:FindChild("UIJiesuan")
    GameResult.Awake()
    GameRecord.transform = this.SecondGroup:FindChild("GameUIRecord")
    GameRecord.Awake()
    GameDetail.transform = this.SecondGroup:FindChild("GameUIDetail")
    GameDetail.Awake()
    ----------------------------
    GameResult.transform.gameObject:SetActive(false)
    -- GameBank.transform.gameObject:SetActive(false)
    -- GameUIShangZhuangList.transform.gameObject:SetActive(false)
    -- GameUIPlayerList.transform.gameObject:SetActive(false)
    GameHelp.transform.gameObject:SetActive(false)
    --GameUIJiangChi.transform.gameObject:SetActive(false)
    -- GameGoldManager.transform.gameObject:SetActive(false)
    isFirstInGame = true
    --this.GoWinPool:SetActive(false)
    this.UpDatePlayerInfo()--在线列表
    this.UpDateChooseBet(1)

    --停止所有的动画
    this.StopAllAnimation(true)
    this.StartNotking()
end
function GameUIManager.InstanceData()
    for i=1,8 do
        this.CurMyBet[i] = 0
        this.CurTotalBet[i] = 0
    end
    for i=1,6 do
        this.mChips[i] = 0
    end
end
function GameUIManager.Start()
    this.InitUI()
    this.InitEvent()
    --UIRoom.StartListenData()--资源初始化完成，开始接收消息
end
function GameUIManager.StartNotking()
    UIRoom.StartListenData()--资源初始化完成，开始接收消息
    UpdateBeat:Add(this.UpData)
    --UpdateBeat:Add(this.Update)
end

function GameUIManager.ShowJoinGameAnima()
    if not isFirstInGame then
        return
    end
    isFirstInGame = false

    local delayFunc = function ()
        WaitForSeconds(0.2)
        this.FirstGroup.gameObject:GetComponent("Animation"):Play()
    end
	StartCoroutine(delayFunc)   
end


function GameUIManager.InitEvent()
    -- if IsClosePay then
    --     this.MainBtnRecharge:SetActive(false)
    -- end
    -- if not CommonBase.IsShowBank then
    --     this.Button_Bank1.gameObject:SetActive(false)
    --     this.Button_Bank2.gameObject:SetActive(false)
    --     this.TrasMenuBack.localScale = Vector3.New(1,0.8,1)
    -- end
    -- this.Button_Chat.gameObject:SetActive(MainMenus.IsShowChat)
    UIEventListener.Get(this.Button_Menu.gameObject).onClick = function()
        local TwpMenu = this.FirstGroup:FindChild("Menu_Panel/Menu").gameObject:GetComponent("TweenPosition")
        if TwpMenu.transform.localPosition.y < 500 then
            this.Button_Menu.normalSprite = "UI_BT_Down"
            TwpMenu.from = Vector3.New(638, 280, 0)
            TwpMenu.to = Vector3.New(638, 800, 0)
            TwpMenu.enabled = true
            TwpMenu:ResetToBeginning()
            TwpMenu:PlayForward()
        else
            this.Button_Menu.normalSprite = "UI_BT_Up"
            TwpMenu.from = Vector3.New(638, 800, 0)
            TwpMenu.to = Vector3.New(638, 280, 0)
            TwpMenu.enabled = true
            TwpMenu:ResetToBeginning()
            TwpMenu:PlayForward()
        end
        GameAudioContro.Play(GameAudioContro.button)
    end
    UIEventListener.Get(this.btnShangZhuang.gameObject).onClick = function()
        GameUIShangZhuangList.ShowUI()
    end
    UIEventListener.Get(this.Button_Exit).onClick = function()
        if this.StationZhuang == MyUserInfo.iDeskStation then
            LblMsgText.Show("You are a banker! Please wait until you leave the villa!")
        elseif this.AllNoteMoney > 0  then
            LblMsgText.Show("You have bet! Please wait until the game is over before exiting!")
        else
            MessageBox.Show("Are you sure quit the game?", this.QuitGame)
        end
        GameAudioContro.Play(GameAudioContro.button)
    end
    UIEventListener.Get(this.Button_Help).onClick = function()
        GameHelp.Show(this.iTaxVlue,this.LeastGamesZhuang,this.JiangChiState)
        GameAudioContro.Play(GameAudioContro.button)
    end
    UIEventListener.Get(this.Button_Bank1).onClick = function()
        if LbIsNeedBindAccount == nil then
            if IsNeedBindGuest or (AccountBindType == 3 and (Network.logintype ~= 4 or not WxRegIsNoUpgrade)) then
                LblMsgText.Show("Please bind your account!")
                return
            end
            GameBank.Show()
        else
            if LbIsNeedBindAccount then
                LblMsgText.Show("Please bind your account!")
            else
                GameBank.Show()
            end
        end
        GameAudioContro.Play(GameAudioContro.button)
    end
    UIEventListener.Get(this.Button_Bank2).onClick = function()
        if LbIsNeedBindAccount == nil then
            if IsNeedBindGuest or (AccountBindType == 3 and (Network.logintype ~= 4 or not WxRegIsNoUpgrade)) then
                LblMsgText.Show("Please bind your account!")
                return
            end
            GameBank.Show()
        else
            if LbIsNeedBindAccount then
                LblMsgText.Show("Please bind your account!")
            else
                GameBank.Show()
            end
        end
        GameAudioContro.Play(GameAudioContro.button)
    end
    UIEventListener.Get(this.Button_Chat).onClick = function()
        HallUIManager.OnBtnChat()
        GameAudioContro.Play(GameAudioContro.button)
        this.IconRedDot:SetActive(false)
    end
    if lobyUIRadio ~= nil then
        lobyUIRadio.GameChatTypeFunc = function()
            this.IconRedDot:SetActive(true)
        end
    end
    if this.Button_Record then
        UIEventListener.Get(this.Button_Record).onClick = function() --打开游戏记录
            GameAudioContro.Play(GameAudioContro.button)
            GameRecord.show()
        end
    end
    UIEventListener.Get(this.BtnRecharge).onClick = this.OpenRecharge
    UIEventListener.Get(this.MainBtnRecharge).onClick = this.OpenRecharge
    --奖池
    UIEventListener.Get(this.BtnJiangChi).onClick = this.OpenJiangChiPlane --奖池
end
--续押
function GameUIManager.OnContinueBetBtnPress()
    if this.GoRecharge.gameObject.activeSelf then
        return
    end
    if this.AllNoteMoney > 0 then
        LblMsgText.Show("You have placed a bet and cannot continue!")
        return
    end
    NetManager:SendData(2000180,GameProtocal.GM_SUB_CONTINUE_NOTE)
end

--在线玩家列表
function GameUIManager.BtnOnLinePress()
    do
        return
    end
    if not isFirstPlayList then
        GameUIPlayerList.ReSetData(this.onLineUserList)
    end
    isFirstPlayList = true

    GameUIPlayerList.ShowUI(this.onLineUserList)
end
--上庄
function GameUIManager.BtnShangZhuangPress()
    GameProtocal.CMD_GM_NtInfo[1].data = 0
    GameProtocal.CMD_GM_NtInfo[2].data = MyUserInfo.iDeskStation
    local sendrob = DataParseLua.StructToBytes(GameProtocal.CMD_GM_NtInfo)
    NetManager:SendData(sendrob,2000180,GameProtocal.GM_SUB_NT_INFO)
end
--下庄
function GameUIManager.BtnXiaZhuangPress()
    GameProtocal.CMD_GM_NtInfo[1].data = 1
    GameProtocal.CMD_GM_NtInfo[2].data = MyUserInfo.iDeskStation
    local sendrob = DataParseLua.StructToBytes(GameProtocal.CMD_GM_NtInfo)
    NetManager:SendData(sendrob,2000180,GameProtocal.GM_SUB_NT_INFO)
end
function GameUIManager.QuitGame()
    UIRoom.QuitGame()
end
--游戏状态 1001
function GameUIManager.GameStation(data)
    GameTimeClock.StopClock()
    local state = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Base)
    this.Station = state.bStation
    this.LeastMoneyZhuang = state.iNtLeastMoney
    this.LeastGamesZhuang = state.NtLeastGames
    this.MaxGamesZhuang = state.MaxNtGames
    this.CurrNTCount = state.iNtCount
    this.PeviousZhuangStation = state.iNtStation
    this.StationZhuang = state.iNtStation
    -- this.RefreshZhuangInfo()
    --GameGoldManager.HideAllGole()
    ChoumaManager:RecoverAllChip()
    this.HideWinFlash()
    this.IsContinueBet = true
    print("--进入游戏 初始状态--",this.Station)
    this.WinLoseMoney = 0
    this.InitBetData()--重置下注界面
    GameDetail.Hide()
    GameRecord.Hide()
    --下注
    if this.Station == GameLogic.GAME_STATE.ENUM_GAMESTATE_NOTE then
        GameAudioContro.PlayBg(GameAudioContro.BGBetAud)
        GameResult.Hide()--隐藏结算界面
        -- if this.StationZhuang == MyUserInfo.iDeskStation then
        --     this.UpdateBetBtnStatus(false)
        -- else
        --     this.UpdateBetBtnStatus(true)
        -- end
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Note)
        this.InItData(msg)
        this.EnabledBtn( true )
        this.SetChouMaBetButtonIsEnable()

        local clockTick = math.ceil(msg.iLeftTick/1000)
        if msg.iLeftTick%1000 > 500 then
            clockTick = clockTick + 1
        end
        --开始计时
        GameTimeClock.StartClock(nil,clockTick-2,1)
        if clockTick > 5 then
            this.ShowNoteTip(2)--提示下注
        end
        this.ShowTip()
    --开奖
    elseif this.Station == GameLogic.GAME_STATE.ENUM_GAMESTATE_OPENPRIZE then
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Open)
        GameAudioContro.PlayBg(GameAudioContro.BGRunAud)
        this.InItData(msg)
        --下注遮挡层
        -- this.UpdateBetBtnStatus(false)
        this.WinLoseMoney = tonumber(tostring(msg.WinMoney))

        this.mZhuangWinLose = tonumber(tostring(msg.mBankerWinMoney))

        this.playerCount = msg.RankingCount
        for i=1,msg.RankingStation.Length do
            local userData = this.GetUserByStation(msg.RankingStation[i-1])
            this.mMaxWinMoneyName[i] = userData.szNickName
        end
        for i=1,msg.RankingMoney.Length do
            this.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end
        this.coroutineParent = coroutine.start(this.WaitOpenPrizeAnimation,msg)
        local clockTick = math.ceil(msg.iLeftTick/1000)
        if msg.iLeftTick%1000 > 500 then
            clockTick = clockTick + 1
        end
        this.EnabledBtn( false )
        --开始计时
        GameTimeClock.StartClock(nil,clockTick,2)
    --结算
    elseif this.Station == GameLogic.GAME_STATE.ENUM_GAMESTATE_SETTLEMENT then
        GameAudioContro.PlayBg(GameAudioContro.BGRunAud)
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Settlement)
        this.InItData(msg)
        this.WinLoseMoney = msg.WinMoney

        this.mZhuangWinLose = msg.mBankerWinMoney

        this.playerCount = msg.RankingCount
        for i=1,msg.RankingStation.Length do
            local userData = this.GetUserByStation(msg.RankingStation[i-1])
            this.mMaxWinMoneyName[i] = userData.szNickName
        end
        for i=1,msg.RankingMoney.Length do
            this.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end
        local clockTick = math.ceil(msg.iLeftTick/1000)
        if msg.iLeftTick%1000 > 500 then
            clockTick = clockTick + 1
        end
        this.EnabledBtn( false )
        --开始计时
        GameTimeClock.StartClock(nil,clockTick,2)
    else
        GameAudioContro.PlayBg(GameAudioContro.BGBetAud)
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Next)
        --筹码
        for i=1,msg.Chip.Length do
            this.mChips[i] = msg.Chip[i-1]
        end
        --历史记录
        this.AddResultList(msg.ResultCount, msg.ResultList)
        GameUIResult.UpdateResultList(this.ResultList)
        this.EnabledBtn( true )
    end
    print("--游戏状态1001--")
    this.UpdateChipBtnStatus()
    this.RefreshUserInfo()
    this.ShowJoinGameAnima()
    print("--游戏状态1001--Over--")
end

function GameUIManager.InItData(msg)
    --筹码
    for i=1,msg.Chip.Length do
        this.mChips[i] = msg.Chip[i-1]
    end
    --更新下注
    for i=1,msg.SelfAreaNotes.Length do
        this.CurMyBet[i] = msg.SelfAreaNotes[i-1] --每个下注区域的下注额度
    end
    --总下注
    this.AllNoteMoney = msg.SelfTotalNotes
    --历史记录
    this.AddResultList(msg.ResultCount, msg.ResultList)
    GameUIResult.UpdateResultList(this.ResultList)

end
--游戏状态更新 1002
function GameUIManager.GameStateSwitch(data)
    local state = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_StateSwitch)
    this.Station = state.iState
    print("--游戏状态更新--1002--Start--",this.Station)
    --下注
    if this.Station == GameLogic.GAME_STATE.ENUM_GAMESTATE_NOTE then
        GameAudioContro.PlayBg(GameAudioContro.BGBetAud)
        GameAudioContro.Play(GameAudioContro.StartBetAud)
        --停止所有的动画
        this.StopAllAnimation(true)
        -- if this.StationZhuang == MyUserInfo.iDeskStation then
        --     this.UpdateBetBtnStatus(false)
        -- else
        --     this.UpdateBetBtnStatus(true)
        -- end
        this.IsContinueBet = true
        GameResult.Hide()
        this.InitBetData()--重置下注界面

        GameGoldManager.HideAllGole()--隐藏所有注码
        this.HideWinFlash()
        this.EnabledBtn( true )
        this.SetChouMaBetButtonIsEnable()
        this.coroutineParent = coroutine.start(this.ShowStartAnima)--提示下注
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_StateSwitch_Note)
        this.CurrNTCount = msg.iNtGames

        GameTimeClock.StopClock()
        local clockTick = math.ceil(msg.Tick / 1000)
        --开始计时
        GameTimeClock.StartClock(nil,clockTick-1,1)
        this.PeviousZhuangStation = this.StationZhuang
        --清除下注区域筹码
        for i=1,#this.CurMyBet do
            this.CurMyBet[i] = 0
            this.CurTotalBet[i] = 0
        end
        this.AllNoteMoney = 0
        this.WinLoseMoney = 0
        --每个下注区域的下注额度
        this.RefreshUserInfo()
        if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
            this.ShowRecharge()
        else
            this.HideRecharge()
        end
    elseif this.Station == GameLogic.GAME_STATE.ENUM_GAMESTATE_OPENPRIZE then
        GameAudioContro.PlayBg(GameAudioContro.BGRunAud)
        GameAudioContro.Play(GameAudioContro.EndBetAud)
        this.ShowNoteTip(3)--提示停止下注
        ListGolds = {}
        this.IsContinueBet = false
        local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_StateSwitch_Open)
        -- this.UpdateBetBtnStatus(false)
        --开奖状态  直接隐藏时钟
        this.coroutineParent = coroutine.start(this.PlayOpenPrizeAnimation,msg.PrizeIndex)
        --输赢的钱
        this.WinLoseMoney = tonumber(tostring(msg.WinLoseMoney))
        this.TotalPercentCount = msg.iCurGameCount

        this.mZhuangWinLose = tonumber(tostring(msg.BankerWinMoney));

        this.playerCount = msg.RankingCount

        for i=1,msg.RankingStation.Length do
            local userData = this.GetUserByStation(msg.RankingStation[i-1])
            this.mMaxWinMoneyName[i] = userData.szNickName
        end
        for i=1,msg.RankingMoney.Length do
            this.mMaxWinSouce[i] = msg.RankingMoney[i-1]
        end
        --同步服务端100局清空一次
        if this.TotalPercentCount >= 100 then
            this.ResultList = {}
        end
        --长度限制在20以内
        while #this.ResultList >= 20 do
            table.remove(this.ResultList,1)
        end
        table.insert(this.ResultList,msg.Prize)
        this.EnabledBtn( false )
        GameTimeClock.StopClock()
        local clockTick = math.ceil(msg.Tick / 1000)
        GameTimeClock.StartClock(nil,clockTick,2)
    elseif this.Station == GameLogic.GAME_STATE.ENUM_GAMESTATE_SETTLEMENT then
        this.ShowGameJS()--显示结算界面
    end
    print("--游戏状态更新--1002--Over--",this.Station)
end

--玩家下注 1003
function GameUIManager.GameNoteResult(noteResultData)
    if noteResultData.State ~= 0 then
        return
    end
    if MyUserInfo.iDeskStation == noteResultData.nDeskStation then
        this.CurMyBet[noteResultData.AreaIndex+1] = this.CurMyBet[noteResultData.AreaIndex+1] + noteResultData.NoteMoney
        this.AllNoteMoney = this.AllNoteMoney + noteResultData.NoteMoney

        this.IsContinueBet = true
        for i=1,#this.mChips do
            if this.mChips[i] == tonumber(tostring(noteResultData.NoteMoney)) then
                this.PlayGoldAnimation(noteResultData.nDeskStation,noteResultData.AreaIndex+1, i)
                break
            end
        end
    else
        for i=1,#this.mChips do
            if this.mChips[i] == noteResultData.NoteMoney then
                local snoplistgode = {noteResultData.nDeskStation,noteResultData.AreaIndex+1, i}
                if #ListGolds < 100 then
                    table.insert(ListGolds,snoplistgode)
                end
                --this.PlayGoldAnimation(noteResultData.nDeskStation, noteResultData.AreaIndex+1, i)
                break
            end
        end
    end
    this.CurTotalBet[noteResultData.AreaIndex+1] = this.CurTotalBet[noteResultData.AreaIndex+1] + noteResultData.NoteMoney
    --更新下注
    this.RefreshUserInfo()
    this.SetChouMaBetButtonIsEnable()
end
--玩家续压 1004
function GameUIManager.GameContinueNote(continueNoteData)
    if continueNoteData.mState ~= 0 then
        return
    end
    if this.AllNoteMoney > 0 then
        return
    end
    local isNote = false
    for i=1,continueNoteData.AreaNoteMoney.Length do
        if MyUserInfo.iDeskStation == continueNoteData.nDeskStation then
            this.CurMyBet[i] = this.CurMyBet[i] + continueNoteData.AreaNoteMoney[i-1]
            if continueNoteData.AreaNoteMoney[i-1] > 0 then
                isNote = true
            end
            this.AllNoteMoney = this.AllNoteMoney + continueNoteData.AreaNoteMoney[i-1]
            this.IsContinueBet = false
            --更新
        end
        this.ContinuePlayGoldGruop(continueNoteData.nDeskStation,continueNoteData.AreaNoteMoney[i-1], i)
        this.CurTotalBet[i] = this.CurTotalBet[i] + continueNoteData.AreaNoteMoney[i-1]
    end
    this.RefreshUserInfo()
end
--清除所有 1006
function GameUIManager.GameCancelAllNote(cancelAllNoteData)
    for i=1,cancelAllNoteData.NoteMoney.Length do
        if MyUserInfo.iDeskStation == cancelAllNoteData.nDeskStation then
            this.CurMyBet[i] = this.CurMyBet[i] + cancelAllNoteData.NoteMoney[i-1]
            this.AllNoteMoney = this.AllNoteMoney + cancelAllNoteData.NoteMoney[i-1]
        end
        this.CurTotalBet[i] = this.CurTotalBet[i] + cancelAllNoteData.NoteMoney[i-1]
    end
    --更新下注
    this.RefreshUserInfo()
    print("GameCancelAllNote")
end
--下注详情 1010
function GameUIManager.GameStatistice(userMoneyData)
    for i=1,userMoneyData.AreaNotes.Length do
        this.CurTotalBet[i] = userMoneyData.AreaNotes[i-1]
    end
    GameGoldManager.SetAreaGold()
    --更新概率
    this.RefreshUserInfo()
end
function GameUIManager.GameNtInfo(ntInfoData)--庄家信息 1012
    --0:上庄 1:下庄  2：切换庄家   10:上庄钱不足 11：本局结束后就可以下庄    >20  (还差多少局)
    print("--庄家信息--",ntInfoData.state)
    if ntInfoData.state == 0 then
        if not this.ListContains(this.ZhuangList,ntInfoData.bDeskStation) then
            if ntInfoData.bDeskStation >= 0 and ntInfoData.bDeskStation < 180 then
                table.insert(this.ZhuangList,ntInfoData.bDeskStation)
            end
        end
        --if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
        --    this.btnShangZhuang.gameObject:SetActive(false)
        --    this.btnXiaZhuang.gameObject:SetActive(true)
        --end
        local lastCount = this.MaxGamesZhuang - this.CurrNTCount
        GameUIShangZhuangList.UpdateData(this.ZhuangList,this.StationZhuang,this.LeastMoneyZhuang,lastCount)
    elseif ntInfoData.state == 1 then
        if this.ListContains(this.ZhuangList,ntInfoData.bDeskStation) then
            for i=1,#this.ZhuangList do
                if this.ZhuangList[i] == ntInfoData.bDeskStation then
                    table.remove(this.ZhuangList,i)
                    break
                end
            end
        end
        --if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
        --    this.btnShangZhuang.gameObject:SetActive(true)
        --    this.btnXiaZhuang.gameObject:SetActive(false)
        --end
        local lastCount = this.MaxGamesZhuang - this.CurrNTCount
        GameUIShangZhuangList.UpdateData(this.ZhuangList,this.StationZhuang,this.LeastMoneyZhuang,lastCount)
    elseif ntInfoData.state == 2 then
        --if MyUserInfo.iDeskStation == this.StationZhuang then
        --    this.btnShangZhuang.gameObject:SetActive(true)
        --    this.btnXiaZhuang.gameObject:SetActive(false)
        --end
        this.IsHuanZhuang = true
        if ntInfoData.bDeskStation == 255 then
            this.PeviousZhuangStation = this.StationZhuang
        else
            if this.StationZhuang == -1 or this.StationZhuang == 255 then
                this.PeviousZhuangStation = ntInfoData.bDeskStation
            else
                this.PeviousZhuangStation = this.StationZhuang
            end
        end
        this.StationZhuang = ntInfoData.bDeskStation
        if this.ListContains(this.ZhuangList,ntInfoData.bDeskStation) then
            for i=1,#this.ZhuangList do
                if this.ZhuangList[i] == ntInfoData.bDeskStation then
                    table.remove(this.ZhuangList,i)
                    break
                end
            end
        end
        --if MyUserInfo.iDeskStation == ntInfoData.bDeskStation then
        --    this.btnShangZhuang.gameObject:SetActive(false)
        --    this.btnXiaZhuang.gameObject:SetActive(true)
        --end
        local lastCount = this.MaxGamesZhuang - this.CurrNTCount
        GameUIShangZhuangList.UpdateData(this.ZhuangList,this.StationZhuang,this.LeastMoneyZhuang,lastCount)
        --this.ShowNoteTip(4)
    elseif ntInfoData.state == 10 then
        LblMsgText.Show("Insufficient money")
    elseif ntInfoData.state == 11 then
        LblMsgText.Show("The dealer is successful, and the dealer will be automatically placed after the end of the game!")
    else
        if ntInfoData.state > 21 then
            --LblMsgText.Show("还有"..(ntInfoData.state - 20).."局后可以下庄！")
            LblMsgText.Show("There are still "..(ntInfoData.state - 20).." rounds in the game before you can stop being the dealer!")
        elseif ntInfoData.state == 21 then
            LblMsgText.Show("After this game is over, you can not be a banker!")
        end
    end
    this.RefreshZhuangInfo()
    print("--庄家信息--Over")
end
function GameUIManager.GameStartAccount()
    isGameOverAnima = true
end
--region 更新用户信息
--更新 下注总筹码
function GameUIManager.RefreshUserInfo()
    if isGameOverAnima then
        return
    end
    this.AllPlayerNoteMoney = 0
    local AllMyMoney = 0
    for n=1,#this.CurMyBet do
        this.mBetIterm[n]:SetBet(this.CurMyBet[n],this.CurTotalBet[n])
        AllMyMoney = AllMyMoney + this.CurMyBet[n]
        this.AllPlayerNoteMoney = this.AllPlayerNoteMoney + this.CurTotalBet[n]
    end
    if this.LbMyGode ~= nil then
        local snopMoney = tonumber(tostring(MyUserInfo.iMoney))- AllMyMoney
        this.LbMyGode.text = FormatNumToYW(MoneyProportionStr(snopMoney))
    end
    if this.LbMyLV ~= nil then
        this.LbMyLV.text = tostring(MyUserInfo.iVipLevel)
    end
    if this.LbAllDownBet ~= nil then
        this.LbAllDownBet.text = FormatNumToYW(MoneyProportionStr(this.AllPlayerNoteMoney))
    end
    local lastCount = this.MaxGamesZhuang - this.CurrNTCount
    GameUIShangZhuangList.UpdateData(this.ZhuangList,this.StationZhuang,this.LeastMoneyZhuang,lastCount)
    this.RefreshZhuangInfo()
end
--更新庄家信息
function GameUIManager.RefreshZhuangInfo()
    if this.StationZhuang ~= -1 and this.StationZhuang ~= 255 then
        local zhuangData = this.GetUserByStation(this.StationZhuang)
        if zhuangData ~= nil then
            this.LbZhuangName.text = zhuangData.szNickName
            this.LbZhuangMoney.text = FormatNumToYW(MoneyProportionStr(zhuangData.iMoney))
            this.LbZhuangLV.gameObject:SetActive(true)
            this.LbZhuangLV.text = tostring(zhuangData.iVipLevel)
        else
            print("玩家为空！",this.StationZhuang)
        end
    else
        this.LbZhuangName.text = ""
        this.LbZhuangMoney.text = ""
        this.LbZhuangLV.gameObject:SetActive(false)
    end
    --if this.StationZhuang == MyUserInfo.iDeskStation then
    --    this.btnShangZhuang.gameObject:SetActive(false)
    --    this.btnXiaZhuang.gameObject:SetActive(true)
    --else
    --    if this.ListContains(this.ZhuangList,MyUserInfo.iDeskStation) then
    --        this.btnShangZhuang.gameObject:SetActive(false)
    --        this.btnXiaZhuang.gameObject:SetActive(true)
    --    else
    --        this.btnShangZhuang.gameObject:SetActive(true)
    --        this.btnXiaZhuang.gameObject:SetActive(false)
    --    end
    --end
    this.LbWaitUpZhuang.text = #this.ZhuangList.."人"
end

function GameUIManager.UpDatePlayerInfo()
    local playerList = GameSUserBaseInfo.userinfolist
    this.onLineUserList = {}
    for i = 1, #playerList do
        if playerList[i].uiUserID ~= MyUserInfo.uiUserID then
            local info = {}
            info.UserId = playerList[i].uiUserID
            info.UserMoney = playerList[i].iMoney
            info.UserName = playerList[i].szNickName
            info.UserImageNO = playerList[i].iImageNO
            info.iPhotoFrame = playerList[i].iPhotoFrame
            info.iVipLevel = playerList[i].iVipLevel
            table.insert(this.onLineUserList,info)
        end
    end
    --table.sort(this.onLineUserList, function(a,b) return a[5] > b[5] end)
    local MyInfo = {}
    MyInfo.UserId = MyUserInfo.uiUserID
    MyInfo.UserMoney = MyUserInfo.iMoney
    MyInfo.UserName = MyUserInfo.szNickName
    MyInfo.UserImageNO = MyUserInfo.iImageNO
    MyInfo.iPhotoFrame = MyUserInfo.iPhotoFrame
    MyInfo.iVipLevel = MyUserInfo.iVipLevel
    table.insert(this.onLineUserList,1,MyInfo)
    this.LbOnLine.text = ""..#this.onLineUserList
    if not isFirstPlayList then
        return
    end
    GameUIPlayerList.ReSetData(this.onLineUserList)
end
function GameUIManager.PlayerSit(userInfo)
    this.UpDatePlayerInfo()
end
function GameUIManager.PlayerLeft(userInfo)
    this.UpDatePlayerInfo()
end
-------------old------------------
--下注框界面
--重置下注界面信息
function GameUIManager.InitBetData()
    for n=1,#this.mBetIterm do
        this.mBetIterm[n]:SetBet(this.CurMyBet[n],this.CurTotalBet[n])
        --不可以点
        this.mBetIterm[n]:SetEnable(true)
    end
end
--下注组更新
function GameUIManager.UpdateBetBtnStatus(bEnable)
    -- --下注按钮
    -- for i=1,#this.mBetIterm do
    --     --可以下注
    --     this.mBetIterm[i]:SetEnable(bEnable)
    -- end
    -- -- 继续下注
    -- this.BtnContinueBet.isEnabled = bEnable
end
--更新筹码状态
function GameUIManager.UpdateChipBtnStatus()
    if nil == this.mChips then
        return
    end
    for i=1,#this.mChips do
        this.LbZhuMa[i].text = FormatNoteNumToYW(MoneyProportionStr(this.mChips[i]))
    end
end
--用户下注
function GameUIManager.OnGameChouMa(obj)
    if this.GoRecharge.gameObject.activeSelf then
        return
    end
    if #this.mChips <= 0 then
        return
    end
    for i=1,#this.BtnChips do
        if obj == this.BtnChips[i] then
            this.UpDateChooseBet(i)
            return
        end
    end
end

--更新下注窗口信息
function GameUIManager.UpdateUIUserBet()
    --[[
    AllPlayerNoteMoney = 0;
    for (int n = 0; n < CurMyBet.Length; ++n)
    {
        mBetIterm[n].mBet = CurMyBet[n];
        mBetIterm[n].mTatolBet = CurTotalBet[n];
        AllPlayerNoteMoney += CurTotalBet[n];
    }
    ]]
end
--下注
function GameUIManager.RequestXiaZhu(index,flag)
    print("--下注--",index,flag)
    if this.StationZhuang == MyUserInfo.iDeskStation then
        LblMsgText.Show("You are the banker, you cannot bet!")
        return
    end
    if this.StationZhuang == -1 or this.StationZhuang == 255 then
        LblMsgText.Show("No dealer, no bets!")
        return
    end
    if flag == nil then
        flag = 1
    end
    local nMoney = flag * this.mChips[this.mCheckIndex]
    --下注减少不对
    if nMoney < 0 and this.CurMyBet[index] < - nMoney then
        return
    end
    GameProtocal.CMD_GM_CurNoteData[1].data = MyUserInfo.iDeskStation
    GameProtocal.CMD_GM_CurNoteData[2].data = index - 1
    GameProtocal.CMD_GM_CurNoteData[3].data = this.mCheckIndex - 1
    GameProtocal.CMD_GM_CurNoteData[4].data = flag == 1 and 1 or -1
    local sendrob = DataParseLua.StructToBytes(GameProtocal.CMD_GM_CurNoteData)
    NetManager:SendData(sendrob,2000180,GameProtocal.GM_SUB_NOTE)
end
function GameUIManager.UpDateChooseBet(index)
    this.mCheckIndex = index
    SetParent(this.BtnChips[this.mCheckIndex],this.TransIconSelected.gameObject)
end
function GameUIManager.SetChouMaBetButtonIsEnable()
    local myBetMoney = 0
    for i = 1, 8 do
        myBetMoney = myBetMoney + this.CurMyBet[i]
    end
    local myMoney = tonumber(tostring(MyUserInfo.iMoney)) - myBetMoney
    local chipLen = #this.mChips
    if this.mChips[1] > myMoney then
        this.ShowOrHideChooseBetIndex(0)
    else
        for i = 1,chipLen do
            local chipIndex = chipLen+1-i
            if this.mChips[chipIndex] <= myMoney then
                this.ShowOrHideChooseBetIndex(chipIndex)
                break
            end
        end
    end
    if this.mChips[this.mCheckIndex] > myMoney then
        local chipLen = #this.mChips
        if this.mChips[1] > myMoney then
            this.UpDateChooseBet(1)
        else
            for i = 1,chipLen do
                local chipIndex = chipLen+1-i
                if this.mChips[chipIndex] <= myMoney then
                    this.UpDateChooseBet(chipIndex)
                    break
                end
            end
        end
    end
end

function GameUIManager.ShowOrHideChooseBetIndex(index)
    for i = 1, #this.BtnChips do
        if i<=index then
            this.BtnChips[i]:GetComponent("UIButton").isEnabled = true
            this.BtnChips[i]:GetComponent("Collider").enabled = true
        else
            this.BtnChips[i]:GetComponent("UIButton").isEnabled = false
            this.BtnChips[i]:GetComponent("Collider").enabled = false
        end
    end
end
--所有的下注按钮能不能点
function GameUIManager.EnabledBtn( bEnabled )
    this.Button_Bank1:GetComponent("UIButton").isEnabled = bEnabled
    this.Button_Bank1:GetComponent("Collider").enabled = bEnabled
    -- 下注按钮
    for i = 1, #this.BtnChips do
        this.BtnChips[i]:GetComponent("UIButton").isEnabled = bEnabled
        this.BtnChips[i]:GetComponent("Collider").enabled = bEnabled
    end
end

--飞金币动画
function GameUIManager.PlayGoldAnimation(station,areaIndex,checkIndex)
    local formPos = nil
    if(station == MyUserInfo.iDeskStation) then
        formPos = this.BtnChips[checkIndex].transform.localPosition
        local goldAnima = GameGoldManager.GetGoldAnima(areaIndex, checkIndex)
        local topos = this.GetRandomPostion(areaIndex)
        goldAnima:GotoPosition(formPos, topos, 0.4)
    else
        formPos = this.BtnOnLine.transform.localPosition
        local goldAnima = GameGoldManager.GetGoldAnima(areaIndex, checkIndex)
        local topos = this.GetRandomPostion(areaIndex)
        goldAnima:GotoPosition(formPos, topos, 0.4)
    end
end
--续压飞金币
function GameUIManager.ContinuePlayGoldGruop(station, money, areaIndex)
    local checkIndexList = {}
    while (money > 0) do
        if (money < this.mChips[1]) then
            table.insert(checkIndexList, 1)
            break
        end
        for i = 1, #this.mChips do
            local chipIndex = #this.mChips-i+1
            if (money >= this.mChips[chipIndex]) then
                money = money - this.mChips[chipIndex]
                table.insert(checkIndexList, chipIndex)
                break
            end
        end
    end
    for i = 1, #checkIndexList do
        this.PlayGoldAnimation(station, areaIndex, checkIndexList[i])
    end
end
--增加历史记录
function GameUIManager.AddResultList(count,results)
    --历史记录
    this.ResultList = {}
    for i=1,count do--因策划需要历史记录大于15，所以不能再限制，现去掉j= Lerp
        local prizeIndex = bit.band(results[i-1], 0x0f)
        table.insert(this.ResultList,prizeIndex)
    end
end
--停止所有动画
function GameUIManager.StopAllAnimation(isBlink)
    isBlink = isBlink or false
    GameBlinkController.StopAllIconLight()
    if isBlink then
        GameBlinkController.BinkLastPrize()
    end
    --GameBlinkController.CloseSelectPrizePanel()
end

--开奖动画
function GameUIManager.PlayOpenPrizeAnimation(PrizeIndex)
    coroutine.wait(1)
    --开奖动画
    GameBlinkController.PlayOpenPrizeAnimation(PrizeIndex,this.OnAnimationComplete)
end
--开奖动画完成---
function GameUIManager.OnAnimationComplete()

    GameUIResult.UpdateResultList(this.ResultList)

    --闪动中奖结果
    if #this.ResultList < 1 then
        return
    end

    local resultIndex = this.ResultList[#this.ResultList]

    --播放车标开奖音效
    GameAudioContro.Play(GameAudioContro.CarTurnEndAud)
end
--播放开奖动画
function GameUIManager.WaitOpenPrizeAnimation(prize)
    local dua = prize.iLeftTick / 1000.0
    if dua > 1 and dua < 3 then
        coroutine.wait(0.01)
        this.OnAnimationComplete()
        this.StopAllAnimation(false)
        GameBlinkController.PlayOpenPrizeResult(prize.PrizeRoadIndex)
    elseif dua > 3 then
        this.TipGroup[1]:SetActive(true)
        coroutine.wait(dua - 3)
        this.TipGroup[1]:SetActive(false)
        this.OnAnimationComplete()
        this.StopAllAnimation(false)
        GameBlinkController.PlayOpenPrizeResult(prize.PrizeRoadIndex)
    end
end

-------------old----------over--------
--显示结算界面
function GameUIManager.ShowGameJS()
    local resultIndex = this.ResultList[#this.ResultList]
    this.coroutineParent = coroutine.start(this.YieldPlayFlyGold,resultIndex)
end
function GameUIManager.YieldPlayFlyGold(resultIndex)
    local isNote = false
    local isPrize = false
    for i = 1, 8 do
        if this.CurMyBet[i] > 0 then
            isNote = true
            break
        end
    end
    if this.CurMyBet[resultIndex+1] > 0 then
        isPrize = true
    end
    for n = 1, 8 do
        this.CurMyBet[n] = 0
    end
    coroutine.wait(1)
    this.PlayOpnePrizeFlash(resultIndex)
    GameGoldManager.AearCollectChip(resultIndex)
    coroutine.wait(1)
    GameGoldManager.AearThrowChip(resultIndex)
    coroutine.wait(1)
    local otherMoney = this.CurTotalBet[resultIndex + 1]*this.mBase[resultIndex + 1]
    GameGoldManager.FeiGoldToPlayer(resultIndex,this.WinLoseMoney,otherMoney)
    coroutine.wait(0.5)
    isGameOverAnima = false
    this.RefreshZhuangInfo()
    this.UpDatePlayerInfo()--在线列表
    this.RefreshUserInfo()
    coroutine.wait(0.5)
    -- 产生结算框
    if GameResult then
        GameResult.transform.gameObject:SetActive(true)
        if this.IsHuanZhuang then
            GameResult.Show(resultIndex, this.WinLoseMoney,isNote,isPrize, this.mZhuangWinLose,
                    this.PeviousZhuangStation, this.mMaxWinMoneyName, this.mMaxWinSouce, this.playerCount)
        else
            GameResult.Show(resultIndex, this.WinLoseMoney,isNote,isPrize, this.mZhuangWinLose,
                    this.StationZhuang, this.mMaxWinMoneyName, this.mMaxWinSouce, this.playerCount)
        end
        this.IsHuanZhuang = false
        this.PeviousZhuangStation = this.StationZhuang
    end
    coroutine.wait(3)
    GameResult.Hide()
end
--播放开奖区域灯光
function GameUIManager.PlayOpnePrizeFlash(resultIndex)
    for i = 1, 8 do
        if resultIndex == i-1 then
            this.GoWinFlash[i].gameObject:SetActive(true)
        end
    end
end

function GameUIManager.HideWinFlash()
    for i = 1, #this.GoWinFlash do
        if (this.GoWinFlash[i].gameObject.activeSelf) then
            this.GoWinFlash[i].gameObject:SetActive(false)
        end
    end
end
function GameUIManager.ShowStartAnima()
    this.StopTips()
    this.TipGroup[2]:SetActive(true)
    coroutine.wait(1)
    this.TipGroup[2]:SetActive(false)
    if this.CurrNTCount < 1 then
        if this.StationZhuang >= 0 and this.StationZhuang < 180 then
            this.ShowNoteTip(4)
        end
        return
    end
    local lbCount = FindChildByName(this.TipGroup[5].transform,"Icon_BlackBox/Lb_LianZhuang","UILabel")
    lbCount.text = tostring(this.CurrNTCount)
    this.ShowNoteTip(5)
end
--展示提示消息
function GameUIManager.ShowNoteTip(index)
    this.TipGroup[index]:SetActive(true)
    this.StopTips()
    TipsCoroutine = coroutine.start(this.HideNoteTip,index)
end
function GameUIManager.HideNoteTip(index)
    coroutine.wait(2)
    this.TipGroup[index]:SetActive(false)
end
function GameUIManager.StopTips()
    if TipsCoroutine ~= nil then
        coroutine.stop(TipsCoroutine)
    end
    TipsCoroutine = nil
end
function GameUIManager.StopCommonCor()
    if ComCoroutine ~= nil then
        coroutine.stop(ComCoroutine)
    end
    ComCoroutine = nil
end

local timeCount = 0
function GameUIManager.UpData()
    for i=1,#this.mBetIterm do
        this.mBetIterm[i]:UpData()
    end
    GameBlinkController.Update()
    if timeCount > 1 then
        if #ListGolds > 0 then
            this.PlayGoldAnimation(ListGolds[1][1],ListGolds[1][2], ListGolds[1][3])
            table.remove(ListGolds,1)
        end
        timeCount = 0
    end
    timeCount = timeCount + 1
end
function GameUIManager.OnDestroy()
    if(this.coroutineParent ~= nil) then
        coroutine.stop(this.coroutineParent)
        this.coroutineParent = nil
    end
    this.StopTips()
    this.StopCommonCor()
    GameLogic.OnDestroy()
    GameBlinkController.OnDestroy()
    GameTimeClock.OnDestroy()
    GameGoldManager.OnDestroy()
	UpdateBeat:Remove(this.UpData)
    package.loaded["607.this"] = nil
    package.loaded["607.GameLogic"] = nil
    package.loaded["607.GameBank"] = nil
    package.loaded["607.GameBlinkCarIcon"] = nil
    package.loaded["607.GameBlinkController"] = nil
    package.loaded["607.GameDetail"] = nil
    package.loaded["607.GameGoldAnima"] = nil
    package.loaded["607.GameGoldManager"] = nil
    package.loaded["607.GameHelp"] = nil
    package.loaded["607.GamePlayerInfo"] = nil
    package.loaded["607.GameRecord"] = nil
    package.loaded["607.GameResult"] = nil
    package.loaded["607.GameSet"] = nil
    package.loaded["607.GameTimeClock"] = nil
    package.loaded["607.GameUIBetIterm"] = nil
    --package.loaded["607.GameUIJiangChi"] = nil
    package.loaded["607.GameUIPlayerGroup"] = nil
    package.loaded["607.GameUIPlayerList"] = nil
    package.loaded["607.GameUIResult"] = nil
    package.loaded["607.GameUIResultIterm"] = nil
    package.loaded["607.GameUIShangZhuangList"] = nil
    --package.loaded["607.GameUIWinPool"] = nil
end
--根据位置获取用户
function GameUIManager.GetUserByStation(userStation)
    for i=1,#GameSUserBaseInfo.userinfolist do
        if GameSUserBaseInfo.userinfolist[i].iDeskStation == userStation then
            return GameSUserBaseInfo.userinfolist[i]
        end
    end
    return nil
end
function GameUIManager.ListContains(original,deskStation)
    for i,v in ipairs(original) do
        if v == deskStation then
            return true
        end
    end
    return false
end
function GameUIManager.IsInTable(tal,value)
    for k,v in pairs(tal) do
        if v.UserId == value then
            return true
        end
    end
    return false
end
function GameUIManager.getIntPart(x)--取整
    if x <= 0 then
        return math.ceil(x)
    end
    if math.ceil(x) == x then
        x = math.ceil(x)
    else
        x = math.ceil(x) - 1
    end
    return x
end
-- 爆池列表
function GameUIManager.SetBtnJiangChiState(state)
    do
        return
    end
    this.JiangChiState = state
    if (not state) then
        this.BtnJiangChi:SetActive(false)
    end
end
function GameUIManager.PoolDataRefresh(data)
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolData_Fresh)
    this.ipoolMoney = msg.iPoolMoney
    this.LbJiangChi.text = FormatNumToYW(MoneyProportionStr(this.ipoolMoney))
    -- if (GameUIJiangChi~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdatePoolData(this.ipoolMoney)
    --     end
    -- end
end
function GameUIManager.Update()
    if #ListGolds > 0 then
        this.PlayGoldAnimation(ListGolds[1][1],ListGolds[1][2], ListGolds[1][3])
        table.remove(ListGolds,1)
    end
end
function GameUIManager.PoolDataDistrubute(data)
    this.prizeList = {}
    local nLen = DataParseLua.GetLuaTableLength(GameProtocal.CMD_GR_PoolData_Distrubute)
    local count = data.mainMsg.Length / nLen
    local isMyDesk = false
    print("*****************"..debug.getinfo(1).name..count)
    for i=1,count do
        local snopBytes = MyLuaInter.NewArray("byte", nLen)
        System.Array.Copy(data.mainMsg, (i-1) * nLen, snopBytes, 0, nLen)
		local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.CMD_GR_PoolData_Distrubute)
        local userInfo = GameSUserBaseInfo.finduserbyid(cmdBigWin.uUserId)
        if (userInfo == nil) then
            return
        end
        if (MyUserInfo.iDeskNO == cmdBigWin.uDeskId) then
            local prizeInfoItem = {userInfo.szNickName,tostring(cmdBigWin.uPoolMoney), userInfo.iImageNO, cmdBigWin.uCardType,cmdBigWin.uUserId}
            table.insert(this.prizeList,prizeInfoItem)
            isMyDesk = true
        end

        local nowTime = System.DateTime.Now.Hour..":"..System.DateTime.Now.Minute..":"..System.DateTime.Now.Second
        local jiangChiIinfoItem = {tostring(cmdBigWin.uPoolMoney), userInfo.szNickName, nowTime, userInfo.iImageNO, cmdBigWin.uCardType}
        if (#this.jiangChiList>= 11) then
        	table.remove(this.jiangChiList,1)
        end
        table.insert(this.jiangChiList,jiangChiIinfoItem)
    end
    -- if (GameUIJiangChi ~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdateUI(this.jiangChiList)
    --     end
    -- end

    -- if (isMyDesk) then
    --     isMyDesk = false
    --     local obj = UnityEngine.GameObject.Instantiate(this.GoWinPool)
    --     obj:SetActive(true)
    --     SetParent(this.SecondGroup.gameObject, obj)
    --     GameUIWinPool.transform = obj.transform
    --     GameUIWinPool.Awake()
    --     GameUIWinPool.ShowUi()
    --     GameUIWinPool.UpdateUI(this.prizeList)
    --     UnityEngine.GameObject.Destroy(obj, 3)
    -- end
end
function GameUIManager.PoolConfig(data)
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolConfig)
	this.SetBtnJiangChiState(msg.cbPoolSwitch == 1)
	if(msg.TaxKind == 2) then
    	this.iTaxVlue = msg.Tax
	else
    	this.iTaxVlue = 0
	end
    local config = MyLuaInter.NewArray("byte", msg.CardTypeProCount)
    System.Array.Copy(data.mainMsg, 0, config, 0, msg.CardTypeProCount)
    -- if (GameUIJiangChi ~= nil) then
	-- 	GameUIJiangChi.SetPlane(config,msg.iFetchPercent)
    -- end
end
function GameUIManager.PoolRecord(data)
    this.jiangChiList = {}
    local nLen = DataParseLua.GetLuaTableLength(GameProtocal.SUB_GM_PoolRecord)
    local count = data.mainMsg.Length / nLen
    if (count > 10) then
        count = 10
    end
    for i=1,count do
        local snopBytes = MyLuaInter.NewArray("byte", nLen)
        System.Array.Copy(data.mainMsg, (count - i) * nLen, snopBytes, 0, nLen)
		local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.SUB_GM_PoolRecord)
        local dTime = LuaInter.ByteArrayToString(cmdBigWin.sTime)
        local uName = LuaInter.ByteArrayToString(cmdBigWin.sName)
        local infoItem = {tostring(cmdBigWin.iPoolMoney), uName, dTime, cmdBigWin.cbFace, cmdBigWin.bCardType}
        table.insert(this.jiangChiList,infoItem)
    end
end
function GameUIManager.OpenJiangChiPlane()
    -- if (GameUIJiangChi ~= nil) then
    --     if (not GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.transform.gameObject:SetActive(true)
    --         GameUIJiangChi.ShowUi(this.ipoolMoney)
    --         GameUIJiangChi.UpdateUI(this.jiangChiList)
    --     end
    -- end
end
function GameUIManager.ShowGameDetail(detaidates)--打开游戏记录详情
    GameAudioContro.Play(GameAudioContro.button)
    GameDetail.show(detaidates)
end
function GameUIManager.LimitNote(data)--限制下注
    local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.SUB_GM_Limit)  
    iLowNoteLimit = tonumber(tostring(msg.iLimitVlue))
    this.ShowTip()
end
function GameUIManager.GetiLowNoteLimit()
    return iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit
end
function GameUIManager.ShowTip()
    if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
        this.ShowRecharge()
    else
        this.HideRecharge()
    end
end
function GameUIManager.OpenRecharge()
    HallUIManager.OnBtnRecharge()
end
function GameUIManager.ShowRecharge()
    -- this.LbRecharge.text =
    -- "[DBCC89FF]处于观战模式，需要[-][86F351FF]" .. FormatNumToYW(MoneyProportionStr(iLowNoteLimit)).."[-][DBCC89FF]金币即可参与游戏！[-]"
    local msg="In observation mode, you need [86F351FF]"..FormatNumToYW(MoneyProportionStr(iLowNoteLimit)).."[-] gold coins to participate in the game"
    this.LbRecharge.text =msg

    this.GoRecharge:SetActive(true)
end
function GameUIManager.HideRecharge()
    this.GoRecharge:SetActive(false)
end
function GameUIManager.GetRandomPostion(areaIndex)
    local resultPos = this.BetPos[areaIndex][1]
    local randValue = math.random(1, 10)
    if areaIndex ~= 2 and areaIndex ~= 8 then
        if randValue > 6 then
            resultPos = this.GetRandomBoxPos(this.BetPos[areaIndex][2],50,5)
        else
            resultPos = this.GetRandomBoxPos(this.BetPos[areaIndex][1],20,30)
        end
    elseif areaIndex == 2 then
        if randValue > 7 then
            resultPos = this.GetRandomBoxPos(this.BetPos[areaIndex][2],5,5)
        else
            resultPos = this.GetRandomBoxPos(this.BetPos[areaIndex][1],20,30)
        end
    elseif areaIndex == 8 then
        if randValue > 8 then
            resultPos = this.GetRandomBoxPos(this.BetPos[areaIndex][2],5,5)
        elseif randValue < 3 then
            resultPos = this.GetRandomBoxPos(this.BetPos[areaIndex][1],10,10)
        else
            resultPos = this.GetRandomBoxPos(this.BetPos[areaIndex][3],10,5)
        end
    end
    return resultPos
end
function GameUIManager.GetRandomBoxPos(v,x1,y1)
    local vx = math.random(v.x - x1, v.x + x1)
    local vy = math.random(v.y - y1, v.y + y1)
    return Vector3.New(vx, vy, 0)
end
function GameUIManager.FormatNumToStringYW(score)
    local num = tonumber(score)
    local value = tostring(num)
    local rideValue = 1
    if ( num < 0 ) then
        num = num * -1
        rideValue = -1
    end
    if ( num >= 10000 ) then
        -- if ( num >= 100000000 ) then
        --     local v = math.floor(num / 1000000)/100
        --     value = tostring(v * rideValue).."Y"
        -- else
        local v = math.floor(num / 100)/100
        value = tostring(v * rideValue).."W"
        -- end
    end
    return value
end
function GameUIManager.FormatNumToYW(score)
    local num = tonumber(score)
    local value = tostring(num)
    local rideValue = 1
    if ( num < 0 ) then
        num = num * -1
        rideValue = -1
    end
    if ( num >= 10000 ) then
        -- if ( num >= 100000000 ) then
        --     local v = math.floor(num / 1000000)/100
        --     value = tostring(v * rideValue).."Y"
        -- else
        local v = math.floor(num / 100)/100
        value = tostring(v * rideValue).."W"
        -- end
    end
    return value
end
function GameUIManager.FormatNoteNumToYW(score)
    local num = tonumber(score)
    local value = tostring(num)
    local rideValue = 1
    if ( num < 0 ) then
        num = num * -1
        rideValue = -1
    end
    if ( num >= 1000 ) then
        -- if ( num >= 100000000 ) then
        --     local v = math.floor(num / 1000000)/100
        --     value = tostring(v * rideValue).."Y"
        if num >= 10000 then
            local v = math.floor(num / 100)/100
            value = tostring(v * rideValue).."W"
        else
            local v = math.floor(num / 10)/100
            value = tostring(v * rideValue).."K"
        end
    end
    return value
end
