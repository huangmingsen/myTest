local GameBlinkCarIcon = 
{

}
function GameBlinkCarIcon:new(trans)
	local _instance = 
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self 
	setmetatable(_instance, self)
	return _instance
end
function GameBlinkCarIcon:Init()
	self.Active = false
	self.Count = 0
	self.Light = FindChildByName(self.transform, "HighLight","UISprite")
	self.ShanDuration = 0
	self.AnimaCoroutine = nil
end
--停止闪动
function GameBlinkCarIcon:StopIconBlink()
	self.Light.alpha = 0
	if self.AnimaCoroutine ~= nil then
		coroutine.stop(self.AnimaCoroutine)
		self.AnimaCoroutine = nil
	end
end
--播放闪动 count 闪动次数  -1时不停的闪动 -2时不闪动而是TweenAlpha消隐
function GameBlinkCarIcon:PlayIconBlink(count,time)
	if count == nil then
		count = -1 
	end
	if time == nil then
		time = 0.5
	end
    self.Count = count
    self.Active = true
	self.Light.alpha = 1
	self.ShanDuration = time
	if self.AnimaCoroutine ~= nil then
		coroutine.stop(self.AnimaCoroutine)
		self.AnimaCoroutine = nil
	end
	if count == -2 then
		self.AnimaCoroutine = coroutine.start(GameBlinkCarIcon.TweenIconAlpha,self,time)
	else
		self.AnimaCoroutine = coroutine.start(GameBlinkCarIcon.BlinkIcon,self,self.ShanDuration)
	end
end
function GameBlinkCarIcon.BlinkIcon(self,time)
	self.Count = self.Count - 1
	if self.Count == 0 then
		self:StopIconBlink()
		return
	end
    self.Active = not self.Active
    coroutine.wait(time)
	self.AnimaCoroutine = coroutine.start(GameBlinkCarIcon.BlinkIcon,self,self.ShanDuration)
end

--消隐
function GameBlinkCarIcon.TweenIconAlpha(self,time)
	coroutine.wait(time)
	local ap1 = TweenAlpha.Begin(self.Light.gameObject, 0.5, 0)
	--ap1.method = UITweener.Method.EaseOut
end
function GameBlinkCarIcon:OnDestroy()
	if self.AnimaCoroutine ~= nil then
		coroutine.stop(self.AnimaCoroutine)
		self.AnimaCoroutine = nil
	end
end
return GameBlinkCarIcon