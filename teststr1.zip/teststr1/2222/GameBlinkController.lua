local GameBlinkCarIcon = require "607.GameBlinkCarIcon"
local GameBlinkController = 
{
	CallBack = nil,

    CurDuration = 5,--时长
    BlinkCarIconTeam = {},
    Car_Team = {},
    Car_Ray = {},

    CurSpeed = 0,--当前速度
    MaxSpeed = 1.8,--最大速度
    MinSpeed = 0.06,--最小速度
    DownSpeedStep = 24,--减速的步数
    TotalStep = 0,--总步数
    CurStep = 0,--当前步数

    LastPrizeIndex = 0,--上次 开奖索引
    CurPrizeIndex = 0,--此次 开奖
    CarTeamCount = 0,--车标数量  
    Duration = 0,
    CurPerTime = 1000,
    Factor = 0.0,
    PrizeIndex = 0,
}

function GameBlinkController.Awake()
	for i=1,32 do
        local path = string.format("Icon%02d",(i-1))
        local trans = FindChildByName(GameBlinkController.transform, path,"gameObject")
        GameBlinkController.BlinkCarIconTeam[i] = GameBlinkCarIcon:new(trans.transform)
        GameBlinkController.BlinkCarIconTeam[i]:Init()
        GameBlinkController.Car_Team[i] = FindChildByName(GameBlinkController.transform, path.."/HighLight","gameObject")
        GameBlinkController.Car_Ray[i] = FindChildByName(GameBlinkController.transform, path.."/Win_Ani","gameObject")
    end
    GameBlinkController.CarTeamCount = #GameBlinkController.Car_Team
    GameBlinkController.CloseAllIconLight()
end
--直接展示 开奖结果
function GameBlinkController.PlayOpenPrizeResult(prizeIndex)
    --记录游戏已经开奖的
    GameBlinkController.LastPrizeIndex = prizeIndex
    local CurrentIndex = prizeIndex % GameBlinkController.CarTeamCount
    local blinkPrize = GameBlinkController.BlinkCarIconTeam[CurrentIndex+1]
    blinkPrize:PlayIconBlink(-1, 0.2)--间隔0.2f闪动一下  count = -1不停的闪
    print("-----开奖结果------",CurrentIndex+1)
    GameBlinkController.Car_Ray[CurrentIndex+1]:GetComponent("Animation"):Play()
    print("-----开奖结果------",CurrentIndex+1)

end
 
--开奖动画
function GameBlinkController.PlayOpenPrizeAnimation(prizeIndex,callBack)
	print("-----开奖动画-----",prizeIndex)
    GameBlinkController.PrizeIndex = prizeIndex
    GameBlinkController.CallBack = callBack
    GameBlinkController.Factor = 0
    GameBlinkController.CurStep = 0

    GameBlinkController.StopAllIconLight()--所有的灯都停止高亮和闪动
    GameBlinkController.TotalStep = (GameBlinkController.CarTeamCount * (prizeIndex >= GameBlinkController.LastPrizeIndex and 3 or 4) + (prizeIndex - GameBlinkController.LastPrizeIndex))
    print("总步数："..GameBlinkController.TotalStep,"当前步数："..GameBlinkController.CurStep)
    --GameAudioContro.Play("Public/Audio/Game/Loop/loop.u3d")
end
function GameBlinkController.StopAllIconLight()
	for i=1,#GameBlinkController.BlinkCarIconTeam do
		GameBlinkController.BlinkCarIconTeam[i]:StopIconBlink()
	end
end
function GameBlinkController.CloseAllIconLight(iconTeam,alpha)
	if alpha == nil then
		alpha = 0
	end
	for i=1,#GameBlinkController.BlinkCarIconTeam do
        GameBlinkController.BlinkCarIconTeam[i].Light.alpha = alpha
    end
end
function GameBlinkController.Update()
    if GameBlinkController.TotalStep > 0 and GameBlinkController.CurStep <= GameBlinkController.TotalStep then
        if GameBlinkController.CurSpeed < GameBlinkController.MaxSpeed and GameBlinkController.CurStep < 6 then--前四步加速
            GameBlinkController.CurSpeed = 0.2--GameBlinkController.Linear(0.1, GameBlinkController.MaxSpeed, GameBlinkController.CurStep / 4.0)
        elseif GameBlinkController.CurStep + GameBlinkController.DownSpeedStep >= GameBlinkController.TotalStep
        and GameBlinkController.CurStep + 5 < GameBlinkController.TotalStep then--后面的24步开始减速
            local value = (GameBlinkController.CurStep + GameBlinkController.DownSpeedStep - GameBlinkController.TotalStep) * 1.0 / (GameBlinkController.DownSpeedStep)
            GameBlinkController.CurSpeed = GameBlinkController.Linear(GameBlinkController.MaxSpeed, GameBlinkController.MinSpeed, value)
        elseif GameBlinkController.CurStep + 5 >= GameBlinkController.TotalStep then--后面的24步开始减速
            --local value = (GameBlinkController.CurStep + GameBlinkController.DownSpeedStep - GameBlinkController.TotalStep) * 1.0 / (GameBlinkController.DownSpeedStep)
            local value = math.floor(GameBlinkController.CurStep/GameBlinkController.TotalStep*1000)/1000
            GameBlinkController.CurSpeed = GameBlinkController.Linear(GameBlinkController.MaxSpeed, GameBlinkController.MinSpeed, value)
        else --中间就是最大速度
            GameBlinkController.CurSpeed = GameBlinkController.MaxSpeed
        end

        GameBlinkController.Factor = GameBlinkController.Factor + GameBlinkController.PerTime() * UnityEngine.Time.deltaTime * GameBlinkController.CurSpeed
        --GameBlinkController.Factor = math.floor(GameBlinkController.Factor*1000)/1000

        local val = Mathf.Clamp01(GameBlinkController.Factor)
        if math.floor(val * GameBlinkController.TotalStep) >= GameBlinkController.CurStep then

            GameBlinkController.CurPrizeIndex = (GameBlinkController.LastPrizeIndex + GameBlinkController.CurStep) % GameBlinkController.CarTeamCount

            GameBlinkController.Car_Team[GameBlinkController.CurPrizeIndex+1].gameObject:SetActive(true)

            local blink = GameBlinkController.BlinkCarIconTeam[GameBlinkController.CurPrizeIndex+1]
            if GameBlinkController.CurStep == GameBlinkController.TotalStep then   --开奖跑完
                GameBlinkController.StopLastIndexBlink()
                --记录游戏已经开奖的
                GameBlinkController.LastPrizeIndex = GameBlinkController.CurPrizeIndex

                --重置
                GameBlinkController.Factor = 0
                GameBlinkController.CurStep = 0
                GameBlinkController.TotalStep = 0
                if GameBlinkController.CallBack ~= nil then
                    GameBlinkController.CallBack()
                    GameBlinkController.CallBack = nil
                end
                blink:PlayIconBlink(-1, 0.2)--间隔0.2f闪动一下  count = -1不停的闪
            elseif GameBlinkController.CurStep + GameBlinkController.DownSpeedStep * 0.12 >= GameBlinkController.TotalStep then--改变车标闪动 效果 
                blink:PlayIconBlink(-1, 0.2)--间隔0.2f闪动一下——跑动时，底图渐变动画，闪
            else
                blink:PlayIconBlink(-2, 0.1)--间隔0.1f后消隐——跑动时，底图渐变动画，闪
            end

            GameAudioContro.Play(GameAudioContro.CarTurnAud)
            --if GameBlinkController.TotalStep - GameBlinkController.CurStep <= 5 and GameBlinkController.TotalStep - GameBlinkController.CurStep >= 0 then--最后3步 开始播放减速音乐
        	--	GameAudioContro.Play("Public/Audio/Game/Loop/zhuandeng.u3d")
            --end
            GameBlinkController.CurStep = GameBlinkController.CurStep + 1
        end
    end
end

--停止上次奖励 图标的高亮
function GameBlinkController.StopLastIndexBlink()
    local lastPrizeIndex = (GameBlinkController.LastPrizeIndex + GameBlinkController.CurStep) % GameBlinkController.CarTeamCount
    GameBlinkController.StopAllIconLight()--所有的灯都停止高亮和闪动
    if GameBlinkController.BlinkCarIconTeam[lastPrizeIndex+1] then
        GameBlinkController.BlinkCarIconTeam[lastPrizeIndex+1]:StopIconBlink()
    end
    GameBlinkController.Car_Ray[lastPrizeIndex+1]:GetComponent("Animation"):Play()
end

function GameBlinkController.BinkLastPrize()
    local lastBlink = GameBlinkController.BlinkCarIconTeam[GameBlinkController.LastPrizeIndex+1]
    if lastBlink then
        lastBlink:PlayIconBlink(-3)
    end
end

function GameBlinkController.PerTime()
    if GameBlinkController.Duration ~= GameBlinkController.CurDuration then
        GameBlinkController.Duration = GameBlinkController.CurDuration
        GameBlinkController.CurPerTime = (GameBlinkController.CurDuration > 0) and (1 / GameBlinkController.CurDuration) or 1
    end
    return GameBlinkController.CurPerTime
end
function GameBlinkController.easeInOutQuint(start,over,value)
    value = value /0.5
    over = over - start
    if value < 1 then
        return over / 2 * value * value * value * value * value + start
    end
    value = value - 2
    return over / 2 * (value * value * value * value * value + 2) + start
end

--直线
function GameBlinkController.Linear(start,over,value)
    return start + (over - start) * value
    --return Mathf.Lerp(start, over, value)
end
function GameBlinkController.OnDestroy()
    for i=1,#GameBlinkController.BlinkCarIconTeam do
        GameBlinkController.BlinkCarIconTeam[i]:OnDestroy()
    end
end
return GameBlinkController