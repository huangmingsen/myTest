local GameUIBetIterm = 
{
	
}
function GameUIBetIterm:new(trans)
	local _instance = 
	{
		transform = trans,
		gameObject = trans.gameObject
	}
	self.__index = self 
	setmetatable(_instance, self)
	return _instance
end
function GameUIBetIterm:InitUI(nIndex)
    --下注
    self.LbBet = FindChildByName(self.transform, "LbBet", "UILabel")
    self.LbBet.text = MoneyProportionStr(0)
    --初始化
	self.mIndex = nIndex

	--是否单击
	self.mPress = false

	self.mCurTime = 0--当前时间
	self.mPressTime = 0.22--单击的时长
	self.mFlag = 1
    UIEventListener.Get(self.transform.gameObject).onClick = function()
        if GameUIManager.GoRecharge.gameObject.activeSelf then
        	return
    	end 
    	GameUIManager.RequestXiaZhu(self.mIndex, self.mFlag)
    end

end
--下注
function GameUIBetIterm:SetBet(myBet,allBet)
    if nil ~= self.LbBet then
		if not self.LbBet.gameObject.activeSelf then
			self.LbBet.gameObject:SetActive(true)
		end
		if myBet > 0 then
			self.LbBet.text =
			"[32FF00FF]"..GameUIManager.FormatNumToStringYW(MoneyProportionStr(myBet)).."[-]/[FFFF00FF]"..GameUIManager.FormatNumToStringYW(MoneyProportionStr(allBet)).."[-]"
		else
			self.LbBet.text = "[FFFF00FF]"..GameUIManager.FormatNumToStringYW(MoneyProportionStr(allBet)).."[-]"
		end
		if allBet <= 0 then
			self.LbBet.gameObject:SetActive(false)
		end
	end
end
--按钮
function GameUIBetIterm:SetEnable(value)
	self.transform.gameObject:GetComponent("UIButton").isEnabled = value
end
function GameUIBetIterm:UpData()
	if self.mPress then
		self.mCurTime = self.mCurTime + UnityEngine.Time.deltaTime
		if  self.mPressTime <= self.mCurTime then
            GameUIManager.RequestXiaZhu(self.mIndex, self.mFlag)
			self.mCurTime = 0
		end
	end
end
--单击
function GameUIBetIterm:OnPress(bPress)
	self.mPress = bPress
	if self.mPress then
		self.mCurTime = 0.0
	else
        self.mCurTime = 0.0
        GameUIManager.RequestXiaZhu(self.mIndex, self.mFlag)
	end
end
return GameUIBetIterm