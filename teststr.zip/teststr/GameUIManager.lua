local bit = require"bit"
local GameLogic = require "224.GameLogic"
local GameHelp = require "224.GameHelp"
local GameJS = require "224.GameJS"
local GameTimeClock = require "224.GameTimeClock"
local GameRecord = require "224.GameRecord"
local GamePlaneRecord = require "224.GamePlaneRecord"
-- local GamePlayerList = require "224.GamePlayerList"
-- local GameBankerList = require "224.GameBankerList"
local GameGoldManager = require "224.GameGoldManager"
-- local GameUIJiangChi = require "224.GameUIJiangChi"
-- local GameUIWinPool = require "224.GameUIWinPool"
local ChoumaManager = require "211.ChoumaManager"
local GameUIRecord = require "224.GameUIRecord"
local GameDetail = require "224.GameDetail"
-- local GameBank = require "224.GameBank"
local GameSet = require "224.GameSet"
-- local GameBankerResult = require "224.GameBankerResult"
GameUIManager = 
{
	Game_Group,
	PanelSecond,
	BtnHelp,
	BtnExit,
	BtnChat,
	BtnBank1,
	BtnBank2,
	BtnJiangChi,
	BtnContinue,
	BtnMenu,--菜单
	BtnRecord,
	BtnOnLine,
	BtnBet = {},
	LbBets = {},
	BtnChips = {},
	BtnShangZhuang,
	BtnXiaZhuang,

	BtnRecharge,
	LbRecharge,
	GoRecharge,

	LbOnLinePlayer,
	LbJiangChi,
	GoRedDot,
	GoBetFocus,
	TipGroup = {},
	GoWinFlash = {},

	recordResults = {},
	TwpMenu,
	IconGameLevel,
	IconMenuBack,
	IconGameLevel,

	GoOpenPrizePlane,
	AniSendCard,
	IconPaixing = {},
	IconResult = {},
	IconCardPoint1 = {},
	IconCardPoint2 = {},
	IconCardSprite = {},
	GoWin = {},
	FanPaiAni = {},
	FanPaiSmallTarget = {},

	IconMeHead,
	IconMeHeadBorder,
	LbMeName,
	LbMeMoney,
	IconZhuangHead,
	IconZhuangHeadBorder,
	LbZhuangName,
	LbZhuangMoney,

	mWinLose = 0,
	dataCard = {},
	dataPrize = {},
	mMyBets = {0,0,0,0,0,0,0,0},
	mTotalBets = {0,0,0,0,0,0,0,0},
	recordData1 = {}, -- 桌面红黑
	recordData2 = {},
	recordCountData = {0,0,0,0,0},
	iGameCount = -1,

	mStateTime = {},
	mBase = { 2, 2, 3, 4, 10, 15},
	mChips = {},
	mCheckIndex = 1,
	m_CurGameCount, --总下注
	mStation = -1,
	onLineUserList = {},
	JiangChiState = false,


	GoWinPool,
    jiangChiList = {},
    prizeList = {},
    ipoolMoney = 0,
    iTaxVlue = 0,

	coroutineParent,
	MainBtnRecharge,
	BetCenterPos = {Vector3.New(414, -45, 0),Vector3.New(0, 14, 0),Vector3.New(-414, -16, 0),Vector3.New(267, 108, 0),
					Vector3.New(-267, 108, 0),Vector3.New(159, -150, 0),Vector3.New(-145, -150, 0),Vector3.New(4, -150, 0)}
}
local iLowNoteLimit = 0
local ZhuangUser = nil
local stateTime = {}
local TotalIntoMoney = 0 --庄家总带入
local iNtCountWin = 0--庄家总输赢
local ZhuangPlayCount = 0 --庄家局数
local iMaxGames = 0--最大上庄局数
local LeastNtPlay = 0 --庄家最少当庄局数
local cbChangeNt = false--是否即将换庄
local NtInFolist = {} --上庄数据
local mLeastNtMoney = 0--玩家最大的下注筹码
local gameCount = 0--游戏局数，超过100重置
local currPrizeType = 0 --当前奖项类型
local CurrcardPoints = {} -- 当前开奖牌型点数
local ListGolds = {} -- 筹码列表
local isFirstInGame = false -- 第一次进入游戏

local this=GameUIManager
function GameUIManager.Awake()
	this.iGameCount = -1
	this.Game_Group = this.transform:FindChild("UI_BJL/UIGame/Game_Group")
	this.PanelSecond = this.transform:FindChild("UI_BJL/PanelSecond")
	this.BtnUIRecord = FindChildByName(this.Game_Group, "Menu/Button_Record","gameObject")
	this.BtnHelp = this.Game_Group:FindChild("Menu/Button_Help").gameObject
	-- this.BtnBank2 = this.Game_Group:FindChild("Menu/Button_Bank").gameObject
	-- this.BtnBank1 = this.Game_Group:FindChild("Game_Down/BtnBank").gameObject
	this.BtnExit = this.Game_Group:FindChild("Game_Left/BtnBack").gameObject
	-- this.BtnRecharge = FindChildByName(this.Game_Group, "CZ_Tips/BtnRecharge","gameObject")
	this.BtnContinue = this.Game_Group:FindChild("Game_Down/BtnXuTou").gameObject
	this.BtnMenu = this.Game_Group:FindChild("Game_Right/BtnMenu").gameObject
	this.BtnRecord = this.Game_Group:FindChild("Game_Right/BtnZouShi").gameObject
	this.BtnOnLine = this.Game_Group:FindChild("Game_Left/BtnOnLine").gameObject
	-- this.BtnJiangChi = this.Game_Group:FindChild("Game_Top/BtnJiangChi").gameObject
	-- this.BtnChat = this.Game_Group:FindChild("Game_Right/BtnChat").gameObject
    -- this.BtnChat.gameObject:SetActive(MainMenus.IsShowChat)
	for i = 1, 5 do
		this.BtnBet[i] = this.Game_Group:FindChild("Game_Center/UIBet/Button_"..(i-1).."/Button").gameObject
		this.LbBets[i] = this.Game_Group:FindChild("Game_Center/UIBet/Button_"..(i-1).."/Label_Coin").gameObject:GetComponent("UILabel")
	end
	for i = 1, 6 do
		this.BtnChips[i] = this.Game_Group:FindChild("Game_Down/CM_Group/Btn"..(i-1)).gameObject
	end
	-- this.BtnShangZhuang = FindChildByName(this.Game_Group, "Game_Top/BtnShangZhuang", "gameObject")
	-- this.BtnXiaZhuang = FindChildByName(this.Game_Group, "Game_Top/BtnXiaZhuang", "gameObject")

	-- this.LbRecharge = FindChildByName(this.Game_Group, "CZ_Tips/Label_Tips","UILabel")
	-- this.GoRecharge = FindChildByName(this.Game_Group, "CZ_Tips","gameObject")
	-- this.LbOnLinePlayer = this.Game_Group:FindChild("Game_Left/BtnOnLine/Label_Player").gameObject:GetComponent("UILabel")
	-- this.LbJiangChi = this.Game_Group:FindChild("Game_Top/BtnJiangChi/Label_Coin").gameObject:GetComponent("UILabel")
	-- this.GoRedDot = this.Game_Group:FindChild("Game_Right/BtnChat/IconRedDot").gameObject
	-- this.GoBetFocus = this.Game_Group:FindChild("Game_Down/CM_Group/IconSelected").gameObject

	for i = 1, 4 do
		this.TipGroup[i] = this.Game_Group:FindChild("Tips_Group/Tips_"..i).gameObject
	end
	for i = 1, 5 do
		this.GoWinFlash[i] = this.Game_Group:FindChild("Game_Center/Win_Ani/Flash_"..(i-1)).gameObject
	end
	
	this.GoOpenPrizePlane = this.Game_Group:FindChild("Game_Center/KaiPai_Group/SendCard").gameObject
	this.AniSendCard = this.Game_Group:FindChild("Game_Center/KaiPai_Group/SendCard").gameObject:GetComponent("Animation")
	this.IconCardPoint1[1] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Zhuang/PaiXing/IconPaiXing").gameObject:GetComponent("UISprite")
	this.IconCardPoint1[2] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Xian/PaiXing/IconPaiXing").gameObject:GetComponent("UISprite")
	this.IconCardPoint2[1] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Zhuang/PaiXing/IconNiuNiu_Ray").gameObject:GetComponent("UISprite")
	this.IconCardPoint2[2] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Xian/PaiXing/IconNiuNiu_Ray").gameObject:GetComponent("UISprite")
	this.IconPaixing[1] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Zhuang/Icon_Paixing").gameObject:GetComponent("UISprite")
	this.IconPaixing[2] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Xian/Icon_Paixing").gameObject:GetComponent("UISprite")
	this.IconResult[1] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Zhuang/Icon_Result").gameObject:GetComponent("UISprite")
	this.IconResult[2] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Xian/Icon_Result").gameObject:GetComponent("UISprite")
	this.GoWin[1] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Zhuang/Win_Flash").gameObject
	this.GoWin[2] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Xian/Win_Flash").gameObject
	this.FanPaiAni[1] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Zhuang/FanPai_Team/FanPai_Flash").gameObject:GetComponent("UISpriteAnimation")
	this.FanPaiAni[2] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Xian/FanPai_Team/FanPai_Flash").gameObject:GetComponent("UISpriteAnimation")
	this.FanPaiSmallTarget[1] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Zhuang/FanPai_Team/Card_Small_Target").gameObject:GetComponent("UISprite")
	this.FanPaiSmallTarget[2] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Xian/FanPai_Team/Card_Small_Target").gameObject:GetComponent("UISprite")
	for i = 1, 3 do
		this.IconCardSprite[2 * i-1] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Zhuang/Card/IconCard"..(i-1)).gameObject:GetComponent("UISprite")
		this.IconCardSprite[2 * i] = this.Game_Group:FindChild("Game_Center/KaiPai_Group/CardTeam/Card_Xian/Card/IconCard"..(i-1)).gameObject:GetComponent("UISprite")
	end

	--this.IconMeHead = FindChildByName(this.Game_Group, "Game_Down/Player_Team/IconHeadBox/ImHead", "UISprite")
	--this.IconMeHeadBorder = FindChildByName(this.Game_Group, "Game_Down/Player_Team/IconHeadBox/ImHead/Vip_Head_Effect1/HeadBox", "UISprite")
	this.LbMeName = FindChildByName(this.Game_Group, "Game_Down/Player_Team/Label_MyName", "UILabel")
	this.LbMeMoney = FindChildByName(this.Game_Group, "Game_Down/Player_Team/Label_MyMoney", "UILabel")
	this.LbMeVip = FindChildByName(this.Game_Group, "Game_Down/Player_Team/LbVip", "UILabel")
	--this.IconZhuangHead = FindChildByName(this.Game_Group, "Game_Top/Zhuang_Team/IconHeadBox/ImHead", "UISprite")
	--this.IconZhuangHeadBorder = FindChildByName(this.Game_Group, "Game_Top/Zhuang_Team/IconHeadBox/ImHead/Vip_Head_Effect1/HeadBox", "UISprite")
	-- this.LbZhuangName = FindChildByName(this.Game_Group, "Game_Top/Zhuang_Team/Label_ZhuangName", "UILabel")
	-- this.LbZhuangMoney = FindChildByName(this.Game_Group, "Game_Top/Zhuang_Team/Label_ZhuangMoney", "UILabel")
	-- this.LbZhuangVip = FindChildByName(this.Game_Group, "Game_Top/Zhuang_Team/LbVip", "UILabel")
	-- this.LbZhuangCount = FindChildByName(this.Game_Group, "Game_Top/Zhuang_Team/Lb_PaiDui", "UILabel")

    --this.UpdateHead(this.IconMeHead, this.IconMeHeadBorder, MyUserInfo.iImageNO, MyUserInfo.iPhotoFrame)
    this.LbMeName.text = MyUserInfo.szNickName
	this.TwpMenu = this.Game_Group:FindChild("Menu").gameObject:GetComponent("TweenPosition")
	this.IconMenuBack = FindChildByName(this.Game_Group, "Menu/Icon_Box","UISprite")
	-- this.IconGameLevel = FindChildByName(this.Game_Group, "Game_Left/Icon_Level_Target","UISprite")
	-- this.IconGameLevel.spriteName = "Txt_ChangCi"..(UIRoom.SelectRoomInfo.iRoomLevel+1)

	-- GameBank.transform = this.PanelSecond:FindChild("GameBank")
	GameSet.transform = this.Game_Group:FindChild("Menu")
	-- GameBankerResult.transform = this.PanelSecond:FindChild("GameJS_Zhuang")
	GameHelp.transform = this.PanelSecond:FindChild("GameHelp")
	GameJS.transform = this.PanelSecond:FindChild("UIJiesuan")
	-- GameBankerList.transform = this.PanelSecond:FindChild("Banker_List")
	-- GamePlayerList.transform = this.Game_Group:FindChild("Player_List")
	GameGoldManager.transform = this.Game_Group:FindChild("ChouMaParent")
	GameRecord.transform = this.PanelSecond:FindChild("GameLD")
	GamePlaneRecord.transform = this.Game_Group:FindChild("Game_Top/LuDan_Group")
    GameUIRecord.transform = FindChildByName(this.PanelSecond,"GameUIRecord")
    GameDetail.transform = FindChildByName(this.PanelSecond,"GameUIDetail")
    -- GameUIJiangChi.transform = this.PanelSecond:FindChild("Game_JiangChi")
    -- this.GoWinPool = this.PanelSecond:FindChild("Game_JiangChi_Win").gameObject
    GameTimeClock.transform = this.Game_Group:FindChild("Game_Center/TimeCount")
	-- this.MainBtnRecharge = FindChildByName(this.Game_Group, "Game_Left/BtnRecharge","gameObject")
    GameTimeClock.Awake()
    -- GameBankerList.Awake()
	-- GameBank.Awake()
	GameSet.Awake()
	-- GameBankerResult.Awake()
	GameHelp.Awake()
    GameJS.Awake()
    GameLogic.Awake()
    this.EventStart()
    GameRecord.Awake()
	GamePlaneRecord.Awake()
    GameUIRecord.Awake()
    GameDetail.Awake()
	ChoumaManager:InitManager()
    -- GamePlayerList.Awake()
    -- GameUIJiangChi.Awake()
    -- GameGoldManager.Awake()
    this.coroutineParent = coroutine.start(this.StartNotking)
    --this.ReSetGameUI()
    this.UpDatePlayerInfo()
	isFirstInGame = true
	-- GameGoldManager.transform.gameObject:SetActive(false)
end

function GameUIManager.EventStart()
	-- UIEventListener.Get(this.MainBtnRecharge).onClick = this.OpenRecharge
	UIEventListener.Get(this.BtnHelp).onClick = this.OnBtnHelp
	UIEventListener.Get(this.BtnExit).onClick = this.OnBtnExit
	-- UIEventListener.Get(this.BtnChat).onClick = this.OnBtnChat
	-- UIEventListener.Get(this.BtnBank1).onClick = this.OnBtnBank
	-- UIEventListener.Get(this.BtnBank2).onClick = this.OnBtnBank
	UIEventListener.Get(this.BtnUIRecord).onClick = this.OnBtnUIRecord
	-- UIEventListener.Get(this.BtnRecharge).onClick = this.OpenRecharge
	UIEventListener.Get(this.BtnContinue).onClick = this.OnBtnContinue
	UIEventListener.Get(this.BtnMenu).onClick = this.OnBtnMenu
	UIEventListener.Get(this.BtnRecord).onClick = this.OnBtnRecord
	--UIEventListener.Get(this.BtnOnLine).onClick = this.OnBtnOnLine
	for i=1,8 do
		UIEventListener.Get(this.BtnBet[i]).onClick = this.OnBetCallback
	end
	for i=1,6 do
		UIEventListener.Get(this.BtnChips[i]).onClick = this.OnChooseBetCallback
	end
	-- UIEventListener.Get(this.BtnJiangChi).onClick = this.OpenJiangChiPlane
	-- UIEventListener.Get(this.BtnShangZhuang).onClick = this.OnBtnShangZhuang
	-- UIEventListener.Get(this.BtnXiaZhuang).onClick = this.OnBtnXiaZhuang
    -- if lobyUIRadio ~= nil then
    --     lobyUIRadio.GameChatTypeFunc = this.SetGameChatType
    -- end
	-- this.MainBtnRecharge:SetActive(not IsClosePay)
	-- if(not CommonBase.IsShowBank) then
	-- 	this.BtnBank1:SetActive(false)
	-- 	this.BtnBank2:SetActive(false)
	-- 	this.IconMenuBack.transform.localScale = Vector3.New(1,0.8,1)
	-- end
end

function GameUIManager.StartNotking()
    coroutine.wait(0.2)
    UIRoom.StartListenData()--资源初始化完成，开始接收消息
    GameAudioContro.PlayBG(GameAudioContro.BGM)

	UpdateBeat:Add(this.Update)
end
function GameUIManager.ShowJoinGameAnima()
	if not isFirstInGame then
		return
	end
	isFirstInGame = false
	coroutine.wait(0.2)
	this.Game_Group.gameObject:GetComponent("Animation"):Play()
	coroutine.wait(0.2)
	GameGoldManager.transform.gameObject:SetActive(true)
end

function GameUIManager.ReSetGameUI() -- 重置游戏
    this.prizeList = {}
	if(this.coroutineParent ~= nil) then
		coroutine.stop(this.coroutineParent)
		this.coroutineParent = nil
	end
	ChoumaManager:RecoverAllChip()
	this.UpDateChooseBet(1)
	this.ReSetOpenUI()
	this.HideWinFlash()
	GameBankerResult.transform.gameObject:SetActive(false)
	GameJS.transform.gameObject:SetActive(false)
	GameHelp.transform.gameObject:SetActive(false)
	-- GameUIJiangChi.transform.gameObject:SetActive(false)
	-- this.GoWinPool:SetActive(false)
	this.RefreshUserInfo()
end

function GameUIManager.OnBtnHelp()--帮助界面
    GameAudioContro.Play(GameAudioContro.ClickAud)
	--GameHelp.Show(this.iTaxVlue,this.JiangChiState)
	GameHelp.Show(this.iTaxVlue,false)
end
function GameUIManager.OnBtnExit()--退出游戏
    GameAudioContro.Play(GameAudioContro.ClickAud)
    if(ZhuangUser~=nil) then
    	if(ZhuangUser.iDeskStation == MyUserInfo.iDeskStation) then
			LblMsgText.Show("You are the banker, please leave only after placing the banker")
			return
    	end
    end
	local mybet = 0
	for i=1, #this.mMyBets do
		mybet = mybet + this.mMyBets[i]
	end
	if mybet > 0 then
		LblMsgText.Show("You have placed your bet! Please wait for the draw before exiting!")
    else
		MessageBox.Show("Are you sure you want to quit the game?", UIRoom.QuitGame)
	end
end

-- function GameUIManager.OnBtnChat()--打开聊天
--     GameAudioContro.Play(GameAudioContro.ClickAud)
-- 	HallUIManager.OnBtnChat()
-- 	this.GoRedDot:SetActive(false)
-- end
-- function GameUIManager.SetGameChatType()
--     this.GoRedDot:SetActive(true)
-- end
-- function GameUIManager.OnBtnBank()--打开银行
--     GameAudioContro.Play(GameAudioContro.ClickAud)
-- 	if LbIsNeedBindAccount == nil then
-- 		if IsNeedBindGuest or (AccountBindType == 3 and (Network.logintype ~= 4 or not WxRegIsNoUpgrade)) then
-- 			LblMsgText.Show("Please go to the lobby to bind the account!")
-- 			return
-- 		end
-- 		GameBank.Show()
-- 	else
-- 		if LbIsNeedBindAccount then
-- 			LblMsgText.Show("Please go to the lobby to bind the account!")
-- 		else
-- 			GameBank.Show()
-- 		end
-- 	end
-- end
function GameUIManager.OnBtnContinue()--续压
    GameAudioContro.Play(GameAudioContro.ClickAud)
	local mybet = 0
	for i=1, #this.mMyBets do
		mybet = mybet + this.mMyBets[i]
	end
	if mybet > 0 then
		LblMsgText.Show("Bet placed,Cannot be continued")
		return
    end
    NetManager:SendData(2000180, GameProtocal.GM_SUB_CONTINUEPRENOTE)
end
function GameUIManager.OnBtnMenu()--菜单
    if (this.TwpMenu.transform.localPosition.y < 500) then
        this.BtnMenu:GetComponent("UIButton").normalSprite = "UI_BT_Down"
        this.TwpMenu.from = Vector3.New(540, 276, 0)
        this.TwpMenu.to = Vector3.New(540, 876, 0)
        this.TwpMenu.enabled = true
        this.TwpMenu:ResetToBeginning()
        this.TwpMenu:PlayForward()
    else
        this.BtnMenu:GetComponent("UIButton").normalSprite = "UI_BT_Up"
        this.TwpMenu.from = Vector3.New(540, 876, 0)
        this.TwpMenu.to = Vector3.New(540, 276, 0)
        this.TwpMenu.enabled = true
        this.TwpMenu:ResetToBeginning()
        this.TwpMenu:PlayForward()
    end
end
function GameUIManager.OpenRecharge()
	HallUIManager.OnBtnRecharge()
end
function GameUIManager.ShowRecharge()
	-- this.LbRecharge.text =
	-- "[DBCC89FF]处于观战模式，需要[-][86F351FF]"..FormatNumToYW(MoneyProportionStr(iLowNoteLimit)).."[-][DBCC89FF]金币即可参与游戏！[-]"
	local msg="In observation mode, you need [86F351FF]"..FormatNumToYW(MoneyProportionStr(iLowNoteLimit)).."[-] gold coins to participate in the game"
    this.LbRecharge.text =msg

	this.GoRecharge:SetActive(true)
end
function GameUIManager.HideRecharge()
	this.GoRecharge:SetActive(false)
end

function GameUIManager.OnBtnUIRecord()--打开游戏记录
    GameAudioContro.Play(GameAudioContro.ClickAud)
    GameUIRecord.show()
end
function GameUIManager.ShowGameDetail(detaidates)--打开游戏记录详情
    GameAudioContro.Play(GameAudioContro.ClickAud)
    GameDetail.show(detaidates)
end
function GameUIManager.OnBtnRecord()--录单
    GameAudioContro.Play(GameAudioContro.ClickAud)
    GameRecord.ShowUi()
end
function GameUIManager.OnBtnOnLine()--在线列表
    GameAudioContro.Play(GameAudioContro.ClickAud)
    --this.UpDatePlayerInfo()
    -- GamePlayerList.ShowUI()
end
function GameUIManager.OnBetCallback(obj)--下注
    GameAudioContro.Play(GameAudioContro.ClickAud)
    if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
    	return
    end

    if this.mStation ~= 20 then
		--LblMsgText.Show("不在下注时间，不可下注!")
		LblMsgText.Show("Currently not betting stage!")
		return
    end
	if(ZhuangUser == nil) then
		--LblMsgText.Show("没有庄家，不可下注!")
		LblMsgText.Show("No banker, no betting!")
		return
	else
		if ZhuangUser.uiUserID == MyUserInfo.uiUserID then
			--LblMsgText.Show("自己是庄家，不可下注!")
			LblMsgText.Show("You are banker, you cannot bet!")
			return
		end
	end
	for i = 1,#this.BtnBet do
		if obj == this.BtnBet[i] then
		    GameProtocal.CMD_GM_C_NoteResult[1].data = MyUserInfo.iDeskStation
		    GameProtocal.CMD_GM_C_NoteResult[2].data = (i-1)
		    GameProtocal.CMD_GM_C_NoteResult[3].data = this.mCheckIndex-1
			local sendbet = DataParseLua.StructToBytes(GameProtocal.CMD_GM_C_NoteResult)
		    NetManager:SendData(sendbet, 2000180, GameProtocal.GM_SUB_NOTERESULT)
			return
		end
	end
end
function GameUIManager.OnChooseBetCallback(obj)--选择筹码
    GameAudioContro.Play(GameAudioContro.ClickAud)
	for i=1,#this.BtnChips do
		if obj == this.BtnChips[i] then
			this.UpDateChooseBet(i)
			return
		end
	end
end
function GameUIManager.UpDateChooseBet(index)
	this.mCheckIndex = index
    SetParent(this.BtnChips[this.mCheckIndex].gameObject,this.GoBetFocus)
end
function GameUIManager.SetChouMaBetButtonIsEnable()
	local myBetMoney = 0
	for i = 1, 8 do
		myBetMoney = myBetMoney + this.mMyBets[i]
	end
	local myMoney = tonumber(tostring(MyUserInfo.iMoney)) - myBetMoney
	local chipLen = #this.mChips
	if this.mChips[1] > myMoney then
		this.ShowOrHideChooseBetIndex(0)
	else
		for i = 1,chipLen do
			local chipIndex = chipLen+1-i
			if this.mChips[chipIndex] <= myMoney then
				this.ShowOrHideChooseBetIndex(chipIndex)
				break
			end
		end
	end
	if this.mChips[this.mCheckIndex] > myMoney then
		local chipLen = #this.mChips
		if this.mChips[1] > myMoney then
			this.UpDateChooseBet(1)
		else
			for i = 1,chipLen do
				local chipIndex = chipLen+1-i
				if this.mChips[chipIndex] <= myMoney then
					this.UpDateChooseBet(chipIndex)
					break
				end
			end
		end
	end
end

function GameUIManager.ShowOrHideChooseBetIndex(index)
	for i = 1, #this.BtnChips do
		if i<=index then
			this.BtnChips[i]:GetComponent("UIButton").isEnabled = true
			this.BtnChips[i]:GetComponent("Collider").enabled = true
		else
			this.BtnChips[i]:GetComponent("UIButton").isEnabled = false
			this.BtnChips[i]:GetComponent("Collider").enabled = false
		end
	end
end

function GameUIManager.OpenCardPlane(_cardData,cardType)
	local cardData = {}
	for i=1,3 do
		cardData[2 * i - 1] = _cardData[i-1]
		cardData[2 * i] = _cardData[2+i]
	end
	coroutine.wait(0.5)
    local animationName
    for i = 1, 4 do
		if(this.transform == nil) then
			return
		end
		local index = math.floor(i%2) + 1
		if index == 1 then
			animationName = "SendCard_Xian"
		else
			animationName = "SendCard_Zhuang"
		end
        this.AniSendCard:Play(animationName)
    	GameAudioContro.Play(GameAudioContro.FaPaiAud)
        local waitTime = this.AniSendCard.clip.length
        coroutine.wait(waitTime)
		if i > 2 then
			this.FanPaiAni[3-index].gameObject:SetActive(true)
			this.FanPaiAni[3-index]:ResetToBeginning()
			coroutine.wait(0.5)
			this.SetCardSprite(this.FanPaiSmallTarget[3-index],cardData[i],true)
			coroutine.wait(0.5)
			this.FanPaiAni[3-index].gameObject:SetActive(false)
			this.FanPaiSmallTarget[3-index].gameObject:SetActive(false)
		end
		this.SetCardSprite(this.IconCardSprite[i], cardData[i])
        --自己的最后一张牌显示牌背
    end
	local cardPoints = {}
	cardPoints[1] = this.GetCardPoint(cardData,3)
	cardPoints[2] = this.GetCardPoint(cardData,4)
    if(cardData[6] > 0) then
    	coroutine.wait(2)
    	GameAudioContro.Play(GameAudioContro.FaPaiAud)
        this.AniSendCard:Play("SendCard_Xian")
        local waitTime = this.AniSendCard.clip.length
        coroutine.wait(waitTime)
		this.FanPaiAni[2].gameObject:SetActive(true)
		this.FanPaiAni[2]:ResetToBeginning()
		coroutine.wait(0.5)
		this.SetCardSprite(this.FanPaiSmallTarget[2],cardData[6],true)
		coroutine.wait(0.5)
		this.FanPaiAni[2].gameObject:SetActive(false)
		this.FanPaiSmallTarget[2].gameObject:SetActive(false)
		cardPoints[2] = this.GetCardPoint(cardData,6)
        this.SetCardSprite(this.IconCardSprite[6], cardData[6])
    end
    if(cardData[5] > 0) then
    	coroutine.wait(2)
    	GameAudioContro.Play(GameAudioContro.FaPaiAud)
        this.AniSendCard:Play("SendCard_Zhuang")
        local waitTime = this.AniSendCard.clip.length
        coroutine.wait(waitTime)
		this.FanPaiAni[1].gameObject:SetActive(true)
		this.FanPaiAni[1]:ResetToBeginning()
		coroutine.wait(0.5)
		this.SetCardSprite(this.FanPaiSmallTarget[1],cardData[5],true)
		coroutine.wait(0.5)
		this.FanPaiAni[1].gameObject:SetActive(false)
		this.FanPaiSmallTarget[1].gameObject:SetActive(false)
		cardPoints[1] = this.GetCardPoint(cardData,5)
        this.SetCardSprite(this.IconCardSprite[5], cardData[5])
    end
	coroutine.wait(0.5)
	this.IconCardPoint1[1].transform.parent.gameObject:SetActive(true)
	this.IconCardPoint1[1].spriteName = "Txt_Game_"..cardPoints[1]
	this.IconCardPoint2[1].spriteName = "Txt_Game_"..cardPoints[1]
	this.IconCardPoint1[2].transform.parent.gameObject:SetActive(true)
	this.IconCardPoint1[2].spriteName = "Txt_Game_"..cardPoints[2]
	this.IconCardPoint2[2].spriteName = "Txt_Game_"..cardPoints[2]
	this.dataPrize = {0,0,0,0,0,0,0,0}
	this.dataPrize[1] = bit.band(cardType, 0x01)
	this.dataPrize[2] = bit.band(cardType, 0x02)
	this.dataPrize[3] = bit.band(cardType, 0x04)
	this.dataPrize[4] = bit.band(cardType, 0x08)
	this.dataPrize[5] = bit.band(cardType, 0x10)
	this.dataPrize[6] = bit.band(cardType, 0x20)
	this.dataPrize[7] = bit.band(cardType, 0x40)
	this.dataPrize[8] = bit.band(cardType, 0x80)
    if this.dataPrize[2] >= 1 then
		this.IconResult[1].spriteName = "Txt_Game_12"
		this.IconResult[2].spriteName = "Txt_Game_12"
	end
	if this.dataPrize[4] >= 1 then
		this.IconPaixing[1].spriteName = "Txt_Game_10"
		this.IconPaixing[1].gameObject:SetActive(true)
	end
	if this.dataPrize[5] >= 1 then
		this.IconPaixing[2].spriteName = "Txt_Game_10"
		this.IconPaixing[2].gameObject:SetActive(true)
	end
	if this.dataPrize[6] >= 1 then
		this.IconPaixing[1].spriteName = "Txt_Game_11"
		this.IconPaixing[1].gameObject:SetActive(true)
	end
	if this.dataPrize[7] >= 1 then
		this.IconPaixing[2].spriteName = "Txt_Game_11"
		this.IconPaixing[2].gameObject:SetActive(true)
	end
	if this.dataPrize[8] >= 1 then
		this.IconResult[1].spriteName = "Txt_Game_13"
		this.IconResult[2].spriteName = "Txt_Game_13"
		this.IconResult[1].gameObject:SetActive(true)
		this.IconResult[2].gameObject:SetActive(true)
	end	
	GameAudioContro.Play(GameAudioContro.XianPointAud[cardPoints[2] + 1])
	coroutine.wait(1.1)
	GameAudioContro.Play(GameAudioContro.ZhuangPointAud[cardPoints[1] + 1])
	coroutine.wait(1.1)
	if cardPoints[1]  > cardPoints[2] then
		this.GoWin[1]:SetActive(true)	
		GameAudioContro.Play(GameAudioContro.ZhuangAud)	
	elseif cardPoints[2]  > cardPoints[1] then
		this.GoWin[2]:SetActive(true)
		GameAudioContro.Play(GameAudioContro.XianAud)		
	else
		GameAudioContro.Play(GameAudioContro.PingAud)
	end
	coroutine.wait(4)
	this.ReSetOpenUI()
end
function GameUIManager.GetCardPoint(CardData,index)
	local cardPoint = {}
	local resultVlue = 0
    for i=1,6 do
    	if(CardData[i] > 0)then
		    local num = bit.band(CardData[i], 0x0F) --扑克数字
		    num = num + 1
		    if (num == 14) then    --牌A
		        num = 1
		    end
		    if(num>10) then
		    	num = 10
		    end
		    cardPoint[i] = num
		else
		    cardPoint[i] = 0
    	end
    end
	if(index == 1) then
		resultVlue = cardPoint[1]
	elseif index == 2 then
		resultVlue = cardPoint[2]
	elseif index == 3 then
		resultVlue = cardPoint[1] + cardPoint[3]
	elseif index == 4 then
		resultVlue = cardPoint[2] + cardPoint[4]
	elseif index == 5 then
		resultVlue = cardPoint[1] + cardPoint[3] + cardPoint[5]
	elseif index == 6 then
		resultVlue = cardPoint[2] + cardPoint[4] + cardPoint[6]
	end
	return resultVlue - math.floor(resultVlue/10) * 10
end

function GameUIManager.UpdateBetInfo(bets)
    local len = 6
    if (#bets > 6) then
        len = 6
	else
		len = #bets
	end
	for i = 1, len do
        local btn = this.BtnChips[i]
		if ( btn ) then
			local label = btn:GetComponentInChildren(System.Type.GetType("UILabel"))
			if ( nil ~= label ) then
				label.text = FormatNumToYW(MoneyProportionStr(bets[i]))
			end
		end
	end
end

function GameUIManager.RefreshUserInfo()
	-- 更新总下注
	local AllNoteMoney = 0
	for i = 1, 8 do
		AllNoteMoney = AllNoteMoney + this.mMyBets[i]
		if this.mMyBets[i] > 0 then
			this.LbBets[i].text = "[5BF394FF]"..FormatNumToYW(MoneyProportionStr(this.mMyBets[i])
			).."[-]/[7BF7FFFF]"..FormatNumToYW(MoneyProportionStr(this.mTotalBets[i])).."[-]"
		else
			if this.mTotalBets[i] > 0 then
				this.LbBets[i].text = "[7BF7FFFF]"..FormatNumToYW(MoneyProportionStr(this.mTotalBets[i])).."[-]"
			else
				this.LbBets[i].text = ""
			end
		end
	end
    if (ZhuangUser ~= nil and ZhuangUser.uiUserID == MyUserInfo.uiUserID) then
        this.LbMeMoney.text = FormatNumToYW(MoneyProportionStr(MyUserInfo.iMoney - TotalIntoMoney - iNtCountWin))
    else
        this.LbMeMoney.text = FormatNumToYW(MoneyProportionStr(MyUserInfo.iMoney - AllNoteMoney))
    end
	this.LbMeVip.text = tostring(MyUserInfo.iVipLevel)
end
-- 显示庄家的信息
function GameUIManager.ShowZhuangInfo()
	-- if #NtInFolist > 1 then
	-- 	this.LbZhuangCount.text = #NtInFolist - 1
	-- else
	-- 	this.LbZhuangCount.text = 0
	-- end
    -- local isShowBtnSZ = true
    -- if (ZhuangUser ~= nil) then
    -- 	if(ZhuangUser.iDeskStation == MyUserInfo.iDeskStation) then
    -- 		isShowBtnSZ = false
    -- 	end
    --     this.LbZhuangName.text = ZhuangUser.szNickName
    --     this.LbZhuangMoney.text = FormatNumToYW(MoneyProportionStr(TotalIntoMoney + iNtCountWin))
	-- 	this.LbZhuangVip.gameObject:SetActive(true)
	-- 	this.LbZhuangVip.text = ZhuangUser.iVipLevel
    --     --this.UpdateHead(this.IconZhuangHead, this.IconZhuangHeadBorder, ZhuangUser.iImageNO, ZhuangUser.iPhotoFrame)
    -- else
    --     this.LbZhuangName.text = ""
    --     this.LbZhuangMoney.text = ""
    --     this.LbZhuangVip.gameObject:SetActive(false)
    -- end
    -- for i=2,#NtInFolist do
    -- 	if NtInFolist[i].DeskStation == MyUserInfo.iDeskStation then
    -- 		isShowBtnSZ = false
    -- 	end
    -- end
    -- if(isShowBtnSZ) then
    --     this.BtnShangZhuang.gameObject:SetActive(true)
    --     this.BtnXiaZhuang.gameObject:SetActive(false)
    -- else
    --     this.BtnShangZhuang.gameObject:SetActive(false)
    --     this.BtnXiaZhuang.gameObject:SetActive(true)
    -- end
    -- GameBankerList.ReSet(NtInFolist,ZhuangUser,iNtCountWin,TotalIntoMoney,ZhuangPlayCount,iMaxGames,mLeastNtMoney,cbChangeNt)
end

function GameUIManager.UpdateHead(imageHead,imageBorder,headId, borderId)
	if imageBorder ~= nil then
	    local HeadBorderName = GetHeadBorderById(borderId)
		imageBorder.spriteName = HeadBorderName
		--self.ImHeadBorder:MakePixelPerfect()
	end

    local HeadName = GetHeadSpriteName(headId)
	imageHead.spriteName = HeadName
	--self.IconHead:MakePixelPerfect()
end

--玩家更新
function GameUIManager.UpDatePlayerInfo()
	local playerList = GameSUserBaseInfo.userinfolist
	this.onLineUserList = {}
	for i = 1, #playerList do
		if playerList[i].uiUserID ~= MyUserInfo.uiUserID then
			local info = {}
			info[1] = playerList[i].uiUserID
			info[2] = playerList[i].iImageNO
			info[3] = playerList[i].iPhotoFrame
			info[4] = playerList[i].szNickName
			info[5] = playerList[i].iMoney
			info[6] = playerList[i].szGameSign
			info[7] = playerList[i].iVipLevel
			table.insert(this.onLineUserList,info)
		end
	end
	--table.sort(this.onLineUserList, function(a,b) return a[5] > b[5] end)
	local MyInfo = {}
	MyInfo[1] = MyUserInfo.uiUserID
	MyInfo[2] = MyUserInfo.iImageNO
	MyInfo[3] = MyUserInfo.iPhotoFrame
	MyInfo[4] = MyUserInfo.szNickName
	MyInfo[5] = MyUserInfo.iMoney
	MyInfo[6] = MyUserInfo.szGameSign
	MyInfo[7] = MyUserInfo.iVipLevel
	table.insert(this.onLineUserList,1,MyInfo)
	-- GamePlayerList.ReSetData(this.onLineUserList)
	-- this.LbOnLinePlayer.text = tostring(#this.onLineUserList)
end
function GameUIManager.AddUserAttri(msgData)
end
function GameUIManager.PlayerSit(userInfo)
	this.UpDatePlayerInfo()
end
function GameUIManager.PlayerLeft(userInfo)
	this.UpDatePlayerInfo()
end
--显示牌背
function GameUIManager.SetBackCardSprite(image)
    image.gameObject:SetActive(true)
    GetComponent("UISprite").spriteName = "0_0"
end

--设置牌的图片
function GameUIManager.SetCardSprite(image, CardData,isFlash)
    image.gameObject:SetActive(true)
    if (CardData <= 0) then
        image.spriteName = "0_0"
    else
        local color = bit.band(CardData, 0xF0)  --扑克花色
        local num = bit.band(CardData, 0x0F) --扑克数字

        color = color / 16 + 1

        num = num + 1
        --牌A
        if (num == 14) then
            num = 1
        end
		if isFlash ~= nil and isFlash then
			image.spriteName = color.."_1_"..num
		else
			image.spriteName = color.."_"..num
		end
    end
end

--所有的下注按钮能不能点
function GameUIManager.EnabledBtn( bEnabled )
	-- 下注按钮
	for i = 1, #this.BtnChips do
		this.BtnChips[i]:GetComponent("UIButton").isEnabled = bEnabled
		this.BtnChips[i]:GetComponent("Collider").enabled = bEnabled
	end
	this.BtnContinue:GetComponent("UIButton").enabled = bEnabled             -- 续押按钮
	this.BtnContinue:GetComponent("Collider").enabled = bEnabled             -- 续押按钮
end
--开奖
function GameUIManager.OpenPrizeAnimation(myWinlose,winInfo)
	local delayFunc = function ()
		local isNote = false
		for i = 1, 8 do
			if this.mMyBets[i]>0 then
				isNote = true
				break
			end
		end
		WaitForSeconds(1)
		-- this.PlayOpnePrizeFlash()
		-- GameGoldManager.AearCollectChip(this.dataPrize) 
		-- WaitForSeconds(1)
		-- GameGoldManager.AearThrowChip(this.dataPrize) 
		-- WaitForSeconds(1)
		-- GameGoldManager.FeiGoldToPlayer(this.dataPrize,myWinlose)
		-- WaitForSeconds(1)
		--6.筹码移动
		this.ChoumaMoveingHandler()

		this.mTotalBets = {0,0,0,0,0,0,0,0}
		this.mMyBets = {0,0,0,0,0,0,0,0}
		this.RefreshUserInfo()
		this.UpDatePlayerInfo()
		this.ShowZhuangInfo()
		if ZhuangUser ~= nil then
			GameJS.Show(ZhuangUser,myWinlose,isNote,CurrcardPoints,winInfo)
			WaitForSeconds(4)
			GameJS.Hide()
		end
	end
	StartCoroutine(delayFunc)	
end
function GameUIManager.ReSetOpenUI()
	for i=1,6 do
		this.IconCardSprite[i].gameObject:SetActive(false)
	end
	this.GoWin[1]:SetActive(false)
	this.GoWin[2]:SetActive(false)
	this.IconCardPoint1[1].transform.parent.gameObject:SetActive(false)
	this.IconCardPoint1[2].transform.parent.gameObject:SetActive(false)
	this.IconResult[1].gameObject:SetActive(false)
	this.IconResult[2].gameObject:SetActive(false)
	this.IconPaixing[1].gameObject:SetActive(false)
	this.IconPaixing[2].gameObject:SetActive(false)
end

--开奖筹码移动处理事件
function GameUIManager.ChoumaMoveingHandler()
	local winAreaArray={}
	for i = 1, #this.dataPrize do
        if (this.dataPrize[i] > 0) then
			winAreaArray[i]=true
		else
			winAreaArray[i]=false
        end
	end

    --1.将输的区域的筹码回收到庄家位置
    ChoumaManager:ResetMaxMoveTime()  --重置最长的筹码移动时间

	--输的给庄家
    ChoumaManager:MoveLoseChoumaToBanker(winAreaArray)
    local maxMoveTime=ChoumaManager:GetMaxMoveTime() --获取最长的筹码移动时间
    if(maxMoveTime>0) then
        --筹码移动音效
		GameAudioContro.Play(GameAudioContro.EFFECT_PassBet)
        WaitForSeconds(maxMoveTime+0.5)
    end   

    --2.将赢的筹码移动到赢的区域
    ChoumaManager:ResetMaxMoveTime()  --重置最长的筹码移动时间
    this.CreateChoumaObjForScore(winAreaArray)  --生成赢的筹码，并将赢的筹码移动到赢的区域
    local maxMoveTime=ChoumaManager:GetMaxMoveTime() --获取最长的筹码移动时间
    if(maxMoveTime>0) then
        --筹码移动音效
        GameAudioContro.Play(GameAudioContro.EFFECT_PassBet)
        WaitForSeconds(maxMoveTime+0.5)
    end        

    --3.将赢的区域的筹码返回给玩家，并将赢的筹码移到对应的玩家
    ChoumaManager:ResetMaxMoveTime()  --重置最长的筹码移动时间
    ChoumaManager:MoveBetChoumaToPlayer(winAreaArray)  --将赢的区域的筹码返回给玩家
    ChoumaManager:MoveWinChoumaToPlayer() --移动赢的筹码给玩家
    local maxMoveTime=ChoumaManager:GetMaxMoveTime() --获取最长的筹码移动时间
    if(maxMoveTime>0) then
        --筹码移动音效
        GameAudioContro.Play(GameAudioContro.EFFECT_PassBet)
        WaitForSeconds(maxMoveTime-0.2)
    end  
end


--播放开奖区域灯光
function GameUIManager.PlayOpnePrizeFlash()
	for i = 1, #this.dataPrize do
        if (this.dataPrize[i] > 0) then
            this.GoWinFlash[i]:SetActive(true)
            this.GoWinFlash[i]:GetComponent("UISprite").alpha = 0
        end
	end
end

function GameUIManager.HideWinFlash()
	for i = 1, #this.GoWinFlash do
		if (this.GoWinFlash[i].activeSelf) then
		    this.GoWinFlash[i]:SetActive(false)
		end
	end
end

--播放下庄结算
function GameUIManager.PlayGameJSPlane(zhuangWinlose)
	GameBankerResult.Show(TotalIntoMoney,ZhuangPlayCount,zhuangWinlose)
	coroutine.wait(3)
	GameBankerResult.Hide()
end

function GameUIManager.PlayGoldAnimation(station, areaIndex, checkIndex)
	local formPos = nil
	if(station == MyUserInfo.iDeskStation) then
		formPos = this.BtnChips[checkIndex].transform.localPosition
	else
		formPos = this.BtnOnLine.transform.localPosition
	end
	if(formPos ~= nil) then
		local goldAnima = GameGoldManager.GetGoldAnima(areaIndex,checkIndex)
		local topos = this.GetRandomPostion(areaIndex)
		goldAnima:GotoPosition(formPos, topos, 0.4)
	end

end
--续压飞金币
function GameUIManager.ContinuePlayGoldGruop(money, areaIndex)
    local checkIndexList = {}
    while (money > 0) do
        if (money < this.mChips[1]) then
	        table.insert(checkIndexList, 1)
	        break
        end
        for i = 1, #this.mChips do
        	local chipIndex = #this.mChips-i+1
            if (money >= this.mChips[chipIndex]) then
                money = money - this.mChips[chipIndex]
        		table.insert(checkIndexList, chipIndex)
                break
            end
        end
    end
    for i = 1, #checkIndexList do
        this.PlayGoldAnimation(MyUserInfo.iDeskStation, areaIndex, checkIndexList[i])
    end
end
--region 奖池模块
-- 爆池列表
function GameUIManager.SetBtnJiangChiState(state)
	-- this.JiangChiState = state
    -- if (not state) then
    --     this.BtnJiangChi:SetActive(false)
    -- end
end
function GameUIManager.PoolDataRefresh(data)
	-- local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolData_Fresh)  
    -- this.ipoolMoney = msg.iPoolMoney
    -- this.LbJiangChi.text = FormatNumToYW(MoneyProportionStr(this.ipoolMoney))
    -- if (GameUIJiangChi~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdatePoolData(this.ipoolMoney)
    --     end
    -- end
end
local timeCount = 0
function GameUIManager.Update()
	if timeCount > 1 then
		if #ListGolds > 0 then
			this.PlayGoldAnimation(ListGolds[1][1],ListGolds[1][2], ListGolds[1][3])
			table.remove(ListGolds,1)
		end
		timeCount = 0
	end
	timeCount = timeCount + 1
end
function GameUIManager.PoolDataDistrubute(data) 
    -- this.prizeList = {}
    -- local nLen = DataParseLua.GetLuaTableLength(GameProtocal.CMD_GR_PoolData_Distrubute)
    -- local count = data.mainMsg.Length / nLen
    -- local isMyDesk = false
    -- for i=1,count do
    --     local snopBytes = MyLuaInter.NewArray("byte", nLen)
    --     System.Array.Copy(data.mainMsg, (i-1) * nLen, snopBytes, 0, nLen)
	-- 	local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.CMD_GR_PoolData_Distrubute)   
    --     local userInfo = GameSUserBaseInfo.finduserbyid(cmdBigWin.uUserId)
    --     if (userInfo == nil) then
    --         return
    --     end
    --     if (MyUserInfo.iDeskNO == cmdBigWin.uDeskId) then
    --         local prizeInfoItem = {userInfo.szNickName,tostring(cmdBigWin.uPoolMoney), userInfo.iImageNO, cmdBigWin.uCardType,cmdBigWin.uUserId}
    --         table.insert(this.prizeList,prizeInfoItem)
    --         isMyDesk = true
    --     end

    --     local nowTime = System.DateTime.Now.Hour..":"..System.DateTime.Now.Minute..":"..System.DateTime.Now.Second
    --     local jiangChiIinfoItem = {tostring(cmdBigWin.uPoolMoney), userInfo.szNickName, nowTime, userInfo.iImageNO, cmdBigWin.uCardType}
    --     if (#this.jiangChiList>= 11) then
    --     	table.remove(this.jiangChiList,1)
    --     end
    --     table.insert(this.jiangChiList,jiangChiIinfoItem)
    -- end
    -- if (GameUIJiangChi ~= nil) then
    --     if (GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.UpdateUI(this.jiangChiList)
    --     end
    -- end
    -- if (isMyDesk) then
    --     isMyDesk = false
    --     local obj = UnityEngine.GameObject.Instantiate(this.GoWinPool)
    --     obj:SetActive(true)
    --     SetParent(this.PanelSecond.gameObject, obj)
    --     GameUIWinPool.transform = obj.transform
    --     GameUIWinPool.Awake()
    --     GameUIWinPool.ShowUi()
    --     GameUIWinPool.UpdateUI(this.prizeList)
    --     UnityEngine.GameObject.Destroy(obj, 3)
    -- end
end
function GameUIManager.PoolConfig(data)
	-- local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GR_PoolConfig)  
	-- this.SetBtnJiangChiState(msg.cbPoolSwitch == 1)
	-- if(msg.TaxKind == 2) then
    -- 	this.iTaxVlue = msg.Tax
	-- else
    -- 	this.iTaxVlue = 0
	-- end
    -- local config = MyLuaInter.NewArray("byte", msg.CardTypeProCount)
    -- System.Array.Copy(data.mainMsg, 0, config, 0, msg.CardTypeProCount)
    -- if (GameUIJiangChi ~= nil) then
	-- 	GameUIJiangChi.SetPlane(config,msg.iFetchPercent)
    -- end
end
function GameUIManager.PoolRecord(data)
    -- this.jiangChiList = {}
    -- local nLen = DataParseLua.GetLuaTableLength(GameProtocal.SUB_GM_PoolRecord)
    -- local count = data.mainMsg.Length / nLen
    -- if (count > 10) then
    --     count = 10
    -- end
    -- for i=1,count do
    --     local snopBytes = MyLuaInter.NewArray("byte", nLen)
    --     System.Array.Copy(data.mainMsg, (count - i) * nLen, snopBytes, 0, nLen)
	-- 	local cmdBigWin = DataParseLua.BytesToStruct(snopBytes, GameProtocal.SUB_GM_PoolRecord)   
    --     local dTime = LuaInter.ByteArrayToString(cmdBigWin.sTime)
    --     local uName = LuaInter.ByteArrayToString(cmdBigWin.sName)
    --     local infoItem = {tostring(cmdBigWin.iPoolMoney), uName, dTime, cmdBigWin.cbFace, cmdBigWin.bCardType}
    --     table.insert(this.jiangChiList,infoItem)
    -- end
end
function GameUIManager.OpenJiangChiPlane()
    -- if (GameUIJiangChi ~= nil) then
    --     if (not GameUIJiangChi.transform.gameObject.activeSelf) then
    --         GameUIJiangChi.transform.gameObject:SetActive(true)
    --         GameUIJiangChi.ShowUi(this.ipoolMoney)
    --         GameUIJiangChi.UpdateUI(this.jiangChiList)
    --     end
    -- end
end
function GameUIManager.OnBtnShangZhuang()
	GameBankerList.ShowUi()
end
function GameUIManager.OnBtnXiaZhuang()
	GameBankerList.ShowUi()
end
--申请上庄
function GameUIManager.SendShangZhaung(SZsliderVlue,SZtoggleValue)
    print("点击了申请上庄")
    if (mLeastNtMoney <= tonumber(tostring(MyUserInfo.iMoney))) then
        local AllNtMoney = mLeastNtMoney + (SZsliderVlue * (tonumber(tostring(MyUserInfo.iMoney)) - mLeastNtMoney))
        if (mLeastNtMoney <= AllNtMoney) then
		    GameProtocal.MD_GM_UpBanker[1].data = MyUserInfo.iDeskStation
		    GameProtocal.MD_GM_UpBanker[2].data = 1
		    -- GameProtocal.MD_GM_UpBanker[3].data = 0
		    -- GameProtocal.MD_GM_UpBanker[4].data = 0
		    -- GameProtocal.MD_GM_UpBanker[5].data = 0
		    -- GameProtocal.MD_GM_UpBanker[6].data = 0
		    GameProtocal.MD_GM_UpBanker[7].data = AllNtMoney
		    GameProtocal.MD_GM_UpBanker[8].data = SZtoggleValue and 1 or 0
			local sendbet = DataParseLua.StructToBytes(GameProtocal.MD_GM_UpBanker)
		    NetManager:SendData(sendbet, 2000180, GameProtocal.GM_SUB_UPBANKER)
        else
            LblMsgText.Show("You don't have enough coins!")
        end
    else
        LblMsgText.Show("You don't have enough coins")
    end
end
--申请下庄
function GameUIManager.SendXiaZhuang()
    print(false, "点击了申请下庄")
    if (ZhuangUser ~= nil and ZhuangUser.uiUserID == MyUserInfo.uiUserID) then
        if (cbChangeNt) then
            LblMsgText.Show("After the game is settled in this round, you will be placed automatically")
        else
			MessageBox.Show("Are you sure you are not the banker after this round of settlement?", this.SureXiaZhuang)
        end
    else
        local isShangZhuang = false
        if (NtInFolist ~= nil and #NtInFolist > 0) then
        	for i=2,#NtInFolist do
                if (NtInFolist[i].DeskStation == MyUserInfo.iDeskStation) then
                    isShangZhuang = true
                    break
                end
        	end
        end
        if (not isShangZhuang) then
            print("申请下庄出错！！")
            return
        end
        this.SendXiaZhaung()
    end
end

function GameUIManager.SureXiaZhuang()
    if (ZhuangPlayCount == iMaxGames) then
        LblMsgText.Show("After the game is settled in this round, you will be placed automatically")
    elseif (ZhuangPlayCount < LeastNtPlay) then
        coroutine.start(this.WaitforShowTips)
    else
        LblMsgText.Show("After the game is settled in this round, you will be placed automatically")
        this.SendXiaZhaung()
    end
end
function GameUIManager.WaitforShowTips()
    coroutine.wait(0.1)
    MessageBox.Show("More handling fees will be charged if you place a banker in advance. Are you sure you want to not be the banker in advance?", this.SendXiaZhaung)
end

function GameUIManager.SendXiaZhaung()
    GameProtocal.MD_GM_UpBanker[1].data = MyUserInfo.iDeskStation
    GameProtocal.MD_GM_UpBanker[2].data = 0
	local sendbet = DataParseLua.StructToBytes(GameProtocal.MD_GM_UpBanker)
    NetManager:SendData(sendbet, 2000180, GameProtocal.GM_SUB_UPBANKER)
end
-- 开始或停止下注
function GameUIManager.StartOrStopDownBetBG(flag)
    if (flag) then
	    GameAudioContro.Play(GameAudioContro.StartNoteAud)
        this.ShowNoteTip(1,true)
    else
	    GameAudioContro.Play(GameAudioContro.EndNoteAud)
        this.ShowNoteTip(2,true)
    end
end
-- 展示提示消息
function GameUIManager.ShowNoteTip(index,isYilde)
    this.TipGroup[index]:SetActive(true)
    if(isYilde) then
    	this.coroutineParent = coroutine.start(this.HideYildeNoteTip,index)
	end
end
function GameUIManager.HideYildeNoteTip(index)
    coroutine.wait(2)
    this.TipGroup[index]:SetActive(false)
    --this.HideNoteTip()
end
function GameUIManager.HideNoteTip()
	for i=1,#this.TipGroup do
    	this.TipGroup[i]:SetActive(false)
	end
end

function GameUIManager.GameRecordInster(_prizeType)
	local prizeArr = {}
	prizeArr[1] = bit.band(_prizeType, 0x01)
	prizeArr[2] = bit.band(_prizeType, 0x02)
	prizeArr[3] = bit.band(_prizeType, 0x04)
	prizeArr[4] = bit.band(_prizeType, 0x08)
	prizeArr[5] = bit.band(_prizeType, 0x10)
	local prizeType = 1
	local zxDuiZi = 0
	if(prizeArr[1] > 0) then
		prizeType = 1
	elseif(prizeArr[2] > 0) then
		prizeType = 2
	elseif(prizeArr[3] > 0) then
		prizeType = 3
	end
	if(prizeArr[4] > 0) then
		zxDuiZi = 1
	elseif(prizeArr[5] > 0) then
		zxDuiZi = 2
	end
	this.iGameCount = this.iGameCount + 1
	if this.iGameCount > 255 then
		this.iGameCount = 0
	end
	if(#this.recordData2 > 0) then
		local data1 = this.recordData2[#this.recordData2]
		if prizeType == 2 then
			if data1[#data1][2] == 1 then
				local newArr = {data1[1][1],1,zxDuiZi}
				table.insert(this.recordData2[#this.recordData2],newArr)
			else
				this.recordData2[#this.recordData2][#data1][2] = 1
			end
		else
			if(data1[1][1] == prizeType) then
				local newArr = {prizeType,0,zxDuiZi}
				table.insert(this.recordData2[#this.recordData2],newArr)
			else
				local snopArr = {prizeType,0,zxDuiZi}
				local newArr = {snopArr}
				table.insert(this.recordData2,newArr)
			end
		end
	else
		local newArr = {}
		if prizeType == 2 then
			local snopArr = {1,1,zxDuiZi}
			newArr = {snopArr}
		else
			local snopArr = {prizeType,0,zxDuiZi}
			newArr = {snopArr}
		end
		table.insert(this.recordData2,newArr)
	end
	this.recordCountData[prizeType] = this.recordCountData[prizeType] + 1
	if zxDuiZi > 0 then
		this.recordCountData[zxDuiZi+3] = this.recordCountData[zxDuiZi+3] + 1
	end
	local snopArr = {prizeType,zxDuiZi}
	table.insert(this.recordData1, snopArr)
	if #this.recordData1 >= 100 then
		local snopData1 = {}
		for i = 81, 100 do
			snopData1[i-80] = this.recordData1[i]
		end
		this.recordData1 = snopData1
		this.recordData2 = {}
		this.recordCountData = {0,0,0,0,0}
		for i = 1, #this.recordData1 do
			this.recordCountData[this.recordData1[i][1]] = this.recordCountData[this.recordData1[i][1]] + 1
			if this.recordData1[i][2] > 0 then
				this.recordCountData[this.recordData1[i][2]+3] = this.recordCountData[this.recordData1[i][2]+3] + 1
			end
			if(#this.recordData2 > 0) then
				local data1 = this.recordData2[#this.recordData2]
				if this.recordData1[i][1] == 2 then
					if data1[#data1][2] == 1 then
						local newArr = {data1[1][1],1,this.recordData1[i][2]}
						table.insert(this.recordData2[#this.recordData2],newArr)
					else
						this.recordData2[#this.recordData2][#data1][2] = 1
					end
				else
					if(data1[1][1] == this.recordData1[i][1]) then
						local newArr = {this.recordData1[i][1],0,this.recordData1[i][2]}
						table.insert(this.recordData2[#this.recordData2],newArr)
					else
						local snopArr = {this.recordData1[i][1],0,this.recordData1[i][2]}
						local newArr = {snopArr}
						table.insert(this.recordData2,newArr)
					end
				end
			else
				local newArr = {}
				if this.recordData1[i][1] == 2 then
					local snopArr = {1,1,this.recordData1[i][2]}
					newArr = {snopArr}
				else
					local snopArr = {this.recordData1[i][1],0,this.recordData1[i][2]}
					newArr = {snopArr}
				end
				table.insert(this.recordData2,newArr)
			end
		end
	end
	this.UpdateRecordUI()
end
function GameUIManager.GameRecordCatLine(cardTypeRecord,gameCount,currGameCount)
	if currGameCount ~= this.iGameCount then
		local snopRecordData = {}
		for i=1,gameCount do
			local prizeArr = {}
			prizeArr[1] = bit.band(cardTypeRecord[i-1], 0x01)
			prizeArr[2] = bit.band(cardTypeRecord[i-1], 0x02)
			prizeArr[3] = bit.band(cardTypeRecord[i-1], 0x04)
			prizeArr[4] = bit.band(cardTypeRecord[i-1], 0x08)
			prizeArr[5] = bit.band(cardTypeRecord[i-1], 0x10)
			local zxhVlue = 1
			local zxDuiZi = 0
			if(prizeArr[1] > 0) then
				zxhVlue = 1
			elseif(prizeArr[2] > 0) then
				zxhVlue = 2
			elseif(prizeArr[3] > 0) then
				zxhVlue = 3
			end
			if(prizeArr[4] > 0) then
				zxDuiZi = 1
			elseif(prizeArr[5] > 0) then
				zxDuiZi = 2
			end
			local snopArr = {zxhVlue,zxDuiZi}
			table.insert(snopRecordData, snopArr)
		end
		if this.iGameCount == -1 then
			this.recordData1 = {}
			for m = 1, #snopRecordData do
				table.insert(this.recordData1, snopRecordData[m])
			end
		else
			local differCount = 0
			if currGameCount > this.iGameCount then
				differCount = currGameCount - this.iGameCount
			else
				differCount = currGameCount + 256 - this.iGameCount
			end
			for m = 1, differCount do
				table.insert(this.recordData1, snopRecordData[#snopRecordData - differCount + 1])
			end
		end
		this.iGameCount = currGameCount
		this.recordData2 = {}
		this.recordCountData = {0,0,0,0,0}
		for i = 1,#this.recordData1 do
			local prizeType = this.recordData1[i][1]
			this.recordCountData[prizeType] = this.recordCountData[prizeType] + 1
			if this.recordData1[i][2] > 0 then
				this.recordCountData[this.recordData1[i][2]+3] = this.recordCountData[this.recordData1[i][2]+3] + 1
			end
			if(#this.recordData2 > 0) then
				local data1 = this.recordData2[#this.recordData2]
				if prizeType == 2 then
					if data1[#data1][2] == 1 then
						local newArr = {data1[1][1],1,this.recordData1[i][2]}
						table.insert(this.recordData2[#this.recordData2],newArr)
					else
						this.recordData2[#this.recordData2][#data1][2] = 1
					end
				else
					if(data1[1][1] == prizeType) then
						local newArr = {prizeType,0,this.recordData1[i][2]}
						table.insert(this.recordData2[#this.recordData2],newArr)
					else
						local snopArr = {prizeType,0,this.recordData1[i][2]}
						local newArr = {snopArr}
						table.insert(this.recordData2,newArr)
					end
				end
			else
				local newArr = {}
				if prizeType == 2 then
					local snopArr = {1,1,this.recordData1[i][2]}
					newArr = {snopArr}
				else
					local snopArr = {prizeType,0,this.recordData1[i][2]}
					newArr = {snopArr}
				end
				table.insert(this.recordData2,newArr)
			end
		end
	end
	this.UpdateRecordUI()
end

function GameUIManager.UpdateRecordUI()
	GameRecord.ReSet(this.recordCountData,this.recordData2,this.recordData1)
	GamePlaneRecord.ReSet(this.recordCountData,this.recordData2,this.recordData1)
end

function GameUIManager.GameDownUpZhuang(data)--上庄 或下庄
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.MD_GM_UpBanker)  
    if (msg.iNtStaton ~= -1) then
        --新的庄家
        if (ZhuangUser == nil or ZhuangUser.iDeskStation ~= msg.iNtStaton) then
            cbChangeNt = false
            ZhuangUser = GameLogic.finduserbyStation(msg.iNtStaton)
            if (ZhuangUser == nil) then
                return
            end
        end
    else
        ZhuangUser = nil
    end
    if (msg.shang == 0) then
    	if(msg.station == MyUserInfo.iDeskStation and msg.bIsHuangZhuang == 1) then
	       this.coroutineParent = coroutine.start(this.PlayGameJSPlane,iNtCountWin)
		end
    end
    this.ShowZhuangInfo()
    --ShowUserInfo()
end
function GameUIManager.GameDownUpZhuangReq(data)--庄家下庄请求已接受
    print(false, "@@@庄家下庄请求已接受 ")
    if (data.mainMsg[0] == MyUserInfo.iDeskStation) then
        m_GameUIManager.ShowTishiNote("Your application has been received!")
    end
    if (ZhuangUser ~= nil) then
        cbChangeNt = true
        this.ShowZhuangInfo()
    end
end
function GameUIManager.GameGruel(data)--庄家提前下庄  惩罚提示
end
function GameUIManager.GameZhuangInfo(data)--庄家信息
	NtInFolist = {}
	if data.mainMsg.Length > 0 then
		NtInFolist = DataParseLua.BytesToStructList(data.mainMsg, GameProtocal.CMD_GM_NtInfo)
	end
    if (NtInFolist ~= nil and #NtInFolist > 0) then
        iNtCountWin = NtInFolist[1].DeskStation
        TotalIntoMoney = NtInFolist[1].TotalIntoMoney
    else
        ZhuangUser = nil
    end
    --显示庄家的信息
    this.ShowZhuangInfo()
    --刷新上庄列表
    --this.RefleshShangZhuangList()
    --this.ShowUserInfo()
end
function GameUIManager.GameNoteReq(data)
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_S_NoteResult)  
	if (msg.bNoteCode == 0) then
		--print("  index:",msg.bNoteObject+1,"  totalBets:",this.mTotalBets[msg.bNoteObject+1],"  chipIndex:",msg.iChip+1,"   Chips:",this.mChips[msg.iChip+1])
		this.mChips[msg.iChip+1]=this.mChips[msg.iChip+1] or 0
	    this.mTotalBets[msg.bNoteObject+1] = tonumber(tostring(this.mTotalBets[msg.bNoteObject+1])) + this.mChips[msg.iChip+1]
		if (MyUserInfo.iDeskStation == msg.bDeskStation) then
	        this.mMyBets[msg.bNoteObject+1] = tonumber(tostring(this.mMyBets[msg.bNoteObject+1])) + this.mChips[msg.iChip+1]
	        if (tonumber(tostring(MyUserInfo.iMoney)) < this.mChips[msg.iChip + 1]) then
				print( "异常，身上的钱为负数！" )
			end
			for i = 1, #this.mChips do
	            if (this.mChips[i] == this.mChips[msg.iChip+1]) then
	                this.PlayGoldAnimation(msg.bDeskStation,msg.bNoteObject+1, i)
	                break
	            end
			end
	    else
			for i = 1, #this.mChips do
	            if (this.mChips[i] == this.mChips[msg.iChip+1]) then
					local snoplistgode = {msg.bDeskStation,msg.bNoteObject+1, i}
					if #ListGolds < 100 then
						table.insert(ListGolds,snoplistgode)
					end
					break
	            end
			end
	    end
		this.SetChouMaBetButtonIsEnable()
		this.RefreshUserInfo()--更新下注和钱
	else
	    if (MyUserInfo.iDeskStation == msg.bDeskStation) then
	        local infoTip = GameLogic.NoteErroCode(msg.bNoteCode)
			LblMsgText.Show(infoTip)
	    end
	end
end
function GameUIManager.GameContinueLastNoteReq(data)
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_ContinuePreNote)   
	if (msg.bState == 0) then
		for i = 1, 8 do
            this.mTotalBets[i] = tonumber(tostring(this.mTotalBets[i])) + msg.AreaNoteMoney[i-1]
            if (msg.nDeskStation == MyUserInfo.iDeskStation) then
                this.mMyBets[i] = tonumber(tostring(this.mMyBets[i])) + msg.AreaNoteMoney[i-1]
                if (tonumber(tostring(MyUserInfo.iMoney))  < msg.AreaNoteMoney[i-1]) then
                    print("异常，身上的钱为负数！")
                else
                    if (msg.AreaNoteMoney[i-1] > 0) then
                        this.ContinuePlayGoldGruop(msg.AreaNoteMoney[i-1], i)
                    end
                end
            end
        end
		this.SetChouMaBetButtonIsEnable()
        this.RefreshUserInfo()--更新下注和钱
	else
	    if (MyUserInfo.iDeskStation == msg.nDeskStation) then
	        local infoTip = GameLogic.ContinueNoteErroCode(msg.bState)
			LblMsgText.Show(infoTip)
	    end
	end
end
function GameUIManager.LimitNote(data)--限制下注
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.SUB_GM_Limit)  
    iLowNoteLimit = tonumber(tostring(msg.iLimitVlue))
    if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
    	this.ShowRecharge()
    else
    	this.HideRecharge()
    end
end
function GameLogic.GameBegin(data)--游戏开始
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Begin)
	this.mStation = 1
	ZhuangPlayCount = msg.iNtPlayNum
	this.mTotalBets = {0,0,0,0,0,0,0,0}
	this.mMyBets = {0,0,0,0,0,0,0,0}
	this.RefreshUserInfo()
	this.SetChouMaBetButtonIsEnable()

    this.ReSetOpenUI()
	-- GameGoldManager.HideAllGole()
	this.HideWinFlash()
	if (msg.iNtStation ~= -1) then
        ZhuangUser = GameLogic.finduserbyStation(msg.iNtStation)
		if (ZhuangUser == nil) then
			print("找不到庄家！！")
			return
		end
	else
		ZhuangUser = nil
	end
    this.ShowZhuangInfo()
    GameTimeClock.StartClock(nil,stateTime[1],1)
    if iLowNoteLimit >0 and tonumber(tostring(MyUserInfo.iMoney)) < iLowNoteLimit then
    	this.ShowRecharge()
    else
    	this.HideRecharge()
    end
end

function GameLogic.GameNoteBet(data)--通知下注
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_NoteNotice)
	this.mStation = 20
	this.StartOrStopDownBetBG(true)
	this.EnabledBtn(true)
	GameTimeClock.StopClock()
    GameTimeClock.StartClock(nil,stateTime[2]-1,1)
end
function GameLogic.GameOpenPrize(data)--游戏开奖
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.MD_GM_State_OpenCard)
	this.mStation = 22
	this.StartOrStopDownBetBG(false)
	ListGolds = {}
    currPrizeType = msg.cbCardType
	CurrcardPoints[1] = msg.cbCardPoint[0]
	CurrcardPoints[2] = msg.cbCardPoint[1]
    this.coroutineParent = coroutine.start(this.OpenCardPlane,msg.cbCardData,msg.cbCardType)
	GameTimeClock.StopClock()
	GameTimeClock.StartClock(nil,stateTime[3],2)
end
function GameUIManager.GameCurrOver(data)
	local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_State_Settlement)
	this.mStation = 23
    iNtCountWin = iNtCountWin + msg.iNtChageMoney
    ZhuangPlayCount = msg.iNtCountPlay + 1
    TotalIntoMoney = TotalIntoMoney + msg.iBankerFillMoney
	--显示庄家的信息
    this.GameRecordInster(currPrizeType,CurrcardPoints)
	local myWinlose = msg.iDesktionChageMoney[MyUserInfo.iDeskStation]
	local resultInfo = {}
	for i = 1, 3 do
		local userInfo = GameLogic.finduserbyStation(msg.cbRankingList[i-1])
		if userInfo ~= nil then
			local snopArr = {userInfo.szNickName,msg.iDesktionChageMoney[msg.cbRankingList[i-1]]}
			table.insert(resultInfo,snopArr)
		end
	end
    --this.coroutineParent = coroutine.start(this.OpenPrizeAnimation,myWinlose,resultInfo) --开奖
	this.OpenPrizeAnimation(myWinlose,resultInfo) --开奖
end

function GameUIManager.GameUserRattri(data)

end

function GameUIManager.GameStation(data)
	print("GameStation = "..tostring(data.mainMsg.Length))
	this.ReSetGameUI()
	local state = data.mainMsg[0]
	this.mStation = state
	if state == 0 or state == 1 then print("闲置")
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Wait)
		print("msg =",DataParseLua.GetLuaTableLength(GameProtocal.CMD_GM_Station_Wait))
		stateTime[1] = msg.iBeginTime
		stateTime[2] = msg.iNoteTime
		stateTime[3] = msg.iOpenCardTime + msg.iAccoutTime
		for i = 1, msg.iChouMaNum do
			this.mChips[i] = msg.iChouMa[i-1]
		end
		gameCount = msg.cbGameCount
    	ZhuangPlayCount = msg.iNtCountPlay
        iNtCountWin = msg.iNtWin
		LeastNtPlay = msg.iLeastNtPlay --庄家最少当庄局数
        iMaxGames = msg.iMaxGames
        cbChangeNt = msg.cbChangeNt == 1
        mLeastNtMoney = msg.iLeastNtMoney--上庄最低额度
		--显示庄家的信息 -1表示没有庄家
		if (msg.iNtStation ~= -1) then
            ZhuangUser = GameLogic.finduserbyStation(msg.iNtStation)
			if (ZhuangUser == nil) then
				print("找不到庄家！！")
				return
			end
		else
			ZhuangUser = nil
		end
		--开始计时
		local time = math.floor(msg.iShengYuTime/1000)
		if msg.iShengYuTime % 1000 > 500 then
			time = time + 1
		end
		GameTimeClock.StartClock(nil,time,2)
		this.GameRecordCatLine(msg.cbCardTypeRecord,msg.cbGameCount,msg.cbCurGameCount)
	elseif state == 20 then print("下注")
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Note)
		print("msg =",DataParseLua.GetLuaTableLength(GameProtocal.CMD_GM_Station_Note))
		stateTime[1] = msg.iBeginTime
		stateTime[2] = msg.iNoteTime
		stateTime[3] = msg.iOpenCardTime + msg.iAccoutTime
		for i = 1, msg.iChouMaNum do
			this.mChips[i] = msg.iChouMa[i-1]
		end
		for i = 1, 8 do
			this.mTotalBets[i] = msg.iTotalNote[i-1]
			this.mMyBets[i] = msg.iPlayerNote[i-1]
		end
		gameCount = msg.cbGameCount
    	ZhuangPlayCount = msg.iNtCountPlay
        iNtCountWin = msg.iNtWin
		LeastNtPlay = msg.iLeastNtPlay --庄家最少当庄局数
        iMaxGames = msg.iMaxGames
        cbChangeNt = msg.cbChangeNt == 1
        mLeastNtMoney = msg.iLeastNtMoney--上庄最低额度
		--显示庄家的信息 -1表示没有庄家
		if (msg.iNtStation ~= -1) then
            ZhuangUser = GameLogic.finduserbyStation(msg.iNtStation)
			if (ZhuangUser == nil) then
				print("找不到庄家！！")
				return
			end
		else
			ZhuangUser = nil
		end
		--开始计时
		local time = math.floor(msg.iShengYuTime/1000)
		if msg.iShengYuTime % 1000 > 500 then
			time = time + 1
		end
		GameTimeClock.StartClock(nil,time,1)
		this.EnabledBtn( true )
		this.SetChouMaBetButtonIsEnable()
		-- this.StartOrStopDownBetBG(true)
		--初始化桌上筹码
		this.InitDeskBetChips(msg)
		this.GameRecordCatLine(msg.cbCardTypeRecord,msg.cbGameCount,msg.cbCurGameCount)
	elseif state == 22 then print("开奖")
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_OpenCard)
		print("msg =",DataParseLua.GetLuaTableLength(GameProtocal.CMD_GM_Station_OpenCard))
		stateTime[1] = msg.iBeginTime
		stateTime[2] = msg.iNoteTime
		stateTime[3] = msg.iOpenCardTime + msg.iAccoutTime
		for i = 1, msg.iChouMaNum do
			this.mChips[i] = msg.iChouMa[i-1]
		end
		for i = 1, 8 do
			this.mTotalBets[i] = msg.iTotalNote[i-1]
			this.mMyBets[i] = msg.iPlayerNote[i-1]
		end
		CurrcardPoints[1] = msg.cbCardPoint[0]
		CurrcardPoints[2] = msg.cbCardPoint[1]
		local cardType = msg.cbCardType
		this.dataPrize = {0,0,0,0,0,0,0,0}
		this.dataPrize[1] = bit.band(cardType, 0x01)
		this.dataPrize[2] = bit.band(cardType, 0x02)
		this.dataPrize[3] = bit.band(cardType, 0x04)
		this.dataPrize[4] = bit.band(cardType, 0x08)
		this.dataPrize[5] = bit.band(cardType, 0x10)
		this.dataPrize[6] = bit.band(cardType, 0X20)
		this.dataPrize[7] = bit.band(cardType, 0x40)
		this.dataPrize[8] = bit.band(cardType, 0x80)
		gameCount = msg.cbGameCount
    	ZhuangPlayCount = msg.iNtCountPlay
        iNtCountWin = msg.iNtWin
		LeastNtPlay = msg.iLeastNtPlay --庄家最少当庄局数
        iMaxGames = msg.iMaxGames
        cbChangeNt = msg.cbChangeNt == 1
        mLeastNtMoney = msg.iLeastNtMoney--上庄最低额度
		--显示庄家的信息 -1表示没有庄家
		if (msg.iNtStation ~= -1) then
            ZhuangUser = GameLogic.finduserbyStation(msg.iNtStation)
			if (ZhuangUser == nil) then
				print("找不到庄家！！")
				return
			end
		else
			ZhuangUser = nil
		end
		--初始化桌上筹码
		this.InitDeskBetChips(msg)
		this.EnabledBtn( false )
		this.GameRecordCatLine(msg.cbCardTypeRecord,msg.cbGameCount,msg.cbCurGameCount)
		--开始计时
		local time = math.floor(msg.iShengYuTime/1000)
		if msg.iShengYuTime % 1000 > 500 then
			time = time + 1
		end
		time = time + math.floor(msg.iAccoutTime/1000)
		GameTimeClock.StartClock(nil,time,2)
	elseif state == 23 then print("下一局")
		local msg = DataParseLua.BytesToStruct(data.mainMsg, GameProtocal.CMD_GM_Station_Next)
		print("msg =",DataParseLua.GetLuaTableLength(GameProtocal.CMD_GM_Station_Next))
		stateTime[1] = msg.iBeginTime
		stateTime[2] = msg.iNoteTime
		stateTime[3] = msg.iOpenCardTime + msg.iAccoutTime
		for i = 1, msg.iChouMaNum do
			this.mChips[i] = msg.iChouMa[i-1]
		end
		for i = 1, 8 do
			this.mTotalBets[i] = msg.iTotalNote[i-1]
			this.mMyBets[i] = msg.iPlayerNote[i-1]
		end
		gameCount = msg.cbGameCount
    	ZhuangPlayCount = msg.iNtCountPlay
        iNtCountWin = msg.iNtWin
		LeastNtPlay = msg.iLeastNtPlay --庄家最少当庄局数
        iMaxGames = msg.iMaxGames
        cbChangeNt = msg.cbChangeNt == 1
        mLeastNtMoney = msg.iLeastNtMoney--上庄最低额度
		--显示庄家的信息 -1表示没有庄家
		if (msg.iNtStation ~= -1) then
            ZhuangUser = GameLogic.finduserbyStation(msg.iNtStation)
			if (ZhuangUser == nil) then
				print("找不到庄家！！")
				return
			end
		else
			ZhuangUser = nil
		end
		this.EnabledBtn( false )
		this.GameRecordCatLine(msg.cbCardTypeRecord,msg.cbGameCount,msg.cbCurGameCount)
		--开始计时
		local time = math.floor(msg.iShengYuTime/1000)
		if msg.iShengYuTime % 1000 > 500 then
			time = time + 1
		end
		GameTimeClock.StartClock(nil,time,2)
	elseif state == 5 then print("而外")
		this.EnabledBtn( false )
	end
	this.UpdateBetInfo(this.mChips)
	this.RefreshUserInfo()
    this.ShowZhuangInfo()
	-- GameGoldManager.SetAreaGold()
	this.coroutineParent = coroutine.start(this.ShowJoinGameAnima)
end

--初始化桌上的筹码
function GameUIManager.InitDeskBetChips(msg)
	--重置筹码深度
	ChoumaManager:InitChoumaDepth()
	--显示区域下注金额
	for i = 1, 5 do
		local areaSelfJetton=msg.iPlayerNote[i-1]
		local areaTotalJetton=msg.iTotalNote[i-1]			
		-- local areaLuckerNoteMoney=msg.iLuckerNoteMoney[i-1]
		local areaOtherJetton=areaTotalJetton-areaSelfJetton	

		local tablePlayerAreaJetton={}

		ChoumaManager:ShowAllAreaChoumaObj(i, areaSelfJetton, tablePlayerAreaJetton, areaOtherJetton)
	end	
end


function GameUIManager.OnDestroy()
	if(this.coroutineParent ~= nil) then
		coroutine.stop(this.coroutineParent)
		this.coroutineParent = nil
	end
	UpdateBeat:Remove(this.Update)
	GameLogic.OnDestroy()
	GameTimeClock.OnDestroy()
	-- GameGoldManager.OnDestroy()
	GameBankerResult.OnDestroy()
	package.loaded["224.GameUIManager"] = nil
	package.loaded["224.GameLogic"] = nil
	package.loaded["224.ChoumaManager"] = nil
	-- package.loaded["224.GameBank"] = nil
	-- package.loaded["224.GameBankerResult"] = nil
	package.loaded["224.GameDetail"] = nil
	package.loaded["224.GameHelp"] = nil
	package.loaded["224.GamePlayerInfo"] = nil
	package.loaded["224.GameRecord"] = nil
	package.loaded["224.GamePlaneRecord"] = nil
	package.loaded["224.GameJS"] = nil
	package.loaded["224.GameSet"] = nil
	package.loaded["224.GameTimeClock"] = nil
	-- package.loaded["224.GameUIBankerList"] = nil
	-- package.loaded["224.GameUIGoldAnima"] = nil
	-- package.loaded["224.GameGoldManager"] = nil
	-- package.loaded["224.GameUIJiangChi"] = nil
	-- package.loaded["224.GameUIPlayerList"] = nil
	package.loaded["224.GameUIRecord"] = nil
	package.loaded["224.GameUIRecordIterm"] = nil
	-- package.loaded["224.GameUIWinPool"] = nil
end
function GameUIManager.FormatNumToStringYW(score)
	local num = tonumber(score)
	local value = tostring(num)
	local rideValue = 1
	if ( num < 0 ) then
		num = num * -1
		rideValue = -1
	end
	if ( num >= 10000 ) then
		if ( num >= 100000000 ) then
			local v = math.floor(num / 1000000)/100
			value = tostring(v * rideValue).."亿"
		elseif num >= 10000 then
			local v = math.floor(num / 100)/100
			value = tostring(v * rideValue).."万"
		else
			local v = math.floor(num / 10)/100
			value = tostring(v * rideValue).."千"
		end
	end
	return value
end
function GameUIManager.FormatNumToYW(score)
	local num = tonumber(score)
	local value = tostring(num)
	local rideValue = 1
	if ( num < 0 ) then
		num = num * -1
		rideValue = -1
	end
	if ( num >= 10000 ) then
		if ( num >= 100000000 ) then
			local v = math.floor(num / 1000000)/100
			value = tostring(v * rideValue).."Y"
		else
			local v = math.floor(num / 100)/100
			value = tostring(v * rideValue).."W"
		end
	end
	return value
end
function GameUIManager.FormatNoteNumToYW(score)
	local num = tonumber(score)
	local value = tostring(num)
	local rideValue = 1
	if ( num < 0 ) then
		num = num * -1
		rideValue = -1
	end
	if ( num >= 1000 ) then
		if ( num >= 100000000 ) then
			local v = math.floor(num / 1000000)/100
			value = tostring(v * rideValue).."Y"
		elseif num >= 10000 then
			local v = math.floor(num / 100)/100
			value = tostring(v * rideValue).."W"
		else
			local v = math.floor(num / 10)/100
			value = tostring(v * rideValue).."Q"
		end
	end
	return value
end
function GameUIManager.GetRandomPostion(index)
	local v = this.BetCenterPos[index]
	if index == 1 or index == 3 then
		return this.GetRandomBoxPos(v,50,50)
	elseif index == 2 then
		return this.GetRandomBoxPos(v,70,40)
	elseif index == 4 or index == 5 then
		return this.GetRandomBoxPos(v,30,30)
	else
		return this.GetRandomBoxPos(v,20,30)
	end
end
function GameUIManager.GetRandomBoxPos(v,x1,y1)
	local vx = math.random(v.x - x1, v.x + x1)
	local vy = math.random(v.y - y1, v.y + y1)
	return Vector3.New(vx, vy, 0)
end
function GameUIManager.GetRandomDesktopPostion(v)
	local vx = math.random(v.x - 20, v.x + 20)
	local vy = math.random(v.y, v.y + 20)
	return Vector3.New(vx, vy, 0)
end